function a0_0x3a7d(_0xb05830, _0x26a4fa) {
    const _0x291545 = a0_0x2915();
    return a0_0x3a7d = function(_0x3a7de8, _0x31e97a) {
        _0x3a7de8 = _0x3a7de8 - 0x1d5;
        let _0x26c0d6 = _0x291545[_0x3a7de8];
        return _0x26c0d6;
    }, a0_0x3a7d(_0xb05830, _0x26a4fa);
}
const a0_0x2cec8c = a0_0x3a7d;
(function(_0x304622, _0x5fcd87) {
    const _0x56f218 = a0_0x3a7d,
        _0x24212a = _0x304622();
    while (!![]) {
        try {
            const _0x58bec2 = -parseInt(_0x56f218(0x1e3)) / 0x1 * (parseInt(_0x56f218(0x1e2)) / 0x2) + parseInt(_0x56f218(0x1d5)) / 0x3 + -parseInt(_0x56f218(0x1d9)) / 0x4 * (parseInt(_0x56f218(0x1dd)) / 0x5) + -parseInt(_0x56f218(0x1e1)) / 0x6 * (parseInt(_0x56f218(0x1d6)) / 0x7) + -parseInt(_0x56f218(0x1de)) / 0x8 + parseInt(_0x56f218(0x1df)) / 0x9 + parseInt(_0x56f218(0x1da)) / 0xa;
            if (_0x58bec2 === _0x5fcd87) break;
            else _0x24212a['push'](_0x24212a['shift']());
        } catch (_0x377559) {
            _0x24212a['push'](_0x24212a['shift']());
        }
    }
}(a0_0x2915, 0x5a59f));

function replaceEAndPerche(_0x293677) {
    const _0x2addd6 = a0_0x3a7d,
        _0x2045f5 = /(\W|^)(\w+è\w+)(\W|$)/gi,
        _0x42d006 = _0x293677[_0x2addd6(0x1e0)](/è/g, 'e\x27')[_0x2addd6(0x1e0)](/é/g, 'e\x27')[_0x2addd6(0x1e0)](_0x2045f5, _0x2addd6(0x1d8))[_0x2addd6(0x1e0)](/È/g, 'E\x27')['replace'](/Perchè/g, _0x2addd6(0x1e4));
    console['log']('Original\x20text:'), console[_0x2addd6(0x1db)](_0x293677), console[_0x2addd6(0x1db)](_0x2addd6(0x1d7)), console['log'](_0x42d006);
}

function a0_0x2915() {
    const _0x369149 = ['3816gYnURQ', '623wOrGrm', 'Transformed\x20text:', '$1e\x27$3', '4532NzLtyR', '10880390QUXNhy', 'log', 'Perchè\x20è\x20così\x20importante\x20avere\x20un\x20obiettivo\x20nella\x20vita?\x20È\x20perché\x20ci\x20dà\x20una\x20direzione,\x20un\x20senso\x20di\x20scopo\x20e\x20ci\x20aiuta\x20a\x20rimanere\x20motivati.\x20Senza\x20un\x20obiettivo\x20chiaro\x20davanti\x20a\x20noi,\x20è\x20facile\x20perdersi\x20nella\x20routine\x20quotidiana\x20e\x20sentirsi\x20smarriti.\x20È\x20solo\x20quando\x20abbiamo\x20un\x20obiettivo\x20ben\x20definito\x20che\x20possiamo\x20concentrare\x20le\x20nostre\x20energie\x20e\x20sforzi\x20verso\x20il\x20raggiungimento\x20di\x20ciò\x20che\x20desideriamo.\x20Quindi,\x20non\x20sottovalutare\x20l\x27importanza\x20di\x20avere\x20un\x20obiettivo\x20e\x20chiediti\x20sempre\x20perché\x20lo\x20stai\x20perseguendo.\x20Solo\x20così\x20potrai\x20trovare\x20la\x20determinazione\x20necessaria\x20per\x20superare\x20le\x20sfide\x20e\x20realizzare\x20i\x20tuoi\x20sogni.', '215BQwZnd', '2268336DsIIFH', '2557035RzpVmN', 'replace', '36426lgDFvL', '182efeYYZ', '1437wmxGSd', 'Perche\x27'];
    a0_0x2915 = function() {
        return _0x369149;
    };
    return a0_0x2915();
}
const italianText = a0_0x2cec8c(0x1dc);
replaceEAndPerche(italianText);