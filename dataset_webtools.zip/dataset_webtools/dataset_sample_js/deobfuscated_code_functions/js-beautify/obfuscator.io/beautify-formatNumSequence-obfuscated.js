function a0_0x5821(_0x2d84ee, _0x29f854) {
    const _0x471efc = a0_0x471e();
    return a0_0x5821 = function(_0x5821c2, _0x2937c0) {
        _0x5821c2 = _0x5821c2 - 0xf6;
        let _0x2fb945 = _0x471efc[_0x5821c2];
        return _0x2fb945;
    }, a0_0x5821(_0x2d84ee, _0x29f854);
}

function a0_0x471e() {
    const _0x258b15 = ['1393804CDLIKx', '163899YXqPSe', 'Formatted\x20sequence:\x20', 'log', 'Initial\x20sequence:\x20', '6392ePAzwX', '2,\x2057,\x2023,\x2089,\x2042,\x2014,\x2076,\x2031,\x2050,\x2068,\x2095,\x2011,\x2083,\x2037,\x2061,\x2029,\x2044,\x2072,\x2018,\x2080,\x2055,\x2097,\x2024,\x2070,\x2039,\x2086,\x2052,\x2060,\x2025,\x2066,\x2012,\x2078,\x2046,\x2092,\x2058,\x2033,\x2079,\x2045,\x2064,\x2020,\x2088,\x2048,\x2073,\x2035,\x2071,\x2026,\x2087,\x2054,\x2016,\x2074,\x2040,\x2065,\x2021,\x2096,\x2090,\x2049,\x2063,\x2030,\x2077,\x2043,\x2069,\x2015,\x2081,\x2059,\x2036,\x2067,\x2013,\x2084,\x2047,\x2091,\x2019,\x2075,\x2041,\x2062,\x2028,\x2051,\x2085,\x2038,\x2094,\x2010,\x2082,\x2056,\x2017,\x2093,\x2022,\x2098,\x2032,\x2053,\x2099,\x2034,\x207,\x2027,\x20102,\x2040,\x2068,\x2052,\x2044,\x2066,\x2087,\x2074,\x2031,\x2019,\x2055,\x2078', 'replace', '3153465zZzvJf', '1099ryGHsH', '$1.', '294212sYEwac', '6xVDwnR', '1645770FIsyJH', '521680nBEyvX'];
    a0_0x471e = function() {
        return _0x258b15;
    };
    return a0_0x471e();
}
const a0_0x3eef93 = a0_0x5821;
(function(_0x341bd8, _0x4c26f8) {
    const _0x355d48 = a0_0x5821,
        _0x2cc829 = _0x341bd8();
    while (!![]) {
        try {
            const _0x3101ca = parseInt(_0x355d48(0xfb)) / 0x1 + parseInt(_0x355d48(0xf6)) / 0x2 * (parseInt(_0x355d48(0xf7)) / 0x3) + -parseInt(_0x355d48(0xfa)) / 0x4 + parseInt(_0x355d48(0xf9)) / 0x5 + parseInt(_0x355d48(0xf8)) / 0x6 + -parseInt(_0x355d48(0x103)) / 0x7 * (-parseInt(_0x355d48(0xff)) / 0x8) + -parseInt(_0x355d48(0x102)) / 0x9;
            if (_0x3101ca === _0x4c26f8) break;
            else _0x2cc829['push'](_0x2cc829['shift']());
        } catch (_0x4cc6ba) {
            _0x2cc829['push'](_0x2cc829['shift']());
        }
    }
}(a0_0x471e, 0x404b5));

function formatNumSequence(_0x42e1b2) {
    const _0x5607d0 = a0_0x5821;
    return _0x42e1b2[_0x5607d0(0x101)](/, /g, '')[_0x5607d0(0x101)](/(\d{2})/g, _0x5607d0(0x104));
}
const initialSequence = a0_0x3eef93(0x100),
    formattedSequence = formatNumSequence(initialSequence);
console[a0_0x3eef93(0xfd)](a0_0x3eef93(0xfe), initialSequence), console[a0_0x3eef93(0xfd)](a0_0x3eef93(0xfc), formattedSequence);