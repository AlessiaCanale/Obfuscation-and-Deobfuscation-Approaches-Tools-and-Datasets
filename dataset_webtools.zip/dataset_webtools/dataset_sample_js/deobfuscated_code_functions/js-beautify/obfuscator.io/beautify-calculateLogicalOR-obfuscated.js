(function(_0x280c60, _0x9d35d9) {
    const _0x2c79c5 = a0_0x3532,
        _0x381725 = _0x280c60();
    while (!![]) {
        try {
            const _0x288c88 = parseInt(_0x2c79c5(0x16b)) / 0x1 + -parseInt(_0x2c79c5(0x172)) / 0x2 + parseInt(_0x2c79c5(0x16e)) / 0x3 * (parseInt(_0x2c79c5(0x16d)) / 0x4) + -parseInt(_0x2c79c5(0x170)) / 0x5 + parseInt(_0x2c79c5(0x173)) / 0x6 * (-parseInt(_0x2c79c5(0x16f)) / 0x7) + -parseInt(_0x2c79c5(0x169)) / 0x8 * (parseInt(_0x2c79c5(0x16a)) / 0x9) + parseInt(_0x2c79c5(0x16c)) / 0xa;
            if (_0x288c88 === _0x9d35d9) break;
            else _0x381725['push'](_0x381725['shift']());
        } catch (_0x361c05) {
            _0x381725['push'](_0x381725['shift']());
        }
    }
}(a0_0x1f3a, 0xc39aa));

function calculateLogicalOR(_0x27fd6b) {
    const _0x40bc67 = a0_0x3532;
    let _0x2a5e08 = _0x27fd6b[0x0];
    for (let _0x2973dd = 0x1; _0x2973dd < _0x27fd6b[_0x40bc67(0x174)]; _0x2973dd++) {
        _0x2a5e08 = _0x2a5e08 || _0x27fd6b[_0x2973dd], console[_0x40bc67(0x175)](_0x27fd6b[_0x2973dd - 0x1] + _0x40bc67(0x168) + _0x27fd6b[_0x2973dd] + _0x40bc67(0x171) + _0x2a5e08);
    }
}
let booleanArray = [!![], !![]];

function a0_0x3532(_0xc9144f, _0x473bbf) {
    const _0x1f3ad6 = a0_0x1f3a();
    return a0_0x3532 = function(_0x353243, _0x2c3baf) {
        _0x353243 = _0x353243 - 0x168;
        let _0x359246 = _0x1f3ad6[_0x353243];
        return _0x359246;
    }, a0_0x3532(_0xc9144f, _0x473bbf);
}

function a0_0x1f3a() {
    const _0x5228cc = ['log', '\x20||\x20', '5861256dlLPcf', '9nTwPvn', '1230197tSzLZO', '26033910jDqbZI', '1410040vYpoVl', '6tKbxvK', '619626BodDbY', '6329390cPbSTL', '\x20=\x20', '1707398djCMUD', '60aWhVPV', 'length'];
    a0_0x1f3a = function() {
        return _0x5228cc;
    };
    return a0_0x1f3a();
}
calculateLogicalOR(booleanArray);
let booleanArray1 = [!![], ![]];
calculateLogicalOR(booleanArray1);
let booleanArray2 = [![], ![]];
calculateLogicalOR(booleanArray2);
let booleanArray3 = [![], !![]];
calculateLogicalOR(booleanArray3);