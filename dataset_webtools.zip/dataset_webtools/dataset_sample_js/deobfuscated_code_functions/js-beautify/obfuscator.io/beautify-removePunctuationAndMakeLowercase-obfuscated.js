function a0_0x5ce3(_0x227493, _0x166f24) {
    const _0x30912d = a0_0x3091();
    return a0_0x5ce3 = function(_0x5ce3f5, _0x227596) {
        _0x5ce3f5 = _0x5ce3f5 - 0x155;
        let _0x152229 = _0x30912d[_0x5ce3f5];
        return _0x152229;
    }, a0_0x5ce3(_0x227493, _0x166f24);
}

function a0_0x3091() {
    const _0x5505cf = ['7482228CguICC', 'Original\x20text:\x20', '1432NJPodg', '13eTvLbB', '32CkXDiM', 'log', 'Modified\x20text:\x20', '50JrtWBm', '942067qrruxO', '291202SQgmKs', '14118IINzrF', '1685nlRLVU', '1816209hBaIRo', '7020651xvSrMf', '6387FwHMzx', '5VZJSzQ'];
    a0_0x3091 = function() {
        return _0x5505cf;
    };
    return a0_0x3091();
}(function(_0x10fc21, _0xb3731) {
    const _0x40be6f = a0_0x5ce3,
        _0x28693e = _0x10fc21();
    while (!![]) {
        try {
            const _0x201205 = -parseInt(_0x40be6f(0x15e)) / 0x1 * (parseInt(_0x40be6f(0x158)) / 0x2) + parseInt(_0x40be6f(0x15d)) / 0x3 * (-parseInt(_0x40be6f(0x161)) / 0x4) + -parseInt(_0x40be6f(0x15a)) / 0x5 * (parseInt(_0x40be6f(0x159)) / 0x6) + -parseInt(_0x40be6f(0x157)) / 0x7 * (-parseInt(_0x40be6f(0x163)) / 0x8) + -parseInt(_0x40be6f(0x15b)) / 0x9 * (-parseInt(_0x40be6f(0x156)) / 0xa) + parseInt(_0x40be6f(0x15c)) / 0xb + parseInt(_0x40be6f(0x15f)) / 0xc * (parseInt(_0x40be6f(0x162)) / 0xd);
            if (_0x201205 === _0xb3731) break;
            else _0x28693e['push'](_0x28693e['shift']());
        } catch (_0xd39032) {
            _0x28693e['push'](_0x28693e['shift']());
        }
    }
}(a0_0x3091, 0x80675));

function removePunctuationAndMakeLowercase(_0x2bb6a7) {
    const _0xd00406 = a0_0x5ce3,
        _0x3582f7 = /[!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~]/g,
        _0x33ac0e = _0x2bb6a7['replace'](_0x3582f7, '')['toLowerCase']();
    console['log'](_0xd00406(0x160) + _0x2bb6a7), console[_0xd00406(0x164)](_0xd00406(0x155) + _0x33ac0e);
}
removePunctuationAndMakeLowercase('WOW!\x20I\x20JUST\x20CAN\x27T\x20BELIEVE\x20IT...\x20I\x27m\x20so\x20EXCITED!!\x20Let\x27s\x20CELEBRATE\x20this\x20moment\x20together,\x20okay?\x20YAY!\x20Let\x27s\x20PARTY!!');