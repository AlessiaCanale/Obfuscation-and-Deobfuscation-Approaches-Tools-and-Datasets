var a0_0x17d753 = a0_0x5c46;

function a0_0x5c46(_0x1d030c, _0x23d425) {
    var _0x96427d = a0_0x9642();
    return a0_0x5c46 = function(_0x5c469f, _0x473a2c) {
        _0x5c469f = _0x5c469f - 0xf7;
        var _0x18288f = _0x96427d[_0x5c469f];
        return _0x18288f;
    }, a0_0x5c46(_0x1d030c, _0x23d425);
}(function(_0x27631f, _0x5490e8) {
    var _0x562946 = a0_0x5c46,
        _0x1805b1 = _0x27631f();
    while (!![]) {
        try {
            var _0xe022ea = parseInt(_0x562946(0x103)) / 0x1 * (parseInt(_0x562946(0x102)) / 0x2) + -parseInt(_0x562946(0xfd)) / 0x3 * (parseInt(_0x562946(0xf7)) / 0x4) + -parseInt(_0x562946(0xfe)) / 0x5 * (parseInt(_0x562946(0xff)) / 0x6) + -parseInt(_0x562946(0x101)) / 0x7 * (-parseInt(_0x562946(0x10b)) / 0x8) + parseInt(_0x562946(0x10c)) / 0x9 + -parseInt(_0x562946(0x100)) / 0xa + -parseInt(_0x562946(0x108)) / 0xb;
            if (_0xe022ea === _0x5490e8) break;
            else _0x1805b1['push'](_0x1805b1['shift']());
        } catch (_0x3c40a4) {
            _0x1805b1['push'](_0x1805b1['shift']());
        }
    }
}(a0_0x9642, 0xf18d3));

function a0_0x9642() {
    var _0x29d111 = ['log', 'Knight', 'Invalid\x20chess\x20piece.', '7508776PIZUSS', 'Bishop', 'King', '14909384kXgMGu', '10840383wOelCe', '96bVsLCI', '\x20can\x20move\x20diagonally\x20in\x20any\x20direction.', '\x20can\x20move\x20forward\x20one\x20square\x20or\x20two\x20squares\x20on\x20its\x20first\x20move.', 'Pawn', '\x20can\x20move\x20horizontally\x20or\x20vertically\x20in\x20any\x20direction.', '\x20can\x20move\x20one\x20square\x20in\x20any\x20direction.', '100461sTXMXj', '355eSmnqI', '136380Tstgau', '1130150XFzBSR', '7RmwWQd', '141798PcNRNn', '16OwuWJu', 'Queen'];
    a0_0x9642 = function() {
        return _0x29d111;
    };
    return a0_0x9642();
}

function chessMoves(_0x39e7ac) {
    var _0x11b19d = a0_0x5c46;
    switch (_0x39e7ac) {
        case _0x11b19d(0xfa):
            console[_0x11b19d(0x105)](_0x39e7ac + _0x11b19d(0xf9));
            break;
        case _0x11b19d(0x106):
            console[_0x11b19d(0x105)](_0x39e7ac + '\x20can\x20move\x20in\x20an\x20L-shape\x20-\x20two\x20squares\x20in\x20one\x20direction\x20and\x20one\x20square\x20perpendicular\x20to\x20that.');
            break;
        case _0x11b19d(0x109):
            console['log'](_0x39e7ac + _0x11b19d(0xf8));
            break;
        case 'Rook':
            console['log'](_0x39e7ac + _0x11b19d(0xfb));
            break;
        case _0x11b19d(0x104):
            console['log'](_0x39e7ac + '\x20can\x20move\x20horizontally,\x20vertically,\x20or\x20diagonally\x20in\x20any\x20direction.');
            break;
        case _0x11b19d(0x10a):
            console[_0x11b19d(0x105)](_0x39e7ac + _0x11b19d(0xfc));
            break;
        default:
            console['log'](_0x11b19d(0x107));
    }
}
chessMoves('Pawn'), chessMoves(a0_0x17d753(0x104));