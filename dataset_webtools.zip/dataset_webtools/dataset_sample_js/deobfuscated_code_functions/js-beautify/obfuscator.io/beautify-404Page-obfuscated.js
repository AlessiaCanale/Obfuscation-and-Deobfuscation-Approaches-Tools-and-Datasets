function a0_0x5a29() {
    var _0x4f885c = ['html,body', '862032fJdqxw', '6914376qUEYVY', 'length', 'click', '1307830ypGIOn', 'animate', 'Page\x20not\x20found', '[name=', '27462690LLXwhr', 'pathname', '.p2', 'hostname', 'fromTo', 'a[href*=#]:not([href=#])', 'offset', 'nothin\x27\x20here', '4ftOnQH', 'hash', '18mXNLoZ', '4757432NlgPDV', '.btn-react', '.hero-down', 'typed', 'top', '753209zlAfOu', 'try\x20again', 'replace', '836724oEBGSn'];
    a0_0x5a29 = function() {
        return _0x4f885c;
    };
    return a0_0x5a29();
}

function a0_0x33b1(_0x4c603e, _0x5925fa) {
    var _0x5a294a = a0_0x5a29();
    return a0_0x33b1 = function(_0x33b192, _0xc7f258) {
        _0x33b192 = _0x33b192 - 0xbb;
        var _0x62b3ef = _0x5a294a[_0x33b192];
        return _0x62b3ef;
    }, a0_0x33b1(_0x4c603e, _0x5925fa);
}
var a0_0x53606d = a0_0x33b1;
(function(_0x53cbf7, _0x48388e) {
    var _0x4557d2 = a0_0x33b1,
        _0x348b0f = _0x53cbf7();
    while (!![]) {
        try {
            var _0x319c9d = -parseInt(_0x4557d2(0xcb)) / 0x1 + parseInt(_0x4557d2(0xc3)) / 0x2 * (-parseInt(_0x4557d2(0xd0)) / 0x3) + -parseInt(_0x4557d2(0xce)) / 0x4 + parseInt(_0x4557d2(0xd4)) / 0x5 * (parseInt(_0x4557d2(0xc5)) / 0x6) + -parseInt(_0x4557d2(0xd1)) / 0x7 + -parseInt(_0x4557d2(0xc6)) / 0x8 + parseInt(_0x4557d2(0xbb)) / 0x9;
            if (_0x319c9d === _0x48388e) break;
            else _0x348b0f['push'](_0x348b0f['shift']());
        } catch (_0x2a614f) {
            _0x348b0f['push'](_0x348b0f['shift']());
        }
    }
}(a0_0x5a29, 0xaef27), $(function() {
    var _0x295fd1 = a0_0x33b1;
    $(_0x295fd1(0xbd))[_0x295fd1(0xc9)]({
        'strings': [_0x295fd1(0xd6), _0x295fd1(0xcc), _0x295fd1(0xc2)],
        'typeSpeed': 0x32,
        'backSpeed': 0xa,
        'backDelay': 0x7d0,
        'showCursor': !![],
        'loop': !![]
    });
}), $(a0_0x53606d(0xc8))['mousedown'](function() {
    var _0x22814e = a0_0x53606d;
    TweenMax[_0x22814e(0xbf)](_0x22814e(0xc7), 0.25, {
        'opacity': 0x0,
        'scale': 0x0
    }, {
        'opacity': 0.25,
        'scale': 0x1,
        'onComplete': function() {
            var _0x147bfd = _0x22814e;
            TweenMax['to'](_0x147bfd(0xc7), 0.25, {
                'opacity': 0x0,
                'scale': 0x0
            });
        }
    });
}), $(a0_0x53606d(0xc0))[a0_0x53606d(0xd3)](function() {
    var _0x38d68c = a0_0x53606d;
    if (location[_0x38d68c(0xbc)][_0x38d68c(0xcd)](/^\//, '') == this['pathname'][_0x38d68c(0xcd)](/^\//, '') && location['hostname'] == this[_0x38d68c(0xbe)]) {
        var _0x395a9a = $(this[_0x38d68c(0xc4)]);
        _0x395a9a = _0x395a9a[_0x38d68c(0xd2)] ? _0x395a9a : $(_0x38d68c(0xd7) + this[_0x38d68c(0xc4)]['slice'](0x1) + ']');
        if (_0x395a9a[_0x38d68c(0xd2)]) return $(_0x38d68c(0xcf))[_0x38d68c(0xd5)]({
            'scrollTop': _0x395a9a[_0x38d68c(0xc1)]()[_0x38d68c(0xca)]
        }, 0x3e8), ![];
    }
}));