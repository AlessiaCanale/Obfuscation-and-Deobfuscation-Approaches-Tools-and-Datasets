const a0_0x102c7b = a0_0x1ed7;

function a0_0x203e() {
    const _0x2d1c5b = ['1152784yitSAc', '867807NILZEg', 'map', '5yOOhpX', '1934712edMTzV', 'full\x20name\x20is:\x20', '5102094wGnhmW', 'jay', 'kumar', 'join', '2EhUHkI', '4418568MbJycs', 'lastname', '851844TtihcE', 'rupal', 'sharma', '9130576hRpPlZ', 'firstname'];
    a0_0x203e = function() {
        return _0x2d1c5b;
    };
    return a0_0x203e();
}(function(_0x37d2d5, _0x2f7cf3) {
    const _0x18ff67 = a0_0x1ed7,
        _0x2a1828 = _0x37d2d5();
    while (!![]) {
        try {
            const _0x2443d2 = parseInt(_0x18ff67(0x155)) / 0x1 + -parseInt(_0x18ff67(0x164)) / 0x2 * (parseInt(_0x18ff67(0x15b)) / 0x3) + parseInt(_0x18ff67(0x15e)) / 0x4 + parseInt(_0x18ff67(0x15d)) / 0x5 * (parseInt(_0x18ff67(0x160)) / 0x6) + -parseInt(_0x18ff67(0x158)) / 0x7 + -parseInt(_0x18ff67(0x15a)) / 0x8 + parseInt(_0x18ff67(0x165)) / 0x9;
            if (_0x2443d2 === _0x2f7cf3) break;
            else _0x2a1828['push'](_0x2a1828['shift']());
        } catch (_0x35cca9) {
            _0x2a1828['push'](_0x2a1828['shift']());
        }
    }
}(a0_0x203e, 0xe5450));

function a0_0x1ed7(_0x3bd80c, _0x4098df) {
    const _0x203e80 = a0_0x203e();
    return a0_0x1ed7 = function(_0x1ed79a, _0x4d2c26) {
        _0x1ed79a = _0x1ed79a - 0x154;
        let _0x15b588 = _0x203e80[_0x1ed79a];
        return _0x15b588;
    }, a0_0x1ed7(_0x3bd80c, _0x4098df);
}
const users = [{
    'firstname': 'Abhishek',
    'lastname': a0_0x102c7b(0x162)
}, {
    'firstname': a0_0x102c7b(0x161),
    'lastname': 'sharma'
}, {
    'firstname': a0_0x102c7b(0x156),
    'lastname': a0_0x102c7b(0x157)
}];
users['map'](getFullName), console['log'](a0_0x102c7b(0x15f) + users[a0_0x102c7b(0x15c)](getFullName));

function getFullName(_0x5ca5f0) {
    const _0x209865 = a0_0x102c7b;
    return [_0x5ca5f0[_0x209865(0x159)], _0x5ca5f0[_0x209865(0x154)]][_0x209865(0x163)](',\x20');
}