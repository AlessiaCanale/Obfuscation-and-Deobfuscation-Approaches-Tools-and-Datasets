var a0_0x23765a = a0_0x4377;
(function(_0x185ca3, _0x4463c3) {
    var _0x44293a = a0_0x4377,
        _0x562247 = _0x185ca3();
    while (!![]) {
        try {
            var _0x27e146 = parseInt(_0x44293a(0x118)) / 0x1 + parseInt(_0x44293a(0x114)) / 0x2 * (parseInt(_0x44293a(0x11b)) / 0x3) + -parseInt(_0x44293a(0x11a)) / 0x4 * (parseInt(_0x44293a(0x119)) / 0x5) + -parseInt(_0x44293a(0x115)) / 0x6 + parseInt(_0x44293a(0x113)) / 0x7 * (parseInt(_0x44293a(0x112)) / 0x8) + parseInt(_0x44293a(0x116)) / 0x9 + -parseInt(_0x44293a(0x11e)) / 0xa;
            if (_0x27e146 === _0x4463c3) break;
            else _0x562247['push'](_0x562247['shift']());
        } catch (_0x2b4e5f) {
            _0x562247['push'](_0x562247['shift']());
        }
    }
}(a0_0x53e8, 0x30322));

function a0_0x4377(_0x5cbb10, _0x3c789a) {
    var _0x53e861 = a0_0x53e8();
    return a0_0x4377 = function(_0x4377e3, _0xa66f54) {
        _0x4377e3 = _0x4377e3 - 0x111;
        var _0x428ecc = _0x53e861[_0x4377e3];
        return _0x428ecc;
    }, a0_0x4377(_0x5cbb10, _0x3c789a);
}
var svgContainer = document[a0_0x23765a(0x11c)](a0_0x23765a(0x11d)),
    animItem = bodymovin[a0_0x23765a(0x111)]({
        'wrapper': svgContainer,
        'animType': a0_0x23765a(0x117),
        'loop': !![],
        'path': 'https://labs.nearpod.com/bodymovin/demo/markus/isometric/markus2.json'
    });

function a0_0x53e8() {
    var _0x1a9a77 = ['8vncGUw', '2257976jWnkJi', '330550UhdSwk', '1284666wIaRdt', '1533609ThSULX', 'svg', '28083QrwTxA', '27615pZRKMz', '184GznLIn', '3qrChmJ', 'getElementById', 'svgContainer', '207480TYsOdG', 'loadAnimation'];
    a0_0x53e8 = function() {
        return _0x1a9a77;
    };
    return a0_0x53e8();
}