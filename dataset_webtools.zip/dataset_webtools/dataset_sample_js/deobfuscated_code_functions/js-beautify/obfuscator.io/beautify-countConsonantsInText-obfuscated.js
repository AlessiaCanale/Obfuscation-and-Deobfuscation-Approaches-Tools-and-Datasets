(function(_0x50c4f9, _0x1160fe) {
    const _0x1219fa = a0_0x1f65,
        _0x2c3df6 = _0x50c4f9();
    while (!![]) {
        try {
            const _0x2848a2 = -parseInt(_0x1219fa(0x182)) / 0x1 * (parseInt(_0x1219fa(0x188)) / 0x2) + -parseInt(_0x1219fa(0x17e)) / 0x3 + parseInt(_0x1219fa(0x17c)) / 0x4 * (parseInt(_0x1219fa(0x17f)) / 0x5) + -parseInt(_0x1219fa(0x184)) / 0x6 + -parseInt(_0x1219fa(0x186)) / 0x7 + parseInt(_0x1219fa(0x187)) / 0x8 + -parseInt(_0x1219fa(0x183)) / 0x9 * (-parseInt(_0x1219fa(0x180)) / 0xa);
            if (_0x2848a2 === _0x1160fe) break;
            else _0x2c3df6['push'](_0x2c3df6['shift']());
        } catch (_0x36e889) {
            _0x2c3df6['push'](_0x2c3df6['shift']());
        }
    }
}(a0_0x3eef, 0x7bf60));

function a0_0x3eef() {
    const _0x731ca2 = ['63juxRLo', '3202770EyJnJQ', 'Number\x20of\x20consonants\x20in\x20the\x20text:\x20', '6607314dDEvje', '266328eOrLXJ', '4jDXaOm', 'log', '4PWFPPQ', 'toLowerCase', '629202EFAPHP', '4868715DzdYMF', '2405490dtsWUh', 'Original\x20text:', '247851PEbGTq'];
    a0_0x3eef = function() {
        return _0x731ca2;
    };
    return a0_0x3eef();
}

function countConsonantsInText(_0x3add61) {
    const _0x52f97e = a0_0x1f65,
        _0x55e862 = 'bcdfghjklmnpqrstvwxyz';
    _0x3add61 = _0x3add61[_0x52f97e(0x17d)]();
    let _0x5a1341 = 0x0;
    for (let _0x2e838f of _0x3add61) {
        _0x55e862['includes'](_0x2e838f) && _0x5a1341++;
    }
    console[_0x52f97e(0x17b)](_0x52f97e(0x181)), console[_0x52f97e(0x17b)](_0x3add61), console[_0x52f97e(0x17b)](_0x52f97e(0x185) + _0x5a1341);
}

function a0_0x1f65(_0x478ade, _0x3927b8) {
    const _0x3eef52 = a0_0x3eef();
    return a0_0x1f65 = function(_0x1f6532, _0x142fa8) {
        _0x1f6532 = _0x1f6532 - 0x17b;
        let _0xbb1dda = _0x3eef52[_0x1f6532];
        return _0xbb1dda;
    }, a0_0x1f65(_0x478ade, _0x3927b8);
}
var inputText = 'This\x20is\x20a\x20sample\x20text\x20containing\x20consonants\x20and\x20vowels.';
countConsonantsInText(inputText);