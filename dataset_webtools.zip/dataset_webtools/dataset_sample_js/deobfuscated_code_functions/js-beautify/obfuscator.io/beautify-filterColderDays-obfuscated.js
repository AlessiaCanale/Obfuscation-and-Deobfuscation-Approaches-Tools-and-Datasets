const a0_0x22e3d3 = a0_0x5338;
(function(_0x23c3be, _0xd12c6b) {
    const _0x341fb2 = a0_0x5338,
        _0x9fc925 = _0x23c3be();
    while (!![]) {
        try {
            const _0xf98166 = parseInt(_0x341fb2(0x13b)) / 0x1 + -parseInt(_0x341fb2(0x13d)) / 0x2 + parseInt(_0x341fb2(0x139)) / 0x3 * (parseInt(_0x341fb2(0x13c)) / 0x4) + parseInt(_0x341fb2(0x135)) / 0x5 * (parseInt(_0x341fb2(0x137)) / 0x6) + -parseInt(_0x341fb2(0x138)) / 0x7 * (-parseInt(_0x341fb2(0x140)) / 0x8) + -parseInt(_0x341fb2(0x136)) / 0x9 + parseInt(_0x341fb2(0x141)) / 0xa;
            if (_0xf98166 === _0xd12c6b) break;
            else _0x9fc925['push'](_0x9fc925['shift']());
        } catch (_0x1fe9aa) {
            _0x9fc925['push'](_0x9fc925['shift']());
        }
    }
}(a0_0xe2b7, 0xe5d1e));
const weeklyReadings = [0x14, 0x16, 20.5, 0x13, 21.5, 0x17],
    colderDays = weeklyReadings['filter'](_0x558106 => {
        return _0x558106 < 0x14;
    });
console[a0_0x22e3d3(0x13f)](a0_0x22e3d3(0x13a) + weeklyReadings + '\x0a'), console['log'](colderDays);

function a0_0x5338(_0x2b6be3, _0x5125a3) {
    const _0xe2b7a1 = a0_0xe2b7();
    return a0_0x5338 = function(_0x53387e, _0x230ed4) {
        _0x53387e = _0x53387e - 0x135;
        let _0xb6a7ee = _0xe2b7a1[_0x53387e];
        return _0xb6a7ee;
    }, a0_0x5338(_0x2b6be3, _0x5125a3);
}

function a0_0xe2b7() {
    const _0x1c1039 = ['864QzLXYv', '95620reXgrq', '303iUJcgm', 'weekly\x20readings:\x20', '32523DeqvXo', '29036VoWnBS', '2066178bCamGs', 'No,\x20there\x20were\x20no\x20colder\x20days\x20(no\x20days\x20<\x2020)', 'log', '728gDiREo', '13637000fPYmrK', '1510sJRPuu', '12973491YdOPAa'];
    a0_0xe2b7 = function() {
        return _0x1c1039;
    };
    return a0_0xe2b7();
}
colderDays != 0x0 ? console[a0_0x22e3d3(0x13f)]('Yes,\x20there\x20were\x20colder\x20days\x20(<\x2020)\x20last\x20week') : console[a0_0x22e3d3(0x13f)](a0_0x22e3d3(0x13e));