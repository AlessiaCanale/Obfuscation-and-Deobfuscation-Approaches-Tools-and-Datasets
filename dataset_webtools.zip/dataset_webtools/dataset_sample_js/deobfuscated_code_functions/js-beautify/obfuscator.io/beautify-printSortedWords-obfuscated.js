function a0_0x53ff(_0x41481a, _0x518479) {
    const _0x2b49a9 = a0_0x2b49();
    return a0_0x53ff = function(_0x53fff1, _0xcb2ab8) {
        _0x53fff1 = _0x53fff1 - 0x122;
        let _0xa32668 = _0x2b49a9[_0x53fff1];
        return _0xa32668;
    }, a0_0x53ff(_0x41481a, _0x518479);
}
const a0_0x431cb6 = a0_0x53ff;

function a0_0x2b49() {
    const _0x138bf6 = ['124186FtDHYA', 'apple', '77fTSUgb', 'grape', '16105302TiVUHO', 'length', '5HspkzV', '1463100agObsT', '700296QlBKBH', '\x0aSorted\x20list:', '6757794yimgCj', 'sort', '2884470uOtdey', '4sxAELE', 'banana', '19212770RBhGiL'];
    a0_0x2b49 = function() {
        return _0x138bf6;
    };
    return a0_0x2b49();
}(function(_0x5f2ed, _0x106434) {
    const _0x12fad6 = a0_0x53ff,
        _0xe975f8 = _0x5f2ed();
    while (!![]) {
        try {
            const _0x56790e = -parseInt(_0x12fad6(0x12e)) / 0x1 * (-parseInt(_0x12fad6(0x128)) / 0x2) + parseInt(_0x12fad6(0x124)) / 0x3 * (parseInt(_0x12fad6(0x125)) / 0x4) + -parseInt(_0x12fad6(0x12f)) / 0x5 + -parseInt(_0x12fad6(0x122)) / 0x6 + -parseInt(_0x12fad6(0x12a)) / 0x7 * (-parseInt(_0x12fad6(0x130)) / 0x8) + -parseInt(_0x12fad6(0x12c)) / 0x9 + parseInt(_0x12fad6(0x127)) / 0xa;
            if (_0x56790e === _0x106434) break;
            else _0xe975f8['push'](_0xe975f8['shift']());
        } catch (_0x31e115) {
            _0xe975f8['push'](_0xe975f8['shift']());
        }
    }
}(a0_0x2b49, 0xe761e));

function printSortedWords(_0x369f78) {
    const _0x5b8e8b = a0_0x53ff;
    _0x369f78[_0x5b8e8b(0x123)]();
    for (let _0x412157 = 0x0; _0x412157 < _0x369f78[_0x5b8e8b(0x12d)]; _0x412157++) {
        console['log']('-\x20' + _0x369f78[_0x412157]);
    }
}
const words = [a0_0x431cb6(0x126), a0_0x431cb6(0x129), a0_0x431cb6(0x12b), 'cherry'];
console['log']('Original\x20array:'), console['log'](words), console['log'](a0_0x431cb6(0x131)), printSortedWords(words);