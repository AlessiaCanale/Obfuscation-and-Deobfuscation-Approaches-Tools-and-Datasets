const a0_0x456e48 = a0_0x261f;

function a0_0x21b9() {
    const _0x3cb601 = ['Anti-Diagonal\x20elements:\x20', '1784582aQOdBW', '3109566jHXRJc', '988071gPMVpf', 'Main\x20Diagonal\x20elements:\x20', 'Main\x20Diagonal\x20concatenation:\x20', '25757240lGRHHG', 'log', '1312682FTCGXH', '20OWKWpT', 'length', '459230btsuxd', '2870721hbENfX', 'Anti-Diagonal\x20concatenation:\x20'];
    a0_0x21b9 = function() {
        return _0x3cb601;
    };
    return a0_0x21b9();
}(function(_0x66a5e3, _0x425c2d) {
    const _0x246b82 = a0_0x261f,
        _0x835a4a = _0x66a5e3();
    while (!![]) {
        try {
            const _0x413750 = parseInt(_0x246b82(0x1c9)) / 0x1 + parseInt(_0x246b82(0x1d0)) / 0x2 + parseInt(_0x246b82(0x1c4)) / 0x3 + -parseInt(_0x246b82(0x1ca)) / 0x4 * (-parseInt(_0x246b82(0x1cc)) / 0x5) + parseInt(_0x246b82(0x1d1)) / 0x6 + parseInt(_0x246b82(0x1cd)) / 0x7 + -parseInt(_0x246b82(0x1c7)) / 0x8;
            if (_0x413750 === _0x425c2d) break;
            else _0x835a4a['push'](_0x835a4a['shift']());
        } catch (_0x1887ec) {
            _0x835a4a['push'](_0x835a4a['shift']());
        }
    }
}(a0_0x21b9, 0xab73d));

function concatenateMainAndAntiDiagonals(_0x516c85) {
    const _0x3854b1 = a0_0x261f;
    let _0x273aeb = '',
        _0x901730 = '';
    for (let _0x7aafab = 0x0; _0x7aafab < _0x516c85[_0x3854b1(0x1cb)]; _0x7aafab++) {
        _0x273aeb += _0x516c85[_0x7aafab][_0x7aafab], _0x901730 += _0x516c85[_0x7aafab][_0x516c85[_0x3854b1(0x1cb)] - 0x1 - _0x7aafab];
    }
    return console['log'](_0x3854b1(0x1c5) + _0x273aeb), console[_0x3854b1(0x1c8)](_0x3854b1(0x1cf) + _0x901730), [_0x273aeb, _0x901730];
}
const matrix = [
    ['a', 'b', 'c'],
    ['d', 'e', 'f'],
    ['g', 'h', 'i']
];

function a0_0x261f(_0x28006e, _0x52b9ea) {
    const _0x21b9d9 = a0_0x21b9();
    return a0_0x261f = function(_0x261f52, _0x37a5a1) {
        _0x261f52 = _0x261f52 - 0x1c4;
        let _0xcb0ba3 = _0x21b9d9[_0x261f52];
        return _0xcb0ba3;
    }, a0_0x261f(_0x28006e, _0x52b9ea);
}
console[a0_0x456e48(0x1c8)](matrix);
const [mainDiagonal, antiDiagonal] = concatenateMainAndAntiDiagonals(matrix);
console[a0_0x456e48(0x1c8)](a0_0x456e48(0x1c6) + mainDiagonal), console[a0_0x456e48(0x1c8)](a0_0x456e48(0x1ce) + antiDiagonal);