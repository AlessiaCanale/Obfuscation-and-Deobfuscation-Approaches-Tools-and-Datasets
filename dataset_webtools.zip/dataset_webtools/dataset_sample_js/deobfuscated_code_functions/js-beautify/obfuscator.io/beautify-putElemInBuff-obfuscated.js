const a0_0x179db0 = a0_0x5840;
(function(_0x1002d7, _0x38a335) {
    const _0x5be260 = a0_0x5840,
        _0x31bfc1 = _0x1002d7();
    while (!![]) {
        try {
            const _0x3fdbe5 = -parseInt(_0x5be260(0x123)) / 0x1 * (-parseInt(_0x5be260(0x11c)) / 0x2) + -parseInt(_0x5be260(0x128)) / 0x3 * (-parseInt(_0x5be260(0x11f)) / 0x4) + -parseInt(_0x5be260(0x127)) / 0x5 + -parseInt(_0x5be260(0x122)) / 0x6 * (-parseInt(_0x5be260(0x11e)) / 0x7) + -parseInt(_0x5be260(0x129)) / 0x8 + parseInt(_0x5be260(0x118)) / 0x9 + parseInt(_0x5be260(0x125)) / 0xa;
            if (_0x3fdbe5 === _0x38a335) break;
            else _0x31bfc1['push'](_0x31bfc1['shift']());
        } catch (_0x5f1147) {
            _0x31bfc1['push'](_0x31bfc1['shift']());
        }
    }
}(a0_0x583f, 0x59925));

function a0_0x583f() {
    const _0x39647e = ['Buffer\x20couldn\x27t\x20accommodate\x20the\x20following\x20numbers:\x20', '6210410KhnpwS', 'Initial\x20array\x20of\x20numbers:\x20', '1833415ncdMGq', '678fJAYDg', '5711024rSwFxt', '277956gxNdTP', 'slice', 'Subtracted\x20', 'length', '668BdVkyV', 'Initial\x20buffer\x20capacity:\x20', '4263231gwnQcy', '3212FKBLjP', 'Numbers\x20that\x20couldn\x27t\x20be\x20subtracted:\x20', 'log', '6nKBAlA', '15GMvrsX'];
    a0_0x583f = function() {
        return _0x39647e;
    };
    return a0_0x583f();
}

function a0_0x5840(_0x2a80dd, _0x5917c5) {
    const _0x583f81 = a0_0x583f();
    return a0_0x5840 = function(_0x5840c7, _0x361b7e) {
        _0x5840c7 = _0x5840c7 - 0x118;
        let _0x29f9e6 = _0x583f81[_0x5840c7];
        return _0x29f9e6;
    }, a0_0x5840(_0x2a80dd, _0x5917c5);
}

function putElemInBuff(_0x2f4f96, _0x3156aa) {
    const _0x5c3ffc = a0_0x5840;
    console[_0x5c3ffc(0x121)](_0x5c3ffc(0x126) + _0x2f4f96), console[_0x5c3ffc(0x121)](_0x5c3ffc(0x11d) + _0x3156aa);
    let _0x1612a3 = [],
        _0x23572b = _0x3156aa;
    for (let _0x10071f = 0x0; _0x10071f < _0x2f4f96[_0x5c3ffc(0x11b)]; _0x10071f++) {
        if (_0x23572b - _0x2f4f96[_0x10071f] >= 0x0) _0x23572b -= _0x2f4f96[_0x10071f], console[_0x5c3ffc(0x121)](_0x5c3ffc(0x11a) + _0x2f4f96[_0x10071f] + ',\x20remaining\x20buffer\x20capacity:\x20' + _0x23572b);
        else {
            _0x1612a3 = _0x2f4f96[_0x5c3ffc(0x119)](_0x10071f);
            break;
        }
    }
    return _0x1612a3['length'] > 0x0 ? console[_0x5c3ffc(0x121)](_0x5c3ffc(0x124) + _0x1612a3) : console[_0x5c3ffc(0x121)]('All\x20numbers\x20were\x20successfully\x20subtracted\x20from\x20the\x20buffer.'), _0x1612a3;
}
const numbers = [0x3, 0x5, 0x7, 0x2, 0x6],
    bufferCapacity = 0xf,
    remaining = putElemInBuff(numbers, bufferCapacity);
console[a0_0x179db0(0x121)](a0_0x179db0(0x120) + remaining);