(function(_0x4f2813, _0x1fd5fc) {
    const _0x2cf357 = a0_0x2f08,
        _0x43013a = _0x4f2813();
    while (!![]) {
        try {
            const _0x92adf9 = -parseInt(_0x2cf357(0x145)) / 0x1 + parseInt(_0x2cf357(0x147)) / 0x2 * (-parseInt(_0x2cf357(0x143)) / 0x3) + parseInt(_0x2cf357(0x14a)) / 0x4 + -parseInt(_0x2cf357(0x14b)) / 0x5 + -parseInt(_0x2cf357(0x148)) / 0x6 + parseInt(_0x2cf357(0x144)) / 0x7 + -parseInt(_0x2cf357(0x146)) / 0x8 * (-parseInt(_0x2cf357(0x149)) / 0x9);
            if (_0x92adf9 === _0x1fd5fc) break;
            else _0x43013a['push'](_0x43013a['shift']());
        } catch (_0x1d2edb) {
            _0x43013a['push'](_0x43013a['shift']());
        }
    }
}(a0_0x22c3, 0x9afad));

function a0_0x2f08(_0x5a4d52, _0x140796) {
    const _0x22c33a = a0_0x22c3();
    return a0_0x2f08 = function(_0x2f088c, _0x3df6e7) {
        _0x2f088c = _0x2f088c - 0x143;
        let _0x528548 = _0x22c33a[_0x2f088c];
        return _0x528548;
    }, a0_0x2f08(_0x5a4d52, _0x140796);
}

function changeSingleQuotesToDoubleQuotes(_0x485d96) {
    const _0x5929b2 = a0_0x2f08;
    let _0x2ff3e6 = _0x485d96['replace'](/'/g, '\x22');
    console[_0x5929b2(0x14c)]('Original\x20text:\x20\x27' + _0x485d96 + '\x27'), console[_0x5929b2(0x14c)]('Modified\x20text:\x20\x27' + _0x2ff3e6 + '\x27');
}
changeSingleQuotesToDoubleQuotes('This\x20is\x20a\x20\x27sample\x27\x20text.'), changeSingleQuotesToDoubleQuotes('\x27Single\x20quotes\x27\x20everywhere!');

function a0_0x22c3() {
    const _0x4b117e = ['2506419jmneqS', '1220128lCdGsv', '3995380cFRvwu', 'log', '3DqgTVd', '3322935jIHcmW', '1104167eCsGrc', '72QQRCmT', '250282RfCNZE', '3737850egUgnJ'];
    a0_0x22c3 = function() {
        return _0x4b117e;
    };
    return a0_0x22c3();
}