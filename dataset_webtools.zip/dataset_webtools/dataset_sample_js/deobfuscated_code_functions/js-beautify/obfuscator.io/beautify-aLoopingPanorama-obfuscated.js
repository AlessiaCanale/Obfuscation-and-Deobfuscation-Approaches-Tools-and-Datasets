const a0_0x3bfaf9 = a0_0x12a6;
(function(_0x573c63, _0x5a196f) {
    const _0x28ed65 = a0_0x12a6,
        _0xc74454 = _0x573c63();
    while (!![]) {
        try {
            const _0xeaa71 = parseInt(_0x28ed65(0x159)) / 0x1 + parseInt(_0x28ed65(0x156)) / 0x2 + -parseInt(_0x28ed65(0x167)) / 0x3 + -parseInt(_0x28ed65(0x161)) / 0x4 * (parseInt(_0x28ed65(0x164)) / 0x5) + -parseInt(_0x28ed65(0x15a)) / 0x6 * (-parseInt(_0x28ed65(0x162)) / 0x7) + -parseInt(_0x28ed65(0x158)) / 0x8 * (-parseInt(_0x28ed65(0x165)) / 0x9) + -parseInt(_0x28ed65(0x15f)) / 0xa * (parseInt(_0x28ed65(0x15d)) / 0xb);
            if (_0xeaa71 === _0x5a196f) break;
            else _0xc74454['push'](_0xc74454['shift']());
        } catch (_0x4fbaae) {
            _0xc74454['push'](_0xc74454['shift']());
        }
    }
}(a0_0x380e, 0x2d511));

function a0_0x12a6(_0x1284bb, _0x4e4ebb) {
    const _0x380ec9 = a0_0x380e();
    return a0_0x12a6 = function(_0x12a61d, _0x262071) {
        _0x12a61d = _0x12a61d - 0x155;
        let _0xae60f3 = _0x380ec9[_0x12a61d];
        return _0xae60f3;
    }, a0_0x12a6(_0x1284bb, _0x4e4ebb);
}
const img = new Image();
img['src'] = a0_0x3bfaf9(0x166);
const canvasXSize = 0x320,
    canvasYSize = 0xc8,
    speed = 0x1e,
    scale = 1.05,
    y = -4.5,
    dx = 0.75;
let imgW, imgH, x = 0x0,
    clearX, clearY, ctx;
img[a0_0x3bfaf9(0x15b)] = () => {
    const _0x13e891 = a0_0x3bfaf9;
    return imgW = img['width'] * scale, imgH = img[_0x13e891(0x155)] * scale, imgW > canvasXSize && (x = canvasXSize - imgW), clearX = Math[_0x13e891(0x15c)](imgW, canvasXSize), clearY = Math[_0x13e891(0x15c)](imgH, canvasYSize), ctx = document[_0x13e891(0x160)](_0x13e891(0x15e))[_0x13e891(0x163)]('2d'), setInterval(draw, speed);
};

function a0_0x380e() {
    const _0x4a3ece = ['32ygkYop', '84652wlTmzg', '1065192kHWzFc', 'onload', 'max', '3586kzQZxP', 'canvas', '1390rnKEmV', 'getElementById', '356260tdCfpe', '7cUWszi', 'getContext', '5qIhNbT', '627147XSsrnn', 'capitan_meadows_yosemite_national_park.jpg', '786762gqSXUJ', 'height', '82668LZPwiw', 'drawImage'];
    a0_0x380e = function() {
        return _0x4a3ece;
    };
    return a0_0x380e();
}

function draw() {
    const _0x520eaa = a0_0x3bfaf9;
    ctx['clearRect'](0x0, 0x0, clearX, clearY), imgW <= canvasXSize ? (x > canvasXSize && (x = -imgW + x), x > 0x0 && ctx[_0x520eaa(0x157)](img, -imgW + x, y, imgW, imgH), x - imgW > 0x0 && ctx['drawImage'](img, -imgW * 0x2 + x, y, imgW, imgH)) : (x > canvasXSize && (x = canvasXSize - imgW), x > canvasXSize - imgW && ctx[_0x520eaa(0x157)](img, x - imgW + 0x1, y, imgW, imgH)), ctx[_0x520eaa(0x157)](img, x, y, imgW, imgH), x += dx;
}