function a0_0x4381() {
    const _0x3e47d4 = ['2CllOCq', '10197096nNpirE', '3709719BxPUvf', '180adGhsj', 'log', 'Now\x20I\x20will\x20flip\x20the\x20coin\x20and\x20tell\x20you\x20if\x20it\x27s\x20Heads\x20or\x20Tails', 'random', '6341562crbMSA', '234tsZrvi', '1013903kOUmYg', '156443bWDPgC', 'Tails', '4295wujems', '948xAxkQo', 'It\x27s\x20', '552967miiOCW'];
    a0_0x4381 = function() {
        return _0x3e47d4;
    };
    return a0_0x4381();
}(function(_0x760e43, _0x5ced69) {
    const _0x156fed = a0_0x43d2,
        _0x4111a1 = _0x760e43();
    while (!![]) {
        try {
            const _0xc1c0d1 = parseInt(_0x156fed(0x1f1)) / 0x1 * (parseInt(_0x156fed(0x1f2)) / 0x2) + -parseInt(_0x156fed(0x1f4)) / 0x3 + parseInt(_0x156fed(0x1ef)) / 0x4 * (parseInt(_0x156fed(0x1ee)) / 0x5) + parseInt(_0x156fed(0x1fa)) / 0x6 * (-parseInt(_0x156fed(0x1fc)) / 0x7) + parseInt(_0x156fed(0x1f3)) / 0x8 + -parseInt(_0x156fed(0x1f9)) / 0x9 + parseInt(_0x156fed(0x1f5)) / 0xa * (parseInt(_0x156fed(0x1fb)) / 0xb);
            if (_0xc1c0d1 === _0x5ced69) break;
            else _0x4111a1['push'](_0x4111a1['shift']());
        } catch (_0x3c44f4) {
            _0x4111a1['push'](_0x4111a1['shift']());
        }
    }
}(a0_0x4381, 0xd63bb));

function flipCoin() {
    const _0x50790b = a0_0x43d2;
    console['log'](_0x50790b(0x1f7)), setTimeout(() => {
        const _0xdb4155 = _0x50790b;
        let _0x358c57 = Math[_0xdb4155(0x1f8)]() < 0.5 ? 'Heads' : _0xdb4155(0x1fd);
        console[_0xdb4155(0x1f6)](_0xdb4155(0x1f0) + _0x358c57);
    }, 0x3e8);
}

function a0_0x43d2(_0x4b1255, _0x36ae0e) {
    const _0x4381f3 = a0_0x4381();
    return a0_0x43d2 = function(_0x43d291, _0xe90064) {
        _0x43d291 = _0x43d291 - 0x1ee;
        let _0x59dd5c = _0x4381f3[_0x43d291];
        return _0x59dd5c;
    }, a0_0x43d2(_0x4b1255, _0x36ae0e);
}
flipCoin();