var a0_0x13597b = a0_0x11f8;

function a0_0x2b91() {
    var _0x4f4c3c = ['426jnpCYS', '#cycle\x20#tyre1,#tyre2', '36043WpDAUY', 'linear', '#cycle\x20#padel', '22584hcvaSn', '71056JfkPjD', '5492950ZqeLoA', '#cycle\x20#firstRoad,\x20#XMLID_34_', '155IIBkri', '92351DGXSzO', '3463110uSSONU', 'reverse', '126csVEUN', 'easeInOutSine', '967008LBYjBu'];
    a0_0x2b91 = function() {
        return _0x4f4c3c;
    };
    return a0_0x2b91();
}

function a0_0x11f8(_0x38f5f7, _0x37dfa1) {
    var _0x2b91dc = a0_0x2b91();
    return a0_0x11f8 = function(_0x11f88d, _0x562d07) {
        _0x11f88d = _0x11f88d - 0x189;
        var _0x2dc0b5 = _0x2b91dc[_0x11f88d];
        return _0x2dc0b5;
    }, a0_0x11f8(_0x38f5f7, _0x37dfa1);
}(function(_0x212301, _0x45a6ca) {
    var _0x3f20a8 = a0_0x11f8,
        _0x3ca9ad = _0x212301();
    while (!![]) {
        try {
            var _0x7a9b01 = -parseInt(_0x3f20a8(0x198)) / 0x1 + -parseInt(_0x3f20a8(0x18b)) / 0x2 * (-parseInt(_0x3f20a8(0x193)) / 0x3) + parseInt(_0x3f20a8(0x194)) / 0x4 * (parseInt(_0x3f20a8(0x197)) / 0x5) + -parseInt(_0x3f20a8(0x18e)) / 0x6 * (parseInt(_0x3f20a8(0x190)) / 0x7) + -parseInt(_0x3f20a8(0x18d)) / 0x8 + parseInt(_0x3f20a8(0x189)) / 0x9 + -parseInt(_0x3f20a8(0x195)) / 0xa;
            if (_0x7a9b01 === _0x45a6ca) break;
            else _0x3ca9ad['push'](_0x3ca9ad['shift']());
        } catch (_0x24b0a9) {
            _0x3ca9ad['push'](_0x3ca9ad['shift']());
        }
    }
}(a0_0x2b91, 0x44c25));
var design = anime({
        'targets': a0_0x13597b(0x196),
        'translateY': -0x7,
        'easing': a0_0x13597b(0x18c),
        'duration': 0x3e8,
        'delay': function(_0x670738, _0x4fd87b) {
            return _0x4fd87b * 0xfa;
        },
        'direction': 'alternate',
        'loop': !![]
    }),
    design = anime({
        'targets': a0_0x13597b(0x18f),
        'rotate': 0x168,
        'easing': a0_0x13597b(0x191),
        'loop': !![],
        'direction': a0_0x13597b(0x18a)
    }),
    design = anime({
        'targets': a0_0x13597b(0x192),
        'rotate': 0x168,
        'easing': 'linear',
        'loop': !![],
        'duration': 0xbb8,
        'direction': a0_0x13597b(0x18a)
    });