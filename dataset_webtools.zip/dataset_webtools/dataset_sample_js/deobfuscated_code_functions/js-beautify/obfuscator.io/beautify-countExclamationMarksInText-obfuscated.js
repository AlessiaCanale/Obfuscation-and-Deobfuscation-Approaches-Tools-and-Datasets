function a0_0x5332(_0xcf64b6, _0x339888) {
    const _0x5b4d44 = a0_0x5b4d();
    return a0_0x5332 = function(_0x5332a4, _0x2f819f) {
        _0x5332a4 = _0x5332a4 - 0xb2;
        let _0x598afe = _0x5b4d44[_0x5332a4];
        return _0x598afe;
    }, a0_0x5332(_0xcf64b6, _0x339888);
}
const a0_0x36e071 = a0_0x5332;
(function(_0x5d595a, _0x3093fb) {
    const _0x1bbc06 = a0_0x5332,
        _0x366ecb = _0x5d595a();
    while (!![]) {
        try {
            const _0x3b889e = parseInt(_0x1bbc06(0xb6)) / 0x1 + -parseInt(_0x1bbc06(0xb2)) / 0x2 * (parseInt(_0x1bbc06(0xb5)) / 0x3) + parseInt(_0x1bbc06(0xbb)) / 0x4 + -parseInt(_0x1bbc06(0xb8)) / 0x5 + parseInt(_0x1bbc06(0xb9)) / 0x6 + -parseInt(_0x1bbc06(0xbc)) / 0x7 + parseInt(_0x1bbc06(0xb7)) / 0x8;
            if (_0x3b889e === _0x3093fb) break;
            else _0x366ecb['push'](_0x366ecb['shift']());
        } catch (_0x4eb405) {
            _0x366ecb['push'](_0x366ecb['shift']());
        }
    }
}(a0_0x5b4d, 0x1b6ee));

function countExclamationMarksInText(_0x357497) {
    const _0x551486 = a0_0x5332;
    let _0x55b0f9 = 0x0;
    for (let _0x37ec46 = 0x0; _0x37ec46 < _0x357497[_0x551486(0xbd)]; _0x37ec46++) {
        _0x357497[_0x37ec46] === '!' && _0x55b0f9++;
    }
    console['log'](_0x551486(0xb3) + _0x357497 + '\x22'), console[_0x551486(0xb4)]('Number\x20of\x20Exclamation\x20Marks:\x20' + _0x55b0f9);
}
countExclamationMarksInText(a0_0x36e071(0xba));

function a0_0x5b4d() {
    const _0x2ae318 = ['89535oIWLVS', '785056SMsvXB', '809230IeDvsn', '759072iJAHdB', 'Wow!\x20This\x20is\x20amazing!!\x20How\x20many\x20exclamation\x20marks\x20are\x20there?!!', '363420KApkiv', '304346ikBzOr', 'length', '3296zQkEFm', 'Original\x20Text:\x20\x22', 'log', '159YWifem'];
    a0_0x5b4d = function() {
        return _0x2ae318;
    };
    return a0_0x5b4d();
}