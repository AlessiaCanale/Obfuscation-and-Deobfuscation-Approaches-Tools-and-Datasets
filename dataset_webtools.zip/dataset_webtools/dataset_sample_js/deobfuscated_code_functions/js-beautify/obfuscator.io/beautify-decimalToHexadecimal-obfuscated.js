var a0_0x1e490a = a0_0x4b80;

function a0_0x19b6() {
    var _0x172a22 = ['2546088ebIivb', '726fbqINM', '528646VrAZcx', '1660365MEsJkl', '181652VyLuoi', '\x20from\x20decimal\x20form\x20to\x20hexadecimal\x20form:\x200x', '1MySbsv', '6262290nyxTEu', '7385Hpitzz', 'log', '15KLMNol', '2717631jhMicW'];
    a0_0x19b6 = function() {
        return _0x172a22;
    };
    return a0_0x19b6();
}(function(_0x39399b, _0x736722) {
    var _0x5dbd00 = a0_0x4b80,
        _0xf4d6ce = _0x39399b();
    while (!![]) {
        try {
            var _0x1561e8 = parseInt(_0x5dbd00(0x189)) / 0x1 * (parseInt(_0x5dbd00(0x191)) / 0x2) + -parseInt(_0x5dbd00(0x18d)) / 0x3 * (-parseInt(_0x5dbd00(0x187)) / 0x4) + parseInt(_0x5dbd00(0x192)) / 0x5 + -parseInt(_0x5dbd00(0x190)) / 0x6 * (-parseInt(_0x5dbd00(0x18b)) / 0x7) + -parseInt(_0x5dbd00(0x18f)) / 0x8 + parseInt(_0x5dbd00(0x18e)) / 0x9 + -parseInt(_0x5dbd00(0x18a)) / 0xa;
            if (_0x1561e8 === _0x736722) break;
            else _0xf4d6ce['push'](_0xf4d6ce['shift']());
        } catch (_0x5b1c74) {
            _0xf4d6ce['push'](_0xf4d6ce['shift']());
        }
    }
}(a0_0x19b6, 0x4b569));
var decimalNumber = 0xff,
    hexNumber = decimalNumber['toString'](0x10);

function a0_0x4b80(_0x5205f9, _0x10d67a) {
    var _0x19b6b2 = a0_0x19b6();
    return a0_0x4b80 = function(_0x4b80f7, _0x3b4e0d) {
        _0x4b80f7 = _0x4b80f7 - 0x187;
        var _0x533ad6 = _0x19b6b2[_0x4b80f7];
        return _0x533ad6;
    }, a0_0x4b80(_0x5205f9, _0x10d67a);
}
console[a0_0x1e490a(0x18c)](decimalNumber + a0_0x1e490a(0x188) + hexNumber);