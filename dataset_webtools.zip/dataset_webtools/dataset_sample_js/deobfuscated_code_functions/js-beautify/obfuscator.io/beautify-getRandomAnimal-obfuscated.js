(function(_0x285375, _0x1e0b00) {
    const _0x5153f5 = a0_0x1614,
        _0x1dd505 = _0x285375();
    while (!![]) {
        try {
            const _0x3efe0a = parseInt(_0x5153f5(0x1a6)) / 0x1 * (parseInt(_0x5153f5(0x1bd)) / 0x2) + parseInt(_0x5153f5(0x1b0)) / 0x3 * (-parseInt(_0x5153f5(0x1af)) / 0x4) + parseInt(_0x5153f5(0x1b3)) / 0x5 + parseInt(_0x5153f5(0x1a7)) / 0x6 + -parseInt(_0x5153f5(0x1b5)) / 0x7 + -parseInt(_0x5153f5(0x1b7)) / 0x8 * (parseInt(_0x5153f5(0x1b8)) / 0x9) + parseInt(_0x5153f5(0x1ae)) / 0xa;
            if (_0x3efe0a === _0x1e0b00) break;
            else _0x1dd505['push'](_0x1dd505['shift']());
        } catch (_0x30407a) {
            _0x1dd505['push'](_0x1dd505['shift']());
        }
    }
}(a0_0x4ec7, 0xdac54));

function a0_0x1614(_0x2deafd, _0x38c6ce) {
    const _0x4ec7f5 = a0_0x4ec7();
    return a0_0x1614 = function(_0x16141b, _0x11a710) {
        _0x16141b = _0x16141b - 0x1a5;
        let _0x5251e7 = _0x4ec7f5[_0x16141b];
        return _0x5251e7;
    }, a0_0x1614(_0x2deafd, _0x38c6ce);
}

function a0_0x4ec7() {
    const _0x19ebcd = ['9atqRFr', '4720584FbfqnM', 'Wolves\x20are\x20social\x20pack\x20animals\x20that\x20communicate\x20through\x20howling.', 'Bears\x20are\x20powerful\x20omnivores\x20that\x20hibernate\x20during\x20the\x20winter.', 'Foxes\x20are\x20cunning\x20and\x20nocturnal\x20hunters.', 'log', 'Kangaroos\x20are\x20marsupials\x20that\x20hop\x20around\x20on\x20their\x20powerful\x20hind\x20legs.', 'Giraffes\x20are\x20the\x20tallest\x20mammals\x20with\x20long\x20necks\x20and\x20legs.', '18214310cBnald', '324LcyOuq', '56517oxCDge', 'length', 'Cats\x20are\x20independent\x20and\x20mysterious\x20creatures.', '8690550rppfIR', 'Tigers\x20are\x20solitary\x20hunters\x20with\x20beautiful\x20striped\x20fur.', '9193254WxVtUA', 'Snakes\x20are\x20cold-blooded\x20reptiles\x20that\x20slither\x20on\x20the\x20ground.', '44632EbTFVw', '2169IrEptl', 'Elephants\x20are\x20the\x20largest\x20land\x20animals\x20and\x20have\x20a\x20strong\x20sense\x20of\x20family.', 'Zebras\x20have\x20black\x20and\x20white\x20stripes\x20that\x20help\x20them\x20camouflage\x20from\x20predators.', 'Cows\x20are\x20gentle\x20herbivores\x20that\x20provide\x20milk\x20for\x20humans.', 'Dogs\x20are\x20known\x20for\x20their\x20loyalty\x20and\x20companionship.', '163022alUtNe', 'Squirrels\x20are\x20agile\x20rodents\x20that\x20hoard\x20nuts\x20for\x20the\x20winter.', 'random', 'floor'];
    a0_0x4ec7 = function() {
        return _0x19ebcd;
    };
    return a0_0x4ec7();
}

function getRandomAnimal() {
    const _0x56224a = a0_0x1614,
        _0x1ef429 = {
            'dog': _0x56224a(0x1bc),
            'cat': _0x56224a(0x1b2),
            'horse': 'Horses\x20are\x20majestic\x20and\x20powerful\x20animals.',
            'rabbit': 'Rabbits\x20are\x20known\x20for\x20their\x20fast\x20reproductive\x20rate.',
            'cow': _0x56224a(0x1bb),
            'snake': _0x56224a(0x1b6),
            'monkey': 'Monkeys\x20are\x20intelligent\x20and\x20playful\x20primates.',
            'elephant': _0x56224a(0x1b9),
            'lion': 'Lions\x20are\x20fierce\x20predators\x20that\x20live\x20in\x20prides.',
            'tiger': _0x56224a(0x1b4),
            'bear': _0x56224a(0x1a9),
            'giraffe': _0x56224a(0x1ad),
            'kangaroo': _0x56224a(0x1ac),
            'zebra': _0x56224a(0x1ba),
            'fox': _0x56224a(0x1aa),
            'wolf': _0x56224a(0x1a8),
            'deer': 'Deer\x20are\x20graceful\x20herbivores\x20with\x20antlers\x20on\x20the\x20males.',
            'squirrel': _0x56224a(0x1be),
            'owl': 'Owls\x20are\x20nocturnal\x20birds\x20of\x20prey\x20with\x20exceptional\x20vision\x20and\x20hearing.',
            'dolphin': 'Dolphins\x20are\x20intelligent\x20marine\x20mammals\x20known\x20for\x20their\x20playful\x20behavior.'
        },
        _0x2d537e = Object['keys'](_0x1ef429),
        _0x5d99a0 = _0x2d537e[Math[_0x56224a(0x1a5)](Math[_0x56224a(0x1bf)]() * _0x2d537e[_0x56224a(0x1b1)])];
    console[_0x56224a(0x1ab)](_0x5d99a0 + ':\x20' + _0x1ef429[_0x5d99a0]);
}
getRandomAnimal();