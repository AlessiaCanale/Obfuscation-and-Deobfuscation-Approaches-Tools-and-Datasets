function a0_0x1330(_0x509d06, _0x1b1a15) {
    const _0x3d61dc = a0_0x3d61();
    return a0_0x1330 = function(_0x133054, _0x4d7c1b) {
        _0x133054 = _0x133054 - 0x1cf;
        let _0x2f0f40 = _0x3d61dc[_0x133054];
        return _0x2f0f40;
    }, a0_0x1330(_0x509d06, _0x1b1a15);
}
const a0_0x3ea9a4 = a0_0x1330;
(function(_0x397ccc, _0x40827d) {
    const _0x32cbca = a0_0x1330,
        _0x26b407 = _0x397ccc();
    while (!![]) {
        try {
            const _0x157b18 = -parseInt(_0x32cbca(0x1cf)) / 0x1 + parseInt(_0x32cbca(0x1d7)) / 0x2 * (parseInt(_0x32cbca(0x1d3)) / 0x3) + -parseInt(_0x32cbca(0x1d1)) / 0x4 + parseInt(_0x32cbca(0x1d9)) / 0x5 + parseInt(_0x32cbca(0x1d6)) / 0x6 * (parseInt(_0x32cbca(0x1d5)) / 0x7) + -parseInt(_0x32cbca(0x1d4)) / 0x8 + parseInt(_0x32cbca(0x1d0)) / 0x9;
            if (_0x157b18 === _0x40827d) break;
            else _0x26b407['push'](_0x26b407['shift']());
        } catch (_0x3cfb3d) {
            _0x26b407['push'](_0x26b407['shift']());
        }
    }
}(a0_0x3d61, 0x53644));
const isAppleDevice = /Mac|iPod|iPhone|iPad/ ['test'](navigator[a0_0x3ea9a4(0x1d2)]);
console[a0_0x3ea9a4(0x1d8)](isAppleDevice);

function a0_0x3d61() {
    const _0x30fea4 = ['platform', '4863SaHczm', '559720HItSxo', '7FcgKsZ', '2205156DkuaeZ', '502DTzqNj', 'log', '1818125Tzgtme', '393606mqRqXk', '1011060BWsLiv', '1780876VtJtEq'];
    a0_0x3d61 = function() {
        return _0x30fea4;
    };
    return a0_0x3d61();
}