var a0_0x56caf0 = a0_0x479a;

function a0_0xfb51() {
    var _0x165a07 = ['1\x20hour\x20is\x20equal\x20to\x20', '7GUIgJO', '9tpSXCc', 'log', '351215DNtCFe', '\x20minutes', '926444uXCfIu', '5485000WbpIUt', '311230dmOLag', '519556MmnXCY', '998816YNxnmv', '828348obAoSb', '585elUiIx', '5\x20hours\x20is\x20equal\x20to\x20'];
    a0_0xfb51 = function() {
        return _0x165a07;
    };
    return a0_0xfb51();
}(function(_0x5538ea, _0x5b49b0) {
    var _0x5670b0 = a0_0x479a,
        _0x12f46b = _0x5538ea();
    while (!![]) {
        try {
            var _0x5620e2 = -parseInt(_0x5670b0(0x170)) / 0x1 + -parseInt(_0x5670b0(0x174)) / 0x2 + parseInt(_0x5670b0(0x17a)) / 0x3 * (parseInt(_0x5670b0(0x173)) / 0x4) + parseInt(_0x5670b0(0x17c)) / 0x5 + parseInt(_0x5670b0(0x175)) / 0x6 + -parseInt(_0x5670b0(0x179)) / 0x7 * (parseInt(_0x5670b0(0x171)) / 0x8) + -parseInt(_0x5670b0(0x176)) / 0x9 * (-parseInt(_0x5670b0(0x172)) / 0xa);
            if (_0x5620e2 === _0x5b49b0) break;
            else _0x12f46b['push'](_0x12f46b['shift']());
        } catch (_0x3bcd88) {
            _0x12f46b['push'](_0x12f46b['shift']());
        }
    }
}(a0_0xfb51, 0x7c62e));

function a0_0x479a(_0x5b31ee, _0x488ed1) {
    var _0xfb51c4 = a0_0xfb51();
    return a0_0x479a = function(_0x479af4, _0x1687eb) {
        _0x479af4 = _0x479af4 - 0x16f;
        var _0x10fe07 = _0xfb51c4[_0x479af4];
        return _0x10fe07;
    }, a0_0x479a(_0x5b31ee, _0x488ed1);
}

function hoursToMinutes(_0x462a5b) {
    return _0x462a5b * 0x3c;
}
console[a0_0x56caf0(0x17b)](a0_0x56caf0(0x178) + hoursToMinutes(0x1) + a0_0x56caf0(0x16f)), console[a0_0x56caf0(0x17b)]('2\x20hours\x20is\x20equal\x20to\x20' + hoursToMinutes(0x2) + a0_0x56caf0(0x16f)), console[a0_0x56caf0(0x17b)]('3\x20hours\x20is\x20equal\x20to\x20' + hoursToMinutes(0x3) + a0_0x56caf0(0x16f)), console[a0_0x56caf0(0x17b)]('4\x20hours\x20is\x20equal\x20to\x20' + hoursToMinutes(0x4) + '\x20minutes'), console[a0_0x56caf0(0x17b)](a0_0x56caf0(0x177) + hoursToMinutes(0x5) + a0_0x56caf0(0x16f));