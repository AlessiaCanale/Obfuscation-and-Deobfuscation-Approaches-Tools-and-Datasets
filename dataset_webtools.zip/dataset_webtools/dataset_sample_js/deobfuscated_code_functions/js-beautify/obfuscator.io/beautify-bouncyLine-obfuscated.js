const a0_0x19e28b = a0_0x1798;
(function(_0x1e6760, _0x3ae6f9) {
    const _0xd46a55 = a0_0x1798,
        _0x11bb75 = _0x1e6760();
    while (!![]) {
        try {
            const _0x58cdc6 = parseInt(_0xd46a55(0x1bd)) / 0x1 * (-parseInt(_0xd46a55(0x1b7)) / 0x2) + parseInt(_0xd46a55(0x1d1)) / 0x3 * (-parseInt(_0xd46a55(0x1c4)) / 0x4) + -parseInt(_0xd46a55(0x1c7)) / 0x5 * (parseInt(_0xd46a55(0x1cc)) / 0x6) + parseInt(_0xd46a55(0x1c9)) / 0x7 + -parseInt(_0xd46a55(0x1b5)) / 0x8 + -parseInt(_0xd46a55(0x1be)) / 0x9 + -parseInt(_0xd46a55(0x1ca)) / 0xa * (-parseInt(_0xd46a55(0x1b8)) / 0xb);
            if (_0x58cdc6 === _0x3ae6f9) break;
            else _0x11bb75['push'](_0x11bb75['shift']());
        } catch (_0x522641) {
            _0x11bb75['push'](_0x11bb75['shift']());
        }
    }
}(a0_0x44fd, 0xa775b));
const svg = document[a0_0x19e28b(0x1c5)](a0_0x19e28b(0x1ba)),
    curve = document[a0_0x19e28b(0x1b4)](a0_0x19e28b(0x1bb)),
    controlPoint = document['getElementById'](a0_0x19e28b(0x1bc)),
    posXLabel = document[a0_0x19e28b(0x1c5)](a0_0x19e28b(0x1cf)),
    posYLabel = document['querySelector']('.posY'),
    svgViewBoxWidth = 0xbe;
let isMouseDown = ![],
    point = {
        'x': 0x5f,
        'y': 0x50
    };

function a0_0x44fd() {
    const _0x5634eb = ['10360908yzXfJP', 'touchmove', 'setAttribute', 'replace', 'mousedown', 'width', '329276FDZLEL', 'querySelector', 'touches', '16945nYnVYQ', 'addEventListener', '6686505ZhhBYa', '8650540pIIeMl', 'mouseup', '1140rtKLNS', 'textContent', 'height', '.posX', 'mousemove', '3XYpfwW', 'ceil', 'toFixed', 'getElementById', '10425504YknECe', 'clientY', '1097774rgdVve', '44KHKGjI', 'getBoundingClientRect', 'svg', 'curve', 'control-point', '1fgxBgC'];
    a0_0x44fd = function() {
        return _0x5634eb;
    };
    return a0_0x44fd();
}

function updateCurve(_0x499274, _0x53d999) {
    const _0x1f2334 = a0_0x19e28b;
    let _0x4f9213 = svg[_0x1f2334(0x1b9)](),
        _0x4776b0 = _0x4f9213['width'] / svgViewBoxWidth,
        _0x4c0b56 = _0x4f9213[_0x1f2334(0x1c3)] / _0x4776b0 - 0x5,
        _0x4828e4 = _0x4f9213[_0x1f2334(0x1ce)] / _0x4776b0 - 0x6;
    _0x499274 && _0x53d999 && (point['x'] = Math[_0x1f2334(0x1d2)]((_0x499274 - _0x4f9213['x']) / _0x4776b0), point['y'] = Math[_0x1f2334(0x1d2)]((_0x53d999 - _0x4f9213['y']) / _0x4776b0)), point['x'] = point['x'] < 0x5 ? 0x5 : point['x'], point['y'] = point['y'] < 0x5 ? 0x5 : point['y'], point['x'] = point['x'] > _0x4c0b56 ? Math['ceil'](_0x4c0b56) : point['x'], point['y'] = point['y'] > _0x4828e4 ? Math[_0x1f2334(0x1d2)](_0x4828e4) : point['y'], posXLabel[_0x1f2334(0x1cd)] = point['x'][_0x1f2334(0x1d3)](0x2), posYLabel[_0x1f2334(0x1cd)] = point['y'][_0x1f2334(0x1d3)](0x2), controlPoint[_0x1f2334(0x1c0)]('cx', point['x']), controlPoint[_0x1f2334(0x1c0)]('cy', point['y']), curve[_0x1f2334(0x1c0)]('d', curve['getAttribute']('d')[_0x1f2334(0x1c1)](/Q (\d+(\.\d+)?) (\d+(\.\d+)?)/, 'Q\x20' + point['x'] + '\x20' + point['y']));
}

function onMouseDown() {
    isMouseDown = !![];
}

function onMouseMove(_0x1fbdae) {
    isMouseDown && updateCurve(_0x1fbdae['clientX'], _0x1fbdae['clientY']);
}

function onMouseUp() {
    isMouseDown = ![], anime({
        'targets': point,
        'x': 0x5f,
        'y': 0x50,
        'duration': 0x3e8,
        'easing': 'easeOutElastic(1.5,\x200.2)',
        'update': function() {
            updateCurve();
        }
    });
}

function a0_0x1798(_0x802e88, _0x43983f) {
    const _0x44fd51 = a0_0x44fd();
    return a0_0x1798 = function(_0x1798ed, _0x36bcf5) {
        _0x1798ed = _0x1798ed - 0x1b4;
        let _0x1ea13e = _0x44fd51[_0x1798ed];
        return _0x1ea13e;
    }, a0_0x1798(_0x802e88, _0x43983f);
}
controlPoint[a0_0x19e28b(0x1c8)](a0_0x19e28b(0x1c2), onMouseDown), controlPoint[a0_0x19e28b(0x1c8)]('touchstart', onMouseDown), document[a0_0x19e28b(0x1c8)](a0_0x19e28b(0x1d0), onMouseMove), document[a0_0x19e28b(0x1c8)](a0_0x19e28b(0x1bf), _0x2264a8 => {
    const _0x37f383 = a0_0x19e28b;
    updateCurve(_0x2264a8[_0x37f383(0x1c6)][0x0]['clientX'], _0x2264a8[_0x37f383(0x1c6)][0x0][_0x37f383(0x1b6)]);
}), document['addEventListener'](a0_0x19e28b(0x1cb), onMouseUp), document[a0_0x19e28b(0x1c8)]('touchend', onMouseUp);