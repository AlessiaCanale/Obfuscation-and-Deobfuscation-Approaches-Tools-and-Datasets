const a0_0x519e78 = a0_0x4bdf;
(function(_0x3c0760, _0x49f73f) {
    const _0x323f4f = a0_0x4bdf,
        _0x1e9ae2 = _0x3c0760();
    while (!![]) {
        try {
            const _0x4e1888 = parseInt(_0x323f4f(0xee)) / 0x1 * (-parseInt(_0x323f4f(0xfe)) / 0x2) + -parseInt(_0x323f4f(0xe7)) / 0x3 + -parseInt(_0x323f4f(0x111)) / 0x4 * (-parseInt(_0x323f4f(0x101)) / 0x5) + -parseInt(_0x323f4f(0x10c)) / 0x6 * (-parseInt(_0x323f4f(0xec)) / 0x7) + parseInt(_0x323f4f(0xe8)) / 0x8 + -parseInt(_0x323f4f(0x107)) / 0x9 + parseInt(_0x323f4f(0xea)) / 0xa * (parseInt(_0x323f4f(0xf9)) / 0xb);
            if (_0x4e1888 === _0x49f73f) break;
            else _0x1e9ae2['push'](_0x1e9ae2['shift']());
        } catch (_0x1f9de8) {
            _0x1e9ae2['push'](_0x1e9ae2['shift']());
        }
    }
}(a0_0x2e4b, 0x71190));

function a0_0x2e4b() {
    const _0x50b437 = ['chickIcon', '388816bQFixf', 'stagger', '.hatch-icon__rabbit', '20plJBuu', '.hatch-icon__rabbit-paws', 'easeOutElastic', '.painting-icon__egg-top', '.hatch-icon', 'querySelector', '7499052HoRBoK', 'nextElementSibling', 'egg1', 'egg2', 'opacity', '162FdAlny', 'basketIcon', '.painting-icon', 'giftIcon', 'center\x20bottom', '339792Wxfrsy', '75%\x20bottom', '.painting-icon__egg-top\x20.egg-top__main', '.chick-icon', 'linear', 'brush', 'rabbit', 'icon', '.hatch-icon__rabbit-head', 'egg', '1780398mteZqm', '451456FWUdyA', 'click', '5380TprnyB', '.hatch-icon__egg', '129556xqYDmN', 'paintingIcon', '4dUwkaW', '.basket-icon__egg-1', '.gift-icon', 'restart', '.gift-icon__egg', '.gift-icon__gift', 'addEventListener', '.painting-icon\x20svg\x20>\x20g', 'style', 'transformOrigin', 'allComponents', '36223IwwBMg', 'eggTop', '.painting-icon__egg-top\x20path', 'hatchIcon'];
    a0_0x2e4b = function() {
        return _0x50b437;
    };
    return a0_0x2e4b();
}
let PATH = {
    'giftIcon': {
        'icon': a0_0x519e78(0xf0),
        'gift': a0_0x519e78(0xf3),
        'egg': a0_0x519e78(0xf2)
    },
    'chickIcon': a0_0x519e78(0xe0),
    'basketIcon': {
        'icon': '.basket-icon',
        'egg1': a0_0x519e78(0xef),
        'egg2': '.basket-icon__egg-2'
    },
    'paintingIcon': {
        'icon': a0_0x519e78(0x10e),
        'allComponents': a0_0x519e78(0xf5),
        'brush': '.painting-icon__brush',
        'eggTop': a0_0x519e78(0x104),
        'eggTopParts': a0_0x519e78(0xfb),
        'eggTopColored': a0_0x519e78(0xdf)
    },
    'hatchIcon': {
        'icon': a0_0x519e78(0x105),
        'rabbit': a0_0x519e78(0x100),
        'rabbitPaws': a0_0x519e78(0x102),
        'rabbitHead': a0_0x519e78(0xe5),
        'egg': a0_0x519e78(0xeb)
    }
};
const _revealVert = (_0x382f42, _0x160001, _0x4ebe78) => ({
        'translateY': [_0x382f42, 0x0],
        'opacity': [0x0, 0x1],
        'easing': _0x160001,
        'delay': anime[a0_0x519e78(0xff)](_0x4ebe78)
    }),
    _shiver = () => ({
        'keyframes': [{
            'rotate': -0xa
        }, {
            'rotate': 0xa
        }, {
            'rotate': 0x0
        }, {
            'rotate': 0x0
        }, {
            'rotate': 0x0
        }, {
            'rotate': 0x0
        }, {
            'rotate': 0x0
        }, {
            'rotate': 0x0
        }, {
            'rotate': 0x0
        }, {
            'rotate': 0x0
        }],
        'loop': !![],
        'easing': a0_0x519e78(0xe1),
        'duration': 0x4b0
    }),
    _hideElem = _0x51137a => {
        const _0x160ee2 = a0_0x519e78,
            _0x420926 = document[_0x160ee2(0x106)](_0x51137a);
        _0x420926[_0x160ee2(0xf6)]['opacity'] = 0x0;
    },
    _showElem = _0x18738b => {
        const _0x1e6097 = a0_0x519e78,
            _0x4e9a8e = document[_0x1e6097(0x106)](_0x18738b);
        _0x4e9a8e[_0x1e6097(0xf6)][_0x1e6097(0x10b)] = 0x1;
    };
let giftEggAnimation;
const giftIconAnimation = anime({
    'targets': ['' + PATH[a0_0x519e78(0x10f)]['gift'], '' + PATH[a0_0x519e78(0x10f)]['egg']],
    ..._revealVert(0x96, a0_0x519e78(0x103), 0x64),
    'complete': function() {
        const _0x5a9b62 = a0_0x519e78,
            _0x3ab6bc = document[_0x5a9b62(0x106)](PATH[_0x5a9b62(0x10f)][_0x5a9b62(0xe6)]);
        _0x3ab6bc[_0x5a9b62(0xf6)][_0x5a9b62(0xf7)] = _0x5a9b62(0x112), giftEggAnimation = anime({
            'targets': '' + PATH[_0x5a9b62(0x10f)]['egg'],
            ..._shiver()
        });
    }
});
let chickJumpAnimation;

function a0_0x4bdf(_0x3a3031, _0x432b03) {
    const _0x2e4b3c = a0_0x2e4b();
    return a0_0x4bdf = function(_0x4bdf01, _0x10aef9) {
        _0x4bdf01 = _0x4bdf01 - 0xdf;
        let _0x23239b = _0x2e4b3c[_0x4bdf01];
        return _0x23239b;
    }, a0_0x4bdf(_0x3a3031, _0x432b03);
}
const jumpKeyframes = {
        'scaleY': [{
            'value': 0.9,
            'duration': 0xaa
        }, {
            'value': 0x1,
            'duration': 0xaa,
            'delay': 0x78
        }],
        'translateY': [{
            'value': -0x14,
            'duration': 0xaa,
            'delay': 0xaa
        }, {
            'value': 0x0,
            'duration': 0xaa,
            'delay': 0xdc
        }]
    },
    chickIconAnimation = anime({
        'targets': '' + PATH['chickIcon'],
        ..._revealVert(0x19, 'easeOutElastic', 0x64),
        'complete': function() {
            const _0x50a389 = a0_0x519e78,
                _0x471793 = document['querySelector'](PATH[_0x50a389(0xfd)]);
            _0x471793[_0x50a389(0xf6)][_0x50a389(0xf7)] = _0x50a389(0x110), chickJumpAnimation = anime({
                'targets': '' + PATH['chickIcon'],
                ...jumpKeyframes,
                'loop': !![],
                'easing': 'linear'
            });
        }
    });
let eggsRevealAnimation;
const basketIconAnimation = anime({
    'targets': '' + PATH[a0_0x519e78(0x10d)][a0_0x519e78(0xe4)],
    ..._revealVert(0x19, a0_0x519e78(0x103), 0x64),
    'complete': function() {
        const _0x4bb3b4 = a0_0x519e78;
        eggsRevealAnimation = anime({
            'targets': ['' + PATH[_0x4bb3b4(0x10d)][_0x4bb3b4(0x109)], '' + PATH[_0x4bb3b4(0x10d)][_0x4bb3b4(0x10a)]],
            ..._revealVert(0x32, _0x4bb3b4(0x103), 0x96),
            'loop': !![]
        });
    }
});
let paintingAnimation, paintedPartAnimation;
_hideElem(PATH[a0_0x519e78(0xed)][a0_0x519e78(0xfa)]);
const brushKeyframes = {
        'translateX': [{
            'value': -0x96,
            'duration': 0x96
        }, {
            'value': -0xb4,
            'duration': 0x96,
            'delay': 0x64
        }, {
            'value': 0x0,
            'duration': 0x96,
            'delay': 0x64
        }, {
            'value': 0x0,
            'duration': 0x96,
            'delay': 0x73a
        }],
        'translateY': [{
            'value': -0xa0,
            'duration': 0x96
        }, {
            'value': 0x0,
            'duration': 0x96,
            'delay': 0x64
        }, {
            'value': 0x0,
            'duration': 0x96,
            'delay': 0x708
        }]
    },
    paintKeyframes = {
        'opacity': [{
            'value': 0x1,
            'duration': 0xc8,
            'delay': 0xc8
        }, {
            'value': 0x0,
            'duration': 0xc8,
            'delay': 0x384
        }, {
            'value': 0x0,
            'duration': 0x96,
            'delay': 0x3e8
        }]
    },
    paintingIconAnimation = anime({
        'targets': '' + PATH[a0_0x519e78(0xed)][a0_0x519e78(0xf8)],
        ..._revealVert(0x96, 'easeOutElastic', 0x64),
        'complete': function() {
            const _0x1a2230 = a0_0x519e78;
            paintingAnimation = anime({
                'targets': '' + PATH[_0x1a2230(0xed)][_0x1a2230(0xe2)],
                ...brushKeyframes,
                'easing': _0x1a2230(0xe1),
                'loop': !![]
            }), paintedPartAnimation = anime({
                'targets': '' + PATH[_0x1a2230(0xed)][_0x1a2230(0xfa)],
                ...paintKeyframes,
                'easing': _0x1a2230(0xe1),
                'loop': !![]
            });
        }
    });
let jumpRabbitAnimation;
_hideElem(PATH[a0_0x519e78(0xfc)][a0_0x519e78(0xe3)]);
const jumpRabbitKeyframes = {
        'translateY': [{
            'value': 0x32,
            'duration': 0x32,
            'delay': 0x64
        }, {
            'value': -0x5a,
            'duration': 0x96,
            'delay': 0x64
        }, {
            'value': 0x0,
            'duration': 0x64,
            'delay': 0x64
        }, {
            'value': 0x0,
            'duration': 0x64,
            'delay': 0x4b0
        }]
    },
    hatchIconAnimation = anime({
        'targets': '' + PATH[a0_0x519e78(0xfc)][a0_0x519e78(0xe4)],
        ..._revealVert(0x19, 'easeOutElastic', 0x64),
        'complete': function() {
            const _0x56d48e = a0_0x519e78;
            _showElem(PATH[_0x56d48e(0xfc)][_0x56d48e(0xe3)]), jumpRabbitAnimation = anime({
                'targets': '' + PATH[_0x56d48e(0xfc)]['rabbit'],
                ...jumpRabbitKeyframes,
                'easing': _0x56d48e(0xe1),
                'loop': !![]
            });
        }
    }),
    replay = ({
        initTarget: _0x42cc8d,
        initValues: _0x2ccea4
    }, _0x500ea0, _0x201efc) => {
        const _0x558bf7 = a0_0x519e78;
        anime['set'](_0x42cc8d, {
            ..._0x2ccea4
        }), _0x500ea0['forEach'](_0x42ac24 => {
            _0x42ac24['pause']();
        }), _0x201efc[_0x558bf7(0xf1)]();
    },
    giftReplay = document['querySelector'](PATH['giftIcon']['icon'])[a0_0x519e78(0x108)];
giftReplay[a0_0x519e78(0xf4)](a0_0x519e78(0xe9), function() {
    const _0x49269b = a0_0x519e78;
    replay({
        'initTargets': ['' + PATH[_0x49269b(0x10f)]['gift'], '' + PATH['giftIcon'][_0x49269b(0xe6)]],
        'initValues': {
            'opacity': 0x0
        }
    }, [giftEggAnimation], giftIconAnimation);
});
const chickReplay = document[a0_0x519e78(0x106)](PATH['chickIcon'])[a0_0x519e78(0x108)];
chickReplay[a0_0x519e78(0xf4)](a0_0x519e78(0xe9), function() {
    replay({
        'initTargets': '' + PATH['chickIcon'],
        'initValues': {
            'opacity': 0x0
        }
    }, [chickJumpAnimation], chickIconAnimation);
});
const basketReplay = document[a0_0x519e78(0x106)](PATH['basketIcon'][a0_0x519e78(0xe4)])[a0_0x519e78(0x108)];
basketReplay[a0_0x519e78(0xf4)](a0_0x519e78(0xe9), function() {
    const _0x4d96cc = a0_0x519e78;
    replay({
        'initTargets': '' + PATH[_0x4d96cc(0x10d)]['icon'],
        'initValues': {
            'opacity': 0x0
        }
    }, [eggsRevealAnimation], basketIconAnimation);
});
const paintingReplay = document['querySelector'](PATH[a0_0x519e78(0xed)][a0_0x519e78(0xe4)])[a0_0x519e78(0x108)];
paintingReplay[a0_0x519e78(0xf4)](a0_0x519e78(0xe9), function() {
    const _0xeb4394 = a0_0x519e78;
    _hideElem(PATH['paintingIcon'][_0xeb4394(0xfa)]), replay({
        'initTargets': '' + PATH[_0xeb4394(0xed)][_0xeb4394(0xfa)],
        'initValues': {
            'opacity': 0x0
        }
    }, [paintingAnimation, paintedPartAnimation], paintingIconAnimation);
});
const hatchReplay = document[a0_0x519e78(0x106)](PATH[a0_0x519e78(0xfc)][a0_0x519e78(0xe4)])[a0_0x519e78(0x108)];
hatchReplay[a0_0x519e78(0xf4)](a0_0x519e78(0xe9), function() {
    const _0x4b0929 = a0_0x519e78;
    _hideElem(PATH[_0x4b0929(0xfc)]['rabbit']), replay({
        'initTargets': '' + PATH[_0x4b0929(0xfc)][_0x4b0929(0xe4)],
        'initValues': {
            'opacity': 0x0
        }
    }, [jumpRabbitAnimation], hatchIconAnimation);
});