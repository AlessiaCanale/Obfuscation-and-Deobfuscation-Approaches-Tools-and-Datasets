(function(_0x4db41b, _0x235e68) {
    const _0x2f867f = a0_0xf468,
        _0x19e226 = _0x4db41b();
    while (!![]) {
        try {
            const _0x103e06 = -parseInt(_0x2f867f(0xe4)) / 0x1 * (-parseInt(_0x2f867f(0xd0)) / 0x2) + parseInt(_0x2f867f(0xd9)) / 0x3 * (parseInt(_0x2f867f(0xda)) / 0x4) + -parseInt(_0x2f867f(0xe1)) / 0x5 * (parseInt(_0x2f867f(0xe7)) / 0x6) + -parseInt(_0x2f867f(0xd5)) / 0x7 * (-parseInt(_0x2f867f(0xe2)) / 0x8) + parseInt(_0x2f867f(0xdf)) / 0x9 + -parseInt(_0x2f867f(0xd4)) / 0xa * (parseInt(_0x2f867f(0xdc)) / 0xb) + -parseInt(_0x2f867f(0xd3)) / 0xc * (parseInt(_0x2f867f(0xe5)) / 0xd);
            if (_0x103e06 === _0x235e68) break;
            else _0x19e226['push'](_0x19e226['shift']());
        } catch (_0x1c9306) {
            _0x19e226['push'](_0x19e226['shift']());
        }
    }
}(a0_0x54f2, 0x1ea52));

function a0_0xf468(_0x1c2140, _0x55a0cf) {
    const _0x54f2f8 = a0_0x54f2();
    return a0_0xf468 = function(_0xf46863, _0x4758d8) {
        _0xf46863 = _0xf46863 - 0xcf;
        let _0x7206ee = _0x54f2f8[_0xf46863];
        return _0x7206ee;
    }, a0_0xf468(_0x1c2140, _0x55a0cf);
}

function getRandomKlingonWord() {
    const _0xc79a4b = a0_0xf468,
        _0x3d985a = {
            'tlhIngan': 'Klingon',
            'Qapla\x27': _0xc79a4b(0xd1),
            'puqloD': _0xc79a4b(0xcf),
            'qo\x27noS': _0xc79a4b(0xdd),
            'bortaS': 'Revenge',
            'ghobe\x27': _0xc79a4b(0xe3),
            'qaStaHvIS': _0xc79a4b(0xdb),
            'vIghro\x27': 'Warrior',
            'Hurgh': _0xc79a4b(0xd7),
            'batlh': _0xc79a4b(0xd8),
            'tlhaQ': _0xc79a4b(0xde),
            'be\x27joy\x27': 'Pain'
        },
        _0xca7c0e = Math[_0xc79a4b(0xe0)](Math['random']() * Object['keys'](_0x3d985a)[_0xc79a4b(0xe6)]),
        _0x26384f = Object['keys'](_0x3d985a)[_0xca7c0e],
        _0x1fc966 = _0x3d985a[_0x26384f];
    console[_0xc79a4b(0xd6)](_0xc79a4b(0xd2) + _0x26384f), console[_0xc79a4b(0xd6)]('English\x20Translation:\x20' + _0x1fc966);
}

function a0_0x54f2() {
    const _0xe94f0 = ['260fzXfUy', 'length', '1388334FtigYO', 'Child', '2ZQUplc', 'Success', 'Klingon\x20Word:\x20', '65064YIKOyO', '1633110pwpllf', '451927PMCYXF', 'log', 'Cry', 'Honor', '694047yvANJP', '4ynzQHc', 'Danger', '11GSiRvd', 'Homeworld', 'Challenge', '1527543uHIFlH', 'floor', '5Zceyem', '8vlyHUH', 'Ghost', '163025eLYZeY'];
    a0_0x54f2 = function() {
        return _0xe94f0;
    };
    return a0_0x54f2();
}
getRandomKlingonWord();