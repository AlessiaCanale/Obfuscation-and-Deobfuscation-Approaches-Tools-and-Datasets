const a0_0x13a615 = a0_0xb7bf;
(function(_0x2766c6, _0x36c0e8) {
    const _0x5971e0 = a0_0xb7bf,
        _0x260aca = _0x2766c6();
    while (!![]) {
        try {
            const _0x19f9fe = -parseInt(_0x5971e0(0x117)) / 0x1 + -parseInt(_0x5971e0(0x11e)) / 0x2 * (-parseInt(_0x5971e0(0x111)) / 0x3) + -parseInt(_0x5971e0(0x11a)) / 0x4 + -parseInt(_0x5971e0(0x11d)) / 0x5 * (parseInt(_0x5971e0(0x118)) / 0x6) + -parseInt(_0x5971e0(0x121)) / 0x7 + -parseInt(_0x5971e0(0x11f)) / 0x8 + parseInt(_0x5971e0(0x11b)) / 0x9;
            if (_0x19f9fe === _0x36c0e8) break;
            else _0x260aca['push'](_0x260aca['shift']());
        } catch (_0x345d91) {
            _0x260aca['push'](_0x260aca['shift']());
        }
    }
}(a0_0x3291, 0x2d7a0));

function a0_0xb7bf(_0x3ae5d4, _0x123cbf) {
    const _0x32919b = a0_0x3291();
    return a0_0xb7bf = function(_0xb7bfbe, _0x2b64a7) {
        _0xb7bfbe = _0xb7bfbe - 0x110;
        let _0x8c90b = _0x32919b[_0xb7bfbe];
        return _0x8c90b;
    }, a0_0xb7bf(_0x3ae5d4, _0x123cbf);
}

function capitalizeRepeatedWords(_0x5693bb) {
    const _0x9f13b8 = a0_0xb7bf;
    let _0x38c9f2 = _0x5693bb['toLowerCase']()[_0x9f13b8(0x110)](/\b\w+\b/g),
        _0x3ef516 = {};
    _0x38c9f2[_0x9f13b8(0x119)](_0x14c3c0 => {
        _0x3ef516[_0x14c3c0] = (_0x3ef516[_0x14c3c0] || 0x0) + 0x1;
    });
    let _0x187f82 = _0x5693bb[_0x9f13b8(0x112)]('\x20')[_0x9f13b8(0x114)](_0x442f64 => {
        const _0x3a09bb = _0x9f13b8;
        if (_0x3ef516[_0x442f64[_0x3a09bb(0x122)]()] > 0x1) return _0x442f64[_0x3a09bb(0x120)]();
        return _0x442f64;
    })[_0x9f13b8(0x116)]('\x20');
    console['log'](_0x9f13b8(0x11c)), console[_0x9f13b8(0x113)](_0x5693bb), console['log']('Transformed\x20text:'), console[_0x9f13b8(0x113)](_0x187f82);
}

function a0_0x3291() {
    const _0x1e6707 = ['The\x20sun\x20shines\x20brightly\x20sun,\x20warming\x20the\x20earth\x20beauty\x20and\x20bringing\x20light\x20to\x20all\x20living\x20creatures.\x20Nature\x27s\x20earth\x20beauty\x20is\x20captivating.', 'join', '191385gZrVue', '54VcCNLK', 'forEach', '1463648TGOxJW', '13220478LLXliZ', 'Original\x20text:', '155525zrvlkH', '141034gabeAZ', '1538616GDPGVC', 'toUpperCase', '2265326EYKOQx', 'toLowerCase', 'match', '3aFqGgH', 'split', 'log', 'map'];
    a0_0x3291 = function() {
        return _0x1e6707;
    };
    return a0_0x3291();
}
let text = a0_0x13a615(0x115);
capitalizeRepeatedWords(text);