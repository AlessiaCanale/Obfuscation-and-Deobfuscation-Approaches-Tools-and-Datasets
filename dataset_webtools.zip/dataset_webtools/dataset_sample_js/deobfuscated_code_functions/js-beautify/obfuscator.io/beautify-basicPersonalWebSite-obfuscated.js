var a0_0x385e5e = a0_0xc677;
(function(_0x931fb5, _0x2648bd) {
    var _0x7777dc = a0_0xc677,
        _0x599c6e = _0x931fb5();
    while (!![]) {
        try {
            var _0x4a039d = -parseInt(_0x7777dc(0x14a)) / 0x1 + parseInt(_0x7777dc(0x14f)) / 0x2 + -parseInt(_0x7777dc(0x14c)) / 0x3 + -parseInt(_0x7777dc(0x15d)) / 0x4 * (-parseInt(_0x7777dc(0x14e)) / 0x5) + -parseInt(_0x7777dc(0x146)) / 0x6 + -parseInt(_0x7777dc(0x148)) / 0x7 + parseInt(_0x7777dc(0x15e)) / 0x8;
            if (_0x4a039d === _0x2648bd) break;
            else _0x599c6e['push'](_0x599c6e['shift']());
        } catch (_0x24a2a9) {
            _0x599c6e['push'](_0x599c6e['shift']());
        }
    }
}(a0_0x557e, 0xf09dd), $(a0_0x385e5e(0x14d))['mouseover'](function() {
    var _0x5732bf = a0_0x385e5e;
    $(this)['addClass'](_0x5732bf(0x151));
}), $(a0_0x385e5e(0x14d))[a0_0x385e5e(0x152)](function() {
    var _0x3cf095 = a0_0x385e5e;
    $(this)[_0x3cf095(0x147)](_0x3cf095(0x151));
}), setTimeout(function() {
    var _0x4c5a7d = a0_0x385e5e;
    $(_0x4c5a7d(0x15f))['css'](_0x4c5a7d(0x154), _0x4c5a7d(0x156)), loaded[_0x4c5a7d(0x158)]();
}, 0x9c4), width = $(window)[a0_0x385e5e(0x15a)]());
width <= 0x2bc && ($('.name')[a0_0x385e5e(0x159)](function() {
    var _0x2cc04e = a0_0x385e5e;
    $(_0x2cc04e(0x153))[_0x2cc04e(0x157)](_0x2cc04e(0x15c), '0'), $(_0x2cc04e(0x150))[_0x2cc04e(0x157)](_0x2cc04e(0x14b), '20');
}), $('.close')[a0_0x385e5e(0x159)](function() {
    var _0x38f050 = a0_0x385e5e;
    $(_0x38f050(0x153))[_0x38f050(0x157)](_0x38f050(0x15c), _0x38f050(0x149));
}));

function a0_0x557e() {
    var _0x4cf3d5 = ['5647164onPxDh', 'removeClass', '10521518qKpfTO', '-1000px', '759632iCrBUm', 'z-index', '5838624WcpqKk', '.buttons', '594565nVChkZ', '2067456LojMyI', '.wrapper', 'animated\x20jello', 'mouseout', '.intro', 'display', '.close', 'none', 'css', 'play', 'click', 'width', '.text', 'right', '4tKnsvm', '39864256jtrKKX', '.loader'];
    a0_0x557e = function() {
        return _0x4cf3d5;
    };
    return a0_0x557e();
}
$(a0_0x385e5e(0x155))[a0_0x385e5e(0x159)](function() {
    var _0x344788 = a0_0x385e5e;
    close[_0x344788(0x158)]();
});

function a0_0xc677(_0x24ab68, _0x3b48af) {
    var _0x557ec5 = a0_0x557e();
    return a0_0xc677 = function(_0xc6771f, _0x5bf7a4) {
        _0xc6771f = _0xc6771f - 0x146;
        var _0x413573 = _0x557ec5[_0xc6771f];
        return _0x413573;
    }, a0_0xc677(_0x24ab68, _0x3b48af);
}
var loaded = anime({
        'targets': '.name',
        'scale': [{
            'value': 0x3,
            'duration': 0x64,
            'elasticity': 0x64
        }, {
            'value': 0x1,
            'duration': 0x1f4,
            'elasticity': 0x64
        }],
        'duration': 0xfa0,
        'autoplay': ![]
    }),
    open = anime({
        'targets': '.intro',
        'translateX': -0x3e8,
        'duration': 0x3e8,
        'autoplay': ![]
    }),
    close = anime({
        'targets': '.intro',
        'translateX': 0x708,
        'duration': 0x1f4,
        'autoplay': ![]
    }),
    about = anime({
        'targets': a0_0x385e5e(0x15b),
        'translateX': [{
            'value': -0xc8,
            'duration': 0x64,
            'elasticity': 0x64
        }, {
            'value': 0x0,
            'duration': 0x1f4,
            'elasticity': 0x64
        }],
        'delay': 0xc8
    });