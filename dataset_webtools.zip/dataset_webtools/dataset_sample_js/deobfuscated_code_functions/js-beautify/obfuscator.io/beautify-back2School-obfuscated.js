const a0_0x46ce09 = a0_0x380b;
(function(_0x3b24e8, _0x5b6b1a) {
    const _0x4bc14d = a0_0x380b,
        _0x1311d8 = _0x3b24e8();
    while (!![]) {
        try {
            const _0xbe39a7 = parseInt(_0x4bc14d(0x1f1)) / 0x1 + parseInt(_0x4bc14d(0x208)) / 0x2 + parseInt(_0x4bc14d(0x1f5)) / 0x3 * (-parseInt(_0x4bc14d(0x1f4)) / 0x4) + -parseInt(_0x4bc14d(0x1e9)) / 0x5 * (parseInt(_0x4bc14d(0x210)) / 0x6) + -parseInt(_0x4bc14d(0x1fc)) / 0x7 * (-parseInt(_0x4bc14d(0x1e8)) / 0x8) + -parseInt(_0x4bc14d(0x1e6)) / 0x9 + parseInt(_0x4bc14d(0x1ed)) / 0xa;
            if (_0xbe39a7 === _0x5b6b1a) break;
            else _0x1311d8['push'](_0x1311d8['shift']());
        } catch (_0xb6005c) {
            _0x1311d8['push'](_0x1311d8['shift']());
        }
    }
}(a0_0x2b16, 0x2eaa8));
const GLOBAL_CFG = {
    'loop': !![]
};

function a0_0x380b(_0x2ab9da, _0x15cd06) {
    const _0x2b1604 = a0_0x2b16();
    return a0_0x380b = function(_0x380b86, _0x1f0e5b) {
        _0x380b86 = _0x380b86 - 0x1e1;
        let _0x2f3505 = _0x2b1604[_0x380b86];
        return _0x2f3505;
    }, a0_0x380b(_0x2ab9da, _0x15cd06);
}

function getRndInteger(_0x5e0b20, _0x3603a1) {
    const _0x3dc7a8 = a0_0x380b;
    return Math[_0x3dc7a8(0x1f6)](Math[_0x3dc7a8(0x1f7)]() * (_0x3603a1 - _0x5e0b20 + 0x1)) + _0x5e0b20;
}
let swetCollection = document[a0_0x46ce09(0x1ec)](a0_0x46ce09(0x1ee));
swetCollection[a0_0x46ce09(0x20d)]((_0x39c81b, _0x76c8a1) => {
    const _0x53d1a3 = a0_0x46ce09;
    anime({
        ...GLOBAL_CFG,
        'targets': _0x39c81b,
        'opacity': [0x0, 0x1, 0x0],
        'delay': _0x76c8a1 * 0x64,
        'duration': _0x76c8a1 * 0x5dc,
        'translateY': _0x76c8a1 * 0x2,
        'easing': _0x53d1a3(0x204)
    });
});
let spitCollection = document[a0_0x46ce09(0x1ec)](a0_0x46ce09(0x20f));
spitCollection['forEach']((_0x2c3d01, _0x43ce0e) => {
    const _0x59e8ae = a0_0x46ce09;
    anime({
        ...GLOBAL_CFG,
        'targets': _0x2c3d01,
        'opacity': [0x0, 0x1, 0x0],
        'delay': 0x1f4,
        'duration': _0x43ce0e * 0x3e8,
        'translateY': getRndInteger(-0x1e, 0x1e),
        'translateX': getRndInteger(-0x1e, 0x1e),
        'easing': _0x59e8ae(0x204)
    });
});
let debreCollection = document[a0_0x46ce09(0x1ec)](a0_0x46ce09(0x207));
debreCollection[a0_0x46ce09(0x20d)]((_0x9e9853, _0x307aaf) => {
    const _0x3a7615 = a0_0x46ce09;
    anime({
        ...GLOBAL_CFG,
        'targets': _0x9e9853,
        'opacity': [0x0, 0x1, 0x0],
        'delay': _0x307aaf * 0x64,
        'duration': _0x307aaf * 0x64,
        'scaleX': 1.3,
        'scaleY': 1.3,
        'translateY': getRndInteger(-0xa, -0x28),
        'translateX': getRndInteger(-0x1e, 0x1e),
        'easing': _0x3a7615(0x1f9)
    });
});

function a0_0x2b16() {
    const _0x4ae533 = ['easeInOutElastic', '#flash2', '-5px', '#whiteFlash1', '#leftPalm', '781236xZIEWc', '#leftHand', '16sCxkcX', '584495UVFcfR', '2px\x2032px\x200', '#gear1\x20path', 'querySelectorAll', '20770WdImZu', '.swet', '#tongue', '#rightHand', '321784VkYFcc', '200px\x20200px\x200', '#hair1', '12RoMRgl', '233427NHmzLV', 'floor', 'random', '30px\x2030px\x200', 'linear', 'alternate', '#whiteFlash2', '38395JKOFSD', '100px\x20180px\x200', '#leftEye', '#paper1', 'easeInOutBack', '4px\x2025px\x200', '30px\x2010px\x200', 'easeOutQuint', 'easeInOutSine', '10px\x2039px\x200', '#gear2\x20path', '.debre', '586886injlBr', '#hair2', 'easeInOutQuart', '#head', '#brows', 'forEach', '-15px', '.spit', '6lQvcZv'];
    a0_0x2b16 = function() {
        return _0x4ae533;
    };
    return a0_0x2b16();
}
const GEAR1 = anime({
        ...GLOBAL_CFG,
        'targets': a0_0x46ce09(0x1eb),
        'rotate': 0x168,
        'easing': 'linear'
    }),
    GEAR2 = anime({
        ...GLOBAL_CFG,
        'targets': a0_0x46ce09(0x206),
        'rotate': -0x168,
        'easing': a0_0x46ce09(0x1f9)
    }),
    SHORT_ARROW = anime({
        ...GLOBAL_CFG,
        'targets': '#shortArrow',
        'rotate': 0x168,
        'duration': 0x2710,
        'easing': a0_0x46ce09(0x1f9),
        'transformOrigin': [a0_0x46ce09(0x201), '6px\x2027px\x200']
    }),
    LONG_ARROW = anime({
        ...GLOBAL_CFG,
        'targets': '#longArrow',
        'rotate': 0x168,
        'duration': 0x320,
        'easing': a0_0x46ce09(0x1f9),
        'transformOrigin': [a0_0x46ce09(0x1ea), '10px\x2039px\x200']
    }),
    LEFT_HAND = anime({
        ...GLOBAL_CFG,
        'targets': a0_0x46ce09(0x1e7),
        'rotate': 0x6,
        'duration': 0x3e8,
        'direction': 'alternate',
        'easing': a0_0x46ce09(0x20a),
        'transformOrigin': [a0_0x46ce09(0x1ea), a0_0x46ce09(0x205)]
    }),
    LEFT_PALM = anime({
        ...GLOBAL_CFG,
        'targets': a0_0x46ce09(0x1e5),
        'translateX': -0xa,
        'duration': 0x3e8,
        'direction': a0_0x46ce09(0x1fa),
        'easing': a0_0x46ce09(0x20a),
        'transformOrigin': [a0_0x46ce09(0x1ea), a0_0x46ce09(0x205)]
    }),
    RIGHT_HAND = anime({
        ...GLOBAL_CFG,
        'targets': a0_0x46ce09(0x1f0),
        'rotate': 0x6,
        'duration': 0x1f4,
        'direction': a0_0x46ce09(0x1fa),
        'easing': a0_0x46ce09(0x200),
        'transformOrigin': ['280px\x20120px\x200', '280px\x20120px\x200']
    }),
    RIGHT_PALM = anime({
        ...GLOBAL_CFG,
        'targets': '#rightPalm',
        'rotate': 0x6,
        'translateX': '-15px',
        'translateY': a0_0x46ce09(0x1e3),
        'duration': 0x1f4,
        'direction': a0_0x46ce09(0x1fa),
        'easing': 'easeInOutBack',
        'transformOrigin': [a0_0x46ce09(0x1f8), a0_0x46ce09(0x1f8)]
    }),
    PEN = anime({
        ...GLOBAL_CFG,
        'targets': '#pen',
        'rotate': 0x8,
        'translateX': a0_0x46ce09(0x20e),
        'translateY': a0_0x46ce09(0x1e3),
        'duration': 0x1f4,
        'direction': a0_0x46ce09(0x1fa),
        'easing': a0_0x46ce09(0x200),
        'transformOrigin': [a0_0x46ce09(0x1f8), a0_0x46ce09(0x1f8)]
    }),
    MOUTH = anime({
        ...GLOBAL_CFG,
        'targets': '#mounth',
        'rotate': 0x2,
        'scaleX': 1.1,
        'scaleY': [1.2, 0.9],
        'duration': 0x5dc,
        'direction': a0_0x46ce09(0x1fa),
        'easing': 'easeInOutElastic',
        'transformOrigin': [a0_0x46ce09(0x1f8), a0_0x46ce09(0x1f8)]
    }),
    TONGUE = anime({
        ...GLOBAL_CFG,
        'targets': a0_0x46ce09(0x1ef),
        'rotate': -0x5,
        'scaleX': 1.2,
        'scaleY': [1.1, 0.6],
        'duration': 0x5dc,
        'direction': a0_0x46ce09(0x1fa),
        'easing': a0_0x46ce09(0x1e1),
        'transformOrigin': [a0_0x46ce09(0x202), '30px\x2010px\x200']
    }),
    HEAD = anime({
        ...GLOBAL_CFG,
        'targets': a0_0x46ce09(0x20b),
        'rotate': -0x5,
        'duration': 0x5dc,
        'direction': a0_0x46ce09(0x1fa),
        'easing': 'easeInOutSine',
        'transformOrigin': [a0_0x46ce09(0x1f2), '200px\x20200px\x200']
    }),
    HAIR1 = anime({
        ...GLOBAL_CFG,
        'targets': a0_0x46ce09(0x1f3),
        'rotate': -0x3,
        'duration': 0x5dc,
        'direction': 'alternate',
        'easing': a0_0x46ce09(0x204),
        'transformOrigin': [a0_0x46ce09(0x1f2), a0_0x46ce09(0x1f2)]
    }),
    HAIR2 = anime({
        ...GLOBAL_CFG,
        'targets': a0_0x46ce09(0x209),
        'rotate': -0x4,
        'duration': 0x5dc,
        'direction': a0_0x46ce09(0x1fa),
        'easing': a0_0x46ce09(0x204),
        'transformOrigin': [a0_0x46ce09(0x1fd), a0_0x46ce09(0x1fd)]
    }),
    BRAW = anime({
        ...GLOBAL_CFG,
        'targets': a0_0x46ce09(0x20c),
        'rotate': -0xa,
        'duration': 0x1f4,
        'direction': a0_0x46ce09(0x1fa),
        'easing': a0_0x46ce09(0x204)
    }),
    EYE1 = anime({
        ...GLOBAL_CFG,
        'targets': a0_0x46ce09(0x1fe),
        'duration': 0x7d0,
        'scaleY': [0.4],
        'direction': 'alternate',
        'easing': a0_0x46ce09(0x204)
    }),
    EYE2 = anime({
        ...GLOBAL_CFG,
        'targets': '#rghtEye',
        'duration': 0x7d0,
        'scaleY': [0.6],
        'direction': a0_0x46ce09(0x1fa),
        'easing': a0_0x46ce09(0x204)
    }),
    FLASH1 = anime({
        ...GLOBAL_CFG,
        'targets': '#flash1',
        'duration': getRndInteger(0x190, 0x1f4),
        'scaleY': [0.6],
        'scaleX': [0.6],
        'rotate': getRndInteger(-0x4, 0x4),
        'opacity': [0x0, 0.7, 0x0],
        'easing': a0_0x46ce09(0x204)
    }),
    FLASH2 = anime({
        ...GLOBAL_CFG,
        'targets': a0_0x46ce09(0x1e2),
        'delay': 0x1f4,
        'duration': getRndInteger(0x190, 0x1f4),
        'scaleY': [0.6],
        'scaleX': [0.6],
        'rotate': getRndInteger(-0x4, 0x4),
        'opacity': [0x0, 0.7, 0x0],
        'easing': a0_0x46ce09(0x204)
    }),
    FLASH3 = anime({
        ...GLOBAL_CFG,
        'targets': a0_0x46ce09(0x1e4),
        'duration': 0x3e8,
        'opacity': [0x0, 0x0, 0.9, 0.7, 0.7, 0x0],
        'easing': a0_0x46ce09(0x203)
    }),
    FLASH4 = anime({
        ...GLOBAL_CFG,
        'targets': a0_0x46ce09(0x1fb),
        'duration': 0x384,
        'delay': 0xc8,
        'opacity': [0x0, 0.6, 0x0],
        'easing': a0_0x46ce09(0x1f9)
    }),
    PAPER = anime({
        ...GLOBAL_CFG,
        'targets': a0_0x46ce09(0x1ff),
        'delay': 0x1f4,
        'duration': 0xdac,
        'scaleY': [0x0, 0.6],
        'scaleX': [0x0, 0.6],
        'translateX': [-0xc8, -0x64],
        'translateY': [-0xc8, -0x64],
        'rotate': getRndInteger(-0x190, -0x64),
        'opacity': [0.3, 0.7, 0x0],
        'easing': a0_0x46ce09(0x204)
    });