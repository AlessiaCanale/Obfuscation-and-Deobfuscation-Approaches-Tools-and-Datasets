const a0_0x976e7c = a0_0x2c33;
(function(_0x1f3cc9, _0x3e92e0) {
    const _0x300e90 = a0_0x2c33,
        _0x420ecc = _0x1f3cc9();
    while (!![]) {
        try {
            const _0x39823d = parseInt(_0x300e90(0x1db)) / 0x1 + parseInt(_0x300e90(0x1cf)) / 0x2 + parseInt(_0x300e90(0x1c7)) / 0x3 * (parseInt(_0x300e90(0x1d6)) / 0x4) + -parseInt(_0x300e90(0x1b1)) / 0x5 * (-parseInt(_0x300e90(0x1c3)) / 0x6) + -parseInt(_0x300e90(0x1b4)) / 0x7 * (-parseInt(_0x300e90(0x1d4)) / 0x8) + parseInt(_0x300e90(0x1d1)) / 0x9 + -parseInt(_0x300e90(0x1d8)) / 0xa;
            if (_0x39823d === _0x3e92e0) break;
            else _0x420ecc['push'](_0x420ecc['shift']());
        } catch (_0x3ab6f6) {
            _0x420ecc['push'](_0x420ecc['shift']());
        }
    }
}(a0_0x55b9, 0x51634));
const cloudBoundary = document[a0_0x976e7c(0x1d0)]('.cloud-boundary'),
    bike = document['querySelector'](a0_0x976e7c(0x1c8)),
    bmContainer = document['querySelector']('#bm'),
    umbrellaAnimation = document['querySelector'](a0_0x976e7c(0x1e0)),
    rain = document[a0_0x976e7c(0x1d0)](a0_0x976e7c(0x1cd)),
    rainDropsTop = document[a0_0x976e7c(0x1d0)](a0_0x976e7c(0x1d3));
let rainDropsTopPosition = rain['clientHeight'] * -0x1;

function a0_0x55b9() {
    const _0x2fa266 = ['rain--active', '143374byuNEC', 'querySelector', '5492133HogxCB', 'transform', '.rain__drops-top', '8tvdNti', 'left', '130372DdgMvG', 'svg', '16646590oueZvc', 'remove', '.bike__marker', '205115XeEukH', 'top', 'requestAnimationFrame', 'classList', 'contains', '.umbrella-animation', 'play', '1335gdcNWc', 'light--active', 'setSpeed', '200102oMIHrf', 'keyup', 'add', 'clientHeight', '.cloud-boundary__marker', 'deg)', 'addEventListener', 'translateX(-50%)\x20rotate(', 'https://s3-us-west-2.amazonaws.com/s.cdpn.io/49240/bike.json', '.outline', 'setDirection', 'getBoundingClientRect', 'style', 'right', 'linear', '14802QywGWV', 'active', 'loadAnimation', 'keydown', '39ZZxqhV', '.bike', 'sqrt', 'keyCode', '.rain__drops-bottom', '.light', '.rain'];
    a0_0x55b9 = function() {
        return _0x2fa266;
    };
    return a0_0x55b9();
}
const rainDropsBottom = document[a0_0x976e7c(0x1d0)](a0_0x976e7c(0x1cb));
let rainDropsBottomPosition = 0x0,
    space;
const light = document['querySelector'](a0_0x976e7c(0x1cc));
var animation = bodymovin['loadAnimation']({
    'container': bmContainer,
    'renderer': a0_0x976e7c(0x1d7),
    'loop': !![],
    'autoplay': !![],
    'path': a0_0x976e7c(0x1bc)
});
animation[a0_0x976e7c(0x1b3)](0x1);
var umbrella = bodymovin[a0_0x976e7c(0x1c5)]({
    'container': umbrellaAnimation,
    'renderer': 'svg',
    'loop': ![],
    'autoplay': ![],
    'path': 'https://s3-us-west-2.amazonaws.com/s.cdpn.io/49240/umbrella.json'
});

function a0_0x2c33(_0x3d3a74, _0x497b73) {
    const _0x55b917 = a0_0x55b9();
    return a0_0x2c33 = function(_0x2c3386, _0xc86d4) {
        _0x2c3386 = _0x2c3386 - 0x1b0;
        let _0x3279cb = _0x55b917[_0x2c3386];
        return _0x3279cb;
    }, a0_0x2c33(_0x3d3a74, _0x497b73);
}
umbrella[a0_0x976e7c(0x1b3)](0x2);
var path = anime['path'](a0_0x976e7c(0x1bd)),
    motionPath = anime({
        'targets': a0_0x976e7c(0x1c8),
        'translateX': path('x'),
        'translateY': path('y'),
        'rotate': path('angle'),
        'easing': a0_0x976e7c(0x1c2),
        'duration': 0x3a98,
        'loop': !![]
    });
const bikeMarker = document[a0_0x976e7c(0x1d0)](a0_0x976e7c(0x1da)),
    cloudBoundaryMarker = document[a0_0x976e7c(0x1d0)](a0_0x976e7c(0x1b8)),
    detectCollision = function(_0x3c02e2, _0x27a77a) {
        const _0x2dc80e = a0_0x976e7c;
        return Math[_0x2dc80e(0x1c9)]((_0x27a77a[_0x2dc80e(0x1d5)] - _0x3c02e2[_0x2dc80e(0x1d5)]) * (_0x27a77a[_0x2dc80e(0x1d5)] - _0x3c02e2[_0x2dc80e(0x1d5)]) + (_0x27a77a['top'] - _0x3c02e2['top']) * (_0x27a77a['top'] - _0x3c02e2[_0x2dc80e(0x1dc)]));
    };
let cloudBoundaryAngle = 0x0,
    cloudBoundaryVelocity = 0x0,
    left = ![],
    right = ![],
    lastDirection = '';
document[a0_0x976e7c(0x1ba)](a0_0x976e7c(0x1c6), _0x15fcc9 => {
    const _0x269bad = a0_0x976e7c;
    if (_0x15fcc9[_0x269bad(0x1ca)] === 0x25) left = !![], lastDirection = _0x269bad(0x1d5);
    else {
        if (_0x15fcc9[_0x269bad(0x1ca)] === 0x27) left = !![], lastDirection = 'right';
        else _0x15fcc9[_0x269bad(0x1ca)] === 0x20 && (space = !![]);
    }
}), document['addEventListener'](a0_0x976e7c(0x1b5), _0x1d86bc => {
    const _0x3b1159 = a0_0x976e7c;
    if (_0x1d86bc[_0x3b1159(0x1ca)] === 0x25) left = ![];
    else {
        if (_0x1d86bc['keyCode'] === 0x27) left = ![];
        else _0x1d86bc[_0x3b1159(0x1ca)] === 0x20 && (space = ![]);
    }
});
const step = function() {
    const _0x11eef1 = a0_0x976e7c;
    (left || right) && (cloudBoundaryVelocity < 0x2 && (cloudBoundaryVelocity += 0.2));
    cloudBoundary[_0x11eef1(0x1c0)][_0x11eef1(0x1d2)] = _0x11eef1(0x1bb) + cloudBoundaryAngle + _0x11eef1(0x1b9);
    if (cloudBoundaryVelocity > 0x0) {
        if (lastDirection === 'left') cloudBoundaryAngle -= cloudBoundaryVelocity;
        else lastDirection === _0x11eef1(0x1c1) && (cloudBoundaryAngle += cloudBoundaryVelocity);
        cloudBoundaryVelocity -= 0.05;
    } else cloudBoundaryVelocity = 0x0;
    let _0x46f49f = detectCollision(bikeMarker[_0x11eef1(0x1bf)](), cloudBoundaryMarker[_0x11eef1(0x1bf)]());
    _0x46f49f < 0x3c ? light['classList'][_0x11eef1(0x1b6)](_0x11eef1(0x1b2)) : light[_0x11eef1(0x1de)][_0x11eef1(0x1df)](_0x11eef1(0x1b2)) && light[_0x11eef1(0x1de)]['remove']('light--active'), _0x46f49f < 0x50 && space ? !bmContainer[_0x11eef1(0x1de)][_0x11eef1(0x1df)](_0x11eef1(0x1c4)) && (bmContainer['classList']['add'](_0x11eef1(0x1c4)), umbrella[_0x11eef1(0x1be)](0x1), umbrella[_0x11eef1(0x1b0)]()) : bmContainer['classList'][_0x11eef1(0x1df)](_0x11eef1(0x1c4)) && (bmContainer[_0x11eef1(0x1de)][_0x11eef1(0x1d9)]('active'), umbrella[_0x11eef1(0x1be)](-0x1), umbrella['play']()), space ? !rain[_0x11eef1(0x1de)]['contains']('rain--active') && rain[_0x11eef1(0x1de)][_0x11eef1(0x1b6)]('rain--active') : rain[_0x11eef1(0x1de)][_0x11eef1(0x1df)]('rain--active') && rain[_0x11eef1(0x1de)]['remove'](_0x11eef1(0x1ce)), rainDropsTop['style'][_0x11eef1(0x1dc)] = rainDropsTopPosition + 'px', rainDropsBottom['style'][_0x11eef1(0x1dc)] = rainDropsBottomPosition + 'px', rainDropsTopPosition += 0x3, rainDropsBottomPosition += 0x3, rainDropsTopPosition >= 0x0 && (rainDropsTopPosition = rain[_0x11eef1(0x1b7)] * -0x1), rainDropsBottomPosition >= rain[_0x11eef1(0x1b7)] && (rainDropsBottomPosition = 0x0), window['requestAnimationFrame'](step);
};
window[a0_0x976e7c(0x1dd)](step);