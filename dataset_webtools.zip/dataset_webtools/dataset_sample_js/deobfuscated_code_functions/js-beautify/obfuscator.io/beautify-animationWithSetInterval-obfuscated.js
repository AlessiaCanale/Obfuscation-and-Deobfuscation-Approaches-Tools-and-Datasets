var a0_0x500f23 = a0_0x4274;
(function(_0x526768, _0x3871f2) {
    var _0x3bbe51 = a0_0x4274,
        _0x1c094e = _0x526768();
    while (!![]) {
        try {
            var _0x212455 = -parseInt(_0x3bbe51(0x1c5)) / 0x1 + parseInt(_0x3bbe51(0x1c0)) / 0x2 + -parseInt(_0x3bbe51(0x1c3)) / 0x3 + -parseInt(_0x3bbe51(0x1c4)) / 0x4 + -parseInt(_0x3bbe51(0x1c1)) / 0x5 * (parseInt(_0x3bbe51(0x1c8)) / 0x6) + -parseInt(_0x3bbe51(0x1bd)) / 0x7 * (-parseInt(_0x3bbe51(0x1cb)) / 0x8) + parseInt(_0x3bbe51(0x1c7)) / 0x9;
            if (_0x212455 === _0x3871f2) break;
            else _0x1c094e['push'](_0x1c094e['shift']());
        } catch (_0x2e1005) {
            _0x1c094e['push'](_0x1c094e['shift']());
        }
    }
}(a0_0x1760, 0x23ac6));
var box = document[a0_0x500f23(0x1c9)](a0_0x500f23(0x1bf)),
    frameRate = document['querySelector']('#frameRate'),
    distance = document[a0_0x500f23(0x1c9)](a0_0x500f23(0x1ca)),
    int;

function a0_0x4274(_0x2728ca, _0x572680) {
    var _0x176028 = a0_0x1760();
    return a0_0x4274 = function(_0x427419, _0x3ef958) {
        _0x427419 = _0x427419 - 0x1bd;
        var _0x171570 = _0x176028[_0x427419];
        return _0x171570;
    }, a0_0x4274(_0x2728ca, _0x572680);
}

function animate() {
    var _0x4e7b2d = 0x0;
    int = setInterval(function() {
        _0x4e7b2d = _0x4e7b2d > window['innerWidth'] ? 0x0 : _0x4e7b2d + Number(distance['value']), box['style']['marginLeft'] = _0x4e7b2d + 'px';
    }, 0x3e8 / Number(frameRate['value']));
}
animate();

function reset() {
    clearInterval(int), animate();
}

function a0_0x1760() {
    var _0x1ffa05 = ['#box', '150874XAQbJz', '5FefAVc', 'addEventListener', '576159CpyrGg', '145144RpSWhh', '8549eWXzjV', 'addEvenetListener', '640692HkqLWu', '101370nfeMYL', 'querySelector', '#distance', '44048IuHnNK', '322ZaEZQW', 'change'];
    a0_0x1760 = function() {
        return _0x1ffa05;
    };
    return a0_0x1760();
}
frameRate[a0_0x500f23(0x1c2)](a0_0x500f23(0x1be), reset), distance[a0_0x500f23(0x1c6)](a0_0x500f23(0x1be), reset);