(function(_0x23fe75, _0x152e36) {
    const _0x3784e3 = a0_0x2636,
        _0x29d820 = _0x23fe75();
    while (!![]) {
        try {
            const _0x14af4a = -parseInt(_0x3784e3(0x133)) / 0x1 + parseInt(_0x3784e3(0x13c)) / 0x2 + parseInt(_0x3784e3(0x13a)) / 0x3 + parseInt(_0x3784e3(0x138)) / 0x4 + -parseInt(_0x3784e3(0x131)) / 0x5 * (-parseInt(_0x3784e3(0x132)) / 0x6) + parseInt(_0x3784e3(0x137)) / 0x7 + parseInt(_0x3784e3(0x139)) / 0x8 * (-parseInt(_0x3784e3(0x135)) / 0x9);
            if (_0x14af4a === _0x152e36) break;
            else _0x29d820['push'](_0x29d820['shift']());
        } catch (_0x1519da) {
            _0x29d820['push'](_0x29d820['shift']());
        }
    }
}(a0_0x5285, 0x6e947));

function calculateCosine(_0x34f1cb) {
    const _0x4c7be4 = a0_0x2636,
        _0x54f4cc = _0x34f1cb * (Math['PI'] / 0xb4),
        _0x153e9f = Math[_0x4c7be4(0x136)](_0x54f4cc);
    return console[_0x4c7be4(0x13b)]('Angle\x20in\x20Degrees:\x20' + _0x34f1cb + '°'), console['log'](_0x4c7be4(0x134) + _0x153e9f), _0x153e9f;
}
const angle = 0x7d;

function a0_0x2636(_0x2fc851, _0x25ac05) {
    const _0x5285ef = a0_0x5285();
    return a0_0x2636 = function(_0x2636d6, _0x23accc) {
        _0x2636d6 = _0x2636d6 - 0x131;
        let _0x231300 = _0x5285ef[_0x2636d6];
        return _0x231300;
    }, a0_0x2636(_0x2fc851, _0x25ac05);
}
calculateCosine(angle);

function a0_0x5285() {
    const _0x5e463b = ['111912Depppi', '5SXUMSA', '161178qLgJXw', '142433tYtqun', 'Cosine\x20Value:\x20', '11123775AEeByV', 'cos', '4420703UwikBk', '1752548mZQkkU', '8odtstC', '2036574lblTKh', 'log'];
    a0_0x5285 = function() {
        return _0x5e463b;
    };
    return a0_0x5285();
}