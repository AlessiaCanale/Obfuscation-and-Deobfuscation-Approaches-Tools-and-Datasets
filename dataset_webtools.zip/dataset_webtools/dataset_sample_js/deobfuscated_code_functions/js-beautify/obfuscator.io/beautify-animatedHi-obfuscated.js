const a0_0x10e179 = a0_0x5c7a;
(function(_0x107a5d, _0x389fd4) {
    const _0x4ff13f = a0_0x5c7a,
        _0x265591 = _0x107a5d();
    while (!![]) {
        try {
            const _0x281944 = -parseInt(_0x4ff13f(0x190)) / 0x1 * (-parseInt(_0x4ff13f(0x193)) / 0x2) + parseInt(_0x4ff13f(0x18b)) / 0x3 * (parseInt(_0x4ff13f(0x186)) / 0x4) + -parseInt(_0x4ff13f(0x196)) / 0x5 + parseInt(_0x4ff13f(0x187)) / 0x6 + parseInt(_0x4ff13f(0x198)) / 0x7 + parseInt(_0x4ff13f(0x18d)) / 0x8 + parseInt(_0x4ff13f(0x194)) / 0x9 * (-parseInt(_0x4ff13f(0x18f)) / 0xa);
            if (_0x281944 === _0x389fd4) break;
            else _0x265591['push'](_0x265591['shift']());
        } catch (_0x2ffd21) {
            _0x265591['push'](_0x265591['shift']());
        }
    }
}(a0_0x2dc4, 0x64535));

function a0_0x2dc4() {
    const _0x1639bb = ['743187lcJIfB', 'timeline', '2946920CpzffI', '.text-3', '15067790JIFyrY', '877vPTkER', '.text-5', '+=500', '44BgiOOU', '9IBVEVg', 'querySelector', '99440GguljY', '.text-1', '1276968NkbnpQ', '12dzJtLE', '3745980hspLqL', 'easeOutExpo', 'alternate', 'add'];
    a0_0x2dc4 = function() {
        return _0x1639bb;
    };
    return a0_0x2dc4();
}

function a0_0x5c7a(_0x1b83b5, _0x268f87) {
    const _0x2dc457 = a0_0x2dc4();
    return a0_0x5c7a = function(_0x5c7aeb, _0x22f673) {
        _0x5c7aeb = _0x5c7aeb - 0x186;
        let _0x1adf0a = _0x2dc457[_0x5c7aeb];
        return _0x1adf0a;
    }, a0_0x5c7a(_0x1b83b5, _0x268f87);
}
let lineOne, lineTwo, lineThree, lineFour, lineFive;
lineOne = document[a0_0x10e179(0x195)](a0_0x10e179(0x197)), lineTwo = document[a0_0x10e179(0x195)]('.text-2'), lineThree = document[a0_0x10e179(0x195)](a0_0x10e179(0x18e)), lineFour = document[a0_0x10e179(0x195)]('.text-4'), lineFive = document[a0_0x10e179(0x195)](a0_0x10e179(0x191));
let tl = anime[a0_0x10e179(0x18c)]({
    'delay': 0x0,
    'easing': a0_0x10e179(0x188),
    'direction': a0_0x10e179(0x189),
    'loop': !![]
});
tl['add']({
    'duration': 0x2bc,
    'targets': lineOne,
    'translateX': -0x4b,
    'opacity': 0x0
}, 0x190), tl[a0_0x10e179(0x18a)]({
    'duration': 0x2bc,
    'targets': lineOne,
    'height': 0xaf,
    'opacity': 0x1
}), tl[a0_0x10e179(0x18a)]({
    'duration': 0x64,
    'targets': lineTwo,
    'translateX': -0x4b,
    'opacity': 0x0
}, a0_0x10e179(0x192)), tl['add']({
    'duration': 0x2bc,
    'targets': lineTwo,
    'width': 0x96,
    'opacity': 0x1
}), tl[a0_0x10e179(0x18a)]({
    'duration': 0x2bc,
    'targets': lineThree,
    'height': 0xc8,
    'opacity': 0x1
}), tl[a0_0x10e179(0x18a)]({
    'duration': 0x64,
    'targets': lineFour,
    'translateX': 0x4b,
    'opacity': 0x0
}), tl[a0_0x10e179(0x18a)]({
    'duration': 0x2bc,
    'translateY': 0x2d,
    'translateX': 0x4b,
    'targets': lineFour,
    'height': 0x64,
    'opacity': 0x1
}), tl['add']({
    'duration': 0x64,
    'targets': lineFive,
    'translateX': 0x4b,
    'opacity': 0x0
}), tl[a0_0x10e179(0x18a)]({
    'duration': 0x2bc,
    'targets': lineFive,
    'translateX': 0x4b,
    'translateY': -0x3c,
    'opacity': 0x1
});