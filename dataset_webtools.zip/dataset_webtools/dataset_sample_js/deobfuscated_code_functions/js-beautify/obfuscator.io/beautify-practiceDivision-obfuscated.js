(function(_0x513132, _0x2c1f3d) {
    var _0xcbdd77 = a0_0x3e4d,
        _0x139e81 = _0x513132();
    while (!![]) {
        try {
            var _0x53e324 = parseInt(_0xcbdd77(0xdf)) / 0x1 * (parseInt(_0xcbdd77(0xe3)) / 0x2) + parseInt(_0xcbdd77(0xe4)) / 0x3 + -parseInt(_0xcbdd77(0xe2)) / 0x4 * (parseInt(_0xcbdd77(0xdc)) / 0x5) + -parseInt(_0xcbdd77(0xe8)) / 0x6 * (-parseInt(_0xcbdd77(0xe5)) / 0x7) + -parseInt(_0xcbdd77(0xd8)) / 0x8 * (parseInt(_0xcbdd77(0xdd)) / 0x9) + parseInt(_0xcbdd77(0xe9)) / 0xa + -parseInt(_0xcbdd77(0xe7)) / 0xb * (-parseInt(_0xcbdd77(0xda)) / 0xc);
            if (_0x53e324 === _0x2c1f3d) break;
            else _0x139e81['push'](_0x139e81['shift']());
        } catch (_0x561492) {
            _0x139e81['push'](_0x139e81['shift']());
        }
    }
}(a0_0x1e74, 0x1b2af));

function practiceDivision() {
    var _0x530d20 = a0_0x3e4d,
        _0x4541ef = Math[_0x530d20(0xe1)](Math[_0x530d20(0xdb)]() * 0x3e9),
        _0x2457e2 = Math[_0x530d20(0xe1)](Math[_0x530d20(0xdb)]() * 0x3e9);
    while (_0x2457e2 === 0x0) {
        _0x2457e2 = Math[_0x530d20(0xe1)](Math[_0x530d20(0xdb)]() * 0x3e9);
    }
    console[_0x530d20(0xe0)](_0x4541ef + _0x530d20(0xd9) + _0x2457e2);
    var _0x1511d2 = _0x4541ef / _0x2457e2;
    console[_0x530d20(0xe0)]('Try\x20to\x20solve\x20the\x20division\x20of\x20the\x20two\x20random\x20numbers\x20and\x20then\x20check\x20if\x20the\x20result\x20is\x20correct\x20with\x20the\x20number\x20that\x20will\x20appear\x20in\x205\x20seconds\x20:)'), setTimeout(function() {
        var _0x186cc8 = _0x530d20;
        console[_0x186cc8(0xe0)](_0x186cc8(0xde) + _0x4541ef + '\x20divided\x20by\x20' + _0x2457e2 + _0x186cc8(0xe6) + _0x1511d2);
    }, 0x1388);
}

function a0_0x3e4d(_0x3c3c51, _0x39842e) {
    var _0x1e741b = a0_0x1e74();
    return a0_0x3e4d = function(_0x3e4d74, _0x2b4c05) {
        _0x3e4d74 = _0x3e4d74 - 0xd8;
        var _0xbca170 = _0x1e741b[_0x3e4d74];
        return _0xbca170;
    }, a0_0x3e4d(_0x3c3c51, _0x39842e);
}
practiceDivision();

function a0_0x1e74() {
    var _0x3e7f9c = ['4PLdadt', '274Tbcujm', '158637zExxNu', '805YVRnlJ', '\x20is:\x20', '11npEQOJ', '2118OFWDdF', '1115050njwHgp', '256344RpgxYM', '\x20/\x20', '1793892kxqydg', 'random', '991500rzVLaB', '27DzWFCZ', 'The\x20result\x20of\x20', '374FAzYsg', 'log', 'floor'];
    a0_0x1e74 = function() {
        return _0x3e7f9c;
    };
    return a0_0x1e74();
}