(function(_0x334046, _0x2d2190) {
    const _0x543743 = a0_0x3981,
        _0x38f2d7 = _0x334046();
    while (!![]) {
        try {
            const _0x2abddc = -parseInt(_0x543743(0x205)) / 0x1 + -parseInt(_0x543743(0x20c)) / 0x2 * (-parseInt(_0x543743(0x1f6)) / 0x3) + parseInt(_0x543743(0x216)) / 0x4 * (-parseInt(_0x543743(0x211)) / 0x5) + parseInt(_0x543743(0x20a)) / 0x6 * (parseInt(_0x543743(0x215)) / 0x7) + parseInt(_0x543743(0x20e)) / 0x8 * (parseInt(_0x543743(0x1f3)) / 0x9) + parseInt(_0x543743(0x1ff)) / 0xa * (-parseInt(_0x543743(0x208)) / 0xb) + parseInt(_0x543743(0x1f7)) / 0xc * (parseInt(_0x543743(0x210)) / 0xd);
            if (_0x2abddc === _0x2d2190) break;
            else _0x38f2d7['push'](_0x38f2d7['shift']());
        } catch (_0x4052af) {
            _0x38f2d7['push'](_0x38f2d7['shift']());
        }
    }
}(a0_0x2884, 0x6e8b4));

function findWordsStartingEndingWithSameLetter(_0x59624a) {
    const _0x5907c7 = a0_0x3981,
        _0x1b4c69 = _0x59624a[_0x5907c7(0x20f)]('\x20'),
        _0x6c9919 = {
            'a': 'banana',
            'b': _0x5907c7(0x213),
            'c': _0x5907c7(0x1fa),
            'd': 'land',
            'e': 'apple',
            'f': _0x5907c7(0x1f4),
            'g': _0x5907c7(0x1f9),
            'h': _0x5907c7(0x217),
            'i': _0x5907c7(0x1f8),
            'j': 'dj',
            'k': _0x5907c7(0x218),
            'l': _0x5907c7(0x1fc),
            'm': 'swim',
            'n': _0x5907c7(0x203),
            'o': _0x5907c7(0x200),
            'p': 'cup',
            'q': 'faq',
            'r': _0x5907c7(0x20b),
            's': _0x5907c7(0x214),
            't': 'basket',
            'u': _0x5907c7(0x204),
            'v': _0x5907c7(0x212),
            'w': _0x5907c7(0x1fb),
            'x': _0x5907c7(0x207),
            'y': _0x5907c7(0x1fd),
            'z': _0x5907c7(0x202)
        },
        _0x388d15 = _0x1b4c69[_0x5907c7(0x206)](_0x4220f8 => {
            const _0x48e5e1 = _0x5907c7,
                _0x572d69 = _0x4220f8[_0x48e5e1(0x20d)](0x0)[_0x48e5e1(0x1fe)]();
            return _0x6c9919[_0x572d69] ? _0x6c9919[_0x572d69] : _0x4220f8;
        }),
        _0x53719b = _0x1b4c69[_0x5907c7(0x209)]('\x20'),
        _0xfda054 = _0x388d15[_0x5907c7(0x209)]('\x20');
    console[_0x5907c7(0x1f5)](_0x5907c7(0x201)), console[_0x5907c7(0x1f5)](_0x53719b), console[_0x5907c7(0x1f5)](_0x5907c7(0x219)), console[_0x5907c7(0x1f5)](_0xfda054);
}

function a0_0x2884() {
    const _0x53ce98 = ['2199240EjxqFY', 'grief', 'log', '75QJPWaZ', '3048sSEDIw', 'ski', 'dog', 'historic', 'saw', 'owl', 'happy', 'toLowerCase', '20obrjzZ', 'burrito', 'Original\x20Text:', 'jazz', 'mountain', 'menu', '828459BuQxpH', 'map', 'fox', '4460489ZbDLoR', 'join', '12iOthQL', 'bear', '24340vIBpNR', 'charAt', '16hgLYnJ', 'split', '75439nPByPU', '5BZlXqZ', 'suv', 'carob', 'bus', '676879zHiDtt', '1472324OKJLfh', 'beach', 'desk', 'Modified\x20Text:'];
    a0_0x2884 = function() {
        return _0x53ce98;
    };
    return a0_0x2884();
}
const text = 'apple\x20saw\x20bus\x20dog\x20cat\x20fox\x20land\x20ski\x20owl\x20banana\x20wave\x20mountain\x20bear\x20jazz\x20wave\x20basket';

function a0_0x3981(_0x2684fb, _0x59779c) {
    const _0x288425 = a0_0x2884();
    return a0_0x3981 = function(_0x398148, _0x4e0ad1) {
        _0x398148 = _0x398148 - 0x1f3;
        let _0x34f3f6 = _0x288425[_0x398148];
        return _0x34f3f6;
    }, a0_0x3981(_0x2684fb, _0x59779c);
}
findWordsStartingEndingWithSameLetter(text);