const a0_0x13a6ed = a0_0x50c3;
(function(_0x4b2f9e, _0x5bd33e) {
    const _0x1a061c = a0_0x50c3,
        _0x34228c = _0x4b2f9e();
    while (!![]) {
        try {
            const _0x47e0e2 = -parseInt(_0x1a061c(0xa5)) / 0x1 * (-parseInt(_0x1a061c(0x9e)) / 0x2) + -parseInt(_0x1a061c(0xa6)) / 0x3 * (-parseInt(_0x1a061c(0xab)) / 0x4) + -parseInt(_0x1a061c(0xad)) / 0x5 * (parseInt(_0x1a061c(0xa8)) / 0x6) + -parseInt(_0x1a061c(0xa1)) / 0x7 + parseInt(_0x1a061c(0xa9)) / 0x8 + -parseInt(_0x1a061c(0xa3)) / 0x9 + -parseInt(_0x1a061c(0xa7)) / 0xa * (-parseInt(_0x1a061c(0x9d)) / 0xb);
            if (_0x47e0e2 === _0x5bd33e) break;
            else _0x34228c['push'](_0x34228c['shift']());
        } catch (_0x39ed80) {
            _0x34228c['push'](_0x34228c['shift']());
        }
    }
}(a0_0x3ed3, 0x1898c));

function printFirstSentenceBeforePunctuation(_0x3a03df) {
    const _0x34a828 = a0_0x50c3,
        _0x4bf008 = /[^.!?]+[.!?]/,
        _0x3a3bc0 = _0x3a03df[_0x34a828(0x9f)](_0x4bf008);
    if (_0x3a3bc0) {
        const _0x57b6de = _0x3a3bc0[0x0][_0x34a828(0xa4)]();
        console['log'](_0x34a828(0xac), _0x3a03df), console[_0x34a828(0xa0)](_0x34a828(0xaa), _0x57b6de);
    } else console[_0x34a828(0xa0)]('No\x20sentence\x20found\x20before\x20a\x20punctuation\x20mark.');
}
const inputText = a0_0x13a6ed(0xa2);

function a0_0x50c3(_0x5ac014, _0x545903) {
    const _0x3ed3d1 = a0_0x3ed3();
    return a0_0x50c3 = function(_0x50c320, _0x5db533) {
        _0x50c320 = _0x50c320 - 0x9d;
        let _0x5c3a5b = _0x3ed3d1[_0x50c320];
        return _0x5c3a5b;
    }, a0_0x50c3(_0x5ac014, _0x545903);
}

function a0_0x3ed3() {
    const _0x1b1949 = ['1764657AynlaX', 'trim', '6662NwQVmf', '32853nEnEfo', '10TtgNXQ', '1884IaDtgD', '58392VHNgcl', 'First\x20Sentence\x20Before\x20Punctuation:\x20', '60mxAiRe', 'Input\x20Text:\x20', '2285zLgoGi', '3112615BvCFUe', '6QugDag', 'match', 'log', '239372gPZVKE', 'This\x20is\x20a\x20sample\x20text.\x20It\x20contains\x20multiple\x20sentences!\x20Let\x27s\x20see\x20which\x20one\x20gets\x20printed.'];
    a0_0x3ed3 = function() {
        return _0x1b1949;
    };
    return a0_0x3ed3();
}
printFirstSentenceBeforePunctuation(inputText);