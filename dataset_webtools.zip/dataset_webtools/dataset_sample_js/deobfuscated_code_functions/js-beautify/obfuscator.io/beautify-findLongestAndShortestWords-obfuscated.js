function a0_0x2ad0() {
    const _0x588ebe = ['length', 'Longest\x20Word:\x20', '23807wgqxky', '92485XjMiPw', '344HxZJLR', 'Shortest\x20Word:\x20', '598110GmjEol', '12ZNeopB', '125205FoTvlo', '88TqXbIp', 'log', 'forEach', '3HqzFNN', 'Lorem\x20ipsum\x20dolor\x20sit\x20amet,\x20consectetur\x20adipiscing\x20elit.\x20Sed\x20do\x20eiusmod\x20tempor\x20incididunt\x20ut\x20labore\x20et\x20dolore\x20magna\x20aliqua.\x20Ut\x20enim\x20ad\x20minim\x20veniam,\x20100\x20words\x20in\x20total.', '1512018QskOTj', '351850YnZJat', 'match', '2078442EUOBKj'];
    a0_0x2ad0 = function() {
        return _0x588ebe;
    };
    return a0_0x2ad0();
}
const a0_0x4b892a = a0_0x51c1;

function a0_0x51c1(_0x524e1d, _0x5c17c9) {
    const _0x2ad032 = a0_0x2ad0();
    return a0_0x51c1 = function(_0x51c12b, _0x2ec8dd) {
        _0x51c12b = _0x51c12b - 0x128;
        let _0x4fdc77 = _0x2ad032[_0x51c12b];
        return _0x4fdc77;
    }, a0_0x51c1(_0x524e1d, _0x5c17c9);
}(function(_0x11b743, _0x42429f) {
    const _0x492e8e = a0_0x51c1,
        _0x387dcf = _0x11b743();
    while (!![]) {
        try {
            const _0x309777 = parseInt(_0x492e8e(0x137)) / 0x1 + -parseInt(_0x492e8e(0x128)) / 0x2 * (-parseInt(_0x492e8e(0x12e)) / 0x3) + -parseInt(_0x492e8e(0x129)) / 0x4 * (parseInt(_0x492e8e(0x12a)) / 0x5) + parseInt(_0x492e8e(0x130)) / 0x6 + parseInt(_0x492e8e(0x136)) / 0x7 * (parseInt(_0x492e8e(0x138)) / 0x8) + -parseInt(_0x492e8e(0x133)) / 0x9 + parseInt(_0x492e8e(0x131)) / 0xa * (-parseInt(_0x492e8e(0x12b)) / 0xb);
            if (_0x309777 === _0x42429f) break;
            else _0x387dcf['push'](_0x387dcf['shift']());
        } catch (_0xf1b6b7) {
            _0x387dcf['push'](_0x387dcf['shift']());
        }
    }
}(a0_0x2ad0, 0x31605));

function findLongestAndShortestWords(_0x4fb2dc) {
    const _0x7c7765 = a0_0x51c1,
        _0x37b9a6 = _0x4fb2dc[_0x7c7765(0x132)](/\w+/g);
    let _0x3407e6 = '',
        _0x917393 = _0x37b9a6[0x0];
    return _0x37b9a6[_0x7c7765(0x12d)](_0x3df32b => {
        const _0x4a65e6 = _0x7c7765;
        _0x3df32b[_0x4a65e6(0x134)] > _0x3407e6[_0x4a65e6(0x134)] && (_0x3407e6 = _0x3df32b), _0x3df32b['length'] < _0x917393['length'] && (_0x917393 = _0x3df32b);
    }), console[_0x7c7765(0x12c)]('Original\x20Text:\x20' + _0x4fb2dc), console[_0x7c7765(0x12c)](_0x7c7765(0x135) + _0x3407e6), console[_0x7c7765(0x12c)](_0x7c7765(0x139) + _0x917393), {
        'text': _0x4fb2dc,
        'longestWord': _0x3407e6,
        'shortestWord': _0x917393
    };
}
const text = a0_0x4b892a(0x12f);
findLongestAndShortestWords(text);