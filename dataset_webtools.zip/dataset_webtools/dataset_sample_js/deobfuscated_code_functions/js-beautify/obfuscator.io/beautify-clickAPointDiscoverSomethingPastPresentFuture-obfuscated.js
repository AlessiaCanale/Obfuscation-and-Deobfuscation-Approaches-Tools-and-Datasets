function a0_0x3b94() {
    const _0x220d9d = ['394462QtiEXX', '57798UoiKVw', '30501TtMGQP', '80BKYrlP', '3101434MVaxhH', '534426ytBbgw', 'getElementById', 'wisdomContainer', 'pastPoint', '25XkvyCS', 'Learn\x20from\x20yesterday,\x20live\x20for\x20today,\x20hope\x20for\x20tomorrow.', 'The\x20future\x20belongs\x20to\x20those\x20who\x20believe\x20in\x20the\x20beauty\x20of\x20their\x20dreams.', 'presentPoint', 'future', 'futurePoint', '8XsJSkB', 'addEventListener', 'present', '143221TsbPij', 'click', 'past', '3800740zDpFrL'];
    a0_0x3b94 = function() {
        return _0x220d9d;
    };
    return a0_0x3b94();
}

function a0_0x3931(_0x43c945, _0x330606) {
    const _0x3b949b = a0_0x3b94();
    return a0_0x3931 = function(_0x3931a7, _0x4798d8) {
        _0x3931a7 = _0x3931a7 - 0x1d1;
        let _0x4be385 = _0x3b949b[_0x3931a7];
        return _0x4be385;
    }, a0_0x3931(_0x43c945, _0x330606);
}(function(_0x12a520, _0x40711c) {
    const _0x53fe38 = a0_0x3931,
        _0x20fd2d = _0x12a520();
    while (!![]) {
        try {
            const _0x10a07b = -parseInt(_0x53fe38(0x1e5)) / 0x1 + parseInt(_0x53fe38(0x1d3)) / 0x2 + -parseInt(_0x53fe38(0x1d8)) / 0x3 * (-parseInt(_0x53fe38(0x1e2)) / 0x4) + parseInt(_0x53fe38(0x1dc)) / 0x5 * (-parseInt(_0x53fe38(0x1d4)) / 0x6) + -parseInt(_0x53fe38(0x1d7)) / 0x7 + -parseInt(_0x53fe38(0x1d6)) / 0x8 * (parseInt(_0x53fe38(0x1d5)) / 0x9) + parseInt(_0x53fe38(0x1d2)) / 0xa;
            if (_0x10a07b === _0x40711c) break;
            else _0x20fd2d['push'](_0x20fd2d['shift']());
        } catch (_0x4ffebe) {
            _0x20fd2d['push'](_0x20fd2d['shift']());
        }
    }
}(a0_0x3b94, 0x40c23));

function clickAPointDiscoverSomethingPastPresentFuture() {
    const _0x44d417 = a0_0x3931;

    function _0x178282(_0x5d6299) {
        const _0x4d9444 = a0_0x3931;
        let _0x3b68ef;
        switch (_0x5d6299) {
            case _0x4d9444(0x1d1):
                _0x3b68ef = _0x4d9444(0x1dd);
                break;
            case _0x4d9444(0x1e4):
                _0x3b68ef = 'The\x20only\x20time\x20you\x20have\x20is\x20now.';
                break;
            case _0x4d9444(0x1e0):
                _0x3b68ef = _0x4d9444(0x1de);
                break;
            default:
                _0x3b68ef = 'Click\x20a\x20point\x20above\x20to\x20discover\x20wisdom...';
        }
        document[_0x4d9444(0x1d9)](_0x4d9444(0x1da))['textContent'] = _0x3b68ef;
    }
    document[_0x44d417(0x1d9)](_0x44d417(0x1db))[_0x44d417(0x1e3)]('click', function() {
        _0x178282('past');
    }), document[_0x44d417(0x1d9)](_0x44d417(0x1df))['addEventListener'](_0x44d417(0x1e6), function() {
        _0x178282('present');
    }), document[_0x44d417(0x1d9)](_0x44d417(0x1e1))['addEventListener']('click', function() {
        const _0x2352f1 = _0x44d417;
        _0x178282(_0x2352f1(0x1e0));
    });
}