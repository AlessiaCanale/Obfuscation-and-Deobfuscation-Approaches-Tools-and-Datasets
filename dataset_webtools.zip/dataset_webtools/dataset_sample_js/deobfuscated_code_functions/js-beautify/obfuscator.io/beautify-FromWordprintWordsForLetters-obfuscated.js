const a0_0x13ac78 = a0_0x4ed2;

function a0_0x4ed2(_0x619e37, _0x5b634a) {
    const _0xa5d9fd = a0_0xa5d9();
    return a0_0x4ed2 = function(_0x4ed237, _0x55761e) {
        _0x4ed237 = _0x4ed237 - 0x152;
        let _0x3552d8 = _0xa5d9fd[_0x4ed237];
        return _0x3552d8;
    }, a0_0x4ed2(_0x619e37, _0x5b634a);
}

function a0_0xa5d9() {
    const _0x15476f = ['36Rheufd', 'Jellyfish', 'Zebra', 'balance', '859742BMpmzh', 'Horse', 'Xylophone', 'Snake', 'startsWith', 'Tiger', 'Umbrella', 'Cat', 'Rabbit', 'Icecream', 'entries', 'Elephant', 'Vase', '2411562cRJRUM', 'Queen', '438036DNqPXA', 'Banana', 'Fox', '167045HrZUhf', 'Whale', 'Giraffe', '3416310qPqoqf', 'split', 'Kangaroo', 'Dog', 'Penguin', 'Yak', '8ogrdhm', '6483190CMNLRg', 'Words\x20starting\x20with\x20\x22', '3041234qyojut', 'forEach', '1iaDaJC'];
    a0_0xa5d9 = function() {
        return _0x15476f;
    };
    return a0_0xa5d9();
}(function(_0x23dadd, _0x70e0ed) {
    const _0x2d1213 = a0_0x4ed2,
        _0x4f4925 = _0x23dadd();
    while (!![]) {
        try {
            const _0x2c50c3 = parseInt(_0x2d1213(0x16d)) / 0x1 * (-parseInt(_0x2d1213(0x172)) / 0x2) + -parseInt(_0x2d1213(0x15c)) / 0x3 + -parseInt(_0x2d1213(0x16e)) / 0x4 * (-parseInt(_0x2d1213(0x15f)) / 0x5) + parseInt(_0x2d1213(0x15a)) / 0x6 + -parseInt(_0x2d1213(0x16b)) / 0x7 * (-parseInt(_0x2d1213(0x168)) / 0x8) + parseInt(_0x2d1213(0x162)) / 0x9 + -parseInt(_0x2d1213(0x169)) / 0xa;
            if (_0x2c50c3 === _0x70e0ed) break;
            else _0x4f4925['push'](_0x4f4925['shift']());
        } catch (_0xdf641b) {
            _0x4f4925['push'](_0x4f4925['shift']());
        }
    }
}(a0_0xa5d9, 0x4766a));
const alphabetWords = {
    'A': 'Apple',
    'B': a0_0x13ac78(0x15d),
    'C': a0_0x13ac78(0x154),
    'D': a0_0x13ac78(0x165),
    'E': a0_0x13ac78(0x158),
    'F': a0_0x13ac78(0x15e),
    'G': a0_0x13ac78(0x161),
    'H': a0_0x13ac78(0x173),
    'I': a0_0x13ac78(0x156),
    'J': a0_0x13ac78(0x16f),
    'K': a0_0x13ac78(0x164),
    'L': 'Lion',
    'M': 'Monkey',
    'N': 'Noodle',
    'O': 'Orange',
    'P': a0_0x13ac78(0x166),
    'Q': a0_0x13ac78(0x15b),
    'R': a0_0x13ac78(0x155),
    'S': a0_0x13ac78(0x175),
    'T': a0_0x13ac78(0x152),
    'U': a0_0x13ac78(0x153),
    'V': a0_0x13ac78(0x159),
    'W': a0_0x13ac78(0x160),
    'X': a0_0x13ac78(0x174),
    'Y': a0_0x13ac78(0x167),
    'Z': a0_0x13ac78(0x170)
};

function FromWordprintWordsForLetters(_0x2ac9a1) {
    const _0x4adef4 = a0_0x13ac78,
        _0x451628 = _0x2ac9a1['toUpperCase']()[_0x4adef4(0x163)]('');
    _0x451628[_0x4adef4(0x16c)](_0x1b97aa => {
        const _0x46f244 = _0x4adef4,
            _0x368e63 = Object[_0x46f244(0x157)](alphabetWords)['filter'](([_0x4ab4b2, _0x39b5d6]) => _0x39b5d6[_0x46f244(0x176)](_0x1b97aa))['map'](([_0x2fd133, _0xbd6190]) => _0xbd6190);
        console['log'](_0x46f244(0x16a) + _0x1b97aa + '\x22:\x20' + _0x368e63['join'](',\x20'));
    });
}
FromWordprintWordsForLetters(a0_0x13ac78(0x171));