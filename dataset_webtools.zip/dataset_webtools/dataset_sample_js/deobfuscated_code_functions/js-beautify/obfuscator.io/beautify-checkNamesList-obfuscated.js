const a0_0x2c89ca = a0_0x2425;
(function(_0x5888d8, _0x12517d) {
    const _0x1ada20 = a0_0x2425,
        _0x2af753 = _0x5888d8();
    while (!![]) {
        try {
            const _0x43ce40 = -parseInt(_0x1ada20(0x103)) / 0x1 + parseInt(_0x1ada20(0xff)) / 0x2 + -parseInt(_0x1ada20(0x100)) / 0x3 * (-parseInt(_0x1ada20(0x108)) / 0x4) + parseInt(_0x1ada20(0x10c)) / 0x5 + parseInt(_0x1ada20(0x118)) / 0x6 * (-parseInt(_0x1ada20(0x10d)) / 0x7) + -parseInt(_0x1ada20(0x119)) / 0x8 * (-parseInt(_0x1ada20(0x11b)) / 0x9) + parseInt(_0x1ada20(0x115)) / 0xa;
            if (_0x43ce40 === _0x12517d) break;
            else _0x2af753['push'](_0x2af753['shift']());
        } catch (_0x5ca64d) {
            _0x2af753['push'](_0x2af753['shift']());
        }
    }
}(a0_0x21f9, 0x8a3c2));

function checkNamesList(_0x234915) {
    const _0x282ad5 = a0_0x2425,
        _0x13f7c4 = [_0x282ad5(0x10e), 'Jane\x20Smith', _0x282ad5(0x114), _0x282ad5(0x106), 'Emma\x20Davis', _0x282ad5(0x109), _0x282ad5(0x113), 'David\x20Thompson', _0x282ad5(0x107), _0x282ad5(0x10f), _0x282ad5(0xfd), _0x282ad5(0x10a), _0x282ad5(0x111), _0x282ad5(0x116), _0x282ad5(0xfe), 'James\x20Martin', _0x282ad5(0x102), _0x282ad5(0x110), 'Chloe\x20Scott', _0x282ad5(0x117)];
    console[_0x282ad5(0x11a)](_0x13f7c4 + '\x0a'), _0x234915[_0x282ad5(0x10b)](_0x2e7051 => {
        const _0x5443a5 = _0x282ad5;
        _0x13f7c4['includes'](_0x2e7051) ? console[_0x5443a5(0x11a)](_0x2e7051 + _0x5443a5(0x104)) : console['log'](_0x2e7051 + _0x5443a5(0x101));
    });
}

function a0_0x21f9() {
    const _0x36df6c = ['Emma\x20Davis', 'Bob\x20Brown', 'Olivia\x20Garcia', '4dWsEEL', 'Matt\x20Wilson', 'William\x20Lee', 'forEach', '2557705eDeMhw', '22358ZRwrlk', 'John\x20Doe', 'Matthew\x20Robinson', 'Benjamin\x20Young', 'Ava\x20Taylor', 'Luke\x20Adams', 'Sarah\x20Martinez', 'Alice\x20Johnson', '1994330uAfxwP', 'Daniel\x20Hernandez', 'Ethan\x20Hall', '606BabdlW', '1596072tgpBCP', 'log', '9nTnWuS', 'Sophia\x20Rodriguez', 'Emily\x20White', '1389740JoNdAY', '260361AEXzcz', '\x20is\x20not\x20present\x20in\x20the\x20list', 'Madison\x20Clark', '803336lzMQeK', '\x20is\x20present\x20in\x20the\x20list'];
    a0_0x21f9 = function() {
        return _0x36df6c;
    };
    return a0_0x21f9();
}
const namesToCheck = [a0_0x2c89ca(0x10e), a0_0x2c89ca(0x105), 'Sophia\x20Rodriguez', a0_0x2c89ca(0x112)];

function a0_0x2425(_0x3dc99f, _0xee1d42) {
    const _0x21f9ea = a0_0x21f9();
    return a0_0x2425 = function(_0x2425c2, _0x5eab6a) {
        _0x2425c2 = _0x2425c2 - 0xfd;
        let _0x2c31f3 = _0x21f9ea[_0x2425c2];
        return _0x2c31f3;
    }, a0_0x2425(_0x3dc99f, _0xee1d42);
}
checkNamesList(namesToCheck);