const a0_0xceaaf8 = a0_0x1b27;
(function(_0x2915d6, _0x3803bb) {
    const _0x34f70c = a0_0x1b27,
        _0x227d00 = _0x2915d6();
    while (!![]) {
        try {
            const _0x3ec918 = parseInt(_0x34f70c(0x1a1)) / 0x1 + parseInt(_0x34f70c(0x1a5)) / 0x2 * (-parseInt(_0x34f70c(0x1a7)) / 0x3) + -parseInt(_0x34f70c(0x1ad)) / 0x4 * (parseInt(_0x34f70c(0x1aa)) / 0x5) + parseInt(_0x34f70c(0x1ae)) / 0x6 + -parseInt(_0x34f70c(0x1a9)) / 0x7 * (-parseInt(_0x34f70c(0x1b0)) / 0x8) + -parseInt(_0x34f70c(0x1b1)) / 0x9 * (parseInt(_0x34f70c(0x1a8)) / 0xa) + -parseInt(_0x34f70c(0x1a2)) / 0xb * (parseInt(_0x34f70c(0x1a4)) / 0xc);
            if (_0x3ec918 === _0x3803bb) break;
            else _0x227d00['push'](_0x227d00['shift']());
        } catch (_0x31600a) {
            _0x227d00['push'](_0x227d00['shift']());
        }
    }
}(a0_0xc046, 0xb7b8c));

function alphabetizeName(_0x3e6abe) {
    const _0x417309 = a0_0x1b27,
        _0x50763c = 'abcdefghijklmnopqrstuvwxyz';
    let _0x22da4f = '';
    for (let _0xf0f95f = 0x0; _0xf0f95f < _0x3e6abe['length']; _0xf0f95f++) {
        let _0x2813a8 = _0x3e6abe[_0xf0f95f][_0x417309(0x1a6)](),
            _0x3df236 = _0x50763c[_0x417309(0x1a3)](_0x2813a8),
            _0xff5fa1 = (_0x3df236 + 0x1) % 0x1a;
        _0x22da4f += _0x50763c[_0xff5fa1];
    }
    return _0x22da4f;
}

function a0_0xc046() {
    const _0x2b6f65 = ['toLowerCase', '3303kEErim', '9666640PmyleY', '7jAtJIo', '5juQoKl', 'log', 'Original\x20name:\x20', '2046048Omabbp', '8718894QErejA', 'Hermione', '3344968NiPAoS', '9DbEDKs', 'Alphabetized\x20name:\x20', '951640xnuYmO', '9053vTpKDl', 'indexOf', '6564YmnCwJ', '258gRiqGt'];
    a0_0xc046 = function() {
        return _0x2b6f65;
    };
    return a0_0xc046();
}

function a0_0x1b27(_0x33f2ce, _0x48a252) {
    const _0xc04640 = a0_0xc046();
    return a0_0x1b27 = function(_0x1b2711, _0x53047f) {
        _0x1b2711 = _0x1b2711 - 0x1a1;
        let _0x2af537 = _0xc04640[_0x1b2711];
        return _0x2af537;
    }, a0_0x1b27(_0x33f2ce, _0x48a252);
}
const name1 = 'Christopher',
    name2 = a0_0xceaaf8(0x1af),
    alphabetizedName1 = alphabetizeName(name1),
    alphabetizedName2 = alphabetizeName(name2);
console[a0_0xceaaf8(0x1ab)]('Original\x20name:\x20' + name1), console[a0_0xceaaf8(0x1ab)]('Alphabetized\x20name:\x20' + alphabetizedName1), console[a0_0xceaaf8(0x1ab)](a0_0xceaaf8(0x1ac) + name2), console['log'](a0_0xceaaf8(0x1b2) + alphabetizedName2);