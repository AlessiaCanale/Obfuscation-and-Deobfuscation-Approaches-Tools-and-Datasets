const a0_0x4f7109 = a0_0x5e59;
(function(_0x1b3cd7, _0x42cda7) {
    const _0x312a23 = a0_0x5e59,
        _0x3d37a2 = _0x1b3cd7();
    while (!![]) {
        try {
            const _0x43fe62 = parseInt(_0x312a23(0x1b0)) / 0x1 + parseInt(_0x312a23(0x1c9)) / 0x2 * (parseInt(_0x312a23(0x1c0)) / 0x3) + -parseInt(_0x312a23(0x1bd)) / 0x4 + parseInt(_0x312a23(0x1c1)) / 0x5 * (-parseInt(_0x312a23(0x1b5)) / 0x6) + -parseInt(_0x312a23(0x1b4)) / 0x7 * (-parseInt(_0x312a23(0x1b2)) / 0x8) + -parseInt(_0x312a23(0x1c6)) / 0x9 + parseInt(_0x312a23(0x1ca)) / 0xa * (parseInt(_0x312a23(0x1bf)) / 0xb);
            if (_0x43fe62 === _0x42cda7) break;
            else _0x3d37a2['push'](_0x3d37a2['shift']());
        } catch (_0x5077c0) {
            _0x3d37a2['push'](_0x3d37a2['shift']());
        }
    }
}(a0_0x10db, 0x2c8ec));

function getRandomFruitByColor(_0x546a96) {
    const _0x349d30 = a0_0x5e59,
        _0x237778 = {
            'yellow': [_0x349d30(0x1ba), 'pineapple', _0x349d30(0x1be)],
            'red': [_0x349d30(0x1b8), 'cherries', _0x349d30(0x1b7)],
            'pink': ['raspberries', _0x349d30(0x1b6), _0x349d30(0x1c2)],
            'purple': [_0x349d30(0x1b3), 'plums', _0x349d30(0x1bc)],
            'green': [_0x349d30(0x1c8), _0x349d30(0x1c4), _0x349d30(0x1c7)]
        },
        _0x1b3a10 = _0x237778[_0x546a96][Math['floor'](Math[_0x349d30(0x1c3)]() * _0x237778[_0x546a96][_0x349d30(0x1b1)])];
    console['log']('Color:\x20' + _0x546a96), console[_0x349d30(0x1c5)](_0x349d30(0x1bb) + _0x1b3a10);
}

function a0_0x5e59(_0x5e813f, _0xf829fa) {
    const _0x10dbef = a0_0x10db();
    return a0_0x5e59 = function(_0x5e597c, _0x16aac7) {
        _0x5e597c = _0x5e597c - 0x1b0;
        let _0x3d45a2 = _0x10dbef[_0x5e597c];
        return _0x3d45a2;
    }, a0_0x5e59(_0x5e813f, _0xf829fa);
}

function a0_0x10db() {
    const _0x3912f4 = ['green\x20apple', 'kiwi', '14TnAXyn', '10yHUcXS', '9839xKiGjO', 'length', '40lJnFAo', 'grapes', '219877RQyxrR', '341058qyMxlo', 'watermelon', 'red\x20apple', 'strawberries', 'pink', 'banana', 'Random\x20Fruit:\x20', 'figs', '945884owDAsh', 'lemon', '3109007nfTBUp', '61875SHErUA', '15yMsyLr', 'dragon\x20fruit', 'random', 'avocado', 'log', '39582mKFjpH'];
    a0_0x10db = function() {
        return _0x3912f4;
    };
    return a0_0x10db();
}
getRandomFruitByColor(a0_0x4f7109(0x1b9));