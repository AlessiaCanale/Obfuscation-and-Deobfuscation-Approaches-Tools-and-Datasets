(function(_0x2444e3, _0x4ebffe) {
    var _0x3d1d79 = a0_0x41a8,
        _0x54c366 = _0x2444e3();
    while (!![]) {
        try {
            var _0x1cd591 = parseInt(_0x3d1d79(0x1d4)) / 0x1 + parseInt(_0x3d1d79(0x1e0)) / 0x2 + -parseInt(_0x3d1d79(0x1d1)) / 0x3 + parseInt(_0x3d1d79(0x1db)) / 0x4 + -parseInt(_0x3d1d79(0x1ce)) / 0x5 + -parseInt(_0x3d1d79(0x1cd)) / 0x6 + -parseInt(_0x3d1d79(0x1cf)) / 0x7 * (parseInt(_0x3d1d79(0x1e6)) / 0x8);
            if (_0x1cd591 === _0x4ebffe) break;
            else _0x54c366['push'](_0x54c366['shift']());
        } catch (_0x4d4b44) {
            _0x54c366['push'](_0x54c366['shift']());
        }
    }
}(a0_0x1b89, 0x70c59));

function a0_0x41a8(_0x14214e, _0x4dcf0a) {
    var _0x1b894d = a0_0x1b89();
    return a0_0x41a8 = function(_0x41a833, _0x39c420) {
        _0x41a833 = _0x41a833 - 0x1cc;
        var _0x5746ed = _0x1b894d[_0x41a833];
        return _0x5746ed;
    }, a0_0x41a8(_0x14214e, _0x4dcf0a);
}

function fitElementToParent(_0xe32344, _0x5c5643) {
    var _0x37d4a2 = a0_0x41a8,
        _0x591375 = null;

    function _0x2c9b9c() {
        var _0x207b63 = a0_0x41a8;
        if (_0x591375) clearTimeout(_0x591375);
        anime[_0x207b63(0x1d2)](_0xe32344, {
            'scale': 0x1
        });
        var _0x4e8a4e = _0x5c5643 || 0x0,
            _0x5a57e5 = _0xe32344[_0x207b63(0x1e3)],
            _0x5e8de5 = _0xe32344[_0x207b63(0x1e1)] - _0x4e8a4e,
            _0x252b7f = _0x5a57e5[_0x207b63(0x1e1)],
            _0x4e56df = _0x252b7f / _0x5e8de5;
        _0x591375 = setTimeout(anime[_0x207b63(0x1d2)](_0xe32344, {
            'scale': _0x4e56df
        }), 0xa);
    }
    _0x2c9b9c(), window[_0x37d4a2(0x1e2)](_0x37d4a2(0x1da), _0x2c9b9c);
}

function a0_0x1b89() {
    var _0x1d6d10 = ['parentNode', 'classList', 'querySelector', '344XsXcan', '.stagger-visualizer\x20.cursor', 'stagger', '1398780CdKSny', '428375FrNiQe', '164766lCZFlB', 'timeline', '1944942LlePec', 'set', 'div', '815009SGfqGe', 'createElement', 'pause', 'easeInOutQuad', 'dot', 'random', 'resize', '3165180UMvWPF', 'add', '-2px', 'appendChild', '4px', '1669724SucGyH', 'offsetWidth', 'addEventListener'];
    a0_0x1b89 = function() {
        return _0x1d6d10;
    };
    return a0_0x1b89();
}
var advancedStaggeringAnimation = (function() {
    var _0x3a73ee = a0_0x41a8,
        _0x5e0d0a = document[_0x3a73ee(0x1e5)]('.stagger-visualizer'),
        _0x4ac519 = _0x5e0d0a[_0x3a73ee(0x1e5)]('.dots-wrapper'),
        _0x2a6411 = document['createDocumentFragment'](),
        _0x4ba17e = [0x14, 0xa],
        _0x3b8c81 = 0x37,
        _0x4362fc = _0x4ba17e[0x0] * _0x4ba17e[0x1],
        _0x3944ed, _0x221370 = !![];
    fitElementToParent(_0x5e0d0a, 0x0);
    for (var _0x41338b = 0x0; _0x41338b < _0x4362fc; _0x41338b++) {
        var _0x73f90d = document[_0x3a73ee(0x1d5)](_0x3a73ee(0x1d3));
        _0x73f90d[_0x3a73ee(0x1e4)][_0x3a73ee(0x1dc)](_0x3a73ee(0x1d8)), _0x2a6411[_0x3a73ee(0x1de)](_0x73f90d);
    }
    _0x4ac519[_0x3a73ee(0x1de)](_0x2a6411);
    var _0x413906 = anime[_0x3a73ee(0x1d9)](0x0, _0x4362fc - 0x1),
        _0x246ef2 = 0x0;
    anime[_0x3a73ee(0x1d2)](_0x3a73ee(0x1e7), {
        'translateX': anime[_0x3a73ee(0x1cc)](-_0x3b8c81, {
            'grid': _0x4ba17e,
            'from': _0x413906,
            'axis': 'x'
        }),
        'translateY': anime[_0x3a73ee(0x1cc)](-_0x3b8c81, {
            'grid': _0x4ba17e,
            'from': _0x413906,
            'axis': 'y'
        }),
        'translateZ': 0x0,
        'scale': 1.5
    });

    function _0xe98f01() {
        var _0xcf3d3 = _0x3a73ee;
        _0x221370 = ![];
        if (_0x3944ed) _0x3944ed[_0xcf3d3(0x1d6)]();
        _0x246ef2 = anime['random'](0x0, _0x4362fc - 0x1), _0x3944ed = anime[_0xcf3d3(0x1d0)]({
            'easing': _0xcf3d3(0x1d7),
            'complete': _0xe98f01
        })['add']({
            'targets': _0xcf3d3(0x1e7),
            'keyframes': [{
                'scale': 0.75,
                'duration': 0x78
            }, {
                'scale': 2.5,
                'duration': 0xdc
            }, {
                'scale': 1.5,
                'duration': 0x1c2
            }],
            'duration': 0x12c
        })[_0xcf3d3(0x1dc)]({
            'targets': '.stagger-visualizer\x20.dot',
            'keyframes': [{
                'translateX': anime[_0xcf3d3(0x1cc)]('-2px', {
                    'grid': _0x4ba17e,
                    'from': _0x413906,
                    'axis': 'x'
                }),
                'translateY': anime[_0xcf3d3(0x1cc)](_0xcf3d3(0x1dd), {
                    'grid': _0x4ba17e,
                    'from': _0x413906,
                    'axis': 'y'
                }),
                'duration': 0x64
            }, {
                'translateX': anime[_0xcf3d3(0x1cc)](_0xcf3d3(0x1df), {
                    'grid': _0x4ba17e,
                    'from': _0x413906,
                    'axis': 'x'
                }),
                'translateY': anime[_0xcf3d3(0x1cc)](_0xcf3d3(0x1df), {
                    'grid': _0x4ba17e,
                    'from': _0x413906,
                    'axis': 'y'
                }),
                'scale': anime[_0xcf3d3(0x1cc)]([2.6, 0x1], {
                    'grid': _0x4ba17e,
                    'from': _0x413906
                }),
                'duration': 0xe1
            }, {
                'translateX': 0x0,
                'translateY': 0x0,
                'scale': 0x1,
                'duration': 0x4b0
            }],
            'delay': anime[_0xcf3d3(0x1cc)](0x50, {
                'grid': _0x4ba17e,
                'from': _0x413906
            })
        }, 0x1e)['add']({
            'targets': '.stagger-visualizer\x20.cursor',
            'translateX': {
                'value': anime[_0xcf3d3(0x1cc)](-_0x3b8c81, {
                    'grid': _0x4ba17e,
                    'from': _0x246ef2,
                    'axis': 'x'
                })
            },
            'translateY': {
                'value': anime['stagger'](-_0x3b8c81, {
                    'grid': _0x4ba17e,
                    'from': _0x246ef2,
                    'axis': 'y'
                })
            },
            'scale': 1.5,
            'easing': 'cubicBezier(.075,\x20.2,\x20.165,\x201)'
        }, '-=800'), _0x413906 = _0x246ef2;
    }
    _0xe98f01();
}());