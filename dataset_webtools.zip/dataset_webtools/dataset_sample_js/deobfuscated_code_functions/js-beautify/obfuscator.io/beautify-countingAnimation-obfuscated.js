function a0_0x3864(_0x2357ef, _0x1aca2c) {
    var _0x386042 = a0_0x3860();
    return a0_0x3864 = function(_0x3864d6, _0x13a977) {
        _0x3864d6 = _0x3864d6 - 0x1a1;
        var _0x35787c = _0x386042[_0x3864d6];
        return _0x35787c;
    }, a0_0x3864(_0x2357ef, _0x1aca2c);
}
var a0_0x259d5d = a0_0x3864;

function a0_0x3860() {
    var _0xa137a1 = ['.start', 'querySelector', '1411785gjZpTC', '14034qzKiBH', '7136hgwlyU', '1889724TorpZP', '11832804BZYPWc', '288nCUdZi', '.square', '10WAbLNS', '5831RNdlSW', '5674288uFWyit', '16192700NNHSiG', 'addEventListener', 'innerHTML'];
    a0_0x3860 = function() {
        return _0xa137a1;
    };
    return a0_0x3860();
}(function(_0x129422, _0x5c776b) {
    var _0x2e2d35 = a0_0x3864,
        _0x41a091 = _0x129422();
    while (!![]) {
        try {
            var _0x28ce9c = -parseInt(_0x2e2d35(0x1a9)) / 0x1 + parseInt(_0x2e2d35(0x1aa)) / 0x2 * (-parseInt(_0x2e2d35(0x1ae)) / 0x3) + -parseInt(_0x2e2d35(0x1a3)) / 0x4 + parseInt(_0x2e2d35(0x1a1)) / 0x5 * (parseInt(_0x2e2d35(0x1ac)) / 0x6) + parseInt(_0x2e2d35(0x1a2)) / 0x7 * (parseInt(_0x2e2d35(0x1ab)) / 0x8) + parseInt(_0x2e2d35(0x1ad)) / 0x9 + parseInt(_0x2e2d35(0x1a4)) / 0xa;
            if (_0x28ce9c === _0x5c776b) break;
            else _0x41a091['push'](_0x41a091['shift']());
        } catch (_0xfdb4a4) {
            _0x41a091['push'](_0x41a091['shift']());
        }
    }
}(a0_0x3860, 0xc40a5));
var square = document[a0_0x259d5d(0x1a8)](a0_0x259d5d(0x1af)),
    startBtn = document['querySelector'](a0_0x259d5d(0x1a7)),
    stopBtn = document['querySelector']('.stop'),
    c = 0x0,
    running = !![],
    run = function() {
        var _0x4d9a94 = a0_0x259d5d;
        if (!running) return;
        requestAnimationFrame(run), c++, square[_0x4d9a94(0x1a6)] = c;
    },
    start = function() {
        running = !![], run();
    },
    stop = function() {
        var _0x3bbb9a = a0_0x259d5d;
        running = ![], c = 0x0, redbox[_0x3bbb9a(0x1a6)] = c;
    };
startBtn['addEventListener']('click', start), stopBtn[a0_0x259d5d(0x1a5)]('click', stop);