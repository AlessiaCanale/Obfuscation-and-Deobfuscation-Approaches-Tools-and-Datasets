function a0_0x28a2(_0x3bbe5e, _0x3aed4c) {
    const _0x16a3ec = a0_0x16a3();
    return a0_0x28a2 = function(_0x28a28b, _0x59aba1) {
        _0x28a28b = _0x28a28b - 0x1b9;
        let _0x16a385 = _0x16a3ec[_0x28a28b];
        return _0x16a385;
    }, a0_0x28a2(_0x3bbe5e, _0x3aed4c);
}
const a0_0x2af9fb = a0_0x28a2;

function a0_0x16a3() {
    const _0x57c8a4 = ['gentle84', 'replace', '411001csUpVf', '1304RJCJUB', 'Koala5', '356776RYfQQw', '72yLSJPC', '9423ctIztS', '1770555jNiSZQ', '4DenhXE', '4245290lwJbXV', '01Pizza', 'log', '18XviQoX', '8913BguTPJ', '5793271KxlXhL'];
    a0_0x16a3 = function() {
        return _0x57c8a4;
    };
    return a0_0x16a3();
}(function(_0x31b245, _0x108d97) {
    const _0x3cdb91 = a0_0x28a2,
        _0x155275 = _0x31b245();
    while (!![]) {
        try {
            const _0x616972 = parseInt(_0x3cdb91(0x1bb)) / 0x1 + -parseInt(_0x3cdb91(0x1c6)) / 0x2 * (parseInt(_0x3cdb91(0x1c7)) / 0x3) + parseInt(_0x3cdb91(0x1c2)) / 0x4 * (parseInt(_0x3cdb91(0x1c1)) / 0x5) + parseInt(_0x3cdb91(0x1bf)) / 0x6 * (-parseInt(_0x3cdb91(0x1be)) / 0x7) + -parseInt(_0x3cdb91(0x1bc)) / 0x8 * (-parseInt(_0x3cdb91(0x1c0)) / 0x9) + -parseInt(_0x3cdb91(0x1c3)) / 0xa + parseInt(_0x3cdb91(0x1c8)) / 0xb;
            if (_0x616972 === _0x108d97) break;
            else _0x155275['push'](_0x155275['shift']());
        } catch (_0x1219d1) {
            _0x155275['push'](_0x155275['shift']());
        }
    }
}(a0_0x16a3, 0x618be));

function changeSomeCharNum(_0x273373, _0x463663, _0x2220e1) {
    const _0x4b5007 = {
            'l': '1',
            '1': 'L',
            'o': '0',
            '0': 'O',
            'a': '4',
            '4': 'A'
        },
        _0x216681 = _0x272219 => {
            const _0x5d15c3 = a0_0x28a2;
            return _0x272219[_0x5d15c3(0x1ba)](/[l10a4]/g, _0x249e49 => _0x4b5007[_0x249e49]);
        },
        _0x1f139e = _0x216681(_0x273373),
        _0x5b572d = _0x216681(_0x463663),
        _0x4aa046 = _0x216681(_0x2220e1);
    return [_0x1f139e, _0x5b572d, _0x4aa046];
}
const [result1, result2, result3] = changeSomeCharNum(a0_0x2af9fb(0x1b9), a0_0x2af9fb(0x1bd), '01Pizza');
console[a0_0x2af9fb(0x1c5)](a0_0x2af9fb(0x1b9), a0_0x2af9fb(0x1bd), a0_0x2af9fb(0x1c4)), console[a0_0x2af9fb(0x1c5)](result1, result2, result3);