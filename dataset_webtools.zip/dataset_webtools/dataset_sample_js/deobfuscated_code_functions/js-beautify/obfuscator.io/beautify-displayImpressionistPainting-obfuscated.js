(function(_0x382c79, _0x26f1f1) {
    const _0x28f1f6 = a0_0x52d7,
        _0x498f56 = _0x382c79();
    while (!![]) {
        try {
            const _0x3350e4 = parseInt(_0x28f1f6(0x1cc)) / 0x1 * (parseInt(_0x28f1f6(0x1d4)) / 0x2) + parseInt(_0x28f1f6(0x1d2)) / 0x3 + -parseInt(_0x28f1f6(0x1be)) / 0x4 * (parseInt(_0x28f1f6(0x1c9)) / 0x5) + -parseInt(_0x28f1f6(0x1c3)) / 0x6 + -parseInt(_0x28f1f6(0x1d0)) / 0x7 * (parseInt(_0x28f1f6(0x1b5)) / 0x8) + -parseInt(_0x28f1f6(0x1c8)) / 0x9 + -parseInt(_0x28f1f6(0x1c4)) / 0xa * (-parseInt(_0x28f1f6(0x1b8)) / 0xb);
            if (_0x3350e4 === _0x26f1f1) break;
            else _0x498f56['push'](_0x498f56['shift']());
        } catch (_0x7e0bc3) {
            _0x498f56['push'](_0x498f56['shift']());
        }
    }
}(a0_0x3af3, 0x6c7d1));

function displayImpressionistPainting() {
    const _0x48fe78 = a0_0x52d7,
        _0x244b07 = [{
            'title': _0x48fe78(0x1bf),
            'author': _0x48fe78(0x1c2),
            'description': _0x48fe78(0x1d1)
        }, {
            'title': _0x48fe78(0x1bb),
            'author': _0x48fe78(0x1cf),
            'description': _0x48fe78(0x1cd)
        }, {
            'title': _0x48fe78(0x1ba),
            'author': _0x48fe78(0x1ca),
            'description': _0x48fe78(0x1c6)
        }, {
            'title': 'Ballet\x20Rehearsal',
            'author': _0x48fe78(0x1b7),
            'description': 'Degas\x27\x20painting\x20showcasing\x20ballerinas\x20rehearsing\x20their\x20movements\x20in\x20a\x20studio\x20setting.'
        }, {
            'title': _0x48fe78(0x1d5),
            'author': 'Vincent\x20van\x20Gogh',
            'description': _0x48fe78(0x1c5)
        }, {
            'title': 'Luncheon\x20of\x20the\x20Boating\x20Party',
            'author': 'Pierre-Auguste\x20Renoir',
            'description': _0x48fe78(0x1c7)
        }, {
            'title': _0x48fe78(0x1cb),
            'author': 'Pierre-Auguste\x20Renoir',
            'description': _0x48fe78(0x1bd)
        }],
        _0x15b6a0 = Math['floor'](Math[_0x48fe78(0x1bc)]() * _0x244b07[_0x48fe78(0x1b6)]),
        _0x154240 = _0x244b07[_0x15b6a0];
    console[_0x48fe78(0x1d3)](_0x48fe78(0x1c1) + _0x154240[_0x48fe78(0x1b9)]), console[_0x48fe78(0x1d3)]('Author:\x20' + _0x154240[_0x48fe78(0x1c0)]), console[_0x48fe78(0x1d3)](_0x48fe78(0x1ce) + _0x154240['description']);
}

function a0_0x3af3() {
    const _0x54fb39 = ['length', 'Edgar\x20Degas', '4367TEzGef', 'title', 'Dance\x20at\x20Le\x20Moulin\x20de\x20la\x20Galette', 'Impression,\x20Sunrise', 'random', 'Renoir\x27s\x20colorful\x20and\x20lively\x20painting\x20capturing\x20a\x20typical\x20Sunday\x20afternoon\x20at\x20the\x20Moulin\x20de\x20la\x20Galette\x20dance\x20hall\x20in\x20Montmartre,\x20Paris.', '228EagVny', 'Starry\x20Night', 'author', 'Title:\x20', 'Vincent\x20van\x20Gogh', '2556300cHvatv', '52890wkQSBW', 'Another\x20one\x20of\x20Van\x20Gogh\x27s\x20masterpieces\x20featuring\x20a\x20vibrant\x20wheat\x20field\x20with\x20tall\x20cypress\x20trees.', 'Renoir\x27s\x20lively\x20painting\x20capturing\x20a\x20scene\x20of\x20people\x20dancing\x20and\x20socializing\x20at\x20a\x20popular\x20Parisian\x20dance\x20hall.', 'Renoir\x27s\x20painting\x20depicting\x20a\x20group\x20of\x20friends\x20enjoying\x20a\x20leisurely\x20lunch\x20by\x20the\x20Seine\x20River.', '7659126UQRqWD', '77555DtbRbn', 'Pierre-Auguste\x20Renoir', 'Bal\x20du\x20moulin\x20de\x20la\x20Galette', '12941RCkrvq', 'Considered\x20the\x20painting\x20that\x20gave\x20birth\x20to\x20the\x20Impressionist\x20movement,\x20it\x20shows\x20a\x20port\x20at\x20sunrise.', 'Description:\x20', 'Claude\x20Monet', '262934HFnmsG', 'Van\x20Gogh\x27s\x20iconic\x20painting\x20depicting\x20a\x20night\x20sky\x20filled\x20with\x20swirling\x20stars.', '65898zPTwfh', 'log', '98HltjDH', 'Wheat\x20Field\x20with\x20Cypresses', '32LQJQde'];
    a0_0x3af3 = function() {
        return _0x54fb39;
    };
    return a0_0x3af3();
}

function a0_0x52d7(_0x3a8515, _0xcc00a3) {
    const _0x3af398 = a0_0x3af3();
    return a0_0x52d7 = function(_0x52d7a8, _0x19a741) {
        _0x52d7a8 = _0x52d7a8 - 0x1b5;
        let _0x4ff6eb = _0x3af398[_0x52d7a8];
        return _0x4ff6eb;
    }, a0_0x52d7(_0x3a8515, _0xcc00a3);
}
displayImpressionistPainting();