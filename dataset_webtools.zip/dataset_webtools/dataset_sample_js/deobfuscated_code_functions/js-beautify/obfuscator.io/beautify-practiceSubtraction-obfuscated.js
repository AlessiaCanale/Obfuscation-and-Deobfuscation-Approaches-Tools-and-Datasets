function a0_0x258e() {
    var _0xebbce = ['50888MvYVgT', '2659258FfZzJj', '28992430dMMYgj', '\x20-\x20', '14213lMnRnc', '5360076AeQvNN', '3260205jvEeWg', '\x20=\x20', 'random', '178xhZcZG', 'log', '225xiZvdd', '20958tfROdA', 'floor', '320HWKsbS'];
    a0_0x258e = function() {
        return _0xebbce;
    };
    return a0_0x258e();
}(function(_0xa2da4c, _0x30569e) {
    var _0x1171b2 = a0_0x344d,
        _0x54c633 = _0xa2da4c();
    while (!![]) {
        try {
            var _0x298047 = -parseInt(_0x1171b2(0x106)) / 0x1 * (-parseInt(_0x1171b2(0xfc)) / 0x2) + parseInt(_0x1171b2(0x108)) / 0x3 + parseInt(_0x1171b2(0x107)) / 0x4 + -parseInt(_0x1171b2(0x101)) / 0x5 * (parseInt(_0x1171b2(0xff)) / 0x6) + parseInt(_0x1171b2(0x103)) / 0x7 + parseInt(_0x1171b2(0x102)) / 0x8 * (-parseInt(_0x1171b2(0xfe)) / 0x9) + -parseInt(_0x1171b2(0x104)) / 0xa;
            if (_0x298047 === _0x30569e) break;
            else _0x54c633['push'](_0x54c633['shift']());
        } catch (_0x2e92a1) {
            _0x54c633['push'](_0x54c633['shift']());
        }
    }
}(a0_0x258e, 0xc0d19));

function practiceSubtraction() {
    var _0x153844 = a0_0x344d,
        _0xd15751 = Math[_0x153844(0x100)](Math[_0x153844(0xfb)]() * 0x3e9),
        _0x468512 = Math[_0x153844(0x100)](Math['random']() * 0x3e9),
        _0x2f6472 = _0xd15751 - _0x468512;
    console['log'](_0xd15751 + '\x20-\x20' + _0x468512), console['log']('Try\x20to\x20subtract\x20the\x20two\x20numbers\x20and\x20then\x20check\x20if\x20it\x20is\x20correct\x20by\x20looking\x20at\x20the\x20result\x20that\x20will\x20appear\x20in\x205\x20seconds\x20:)'), setTimeout(function() {
        var _0x4e2803 = _0x153844;
        console[_0x4e2803(0xfd)](_0xd15751 + _0x4e2803(0x105) + _0x468512 + _0x4e2803(0x109) + _0x2f6472);
    }, 0x1388);
}

function a0_0x344d(_0x1575ae, _0x56df8f) {
    var _0x258e5d = a0_0x258e();
    return a0_0x344d = function(_0x344d2f, _0x317d27) {
        _0x344d2f = _0x344d2f - 0xfb;
        var _0x753e60 = _0x258e5d[_0x344d2f];
        return _0x753e60;
    }, a0_0x344d(_0x1575ae, _0x56df8f);
}
practiceSubtraction();