const a0_0x2fab3e = a0_0x1cf9;
(function(_0x4ad987, _0x5247f8) {
    const _0x439e96 = a0_0x1cf9,
        _0x356e87 = _0x4ad987();
    while (!![]) {
        try {
            const _0x58a972 = parseInt(_0x439e96(0x1a3)) / 0x1 + -parseInt(_0x439e96(0x1a2)) / 0x2 * (parseInt(_0x439e96(0x19a)) / 0x3) + -parseInt(_0x439e96(0x19f)) / 0x4 * (parseInt(_0x439e96(0x199)) / 0x5) + parseInt(_0x439e96(0x1a1)) / 0x6 + parseInt(_0x439e96(0x19c)) / 0x7 + -parseInt(_0x439e96(0x19d)) / 0x8 + -parseInt(_0x439e96(0x198)) / 0x9 * (-parseInt(_0x439e96(0x19e)) / 0xa);
            if (_0x58a972 === _0x5247f8) break;
            else _0x356e87['push'](_0x356e87['shift']());
        } catch (_0x55b84e) {
            _0x356e87['push'](_0x356e87['shift']());
        }
    }
}(a0_0x46ed, 0xf1da6));

function a0_0x1cf9(_0x49cdf4, _0x5bd448) {
    const _0x46edb9 = a0_0x46ed();
    return a0_0x1cf9 = function(_0x1cf97c, _0x38a95e) {
        _0x1cf97c = _0x1cf97c - 0x195;
        let _0x3d7042 = _0x46edb9[_0x1cf97c];
        return _0x3d7042;
    }, a0_0x1cf9(_0x49cdf4, _0x5bd448);
}

function capitalizeAfterDot(_0x2b7692) {
    const _0x51f034 = a0_0x1cf9,
        _0x124cfc = _0x2b7692[_0x51f034(0x19b)](/([.!?]\s*)([a-z])/g, (_0x5d46c3, _0x41d064, _0x3b7011) => {
            const _0x172f22 = _0x51f034;
            return _0x41d064 + _0x3b7011[_0x172f22(0x196)]();
        });
    return console[_0x51f034(0x1a4)](_0x51f034(0x195) + _0x2b7692), console[_0x51f034(0x1a4)](_0x51f034(0x197) + _0x124cfc), _0x124cfc;
}

function a0_0x46ed() {
    const _0x3cc661 = ['this\x20is\x20a\x20sentence.\x20this\x20is\x20another\x20sentence.\x20this\x20is\x20yet\x20another\x20sentence.', '3262440WqOcjZ', '358430bNlhoT', '737009LGYQKX', 'log', 'Original\x20text:\x20', 'toUpperCase', 'Modified\x20text:\x20', '36EgFEht', '99335OFWwlr', '24JzAgRz', 'replace', '11145190jnVJgD', '9541784pqBBLw', '4145090mVCvXq', '184vQurZr'];
    a0_0x46ed = function() {
        return _0x3cc661;
    };
    return a0_0x46ed();
}
const text = a0_0x2fab3e(0x1a0);
capitalizeAfterDot(text);
const text1 = 'Hello\x20world.\x20how\x20are\x20you.\x20hope\x20well.';
capitalizeAfterDot(text1);