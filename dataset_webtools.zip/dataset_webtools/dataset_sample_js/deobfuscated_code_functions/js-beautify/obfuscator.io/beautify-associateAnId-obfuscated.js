const a0_0x111e05 = a0_0x19cc;
(function(_0x56aaeb, _0x501ed2) {
    const _0x151f1e = a0_0x19cc,
        _0x4e9e26 = _0x56aaeb();
    while (!![]) {
        try {
            const _0x415731 = -parseInt(_0x151f1e(0x1e2)) / 0x1 + parseInt(_0x151f1e(0x1dc)) / 0x2 + -parseInt(_0x151f1e(0x1e0)) / 0x3 * (parseInt(_0x151f1e(0x1db)) / 0x4) + parseInt(_0x151f1e(0x1d5)) / 0x5 + -parseInt(_0x151f1e(0x1d1)) / 0x6 * (parseInt(_0x151f1e(0x1d9)) / 0x7) + -parseInt(_0x151f1e(0x1dd)) / 0x8 * (parseInt(_0x151f1e(0x1d8)) / 0x9) + parseInt(_0x151f1e(0x1de)) / 0xa;
            if (_0x415731 === _0x501ed2) break;
            else _0x4e9e26['push'](_0x4e9e26['shift']());
        } catch (_0x5a43e9) {
            _0x4e9e26['push'](_0x4e9e26['shift']());
        }
    }
}(a0_0xdf3f, 0x2c5fd));

function generateRandomId() {
    const _0x207a77 = a0_0x19cc,
        _0x502562 = _0x207a77(0x1da);
    let _0x138517 = '';
    for (let _0x5f5901 = 0x0; _0x5f5901 < 0x5; _0x5f5901++) {
        _0x138517 += _0x502562['charAt'](Math[_0x207a77(0x1d3)](Math['random']() * _0x502562[_0x207a77(0x1d4)]));
    }
    return _0x138517;
}

function associateAnId(_0x398a6a) {
    const _0x6f1886 = a0_0x19cc,
        _0xd078c1 = {},
        _0x2262ee = _0x398a6a[_0x6f1886(0x1df)](_0x278c08 => {
            let _0x1f1675;
            do {
                _0x1f1675 = generateRandomId();
            } while (_0xd078c1[_0x1f1675]);
            return _0xd078c1[_0x1f1675] = !![], {
                'name': _0x278c08,
                'id': _0x1f1675
            };
        });
    return _0x2262ee['forEach'](({
        name: _0x37d1d7,
        id: _0x5a91ae
    }) => console[_0x6f1886(0x1d2)](_0x37d1d7 + ':\x20' + _0x5a91ae)), _0x2262ee;
}
const names = ['Alice', a0_0x111e05(0x1d7), a0_0x111e05(0x1d0), a0_0x111e05(0x1e1), a0_0x111e05(0x1d6)];

function a0_0x19cc(_0x2efb3f, _0x5e9fcb) {
    const _0xdf3fa5 = a0_0xdf3f();
    return a0_0x19cc = function(_0x19cc80, _0x357931) {
        _0x19cc80 = _0x19cc80 - 0x1d0;
        let _0x1d6469 = _0xdf3fa5[_0x19cc80];
        return _0x1d6469;
    }, a0_0x19cc(_0x2efb3f, _0x5e9fcb);
}
associateAnId(names);

function a0_0xdf3f() {
    const _0x352f74 = ['182rJNBNA', 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', '1196UhoJpd', '321156RTfOiv', '401824PiuJHb', '5411940gQFdxk', 'map', '1962EvQYXR', 'David', '45655qEtnVi', 'Charlie', '62754JQPKwC', 'log', 'floor', 'length', '216740LHxPld', 'Eve', 'Bob', '9kbzTPY'];
    a0_0xdf3f = function() {
        return _0x352f74;
    };
    return a0_0xdf3f();
}