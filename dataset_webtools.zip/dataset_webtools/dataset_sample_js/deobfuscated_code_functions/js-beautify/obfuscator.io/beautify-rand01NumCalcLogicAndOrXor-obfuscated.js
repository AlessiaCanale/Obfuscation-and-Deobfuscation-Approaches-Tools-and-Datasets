function a0_0x597f(_0x23bb7c, _0x4ffc54) {
    const _0x4232b0 = a0_0x4232();
    return a0_0x597f = function(_0x597f18, _0x25cc48) {
        _0x597f18 = _0x597f18 - 0x12a;
        let _0x586282 = _0x4232b0[_0x597f18];
        return _0x586282;
    }, a0_0x597f(_0x23bb7c, _0x4ffc54);
}(function(_0x48d108, _0x251bf0) {
    const _0x30b424 = a0_0x597f,
        _0x2f96a2 = _0x48d108();
    while (!![]) {
        try {
            const _0x3662dd = -parseInt(_0x30b424(0x134)) / 0x1 + parseInt(_0x30b424(0x133)) / 0x2 + parseInt(_0x30b424(0x12d)) / 0x3 * (parseInt(_0x30b424(0x12f)) / 0x4) + parseInt(_0x30b424(0x137)) / 0x5 + -parseInt(_0x30b424(0x135)) / 0x6 + parseInt(_0x30b424(0x12e)) / 0x7 * (parseInt(_0x30b424(0x12b)) / 0x8) + -parseInt(_0x30b424(0x138)) / 0x9;
            if (_0x3662dd === _0x251bf0) break;
            else _0x2f96a2['push'](_0x2f96a2['shift']());
        } catch (_0x377928) {
            _0x2f96a2['push'](_0x2f96a2['shift']());
        }
    }
}(a0_0x4232, 0xd94a0));

function rand01NumCalcLogicAndOrXor() {
    const _0x2740c7 = a0_0x597f,
        _0x384f93 = Math[_0x2740c7(0x130)](Math[_0x2740c7(0x132)]() * 0x5) + 0x1;
    let _0x7a69c6 = '';
    for (let _0x2588af = 0x0; _0x2588af < _0x384f93; _0x2588af++) {
        _0x7a69c6 += Math['floor'](Math[_0x2740c7(0x132)]() * 0x2);
    }
    const _0x4755f0 = [_0x2740c7(0x12c), 'OR', 'XOR'],
        _0x1974a2 = _0x4755f0[Math[_0x2740c7(0x130)](Math[_0x2740c7(0x132)]() * _0x4755f0[_0x2740c7(0x131)])];
    let _0x3ffe71;
    switch (_0x1974a2) {
        case _0x2740c7(0x12c):
            _0x3ffe71 = 0x1;
            for (let _0x143411 of _0x7a69c6) {
                _0x3ffe71 &= parseInt(_0x143411);
            }
            break;
        case 'OR':
            _0x3ffe71 = 0x0;
            for (let _0xd29b17 of _0x7a69c6) {
                _0x3ffe71 |= parseInt(_0xd29b17);
            }
            break;
        case _0x2740c7(0x136):
            _0x3ffe71 = 0x0;
            for (let _0x24e9b8 of _0x7a69c6) {
                _0x3ffe71 ^= parseInt(_0x24e9b8);
            }
            break;
    }
    return console['log']('Random\x20number\x20n1:\x20' + _0x384f93), console[_0x2740c7(0x13a)](_0x2740c7(0x12a) + _0x7a69c6), console[_0x2740c7(0x13a)](_0x2740c7(0x139) + _0x1974a2), console[_0x2740c7(0x13a)]('Result\x20of\x20' + _0x1974a2 + ':\x20' + _0x3ffe71), _0x3ffe71;
}

function a0_0x4232() {
    const _0x228ed9 = ['AND', '129GAqlOw', '23114lBqvDw', '94616WOCdZw', 'floor', 'length', 'random', '3000764qpcIco', '50440LvssEO', '2565330mpgKUN', 'XOR', '7795895EkwTEZ', '37870020lratPI', 'Random\x20operation:\x20', 'log', 'Number\x20with\x20n1\x20digits:\x20', '3632sEmROo'];
    a0_0x4232 = function() {
        return _0x228ed9;
    };
    return a0_0x4232();
}
rand01NumCalcLogicAndOrXor();