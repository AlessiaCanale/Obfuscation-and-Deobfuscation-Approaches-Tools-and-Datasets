var a0_0x3432c7 = a0_0x3599;

function a0_0x3599(_0xdfee5a, _0x3d6c77) {
    var _0x489652 = a0_0x4896();
    return a0_0x3599 = function(_0x35994e, _0x1ea9c2) {
        _0x35994e = _0x35994e - 0x193;
        var _0x528d22 = _0x489652[_0x35994e];
        return _0x528d22;
    }, a0_0x3599(_0xdfee5a, _0x3d6c77);
}(function(_0x38a088, _0x343279) {
    var _0x2a5721 = a0_0x3599,
        _0x5a004d = _0x38a088();
    while (!![]) {
        try {
            var _0x555468 = -parseInt(_0x2a5721(0x196)) / 0x1 * (parseInt(_0x2a5721(0x198)) / 0x2) + -parseInt(_0x2a5721(0x19e)) / 0x3 * (parseInt(_0x2a5721(0x1a3)) / 0x4) + -parseInt(_0x2a5721(0x197)) / 0x5 * (parseInt(_0x2a5721(0x193)) / 0x6) + -parseInt(_0x2a5721(0x19d)) / 0x7 * (parseInt(_0x2a5721(0x19f)) / 0x8) + parseInt(_0x2a5721(0x1a1)) / 0x9 * (-parseInt(_0x2a5721(0x1a2)) / 0xa) + parseInt(_0x2a5721(0x1a0)) / 0xb + parseInt(_0x2a5721(0x19a)) / 0xc * (parseInt(_0x2a5721(0x195)) / 0xd);
            if (_0x555468 === _0x343279) break;
            else _0x5a004d['push'](_0x5a004d['shift']());
        } catch (_0x42b235) {
            _0x5a004d['push'](_0x5a004d['shift']());
        }
    }
}(a0_0x4896, 0x4fab0));

function changeRoundBracketsWithSquareBrackets(_0x2d9306) {
    var _0x4375fc = a0_0x3599,
        _0x3b6f36 = _0x2d9306[_0x4375fc(0x19c)](/\(/g, '[')['replace'](/\)/g, ']');
    console[_0x4375fc(0x199)](_0x4375fc(0x19b), _0x2d9306), console[_0x4375fc(0x199)]('Modified\x20sentence:', _0x3b6f36);
}
var inputSentence = a0_0x3432c7(0x194);

function a0_0x4896() {
    var _0x52c068 = ['307143txQXPe', '160HEznjs', '1166584sQhiMG', '690XMPvTS', 'This\x20(is)\x20a\x20(sentence)\x20with\x20(round)\x20brackets.', '13HyBPlu', '267zctDoT', '12835XHtvnu', '3272yGzdmq', 'log', '22892208QzuBwC', 'Original\x20sentence:', 'replace', '4016215FBbDCh', '3StJScq', '8xzeuuY', '6182836LMdhFM'];
    a0_0x4896 = function() {
        return _0x52c068;
    };
    return a0_0x4896();
}
changeRoundBracketsWithSquareBrackets(inputSentence);