const a0_0x534901 = a0_0x1d86;
(function(_0x3af9d3, _0x18b802) {
    const _0x22a0ef = a0_0x1d86,
        _0x57a254 = _0x3af9d3();
    while (!![]) {
        try {
            const _0x548d41 = parseInt(_0x22a0ef(0xb7)) / 0x1 + parseInt(_0x22a0ef(0xb6)) / 0x2 + parseInt(_0x22a0ef(0xb2)) / 0x3 + parseInt(_0x22a0ef(0xc0)) / 0x4 * (-parseInt(_0x22a0ef(0xc2)) / 0x5) + -parseInt(_0x22a0ef(0xbf)) / 0x6 * (-parseInt(_0x22a0ef(0xb9)) / 0x7) + -parseInt(_0x22a0ef(0xbe)) / 0x8 + parseInt(_0x22a0ef(0xb8)) / 0x9 * (-parseInt(_0x22a0ef(0xb5)) / 0xa);
            if (_0x548d41 === _0x18b802) break;
            else _0x57a254['push'](_0x57a254['shift']());
        } catch (_0x45ff58) {
            _0x57a254['push'](_0x57a254['shift']());
        }
    }
}(a0_0x4d33, 0x80b93));
let date1 = new Date(a0_0x534901(0xba)),
    date2 = new Date(a0_0x534901(0xb3)),
    Difference_In_Time = date2['getTime']() - date1[a0_0x534901(0xc3)](),
    Difference_In_Days = Math[a0_0x534901(0xbc)](Difference_In_Time / (0x3e8 * 0xe10 * 0x18));

function a0_0x1d86(_0x253766, _0x2349f8) {
    const _0x4d33d1 = a0_0x4d33();
    return a0_0x1d86 = function(_0x1d86a3, _0x2d0d76) {
        _0x1d86a3 = _0x1d86a3 - 0xb2;
        let _0x13e4be = _0x4d33d1[_0x1d86a3];
        return _0x13e4be;
    }, a0_0x1d86(_0x253766, _0x2349f8);
}
console[a0_0x534901(0xb4)](a0_0x534901(0xbb) + date1['toDateString']() + a0_0x534901(0xc1) + date2[a0_0x534901(0xbd)]() + '\x20is:\x20' + Difference_In_Days + '\x20days');

function a0_0x4d33() {
    const _0x467fcd = ['01/27/2024', 'log', '20YaZOHV', '475012wbncpm', '574474mgQiny', '2349639lgdcDI', '224SaKrWz', '01/20/2024', 'Total\x20number\x20of\x20days\x20between\x20dates:\x0a', 'round', 'toDateString', '7989920VsUVhc', '124302CZFVrt', '16CgSwXD', '\x20and\x20', '558775gNpdCi', 'getTime', '3060687BtQnYd'];
    a0_0x4d33 = function() {
        return _0x467fcd;
    };
    return a0_0x4d33();
}