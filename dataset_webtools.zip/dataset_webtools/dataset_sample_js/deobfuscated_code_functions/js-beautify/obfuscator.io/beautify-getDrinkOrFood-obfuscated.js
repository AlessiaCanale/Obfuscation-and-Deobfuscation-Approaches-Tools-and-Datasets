const a0_0x12ccf9 = a0_0x256b;
(function(_0x54b9d9, _0x1179aa) {
    const _0x50f03f = a0_0x256b,
        _0x58933f = _0x54b9d9();
    while (!![]) {
        try {
            const _0x16d70e = parseInt(_0x50f03f(0xc6)) / 0x1 + -parseInt(_0x50f03f(0xc4)) / 0x2 * (parseInt(_0x50f03f(0xd3)) / 0x3) + parseInt(_0x50f03f(0xd6)) / 0x4 + -parseInt(_0x50f03f(0xd7)) / 0x5 * (parseInt(_0x50f03f(0xd8)) / 0x6) + parseInt(_0x50f03f(0xcd)) / 0x7 * (-parseInt(_0x50f03f(0xd9)) / 0x8) + parseInt(_0x50f03f(0xcf)) / 0x9 * (-parseInt(_0x50f03f(0xc9)) / 0xa) + parseInt(_0x50f03f(0xd1)) / 0xb;
            if (_0x16d70e === _0x1179aa) break;
            else _0x58933f['push'](_0x58933f['shift']());
        } catch (_0x5cec24) {
            _0x58933f['push'](_0x58933f['shift']());
        }
    }
}(a0_0x1375, 0xd3b3a));

function getDrinkOrFood(_0x46204c) {
    const _0x5cc06a = a0_0x256b,
        _0x2310ee = {
            'thirsty': ['water', 'orange\x20juice', _0x5cc06a(0xc8), _0x5cc06a(0xc5), 'tea'],
            'hungry': [_0x5cc06a(0xc1), _0x5cc06a(0xce), _0x5cc06a(0xd5), _0x5cc06a(0xd0), _0x5cc06a(0xd4)]
        };
    if (_0x46204c === 'thirsty') return _0x2310ee[_0x5cc06a(0xcc)][Math['floor'](Math[_0x5cc06a(0xc2)]() * _0x2310ee[_0x5cc06a(0xcc)][_0x5cc06a(0xd2)])];
    else return _0x46204c === 'hungry' ? _0x2310ee[_0x5cc06a(0xc7)][Math['floor'](Math['random']() * _0x2310ee['hungry'][_0x5cc06a(0xd2)])] : _0x5cc06a(0xc3);
}

function a0_0x1375() {
    const _0xab1210 = ['Invalid\x20feeling\x20provided!', '566LHNGST', 'infusion', '1176000osBGXm', 'hungry', 'milk', '4925730kpeHhG', 'log', 'Random\x20drink\x20for\x20when\x20you\x27re\x20thirsty:\x20', 'thirsty', '414428WJHySr', 'pop\x20corn', '9UuQZJD', 'vegetables', '15717108stjqyA', 'length', '17814OaaZpv', 'porridge', 'fruit', '3624268xamaiy', '1465630lStbzH', '6MJthfr', '24TSrUdN', 'dried\x20fruit', 'random'];
    a0_0x1375 = function() {
        return _0xab1210;
    };
    return a0_0x1375();
}
const randomDrink = getDrinkOrFood('thirsty'),
    randomFood = getDrinkOrFood(a0_0x12ccf9(0xc7));

function a0_0x256b(_0xeb944f, _0x533b19) {
    const _0x137520 = a0_0x1375();
    return a0_0x256b = function(_0x256bc1, _0xe0b236) {
        _0x256bc1 = _0x256bc1 - 0xc1;
        let _0x29e855 = _0x137520[_0x256bc1];
        return _0x29e855;
    }, a0_0x256b(_0xeb944f, _0x533b19);
}
console[a0_0x12ccf9(0xca)](a0_0x12ccf9(0xcb) + randomDrink), console[a0_0x12ccf9(0xca)]('Random\x20food\x20for\x20when\x20you\x27re\x20hungry:\x20' + randomFood);