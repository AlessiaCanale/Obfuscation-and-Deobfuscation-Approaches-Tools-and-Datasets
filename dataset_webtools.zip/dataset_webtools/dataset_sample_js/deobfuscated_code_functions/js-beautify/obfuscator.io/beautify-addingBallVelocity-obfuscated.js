function a0_0x2195(_0x3ce243, _0x126623) {
    const _0x1cd399 = a0_0x1cd3();
    return a0_0x2195 = function(_0x21951a, _0x5cf929) {
        _0x21951a = _0x21951a - 0x1e9;
        let _0x4c2ea9 = _0x1cd399[_0x21951a];
        return _0x4c2ea9;
    }, a0_0x2195(_0x3ce243, _0x126623);
}
const a0_0x14b68c = a0_0x2195;
(function(_0x377fab, _0x217e2d) {
    const _0x2ad8d4 = a0_0x2195,
        _0x1d7036 = _0x377fab();
    while (!![]) {
        try {
            const _0x2176df = parseInt(_0x2ad8d4(0x1e9)) / 0x1 + parseInt(_0x2ad8d4(0x201)) / 0x2 * (parseInt(_0x2ad8d4(0x1ff)) / 0x3) + -parseInt(_0x2ad8d4(0x1fc)) / 0x4 + parseInt(_0x2ad8d4(0x1f6)) / 0x5 * (-parseInt(_0x2ad8d4(0x1ee)) / 0x6) + parseInt(_0x2ad8d4(0x1f3)) / 0x7 + parseInt(_0x2ad8d4(0x1f4)) / 0x8 * (-parseInt(_0x2ad8d4(0x1f2)) / 0x9) + parseInt(_0x2ad8d4(0x1f7)) / 0xa * (-parseInt(_0x2ad8d4(0x1f0)) / 0xb);
            if (_0x2176df === _0x217e2d) break;
            else _0x1d7036['push'](_0x1d7036['shift']());
        } catch (_0x33adf8) {
            _0x1d7036['push'](_0x1d7036['shift']());
        }
    }
}(a0_0x1cd3, 0x1bad5));
const canvas = document['getElementById']('canvas'),
    ctx = canvas[a0_0x14b68c(0x1f8)]('2d');

function a0_0x1cd3() {
    const _0x352bcf = ['2133263fTMrYB', 'color', '673857maEvWv', '1582889jfHnJE', '8RCdzkw', 'clearRect', '5zfiDFU', '10VfDErF', 'getContext', 'beginPath', 'height', 'closePath', '352452peDNJN', 'mouseover', 'radius', '593742aZtUTk', 'arc', '2cCMFzK', '142474ltxlYk', 'blue', 'draw', 'addEventListener', 'width', '577386bYIQVL', 'mouseout'];
    a0_0x1cd3 = function() {
        return _0x352bcf;
    };
    return a0_0x1cd3();
}
let raf;
const ball = {
    'x': 0x64,
    'y': 0x64,
    'vx': 0x5,
    'vy': 0x2,
    'radius': 0x19,
    'color': a0_0x14b68c(0x1ea),
    'draw'() {
        const _0x525dcc = a0_0x14b68c;
        ctx[_0x525dcc(0x1f9)](), ctx[_0x525dcc(0x200)](this['x'], this['y'], this[_0x525dcc(0x1fe)], 0x0, Math['PI'] * 0x2, !![]), ctx[_0x525dcc(0x1fb)](), ctx['fillStyle'] = this[_0x525dcc(0x1f1)], ctx['fill']();
    }
};

function draw() {
    const _0x281590 = a0_0x14b68c;
    ctx[_0x281590(0x1f5)](0x0, 0x0, canvas[_0x281590(0x1ed)], canvas[_0x281590(0x1fa)]), ball[_0x281590(0x1eb)](), ball['x'] += ball['vx'], ball['y'] += ball['vy'], raf = window['requestAnimationFrame'](draw);
}
canvas[a0_0x14b68c(0x1ec)](a0_0x14b68c(0x1fd), _0x5f5827 => {
    raf = window['requestAnimationFrame'](draw);
}), canvas['addEventListener'](a0_0x14b68c(0x1ef), _0x287169 => {
    window['cancelAnimationFrame'](raf);
}), ball[a0_0x14b68c(0x1eb)]();