const a0_0xbd7d46 = a0_0x5619;
(function(_0x4cbeac, _0x1780fe) {
    const _0x2aee5e = a0_0x5619,
        _0x2bf6b6 = _0x4cbeac();
    while (!![]) {
        try {
            const _0x1aedf9 = parseInt(_0x2aee5e(0x15b)) / 0x1 * (-parseInt(_0x2aee5e(0x15c)) / 0x2) + -parseInt(_0x2aee5e(0x159)) / 0x3 + -parseInt(_0x2aee5e(0x153)) / 0x4 + -parseInt(_0x2aee5e(0x15a)) / 0x5 + parseInt(_0x2aee5e(0x154)) / 0x6 + -parseInt(_0x2aee5e(0x155)) / 0x7 + parseInt(_0x2aee5e(0x156)) / 0x8;
            if (_0x1aedf9 === _0x1780fe) break;
            else _0x2bf6b6['push'](_0x2bf6b6['shift']());
        } catch (_0x17ae94) {
            _0x2bf6b6['push'](_0x2bf6b6['shift']());
        }
    }
}(a0_0x1546, 0x9b0c8));

function countDotInDotSequence(_0xe2e0b0) {
    const _0x137b5e = a0_0x5619;
    let _0x246baf = 0x0;
    for (let _0xb02659 = 0x0; _0xb02659 < _0xe2e0b0[_0x137b5e(0x15d)]; _0xb02659++) {
        _0xe2e0b0[_0xb02659] === '.' && _0x246baf++;
    }
    console[_0x137b5e(0x158)]('Sequence\x20of\x20dots:\x20\x22' + _0xe2e0b0 + '\x22'), console[_0x137b5e(0x158)](_0x137b5e(0x15e) + _0x246baf);
}

function a0_0x5619(_0x330311, _0x490a28) {
    const _0x15469c = a0_0x1546();
    return a0_0x5619 = function(_0x5619de, _0x2c66df) {
        _0x5619de = _0x5619de - 0x153;
        let _0x56ee83 = _0x15469c[_0x5619de];
        return _0x56ee83;
    }, a0_0x5619(_0x330311, _0x490a28);
}
countDotInDotSequence('............'), countDotInDotSequence(a0_0xbd7d46(0x157)), countDotInDotSequence('.......'), countDotInDotSequence('');

function a0_0x1546() {
    const _0xc76d4a = ['length', 'Number\x20of\x20dots:\x20', '4053328OZjMvf', '1232436HFaJat', '975415xVBWYF', '25805368PDBWXF', '.....', 'log', '1664892jhnjVN', '2048185EXPwrT', '678719vaECXs', '2rDCctq'];
    a0_0x1546 = function() {
        return _0xc76d4a;
    };
    return a0_0x1546();
}