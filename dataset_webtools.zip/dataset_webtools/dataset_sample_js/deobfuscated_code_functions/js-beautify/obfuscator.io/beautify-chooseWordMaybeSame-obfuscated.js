const a0_0x168bbc = a0_0x2edc;
(function(_0x161ce1, _0x270c8b) {
    const _0x36dd93 = a0_0x2edc,
        _0x1e8672 = _0x161ce1();
    while (!![]) {
        try {
            const _0x93bbd6 = parseInt(_0x36dd93(0xd4)) / 0x1 * (-parseInt(_0x36dd93(0xd0)) / 0x2) + parseInt(_0x36dd93(0xdb)) / 0x3 + -parseInt(_0x36dd93(0xe0)) / 0x4 + parseInt(_0x36dd93(0xc9)) / 0x5 * (parseInt(_0x36dd93(0xd6)) / 0x6) + parseInt(_0x36dd93(0xd3)) / 0x7 * (-parseInt(_0x36dd93(0xca)) / 0x8) + -parseInt(_0x36dd93(0xd5)) / 0x9 * (parseInt(_0x36dd93(0xcc)) / 0xa) + parseInt(_0x36dd93(0xcb)) / 0xb;
            if (_0x93bbd6 === _0x270c8b) break;
            else _0x1e8672['push'](_0x1e8672['shift']());
        } catch (_0x253333) {
            _0x1e8672['push'](_0x1e8672['shift']());
        }
    }
}(a0_0x1254, 0xb1e94));

function a0_0x1254() {
    const _0x27119d = ['99016qfqKNk', '17117650TMMOED', '1104890XMnyuR', 'log', 'Tranquility', 'Stillness', '20742hGEoyt', 'No,\x20we\x20did\x20not\x20choose\x20the\x20same\x20word.', 'Solitude', '609ByLtom', '67xdAogh', '54pfttNN', '6AYhQjo', 'Forest', 'River', 'Harmony', 'Yes,\x20we\x20chose\x20the\x20same\x20word!', '4317564VAVRMT', 'Serenity', 'Did\x20we\x20choose\x20the\x20same\x20word?\x20', 'Relaxation', 'random', '4084472lGkBQF', '5945470Uenizz'];
    a0_0x1254 = function() {
        return _0x27119d;
    };
    return a0_0x1254();
}

function chooseWordMaybeSame(_0xa8435d) {
    const _0x3e39d3 = a0_0x2edc,
        _0x27b37b = [_0x3e39d3(0xce), _0x3e39d3(0xdc), _0x3e39d3(0xd9), _0x3e39d3(0xcf), 'Zen', _0x3e39d3(0xd2), _0x3e39d3(0xde), 'Bliss', _0x3e39d3(0xd7), _0x3e39d3(0xd8)];
    console[_0x3e39d3(0xcd)]('Choose\x20one\x20of\x20the\x20following\x20words:\x20Tranquility,\x20Serenity,\x20Harmony,\x20Stillness,\x20Zen,\x20Solitude,\x20Relaxation,\x20Bliss,\x20Forest,\x20River'), console[_0x3e39d3(0xcd)](_0xa8435d), setTimeout(function() {
        const _0x24fe9e = _0x3e39d3,
            _0x487449 = _0x27b37b[Math['floor'](Math[_0x24fe9e(0xdf)]() * _0x27b37b['length'])];
        console[_0x24fe9e(0xcd)](_0x24fe9e(0xdd) + _0x487449);
        const _0x1c25f2 = _0x487449 == _0xa8435d;
        _0x1c25f2 ? console[_0x24fe9e(0xcd)](_0x24fe9e(0xda)) : console[_0x24fe9e(0xcd)](_0x24fe9e(0xd1));
    }, 0x7d0);
}

function a0_0x2edc(_0x1c760c, _0x17da5f) {
    const _0x125431 = a0_0x1254();
    return a0_0x2edc = function(_0x2edce5, _0xd037f8) {
        _0x2edce5 = _0x2edce5 - 0xc9;
        let _0x5f171e = _0x125431[_0x2edce5];
        return _0x5f171e;
    }, a0_0x2edc(_0x1c760c, _0x17da5f);
}
chooseWordMaybeSame(a0_0x168bbc(0xd9));