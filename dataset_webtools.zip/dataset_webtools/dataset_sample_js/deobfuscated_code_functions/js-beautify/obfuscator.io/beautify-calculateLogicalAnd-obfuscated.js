(function(_0x33950b, _0x428992) {
    const _0x500e66 = a0_0x423e,
        _0x1ae237 = _0x33950b();
    while (!![]) {
        try {
            const _0x2a4e1b = -parseInt(_0x500e66(0x77)) / 0x1 * (parseInt(_0x500e66(0x83)) / 0x2) + parseInt(_0x500e66(0x7d)) / 0x3 + -parseInt(_0x500e66(0x76)) / 0x4 + parseInt(_0x500e66(0x82)) / 0x5 + parseInt(_0x500e66(0x7f)) / 0x6 * (parseInt(_0x500e66(0x81)) / 0x7) + -parseInt(_0x500e66(0x7e)) / 0x8 + parseInt(_0x500e66(0x79)) / 0x9 * (parseInt(_0x500e66(0x80)) / 0xa);
            if (_0x2a4e1b === _0x428992) break;
            else _0x1ae237['push'](_0x1ae237['shift']());
        } catch (_0x46cbd4) {
            _0x1ae237['push'](_0x1ae237['shift']());
        }
    }
}(a0_0x48c2, 0x5f995));

function calculateLogicalAnd(_0x5c16ee) {
    const _0x40d3cf = a0_0x423e;
    if (_0x5c16ee[_0x40d3cf(0x78)] !== 0x2) {
        console[_0x40d3cf(0x7c)](_0x40d3cf(0x7b));
        return;
    }
    let _0x21eb81 = _0x5c16ee[0x0] && _0x5c16ee[0x1];
    console[_0x40d3cf(0x7c)](_0x40d3cf(0x84) + _0x5c16ee[0x0] + '\x20and\x20' + _0x5c16ee[0x1] + _0x40d3cf(0x7a) + _0x21eb81);
}

function a0_0x423e(_0x3d4215, _0x5bd4f5) {
    const _0x48c26a = a0_0x48c2();
    return a0_0x423e = function(_0x423e60, _0x4afb6c) {
        _0x423e60 = _0x423e60 - 0x76;
        let _0x2245f1 = _0x48c26a[_0x423e60];
        return _0x2245f1;
    }, a0_0x423e(_0x3d4215, _0x5bd4f5);
}
calculateLogicalAnd([!![], !![]]), calculateLogicalAnd([!![], ![]]), calculateLogicalAnd([![], ![]]), calculateLogicalAnd([![], !![]]);

function a0_0x48c2() {
    const _0x1b523a = ['2895296SqibjZ', '5OvlwHl', 'length', '958653qgdMJe', '\x20is\x20', 'Error:\x20Array\x20must\x20have\x20exactly\x202\x20elements', 'log', '323769ZPIcpE', '3251576GScfqK', '6GwxsRE', '80jIvqhq', '4532668XuFBvC', '883155UpNSJO', '104948ClShED', 'Logical\x20AND\x20between\x20'];
    a0_0x48c2 = function() {
        return _0x1b523a;
    };
    return a0_0x48c2();
}