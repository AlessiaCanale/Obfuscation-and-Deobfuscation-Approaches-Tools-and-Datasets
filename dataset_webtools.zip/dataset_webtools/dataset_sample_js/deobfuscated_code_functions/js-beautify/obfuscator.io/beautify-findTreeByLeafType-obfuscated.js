function a0_0x2734(_0x436b5c, _0x559370) {
    var _0x5e0578 = a0_0x5e05();
    return a0_0x2734 = function(_0x2734f9, _0x5c81ef) {
        _0x2734f9 = _0x2734f9 - 0x1b9;
        var _0x4a93fe = _0x5e0578[_0x2734f9];
        return _0x4a93fe;
    }, a0_0x2734(_0x436b5c, _0x559370);
}
var a0_0x447a13 = a0_0x2734;
(function(_0x241bf4, _0x150b86) {
    var _0x44244f = a0_0x2734,
        _0x32a07d = _0x241bf4();
    while (!![]) {
        try {
            var _0x13b411 = -parseInt(_0x44244f(0x1c7)) / 0x1 * (-parseInt(_0x44244f(0x1c8)) / 0x2) + -parseInt(_0x44244f(0x1c2)) / 0x3 + -parseInt(_0x44244f(0x1bd)) / 0x4 + parseInt(_0x44244f(0x1c6)) / 0x5 + parseInt(_0x44244f(0x1c1)) / 0x6 + parseInt(_0x44244f(0x1bf)) / 0x7 + -parseInt(_0x44244f(0x1cb)) / 0x8;
            if (_0x13b411 === _0x150b86) break;
            else _0x32a07d['push'](_0x32a07d['shift']());
        } catch (_0xec3f8b) {
            _0x32a07d['push'](_0x32a07d['shift']());
        }
    }
}(a0_0x5e05, 0x47190));

function findTreeByLeafType(_0x5819c5) {
    var _0x2ac568 = a0_0x2734;
    switch (_0x5819c5) {
        case _0x2ac568(0x1b9):
            console[_0x2ac568(0x1c3)](_0x2ac568(0x1d0));
            break;
        case _0x2ac568(0x1ba):
            console[_0x2ac568(0x1c3)]('Example\x20tree:\x20Poplar\x20Tree\x0aExplanation:\x20Lanceolate\x20leaves\x20have\x20a\x20narrow\x20and\x20elongated\x20shape\x20with\x20a\x20pointed\x20tip.\x20They\x20are\x20common\x20in\x20trees\x20like\x20poplars\x20and\x20willows.');
            break;
        case _0x2ac568(0x1bc):
            console[_0x2ac568(0x1c3)]('Example\x20tree:\x20Beech\x20Tree\x0aExplanation:\x20Ovate\x20leaves\x20have\x20an\x20oval\x20shape\x20with\x20regular\x20edges.\x20They\x20are\x20typical\x20of\x20trees\x20like\x20beeches\x20and\x20planes.');
            break;
        case _0x2ac568(0x1cc):
            console[_0x2ac568(0x1c3)](_0x2ac568(0x1ca));
            break;
        case _0x2ac568(0x1c9):
            console[_0x2ac568(0x1c3)](_0x2ac568(0x1cd));
            break;
        case _0x2ac568(0x1bb):
            console[_0x2ac568(0x1c3)](_0x2ac568(0x1ce));
            break;
        case _0x2ac568(0x1cf):
            console[_0x2ac568(0x1c3)](_0x2ac568(0x1c4));
            break;
        case _0x2ac568(0x1c5):
            console[_0x2ac568(0x1c3)](_0x2ac568(0x1c0));
            break;
        default:
            console[_0x2ac568(0x1c3)](_0x2ac568(0x1be));
    }
}
findTreeByLeafType(a0_0x447a13(0x1b9)), findTreeByLeafType(a0_0x447a13(0x1cc)), findTreeByLeafType(a0_0x447a13(0x1bb));

function a0_0x5e05() {
    var _0x3fa5f1 = ['1977150hrmGLd', 'Example\x20tree:\x20Robinia\x20Tree\x20(Black\x20Locust)\x0aExplanation:\x20Compound\x20leaves\x20are\x20composed\x20of\x20multiple\x20leaflets\x20branching\x20off\x20from\x20a\x20single\x20petiole.\x20They\x20are\x20typical\x20of\x20trees\x20like\x20robinias\x20and\x20wisterias.', '1443996cXjxXk', '275796eitiON', 'log', 'Example\x20tree:\x20Ash\x20Tree\x0aExplanation:\x20Pinnate\x20leaves\x20are\x20divided\x20into\x20feather-like\x20leaflets.\x20They\x20are\x20common\x20in\x20trees\x20like\x20ash\x20trees\x20and\x20elderberries.', 'Compound', '1739700tabgel', '21CsPfiE', '50080PkeCRh', 'Palmate', 'Example\x20tree:\x20Lime\x20Tree\x20(Tilia)\x0aExplanation:\x20Cordate\x20leaves\x20have\x20a\x20heart\x20shape\x20with\x20a\x20rounded\x20base.\x20They\x20are\x20common\x20in\x20trees\x20like\x20limes\x20and\x20black\x20poplars.', '3734272tVGxzM', 'Cordate', 'Example\x20tree:\x20Maple\x20Tree\x0aExplanation:\x20Palmate\x20leaves\x20have\x20a\x20hand-like\x20shape\x20with\x20open\x20fingers.\x20They\x20are\x20common\x20in\x20trees\x20like\x20maples\x20and\x20plane\x20trees.', 'Example\x20tree:\x20Oak\x20Tree\x0aExplanation:\x20Lobed\x20leaves\x20have\x20deep\x20lobes\x20or\x20incisions\x20on\x20the\x20edges.\x20They\x20are\x20typical\x20of\x20trees\x20like\x20oaks\x20and\x20raspberries.', 'Pinnate', 'Example\x20tree:\x20Pine\x20Tree\x0aExplanation:\x20Needle-like\x20leaves\x20are\x20typical\x20of\x20coniferous\x20trees\x20such\x20as\x20pines\x20and\x20firs.\x20They\x20have\x20elongated\x20and\x20pointed\x20shape.', 'Needle-like', 'Lanceolate', 'Lobed', 'Ovate', '2187856IteeXs', 'Invalid\x20leaf\x20type\x20provided.'];
    a0_0x5e05 = function() {
        return _0x3fa5f1;
    };
    return a0_0x5e05();
}