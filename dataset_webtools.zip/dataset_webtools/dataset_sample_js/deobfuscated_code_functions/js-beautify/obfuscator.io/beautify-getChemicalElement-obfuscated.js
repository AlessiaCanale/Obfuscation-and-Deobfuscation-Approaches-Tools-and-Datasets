(function(_0x541dd4, _0x373e27) {
    const _0x506667 = a0_0x2b27,
        _0x426b01 = _0x541dd4();
    while (!![]) {
        try {
            const _0x3e2531 = parseInt(_0x506667(0x19a)) / 0x1 * (parseInt(_0x506667(0x18d)) / 0x2) + -parseInt(_0x506667(0x19f)) / 0x3 * (parseInt(_0x506667(0x190)) / 0x4) + -parseInt(_0x506667(0x18c)) / 0x5 + parseInt(_0x506667(0x197)) / 0x6 + parseInt(_0x506667(0x19d)) / 0x7 + parseInt(_0x506667(0x180)) / 0x8 * (parseInt(_0x506667(0x185)) / 0x9) + -parseInt(_0x506667(0x189)) / 0xa;
            if (_0x3e2531 === _0x373e27) break;
            else _0x426b01['push'](_0x426b01['shift']());
        } catch (_0x16cc16) {
            _0x426b01['push'](_0x426b01['shift']());
        }
    }
}(a0_0x1f89, 0x24fdd));

function a0_0x2b27(_0x23231c, _0xfd0325) {
    const _0x1f89a1 = a0_0x1f89();
    return a0_0x2b27 = function(_0x2b2789, _0x45500f) {
        _0x2b2789 = _0x2b2789 - 0x180;
        let _0x2a0c8b = _0x1f89a1[_0x2b2789];
        return _0x2a0c8b;
    }, a0_0x2b27(_0x23231c, _0xfd0325);
}

function getChemicalElement() {
    const _0x456a03 = a0_0x2b27,
        _0x575582 = {
            'H': _0x456a03(0x192),
            'He': _0x456a03(0x19e),
            'Li': 'Lithium',
            'Be': 'Beryllium',
            'B': _0x456a03(0x187),
            'C': _0x456a03(0x19b),
            'N': 'Nitrogen',
            'O': 'Oxygen',
            'F': _0x456a03(0x195),
            'Ne': _0x456a03(0x194),
            'Na': _0x456a03(0x18b),
            'Mg': 'Magnesium',
            'Al': _0x456a03(0x198),
            'Si': _0x456a03(0x19c),
            'P': 'Phosphorus',
            'S': _0x456a03(0x196),
            'Cl': 'Chlorine',
            'K': _0x456a03(0x186),
            'Ca': _0x456a03(0x18a),
            'Ar': _0x456a03(0x183)
        },
        _0x316d6f = Object[_0x456a03(0x191)](_0x575582)[_0x456a03(0x193)](() => 0.5 - Math[_0x456a03(0x188)]())[_0x456a03(0x199)](0x0, 0x5);
    return _0x316d6f[_0x456a03(0x181)](_0x309f42 => ({
        'symbol': _0x309f42,
        'element': _0x575582[_0x309f42]
    }));
}

function a0_0x1f89() {
    const _0x1202a7 = ['Fluorine', 'Sulfur', '1275054oIerXW', 'Aluminum', 'slice', '362UzKgHi', 'Carbon', 'Silicon', '993104cHkhRy', 'Helium', '186099IaNWxQ', '1196408tHYaQp', 'map', 'Symbol:\x20', 'Argon', 'log', '9lXsmTe', 'Potassium', 'Boron', 'random', '1084570NClTps', 'Calcium', 'Sodium', '944015ZZWXYx', '38HwEDJF', 'element', 'symbol', '4GFbOhl', 'keys', 'Hydrogen', 'sort', 'Neon'];
    a0_0x1f89 = function() {
        return _0x1202a7;
    };
    return a0_0x1f89();
}
const randomElements = getChemicalElement();
randomElements['forEach'](_0x57a595 => {
    const _0x86df89 = a0_0x2b27;
    console[_0x86df89(0x184)](_0x86df89(0x182) + _0x57a595[_0x86df89(0x18f)] + ',\x20Element:\x20' + _0x57a595[_0x86df89(0x18e)]);
});