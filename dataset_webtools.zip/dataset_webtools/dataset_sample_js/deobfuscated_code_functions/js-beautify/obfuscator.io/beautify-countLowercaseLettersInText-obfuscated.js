const a0_0x42d01c = a0_0xaa6b;

function a0_0x4e0c() {
    const _0x327a9f = ['752350pAbdAx', '1XpILUO', '199884OgDnDS', 'Hello\x20World!\x20This\x20Is\x20An\x20Example\x20Text.', '4870019hdqvlC', '1060196QCMHra', 'Original\x20Text:\x20\x22', '1225320UXidbg', '3mlEECS', '8913512gLfdpN', '13773699aNdjir', 'log', 'length'];
    a0_0x4e0c = function() {
        return _0x327a9f;
    };
    return a0_0x4e0c();
}

function a0_0xaa6b(_0x3ce37b, _0x59b878) {
    const _0x4e0cdd = a0_0x4e0c();
    return a0_0xaa6b = function(_0xaa6b8c, _0x3b26a1) {
        _0xaa6b8c = _0xaa6b8c - 0xb2;
        let _0x47d27b = _0x4e0cdd[_0xaa6b8c];
        return _0x47d27b;
    }, a0_0xaa6b(_0x3ce37b, _0x59b878);
}(function(_0x3d03a2, _0x331695) {
    const _0xd7894b = a0_0xaa6b,
        _0x32a9c9 = _0x3d03a2();
    while (!![]) {
        try {
            const _0x4620be = -parseInt(_0xd7894b(0xb2)) / 0x1 * (parseInt(_0xd7894b(0xb3)) / 0x2) + parseInt(_0xd7894b(0xb9)) / 0x3 * (-parseInt(_0xd7894b(0xb6)) / 0x4) + parseInt(_0xd7894b(0xbe)) / 0x5 + -parseInt(_0xd7894b(0xb8)) / 0x6 + parseInt(_0xd7894b(0xb5)) / 0x7 + -parseInt(_0xd7894b(0xba)) / 0x8 + parseInt(_0xd7894b(0xbb)) / 0x9;
            if (_0x4620be === _0x331695) break;
            else _0x32a9c9['push'](_0x32a9c9['shift']());
        } catch (_0x35beea) {
            _0x32a9c9['push'](_0x32a9c9['shift']());
        }
    }
}(a0_0x4e0c, 0xa93ce));

function countLowercaseLettersInText(_0x2916c4) {
    const _0x3a89ed = a0_0xaa6b;
    let _0x5caa15 = 0x0;
    for (let _0x55e11f = 0x0; _0x55e11f < _0x2916c4[_0x3a89ed(0xbd)]; _0x55e11f++) {
        _0x2916c4[_0x55e11f] >= 'a' && _0x2916c4[_0x55e11f] <= 'z' && _0x5caa15++;
    }
    console[_0x3a89ed(0xbc)](_0x3a89ed(0xb7) + _0x2916c4 + '\x22'), console['log']('Number\x20of\x20Lowercase\x20Letters:\x20' + _0x5caa15);
}
countLowercaseLettersInText(a0_0x42d01c(0xb4));