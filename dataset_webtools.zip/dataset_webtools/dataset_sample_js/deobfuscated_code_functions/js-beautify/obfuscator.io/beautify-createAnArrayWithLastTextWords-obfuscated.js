const a0_0x3afde4 = a0_0x41ea;
(function(_0x3ae0b8, _0x432731) {
    const _0x2911db = a0_0x41ea,
        _0x97fe8c = _0x3ae0b8();
    while (!![]) {
        try {
            const _0x150b77 = -parseInt(_0x2911db(0xe3)) / 0x1 + parseInt(_0x2911db(0xdd)) / 0x2 * (-parseInt(_0x2911db(0xe1)) / 0x3) + -parseInt(_0x2911db(0xe0)) / 0x4 + parseInt(_0x2911db(0xd5)) / 0x5 * (parseInt(_0x2911db(0xd3)) / 0x6) + parseInt(_0x2911db(0xd9)) / 0x7 + -parseInt(_0x2911db(0xcf)) / 0x8 * (-parseInt(_0x2911db(0xd0)) / 0x9) + parseInt(_0x2911db(0xdc)) / 0xa * (parseInt(_0x2911db(0xd6)) / 0xb);
            if (_0x150b77 === _0x432731) break;
            else _0x97fe8c['push'](_0x97fe8c['shift']());
        } catch (_0x8f9aa6) {
            _0x97fe8c['push'](_0x97fe8c['shift']());
        }
    }
}(a0_0x6001, 0x31ad2));

function createAnArrayWithLastTextWords(_0x1c9470) {
    const _0x4ab399 = a0_0x41ea;
    let _0x456c56 = _0x1c9470[_0x4ab399(0xe5)](/\s+/);
    if (_0x456c56[_0x4ab399(0xe4)] < 0x19) {
        console[_0x4ab399(0xd4)](_0x4ab399(0xdb));
        return;
    }
    let _0x4fae63 = Math[_0x4ab399(0xe2)](Math[_0x4ab399(0xd2)]() * 0x7) + 0x1,
        _0x39751f = [],
        _0x51cd87 = new Set();
    for (let _0x4f4fdf = _0x456c56[_0x4ab399(0xe4)] - 0x1; _0x4f4fdf >= 0x0; _0x4f4fdf--) {
        let _0x52c300 = _0x456c56[_0x4f4fdf];
        !_0x51cd87[_0x4ab399(0xd7)](_0x52c300) && (_0x39751f[_0x4ab399(0xda)](_0x52c300), _0x51cd87['add'](_0x52c300));
        if (_0x39751f[_0x4ab399(0xe4)] === _0x4fae63) break;
    }
    console[_0x4ab399(0xd4)]('Original\x20text:'), console[_0x4ab399(0xd4)](_0x1c9470), console['log'](_0x4ab399(0xd1) + _0x4fae63), console['log'](_0x4ab399(0xd8) + _0x4fae63 + _0x4ab399(0xdf)), console[_0x4ab399(0xd4)](_0x39751f);
}
let sampleText = a0_0x3afde4(0xde);

function a0_0x41ea(_0x20dae0, _0x14d534) {
    const _0x60016a = a0_0x6001();
    return a0_0x41ea = function(_0x41ea64, _0x54ebc2) {
        _0x41ea64 = _0x41ea64 - 0xcf;
        let _0x3dadca = _0x60016a[_0x41ea64];
        return _0x3dadca;
    }, a0_0x41ea(_0x20dae0, _0x14d534);
}
createAnArrayWithLastTextWords(sampleText);

function a0_0x6001() {
    const _0x2a9fdc = ['2778008oSzCwQ', '9ZVLHav', 'Random\x20number\x20n1:\x20', 'random', '6bywUXl', 'log', '1857295iIYOZl', '671AzZMEC', 'has', 'Array\x20arr\x20with\x20last\x20', '119070dllXJv', 'unshift', 'Error:\x20The\x20text\x20should\x20contain\x20at\x20least\x2025\x20words.', '28330knAqYE', '167198Fegpuu', 'This\x20is\x20a\x20sample\x20text\x20with\x20at\x20least\x2025\x20words.\x20It\x20contains\x20more\x20than\x2025\x20words\x20to\x20ensure\x20we\x20can\x20select\x20enough\x20unique\x20words.hi,\x20how\x20are\x20you?', '\x20unique\x20words:', '1090388wScgBX', '3VbmDpr', 'floor', '348863RiYxJG', 'length', 'split'];
    a0_0x6001 = function() {
        return _0x2a9fdc;
    };
    return a0_0x6001();
}