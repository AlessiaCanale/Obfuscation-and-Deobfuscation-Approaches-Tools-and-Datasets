const a0_0x1f3022 = a0_0x4e50;
(function(_0x49a216, _0x5a03d8) {
    const _0x1b8ed7 = a0_0x4e50,
        _0x4a7ab1 = _0x49a216();
    while (!![]) {
        try {
            const _0x32f639 = parseInt(_0x1b8ed7(0x1df)) / 0x1 * (parseInt(_0x1b8ed7(0x1d8)) / 0x2) + -parseInt(_0x1b8ed7(0x1dd)) / 0x3 + -parseInt(_0x1b8ed7(0x1d9)) / 0x4 + parseInt(_0x1b8ed7(0x1d5)) / 0x5 * (parseInt(_0x1b8ed7(0x1db)) / 0x6) + -parseInt(_0x1b8ed7(0x1d3)) / 0x7 + parseInt(_0x1b8ed7(0x1e1)) / 0x8 * (parseInt(_0x1b8ed7(0x1de)) / 0x9) + parseInt(_0x1b8ed7(0x1d4)) / 0xa;
            if (_0x32f639 === _0x5a03d8) break;
            else _0x4a7ab1['push'](_0x4a7ab1['shift']());
        } catch (_0x187a99) {
            _0x4a7ab1['push'](_0x4a7ab1['shift']());
        }
    }
}(a0_0x4710, 0x412ca));

function a0_0x4e50(_0x498104, _0x5c0ac2) {
    const _0x4710fc = a0_0x4710();
    return a0_0x4e50 = function(_0x4e5009, _0x478936) {
        _0x4e5009 = _0x4e5009 - 0x1d3;
        let _0x4f5368 = _0x4710fc[_0x4e5009];
        return _0x4f5368;
    }, a0_0x4e50(_0x498104, _0x5c0ac2);
}

function findAlphabetLetter(_0x870441) {
    const _0x2c4fb3 = a0_0x4e50,
        _0x3d9491 = {},
        _0x1bb792 = /[a-zA-Z]/g,
        _0x472ada = _0x870441[_0x2c4fb3(0x1e0)](_0x1bb792, _0x597b0e => {
            const _0x27bd7d = _0x2c4fb3;
            return !_0x3d9491[_0x597b0e[_0x27bd7d(0x1da)]()] ? (_0x3d9491[_0x597b0e[_0x27bd7d(0x1da)]()] = !![], '[' + _0x597b0e['toUpperCase']() + ']') : _0x597b0e;
        });
    return console[_0x2c4fb3(0x1d6)](_0x2c4fb3(0x1d7) + _0x870441), console[_0x2c4fb3(0x1d6)](_0x2c4fb3(0x1dc) + _0x472ada), _0x472ada;
}
const text = a0_0x1f3022(0x1e2);

function a0_0x4710() {
    const _0x58df80 = ['19178VZseek', '34484eXvlmX', 'toUpperCase', '433974ORTcEX', 'Modified\x20text:\x20', '565773ebWHzY', '7488ZGOHYU', '18IpHdyR', 'replace', '688RrNBwJ', 'The\x20quick\x20brown\x20fox\x20jumps\x20over\x20the\x20lazy\x20dog.', 'Embrace\x20the\x20journey,\x20for\x20within\x20it\x20lie\x20the\x20moments\x20that\x20shape\x20us.', '3718519NnPFsV', '2449260FbjgtI', '35TNZTzC', 'log', 'Original\x20text:\x20'];
    a0_0x4710 = function() {
        return _0x58df80;
    };
    return a0_0x4710();
}
findAlphabetLetter(text);
const text1 = a0_0x1f3022(0x1e3);
findAlphabetLetter(text1);