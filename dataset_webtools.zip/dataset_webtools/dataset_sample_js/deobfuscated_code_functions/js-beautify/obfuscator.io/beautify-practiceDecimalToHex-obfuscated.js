function a0_0xed65() {
    const _0x39900c = ['toUpperCase', '999710YnxBpq', '111WhBjyD', '51258KTxkEe', '144tuFyCj', 'toString', 'random', 'floor', '24216HaiaBp', '169050VGLmtm', '486bPHjSb', '299200eGiUaq', '10IBhClO', '63IeWjrD', 'Random\x20decimal\x20number:\x20', '12761bUhCMG', '52616AfGFpR', 'Try\x20to\x20convert\x20the\x20decimal\x20number\x20shown\x20above\x20to\x20hexadecimal.\x20The\x20answer\x20will\x20be\x20shown\x20in\x2010\x20seconds.', 'log'];
    a0_0xed65 = function() {
        return _0x39900c;
    };
    return a0_0xed65();
}

function a0_0x2bca(_0x8c27bb, _0x2ac758) {
    const _0xed65a3 = a0_0xed65();
    return a0_0x2bca = function(_0x2bcab8, _0x4fbb61) {
        _0x2bcab8 = _0x2bcab8 - 0x188;
        let _0xfe03db = _0xed65a3[_0x2bcab8];
        return _0xfe03db;
    }, a0_0x2bca(_0x8c27bb, _0x2ac758);
}(function(_0x3480e4, _0x1e1f0e) {
    const _0x1e2bed = a0_0x2bca,
        _0x2dcc2b = _0x3480e4();
    while (!![]) {
        try {
            const _0x560f17 = -parseInt(_0x1e2bed(0x189)) / 0x1 * (parseInt(_0x1e2bed(0x193)) / 0x2) + -parseInt(_0x1e2bed(0x192)) / 0x3 * (parseInt(_0x1e2bed(0x198)) / 0x4) + parseInt(_0x1e2bed(0x199)) / 0x5 + -parseInt(_0x1e2bed(0x19a)) / 0x6 * (-parseInt(_0x1e2bed(0x18c)) / 0x7) + parseInt(_0x1e2bed(0x18d)) / 0x8 * (parseInt(_0x1e2bed(0x18a)) / 0x9) + parseInt(_0x1e2bed(0x191)) / 0xa + -parseInt(_0x1e2bed(0x188)) / 0xb * (-parseInt(_0x1e2bed(0x194)) / 0xc);
            if (_0x560f17 === _0x1e1f0e) break;
            else _0x2dcc2b['push'](_0x2dcc2b['shift']());
        } catch (_0x53ae8e) {
            _0x2dcc2b['push'](_0x2dcc2b['shift']());
        }
    }
}(a0_0xed65, 0x2a61b));

function practiceDecimalToHex() {
    const _0x481835 = a0_0x2bca,
        _0x541396 = Math[_0x481835(0x197)](Math[_0x481835(0x196)]() * 0x65),
        _0x23f79f = _0x541396[_0x481835(0x195)](0x10)[_0x481835(0x190)]();
    console['log'](_0x481835(0x18b) + _0x541396), console[_0x481835(0x18f)](_0x481835(0x18e)), setTimeout(() => {
        const _0x167659 = _0x481835;
        console[_0x167659(0x18f)]('Random\x20decimal\x20number\x20in\x20hexadecimal:\x20' + _0x23f79f);
    }, 0x2710);
}
practiceDecimalToHex();