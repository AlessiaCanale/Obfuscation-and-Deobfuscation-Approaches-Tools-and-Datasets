(function(_0x3db70e, _0x1cd235) {
    const _0x50a279 = a0_0x3c78,
        _0x38f944 = _0x3db70e();
    while (!![]) {
        try {
            const _0xc51789 = parseInt(_0x50a279(0x1ef)) / 0x1 * (parseInt(_0x50a279(0x1e1)) / 0x2) + parseInt(_0x50a279(0x1e6)) / 0x3 + -parseInt(_0x50a279(0x1e4)) / 0x4 + parseInt(_0x50a279(0x1f5)) / 0x5 + -parseInt(_0x50a279(0x1f1)) / 0x6 * (-parseInt(_0x50a279(0x1ed)) / 0x7) + parseInt(_0x50a279(0x1e3)) / 0x8 * (parseInt(_0x50a279(0x1fb)) / 0x9) + -parseInt(_0x50a279(0x1f2)) / 0xa;
            if (_0xc51789 === _0x1cd235) break;
            else _0x38f944['push'](_0x38f944['shift']());
        } catch (_0x3ebeb9) {
            _0x38f944['push'](_0x38f944['shift']());
        }
    }
}(a0_0x3b6c, 0xead8d));

function animalSound() {
    const _0x438fff = a0_0x3c78,
        _0x4ef09f = [{
            'sound': 'meow',
            'animal': 'cat'
        }, {
            'sound': _0x438fff(0x1e7),
            'animal': _0x438fff(0x1f0)
        }, {
            'sound': _0x438fff(0x1fa),
            'animal': 'tiger'
        }, {
            'sound': 'buzz',
            'animal': _0x438fff(0x1f8)
        }, {
            'sound': _0x438fff(0x1e5),
            'animal': 'duck'
        }, {
            'sound': _0x438fff(0x1f4),
            'animal': _0x438fff(0x1e9)
        }, {
            'sound': _0x438fff(0x1ea),
            'animal': _0x438fff(0x1ec)
        }],
        _0x3bb4fa = Math[_0x438fff(0x1f3)](Math[_0x438fff(0x1f6)]() * _0x4ef09f[_0x438fff(0x1f7)]),
        _0x8f511e = _0x4ef09f[_0x3bb4fa];
    console[_0x438fff(0x1e8)](_0x438fff(0x1f9) + _0x8f511e[_0x438fff(0x1eb)]), console[_0x438fff(0x1e8)](_0x438fff(0x1ee) + _0x8f511e[_0x438fff(0x1e2)]);
}

function a0_0x3b6c() {
    const _0x1f31f7 = ['random', 'length', 'bee', 'Animal\x20sound:\x20', 'roar', '69129TzhTxD', '1862AOPfkO', 'animal', '120FkWyQD', '3717332kxDcRe', 'quack', '5723736UzOoZu', 'bark', 'log', 'frog', 'squeak', 'sound', 'mouse', '185164JeKkmy', 'Corresponding\x20animal:\x20', '1240NxyMQQ', 'dog', '138OKKcvj', '20822580tKJZXH', 'floor', 'croak', '937805cXZnIl'];
    a0_0x3b6c = function() {
        return _0x1f31f7;
    };
    return a0_0x3b6c();
}

function a0_0x3c78(_0x1ccf9e, _0xab4b71) {
    const _0x3b6c6e = a0_0x3b6c();
    return a0_0x3c78 = function(_0x3c783b, _0x2c54ba) {
        _0x3c783b = _0x3c783b - 0x1e1;
        let _0x25f393 = _0x3b6c6e[_0x3c783b];
        return _0x25f393;
    }, a0_0x3c78(_0x1ccf9e, _0xab4b71);
}
animalSound();