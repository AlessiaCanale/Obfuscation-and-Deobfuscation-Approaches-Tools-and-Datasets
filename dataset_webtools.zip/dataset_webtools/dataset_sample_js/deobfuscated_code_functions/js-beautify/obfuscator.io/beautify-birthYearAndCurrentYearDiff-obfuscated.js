(function(_0x3f805c, _0x2d25f9) {
    const _0x28ef15 = a0_0x1e76,
        _0x17344f = _0x3f805c();
    while (!![]) {
        try {
            const _0x195803 = parseInt(_0x28ef15(0x1d7)) / 0x1 * (parseInt(_0x28ef15(0x1de)) / 0x2) + -parseInt(_0x28ef15(0x1ce)) / 0x3 * (-parseInt(_0x28ef15(0x1da)) / 0x4) + -parseInt(_0x28ef15(0x1d5)) / 0x5 * (-parseInt(_0x28ef15(0x1cd)) / 0x6) + -parseInt(_0x28ef15(0x1d8)) / 0x7 * (-parseInt(_0x28ef15(0x1d3)) / 0x8) + -parseInt(_0x28ef15(0x1d4)) / 0x9 * (-parseInt(_0x28ef15(0x1dc)) / 0xa) + -parseInt(_0x28ef15(0x1d6)) / 0xb * (parseInt(_0x28ef15(0x1d9)) / 0xc) + -parseInt(_0x28ef15(0x1df)) / 0xd * (parseInt(_0x28ef15(0x1d1)) / 0xe);
            if (_0x195803 === _0x2d25f9) break;
            else _0x17344f['push'](_0x17344f['shift']());
        } catch (_0x53f570) {
            _0x17344f['push'](_0x17344f['shift']());
        }
    }
}(a0_0x5a74, 0xd1dcb));

function a0_0x5a74() {
    const _0x5239cd = ['19224fmKoTR', '9iaWbBQ', 'getFullYear', '\x20will\x20turn\x20', '35361382fRozNK', 'There\x20are\x20', '16NZTRpE', '4385403LKFVRP', '1290GMnHYf', '1439185idJZxS', '2XzsVok', '1714503tlYYzO', '156hKweKB', '1266264xLmwNY', 'log', '30xExqRH', '\x20is\x20the\x20current\x20year.', '1358274gNlbsn', '13ygYNIx', '\x20years\x20left\x20until\x20the\x20birth\x20year\x20', '\x20this\x20year.'];
    a0_0x5a74 = function() {
        return _0x5239cd;
    };
    return a0_0x5a74();
}

function a0_0x1e76(_0x24d8e6, _0x8af263) {
    const _0x5a746 = a0_0x5a74();
    return a0_0x1e76 = function(_0x1e7687, _0x108020) {
        _0x1e7687 = _0x1e7687 - 0x1cd;
        let _0x4f97ee = _0x5a746[_0x1e7687];
        return _0x4f97ee;
    }, a0_0x1e76(_0x24d8e6, _0x8af263);
}

function birthYearAndCurrentYearDiff(_0x411980) {
    const _0x3289c8 = a0_0x1e76,
        _0x45a978 = new Date(),
        _0x5a7977 = _0x45a978[_0x3289c8(0x1cf)]();
    if (_0x5a7977 > _0x411980) {
        const _0x142c09 = _0x5a7977 - _0x411980;
        return console[_0x3289c8(0x1db)]('The\x20person\x20born\x20in\x20' + _0x411980 + _0x3289c8(0x1d0) + _0x142c09 + _0x3289c8(0x1e1)), {
            'age': _0x142c09
        };
    } else {
        if (_0x5a7977 < _0x411980) {
            const _0x3b4d7a = _0x411980 - _0x5a7977;
            return console[_0x3289c8(0x1db)](_0x3289c8(0x1d2) + _0x3b4d7a + _0x3289c8(0x1e0) + _0x411980 + '.'), {
                'yearsUntilBirth': _0x3b4d7a
            };
        } else return console['log']('The\x20birth\x20year\x20' + _0x411980 + _0x3289c8(0x1dd)), {
            'age': 0x0
        };
    }
}
birthYearAndCurrentYearDiff(0x7c3), birthYearAndCurrentYearDiff(0x7f0);