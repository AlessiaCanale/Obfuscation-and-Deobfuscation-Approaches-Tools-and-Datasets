const a0_0x3b9d5c = a0_0xd9e1;
(function(_0x3e15bd, _0xbb0e5b) {
    const _0x5521b8 = a0_0xd9e1,
        _0x3b3c27 = _0x3e15bd();
    while (!![]) {
        try {
            const _0x3d33c5 = -parseInt(_0x5521b8(0x1aa)) / 0x1 + parseInt(_0x5521b8(0x1ac)) / 0x2 + -parseInt(_0x5521b8(0x1a5)) / 0x3 + parseInt(_0x5521b8(0x1a4)) / 0x4 + -parseInt(_0x5521b8(0x1ab)) / 0x5 + -parseInt(_0x5521b8(0x1af)) / 0x6 * (parseInt(_0x5521b8(0x1ad)) / 0x7) + parseInt(_0x5521b8(0x1a8)) / 0x8;
            if (_0x3d33c5 === _0xbb0e5b) break;
            else _0x3b3c27['push'](_0x3b3c27['shift']());
        } catch (_0x5ec43d) {
            _0x3b3c27['push'](_0x3b3c27['shift']());
        }
    }
}(a0_0x454c, 0x4bb83));

function replaceDecimalCommaWithLettera(_0x2f30dc) {
    const _0x5cf2b2 = a0_0xd9e1;
    return _0x2f30dc[_0x5cf2b2(0x1a7)](_0x479a20 => {
        const _0x37165d = _0x5cf2b2;
        return _0x479a20[_0x37165d(0x1ae)]()[_0x37165d(0x1a6)]('.', 'a');
    });
}

function a0_0xd9e1(_0x21a399, _0x5eaf51) {
    const _0x454cbb = a0_0x454c();
    return a0_0xd9e1 = function(_0xd9e160, _0xc6b64e) {
        _0xd9e160 = _0xd9e160 - 0x1a4;
        let _0x226f1a = _0x454cbb[_0xd9e160];
        return _0x226f1a;
    }, a0_0xd9e1(_0x21a399, _0x5eaf51);
}

function a0_0x454c() {
    const _0x37efeb = ['101630MWsXZC', '1323Oifuav', 'toString', '4542cVpbvF', '1514372vYWAVj', '738012pTvilC', 'replace', 'map', '7153568VOAijJ', 'log', '183087qEgfKO', '2206465nfXAdR'];
    a0_0x454c = function() {
        return _0x37efeb;
    };
    return a0_0x454c();
}
const numbers = [3.14, 2.718, 1.618],
    replacedNumbers = replaceDecimalCommaWithLettera(numbers);
console[a0_0x3b9d5c(0x1a9)](numbers + '\x0a' + replacedNumbers);