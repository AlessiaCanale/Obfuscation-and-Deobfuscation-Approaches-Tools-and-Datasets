function a0_0x260e(_0x2aca16, _0x537443) {
    var _0x18bf21 = a0_0x18bf();
    return a0_0x260e = function(_0x260eec, _0xdb5755) {
        _0x260eec = _0x260eec - 0x15b;
        var _0x1198f6 = _0x18bf21[_0x260eec];
        return _0x1198f6;
    }, a0_0x260e(_0x2aca16, _0x537443);
}(function(_0x4ec863, _0x2fe765) {
    var _0x49c9a8 = a0_0x260e,
        _0x2c27ca = _0x4ec863();
    while (!![]) {
        try {
            var _0x4809b6 = parseInt(_0x49c9a8(0x190)) / 0x1 * (parseInt(_0x49c9a8(0x19f)) / 0x2) + -parseInt(_0x49c9a8(0x17a)) / 0x3 + -parseInt(_0x49c9a8(0x177)) / 0x4 * (parseInt(_0x49c9a8(0x185)) / 0x5) + parseInt(_0x49c9a8(0x18a)) / 0x6 * (parseInt(_0x49c9a8(0x169)) / 0x7) + parseInt(_0x49c9a8(0x181)) / 0x8 * (-parseInt(_0x49c9a8(0x18f)) / 0x9) + parseInt(_0x49c9a8(0x19e)) / 0xa * (-parseInt(_0x49c9a8(0x16c)) / 0xb) + -parseInt(_0x49c9a8(0x16f)) / 0xc * (-parseInt(_0x49c9a8(0x1a1)) / 0xd);
            if (_0x4809b6 === _0x2fe765) break;
            else _0x2c27ca['push'](_0x2c27ca['shift']());
        } catch (_0x19eebb) {
            _0x2c27ca['push'](_0x2c27ca['shift']());
        }
    }
}(a0_0x18bf, 0x42d2a));

function a0_0x18bf() {
    var _0x50e68d = ['-=1300', '6ncjFsH', 'dataset', 'offsetWidth', 'path', '-=670', '9OAGRTF', '1OiSAqd', '-=474', '.main-logo-circle', '.bounce\x20path', '.letter-i\x20.line', 'easeOutElastic(1,\x20.5)', '.bounce\x20svg', 'cubicBezier(0.400,\x200.530,\x200.070,\x201)', '-=1273', 'easeOutQuad', '-=600', 'resize', '-=680', 'target', '10tWLQTH', '525598YpCNjr', 'linear-gradient(-135deg,\x20#FFFFFF\x2050%,\x20#F6F4F2\x2075%,\x20#F6F4F2\x20100%,\x20#DDDAD7\x20100%)', '989807mUecQA', 'easeInOutQuad', '-=970', '.letter-a', 'easeInOutSine', '.logo-animation', 'add', 'linear-gradient(-135deg,\x20#FFFFFF\x205%,\x20#F6F4F2\x2040%,\x20#F6F4F2\x2070%,\x20#DDDAD7\x20100%)', '80px', '60px', '-=140', '.bounced', '-=290', 'stagger', '.dot', '1turn', '2846725YyBKYY', 'querySelector', 'animatables', '5372147blGhzg', 'removeAttribute', 'easeOutElastic(1,\x20.6)', '120hGstiv', '.letter-e', '-=1090', 'easeOutQuart', '.letter-n', '50%\x20100%\x200px', 'set', 'easeOutElastic(1,\x20.8)', '284PvoUZf', 'easeInQuad', 'easeOutSine', '1135554vTaPeH', '.description-paragraph', 'spring(.2,\x20200,\x203,\x2060)', 'cubicBezier(0.175,\x200.865,\x200.245,\x200.840)', 'stroke-dasharray', '50%\x20100%\x200', 'center', '2320400XzxPHZ', 'easeOutElastic(1,\x20.9)', 'setDashoffset', 'cubicBezier(0.350,\x200.560,\x200.305,\x201)', '15tPVOYm', 'timeline', '.description-title', '.letter-i'];
    a0_0x18bf = function() {
        return _0x50e68d;
    };
    return a0_0x18bf();
}

function fitElementToParent(_0x13ad06, _0x2212a9, _0x43a18b) {
    var _0x51004f = a0_0x260e,
        _0x188609 = null;

    function _0x25286b() {
        var _0x1ed616 = a0_0x260e;
        if (_0x188609) clearTimeout(_0x188609);
        anime[_0x1ed616(0x175)](_0x13ad06, {
            'scale': 0x1
        });
        if (_0x43a18b) anime[_0x1ed616(0x175)](_0x43a18b, {
            'scale': 0x1
        });
        var _0x24254c = _0x2212a9 || 0x0,
            _0x5755fa = _0x13ad06['parentNode'],
            _0x2a64eb = _0x13ad06[_0x1ed616(0x18c)] - _0x24254c,
            _0x39fd3e = _0x5755fa[_0x1ed616(0x18c)],
            _0x40b727 = _0x39fd3e / _0x2a64eb,
            _0x188f1c = _0x2a64eb / _0x39fd3e;
        _0x188609 = setTimeout(function() {
            var _0x30c075 = _0x1ed616;
            anime[_0x30c075(0x175)](_0x13ad06, {
                'scale': _0x40b727
            });
            if (_0x43a18b) anime['set'](_0x43a18b, {
                'scale': _0x188f1c
            });
        }, 0xa);
    }
    _0x25286b(), window['addEventListener'](_0x51004f(0x19b), _0x25286b);
}
var logoAnimation = (function() {
    var _0x38dfb9 = a0_0x260e,
        _0x12d64f = document[_0x38dfb9(0x16a)](_0x38dfb9(0x15e)),
        _0x411fcf = anime[_0x38dfb9(0x18d)](_0x38dfb9(0x193));
    fitElementToParent(_0x12d64f, 0x0, _0x38dfb9(0x196)), anime[_0x38dfb9(0x175)](['.letter-a', _0x38dfb9(0x173), '.letter-i'], {
        'translateX': 0x46
    }), anime[_0x38dfb9(0x175)](_0x38dfb9(0x170), {
        'translateX': -0x46
    }), anime['set'](_0x38dfb9(0x167), {
        'translateX': 0x276,
        'translateY': -0xc8
    });
    var _0x318e61 = anime[_0x38dfb9(0x186)]({
        'autoplay': ![],
        'easing': 'easeOutSine'
    })[_0x38dfb9(0x15f)]({
        'targets': '.letter-i\x20.line',
        'duration': 0x0,
        'begin': function(_0x130701) {
            var _0x26e462 = _0x38dfb9;
            _0x130701[_0x26e462(0x16b)][0x0][_0x26e462(0x19d)][_0x26e462(0x16d)](_0x26e462(0x17e));
        }
    }, 0x0)['add']({
        'targets': _0x38dfb9(0x164),
        'transformOrigin': [_0x38dfb9(0x174), _0x38dfb9(0x174)],
        'translateY': [{
            'value': [0x96, -0xa0],
            'duration': 0xbe,
            'endDelay': 0x14,
            'easing': 'cubicBezier(0.225,\x201,\x200.915,\x200.980)'
        }, {
            'value': 0x4,
            'duration': 0x78,
            'easing': _0x38dfb9(0x178)
        }, {
            'value': 0x0,
            'duration': 0x78,
            'easing': _0x38dfb9(0x199)
        }],
        'scaleX': [{
            'value': [0.25, 0.85],
            'duration': 0xbe,
            'easing': _0x38dfb9(0x199)
        }, {
            'value': 1.08,
            'duration': 0x78,
            'delay': 0x55,
            'easing': _0x38dfb9(0x15d)
        }, {
            'value': 0x1,
            'duration': 0x104,
            'delay': 0x19,
            'easing': 'easeOutQuad'
        }],
        'scaleY': [{
            'value': [0.3, 0.8],
            'duration': 0x78,
            'easing': _0x38dfb9(0x179)
        }, {
            'value': 0.35,
            'duration': 0x78,
            'delay': 0xb4,
            'easing': _0x38dfb9(0x15d)
        }, {
            'value': 0.57,
            'duration': 0xb4,
            'delay': 0x19,
            'easing': 'easeOutQuad'
        }, {
            'value': 0.5,
            'duration': 0xbe,
            'delay': 0xf,
            'easing': _0x38dfb9(0x199)
        }],
        'delay': anime['stagger'](0x50)
    }, 0x3e8)['add']({
        'targets': _0x38dfb9(0x167),
        'opacity': {
            'value': 0x1,
            'duration': 0x64
        },
        'translateY': 0xfa,
        'scaleY': [0x4, 0.7],
        'scaleX': {
            'value': 1.3,
            'delay': 0x64,
            'duration': 0xc8
        },
        'duration': 0x118,
        'easing': _0x38dfb9(0x184)
    }, _0x38dfb9(0x165))[_0x38dfb9(0x15f)]({
        'targets': '.letter-m\x20.line',
        'easing': _0x38dfb9(0x176),
        'duration': 0x258,
        'd': function(_0x35d9d8) {
            var _0x1e7df1 = _0x38dfb9;
            return _0x35d9d8[_0x1e7df1(0x18b)]['d2'];
        },
        'begin': function(_0x49b6d3) {
            var _0x579a69 = _0x38dfb9;
            _0x49b6d3[_0x579a69(0x16b)][0x0]['target'][_0x579a69(0x16d)](_0x579a69(0x17e));
        }
    }, _0x38dfb9(0x163))['add']({
        'targets': [_0x38dfb9(0x15c), _0x38dfb9(0x173), _0x38dfb9(0x188), _0x38dfb9(0x170)],
        'translateX': 0x0,
        'easing': _0x38dfb9(0x16e),
        'duration': 0x320,
        'delay': anime['stagger'](0x28, {
            'from': 2.5
        }),
        'change': function(_0x5762f2) {
            var _0x3fbf1c = _0x38dfb9;
            _0x5762f2[_0x3fbf1c(0x16b)][0x2][_0x3fbf1c(0x19d)][_0x3fbf1c(0x16d)](_0x3fbf1c(0x17e));
        }
    }, _0x38dfb9(0x19a))[_0x38dfb9(0x15f)]({
        'targets': '.letter-m\x20.line',
        'd': function(_0x45734d) {
            var _0x45a011 = _0x38dfb9;
            return _0x45734d[_0x45a011(0x18b)]['d3'];
        },
        'easing': _0x38dfb9(0x17c)
    }, _0x38dfb9(0x19c))[_0x38dfb9(0x15f)]({
        'targets': '.dot',
        'translateX': _0x411fcf('x'),
        'translateY': _0x411fcf('y'),
        'rotate': {
            'value': _0x38dfb9(0x168),
            'duration': 0x316
        },
        'scaleX': {
            'value': 0x1,
            'duration': 0x32,
            'easing': _0x38dfb9(0x179)
        },
        'scaleY': [{
            'value': [0x1, 1.5],
            'duration': 0x32,
            'easing': 'easeInSine'
        }, {
            'value': 0x1,
            'duration': 0x32,
            'easing': 'easeOutExpo'
        }],
        'easing': 'cubicBezier(0,\x20.74,\x201,\x20.255)',
        'duration': 0x320
    }, _0x38dfb9(0x198))[_0x38dfb9(0x15f)]({
        'targets': _0x38dfb9(0x167),
        'scale': 0x1,
        'rotate': _0x38dfb9(0x168),
        'scaleY': {
            'value': 0.5,
            'delay': 0x0,
            'duration': 0x96,
            'delay': 0xe6
        },
        'translateX': 0x1ae,
        'translateY': [{
            'value': 0xf4,
            'duration': 0x64
        }, {
            'value': 0xcc,
            'duration': 0xc8,
            'delay': 0x82
        }, {
            'value': 0xe0,
            'duration': 0xe1,
            'easing': _0x38dfb9(0x199),
            'delay': 0x19
        }],
        'duration': 0xc8,
        'easing': _0x38dfb9(0x179)
    }, _0x38dfb9(0x191))['add']({
        'targets': _0x38dfb9(0x194),
        'transformOrigin': [_0x38dfb9(0x17f), '50%\x20100%\x200'],
        'd': function(_0x16d02c) {
            var _0x83a03 = _0x38dfb9;
            return _0x16d02c[_0x83a03(0x18b)]['d2'];
        },
        'easing': _0x38dfb9(0x197),
        'duration': 0x50
    }, _0x38dfb9(0x18e))[_0x38dfb9(0x15f)]({
        'targets': '.logo-letter',
        'translateY': [{
            'value': 0x28,
            'duration': 0x96,
            'easing': _0x38dfb9(0x172)
        }, {
            'value': 0x0,
            'duration': 0x320,
            'easing': _0x38dfb9(0x195)
        }],
        'strokeDashoffset': [anime[_0x38dfb9(0x183)], 0x0],
        'delay': anime[_0x38dfb9(0x166)](0x3c, {
            'from': _0x38dfb9(0x180)
        })
    }, _0x38dfb9(0x18e))[_0x38dfb9(0x15f)]({
        'targets': _0x38dfb9(0x164),
        'scaleY': [{
            'value': 0.4,
            'duration': 0x96,
            'easing': _0x38dfb9(0x172)
        }, {
            'value': 0.5,
            'duration': 0x320,
            'easing': 'easeOutElastic(1,\x20.5)'
        }],
        'delay': anime['stagger'](0x3c, {
            'from': _0x38dfb9(0x180)
        })
    }, _0x38dfb9(0x171))['add']({
        'targets': '.logo-text',
        'translateY': [{
            'value': 0x14,
            'easing': _0x38dfb9(0x199),
            'duration': 0x64
        }, {
            'value': 0x0,
            'easing': _0x38dfb9(0x182),
            'duration': 0x1c2
        }],
        'opacity': {
            'value': [0.001, 0x1],
            'duration': 0x32
        },
        'duration': 0x1f4
    }, _0x38dfb9(0x15b))['add']({
        'targets': _0x38dfb9(0x192),
        'opacity': {
            'value': [0.001, 0x1],
            'duration': 0x5dc
        },
        'backgroundImage': [_0x38dfb9(0x1a0), _0x38dfb9(0x160)],
        'translateY': {
            'value': [_0x38dfb9(0x162), 0x0],
            'easing': 'cubicBezier(0.175,\x200.865,\x200.245,\x200.840)'
        },
        'duration': 0x7d0,
        'easing': _0x38dfb9(0x1a2)
    }, _0x38dfb9(0x15b))[_0x38dfb9(0x15f)]({
        'targets': [_0x38dfb9(0x187), _0x38dfb9(0x17b)],
        'opacity': {
            'value': [0.001, 0x1],
            'easing': _0x38dfb9(0x17d)
        },
        'translateY': {
            'value': [_0x38dfb9(0x161), 0x0],
            'easing': _0x38dfb9(0x17d)
        },
        'duration': 0xdac,
        'delay': anime['stagger'](0x4b)
    }, _0x38dfb9(0x189));
    return _0x318e61;
}());
logoAnimation['play']();