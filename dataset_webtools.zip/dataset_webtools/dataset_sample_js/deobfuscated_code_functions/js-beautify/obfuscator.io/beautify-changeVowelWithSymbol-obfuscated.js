const a0_0x260ff0 = a0_0x1cbb;

function a0_0x1cbb(_0x9d7d8d, _0x514435) {
    const _0x22e642 = a0_0x22e6();
    return a0_0x1cbb = function(_0x1cbbaf, _0x2315f1) {
        _0x1cbbaf = _0x1cbbaf - 0xa4;
        let _0x389289 = _0x22e642[_0x1cbbaf];
        return _0x389289;
    }, a0_0x1cbb(_0x9d7d8d, _0x514435);
}(function(_0x81748f, _0x390413) {
    const _0xa8252a = a0_0x1cbb,
        _0x5cc980 = _0x81748f();
    while (!![]) {
        try {
            const _0x335a3a = -parseInt(_0xa8252a(0xae)) / 0x1 + parseInt(_0xa8252a(0xa5)) / 0x2 + parseInt(_0xa8252a(0xa8)) / 0x3 + -parseInt(_0xa8252a(0xad)) / 0x4 * (parseInt(_0xa8252a(0xa6)) / 0x5) + -parseInt(_0xa8252a(0xa4)) / 0x6 + parseInt(_0xa8252a(0xa9)) / 0x7 * (-parseInt(_0xa8252a(0xaf)) / 0x8) + parseInt(_0xa8252a(0xb4)) / 0x9 * (parseInt(_0xa8252a(0xa7)) / 0xa);
            if (_0x335a3a === _0x390413) break;
            else _0x5cc980['push'](_0x5cc980['shift']());
        } catch (_0x223984) {
            _0x5cc980['push'](_0x5cc980['shift']());
        }
    }
}(a0_0x22e6, 0x8930e));

function changeVowelWithSymbol(_0x42cfba) {
    const _0x3247ae = a0_0x1cbb,
        _0xa44fb9 = {
            'a': '@',
            'A': '@',
            'e': '&',
            'E': '&',
            'i': '!',
            'I': '!',
            'o': '0',
            'O': '0',
            'u': '|_|',
            'U': _0x3247ae(0xb2)
        };
    let _0x1d8a2c = [];
    for (let _0x2d036c of _0x42cfba) {
        _0xa44fb9[_0x3247ae(0xaa)](_0x2d036c) ? _0x1d8a2c[_0x3247ae(0xac)](_0xa44fb9[_0x2d036c]) : _0x1d8a2c[_0x3247ae(0xac)](_0x2d036c);
    }
    _0x1d8a2c = _0x1d8a2c['join'](''), console[_0x3247ae(0xab)](_0x3247ae(0xb3) + _0x42cfba), console[_0x3247ae(0xab)](_0x3247ae(0xb0) + _0x1d8a2c);
}
changeVowelWithSymbol('Hello,\x20world!'), changeVowelWithSymbol(a0_0x260ff0(0xb1)), changeVowelWithSymbol('AaEeIiOoUu');

function a0_0x22e6() {
    const _0x26c9e7 = ['push', '4jEVIya', '465111KoXvEq', '8jSjwfv', 'Modified\x20sentence:\x20', 'This\x20is\x20a\x20sentence\x20with\x20vowels.', '|_|', 'Original\x20sentence:\x20', '1512quMEgc', '5506386GxSymw', '419332SoCrFT', '1174300odxFXT', '150430xoVfAn', '898887Cnloqu', '5998181jtXWUn', 'hasOwnProperty', 'log'];
    a0_0x22e6 = function() {
        return _0x26c9e7;
    };
    return a0_0x22e6();
}