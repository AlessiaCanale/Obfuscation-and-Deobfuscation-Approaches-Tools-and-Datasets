const a0_0x491780 = a0_0x3b6e;

function a0_0x5ed4() {
    const _0x1c3c93 = ['7453600fMAiXW', 'test', 'random', '14328sfKvSd', 'allocca', '5598418lKgtgk', 'Resulting\x20string:', '2827762vlYbpm', '575RekgSr', '1838736hqZyiF', 'includes', '1EfURyt', '4494438kCyGbL', '13119984QqtkyA', 'length', 'Input\x20string:'];
    a0_0x5ed4 = function() {
        return _0x1c3c93;
    };
    return a0_0x5ed4();
}(function(_0x355205, _0x4c3331) {
    const _0x47eb88 = a0_0x3b6e,
        _0x7fb512 = _0x355205();
    while (!![]) {
        try {
            const _0x5feccb = parseInt(_0x47eb88(0x17c)) / 0x1 * (-parseInt(_0x47eb88(0x178)) / 0x2) + parseInt(_0x47eb88(0x17a)) / 0x3 + parseInt(_0x47eb88(0x181)) / 0x4 + -parseInt(_0x47eb88(0x179)) / 0x5 * (-parseInt(_0x47eb88(0x184)) / 0x6) + parseInt(_0x47eb88(0x186)) / 0x7 + -parseInt(_0x47eb88(0x17e)) / 0x8 + parseInt(_0x47eb88(0x17d)) / 0x9;
            if (_0x5feccb === _0x4c3331) break;
            else _0x7fb512['push'](_0x7fb512['shift']());
        } catch (_0xd56b88) {
            _0x7fb512['push'](_0x7fb512['shift']());
        }
    }
}(a0_0x5ed4, 0xf3371));

function a0_0x3b6e(_0x50d1a2, _0x5efc13) {
    const _0x5ed470 = a0_0x5ed4();
    return a0_0x3b6e = function(_0x3b6e4b, _0x48b7c1) {
        _0x3b6e4b = _0x3b6e4b - 0x178;
        let _0xf4be04 = _0x5ed470[_0x3b6e4b];
        return _0xf4be04;
    }, a0_0x3b6e(_0x50d1a2, _0x5efc13);
}

function addVowelsAfterConsonants(_0x5e6c60) {
    const _0x38208f = a0_0x3b6e,
        _0x383d36 = ['a', 'e', 'i', 'o', 'u'];
    let _0x422c49 = '',
        _0x2d3ca5 = ![];
    for (let _0x4c8b83 = 0x0; _0x4c8b83 < _0x5e6c60['length']; _0x4c8b83++) {
        const _0x23962c = _0x5e6c60[_0x4c8b83],
            _0x1e3dbe = !_0x383d36[_0x38208f(0x17b)](_0x23962c) && /[a-z]/ [_0x38208f(0x182)](_0x23962c);
        if (_0x1e3dbe && _0x2d3ca5) {
            const _0x295fa7 = _0x383d36[Math['floor'](Math[_0x38208f(0x183)]() * _0x383d36[_0x38208f(0x17f)])];
            _0x422c49 += _0x295fa7 + _0x23962c;
        } else _0x422c49 += _0x23962c;
        _0x2d3ca5 = _0x1e3dbe;
    }
    return _0x422c49;
}
const input = a0_0x491780(0x185),
    output = addVowelsAfterConsonants(input);
console['log'](a0_0x491780(0x180), input), console['log'](a0_0x491780(0x187), output);