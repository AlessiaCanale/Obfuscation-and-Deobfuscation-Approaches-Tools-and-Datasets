const a0_0x50ac01 = a0_0x2c0e;

function a0_0x2c0e(_0x2abaa1, _0x2d5d64) {
    const _0x4d6a8a = a0_0x4d6a();
    return a0_0x2c0e = function(_0x2c0eab, _0x5b3418) {
        _0x2c0eab = _0x2c0eab - 0xc0;
        let _0x548d30 = _0x4d6a8a[_0x2c0eab];
        return _0x548d30;
    }, a0_0x2c0e(_0x2abaa1, _0x2d5d64);
}

function a0_0x4d6a() {
    const _0x3e0124 = ['starlight', '1067871xViffH', 'language', '14owjBmq', 'know', 'summer', 'log', '1330988xBfIpX', 'tear', '1202888iKRcKA', 'elf', 'random', 'sharp', '331CgsxGk', 'treasure', 'jewel', 'stone', 'love', 'cloud', 'long', '581905OYFHak', '56XlhPzJ', '1609194rGSYVs', 'darkness', '6322851LtXLIF', 'queen', 'angel', 'cup', 'floor', '\x20-\x20Translation:\x20', 'call'];
    a0_0x4d6a = function() {
        return _0x3e0124;
    };
    return a0_0x4d6a();
}(function(_0x21e352, _0x1716ce) {
    const _0x4f2f05 = a0_0x2c0e,
        _0x28a3ea = _0x21e352();
    while (!![]) {
        try {
            const _0x2e0db7 = parseInt(_0x4f2f05(0xda)) / 0x1 * (-parseInt(_0x4f2f05(0xc3)) / 0x2) + parseInt(_0x4f2f05(0xce)) / 0x3 + -parseInt(_0x4f2f05(0xd4)) / 0x4 + parseInt(_0x4f2f05(0xc2)) / 0x5 + -parseInt(_0x4f2f05(0xc4)) / 0x6 + -parseInt(_0x4f2f05(0xd0)) / 0x7 * (parseInt(_0x4f2f05(0xd6)) / 0x8) + parseInt(_0x4f2f05(0xc6)) / 0x9;
            if (_0x2e0db7 === _0x1716ce) break;
            else _0x28a3ea['push'](_0x28a3ea['shift']());
        } catch (_0x20667c) {
            _0x28a3ea['push'](_0x28a3ea['shift']());
        }
    }
}(a0_0x4d6a, 0x40705));
const quenyaWords = {
    'melme': a0_0x50ac01(0xde),
    'elda': a0_0x50ac01(0xd7),
    'nár': 'fire',
    'morë': a0_0x50ac01(0xc5),
    'vala': a0_0x50ac01(0xc8),
    'mára': 'good',
    'aika': a0_0x50ac01(0xd9),
    'hyanda': a0_0x50ac01(0xc1),
    'istya': a0_0x50ac01(0xd1),
    'yulma': a0_0x50ac01(0xc9),
    'harma': a0_0x50ac01(0xdb),
    'silmë': a0_0x50ac01(0xcd),
    'fána': a0_0x50ac01(0xc0),
    'lóte': 'flower',
    'nique': a0_0x50ac01(0xd5),
    'laire': a0_0x50ac01(0xd2),
    'aista': a0_0x50ac01(0xcc),
    'súrëa': 'secret',
    'tári': a0_0x50ac01(0xc7),
    'enwë': a0_0x50ac01(0xcf),
    'ondo': a0_0x50ac01(0xdd),
    'mírë': a0_0x50ac01(0xdc),
    'quenya': 'language',
    'valanya': 'blessed',
    'lumna': 'echo'
};

function displayRandomQuenyaWord() {
    const _0xb3d2d3 = a0_0x50ac01,
        _0x401c77 = Object['keys'](quenyaWords),
        _0x6a0be2 = Math[_0xb3d2d3(0xca)](Math[_0xb3d2d3(0xd8)]() * _0x401c77['length']),
        _0x100849 = _0x401c77[_0x6a0be2];
    console[_0xb3d2d3(0xd3)]('Quenya:\x20' + _0x100849 + _0xb3d2d3(0xcb) + quenyaWords[_0x100849]);
}
displayRandomQuenyaWord();