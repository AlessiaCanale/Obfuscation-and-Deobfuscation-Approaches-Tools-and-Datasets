function a0_0x114e() {
    const _0x34aec5 = ['345010ygiBTy', 'random', 'log', '682414rYOQcz', '1270535WuHRGZ', 'Random\x20number:\x20', '7886592UJbmOj', '520903ppQhJR', 'Error:\x20The\x20text\x20should\x20contain\x20at\x20least\x2025\x20words.', '48izQBky', 'push', '1876232mHrSla', '966072IstIhA', 'add', 'split', '6JfUWnl', 'This\x20is\x20a\x20sample\x20text\x20with\x20at\x20least\x2025\x20words.\x20It\x20contains\x20more\x20than\x2025\x20words\x20to\x20ensure\x20we\x20can\x20select\x20enough\x20unique\x20words.\x20hi,\x20how\x20are\x20you?', '\x20unique\x20words\x20in\x20text:', 'Original\x20text:', 'length'];
    a0_0x114e = function() {
        return _0x34aec5;
    };
    return a0_0x114e();
}
const a0_0x304fa9 = a0_0x18a9;

function a0_0x18a9(_0x1739c2, _0x11f1b6) {
    const _0x114e27 = a0_0x114e();
    return a0_0x18a9 = function(_0x18a91e, _0x15375c) {
        _0x18a91e = _0x18a91e - 0x1c7;
        let _0x31322f = _0x114e27[_0x18a91e];
        return _0x31322f;
    }, a0_0x18a9(_0x1739c2, _0x11f1b6);
}(function(_0x21013f, _0x14431d) {
    const _0x23262f = a0_0x18a9,
        _0x55c174 = _0x21013f();
    while (!![]) {
        try {
            const _0x30b86b = -parseInt(_0x23262f(0x1d0)) / 0x1 + parseInt(_0x23262f(0x1cc)) / 0x2 + -parseInt(_0x23262f(0x1d8)) / 0x3 * (parseInt(_0x23262f(0x1d5)) / 0x4) + -parseInt(_0x23262f(0x1c9)) / 0x5 * (-parseInt(_0x23262f(0x1d2)) / 0x6) + -parseInt(_0x23262f(0x1cd)) / 0x7 + -parseInt(_0x23262f(0x1d4)) / 0x8 + parseInt(_0x23262f(0x1cf)) / 0x9;
            if (_0x30b86b === _0x14431d) break;
            else _0x55c174['push'](_0x55c174['shift']());
        } catch (_0x2ca9ed) {
            _0x55c174['push'](_0x55c174['shift']());
        }
    }
}(a0_0x114e, 0x55562));

function createAnArrayWithFirstTextWords(_0x4006bd) {
    const _0x3fd616 = a0_0x18a9;
    let _0x3aa8b7 = _0x4006bd[_0x3fd616(0x1d7)](/\s+/);
    if (_0x3aa8b7[_0x3fd616(0x1c8)] < 0x19) {
        console[_0x3fd616(0x1cb)](_0x3fd616(0x1d1));
        return;
    }
    let _0xac6811 = Math['floor'](Math[_0x3fd616(0x1ca)]() * 0x7) + 0x1,
        _0x2f0347 = [],
        _0x1cb801 = new Set();
    for (let _0x1ec3a4 of _0x3aa8b7) {
        !_0x1cb801['has'](_0x1ec3a4) && (_0x2f0347[_0x3fd616(0x1d3)](_0x1ec3a4), _0x1cb801[_0x3fd616(0x1d6)](_0x1ec3a4));
        if (_0x2f0347[_0x3fd616(0x1c8)] === _0xac6811) break;
    }
    console[_0x3fd616(0x1cb)](_0x3fd616(0x1c7)), console[_0x3fd616(0x1cb)](_0x4006bd), console[_0x3fd616(0x1cb)](_0x3fd616(0x1ce) + _0xac6811), console[_0x3fd616(0x1cb)]('Array\x20arr\x20with\x20first\x20' + _0xac6811 + _0x3fd616(0x1da)), console[_0x3fd616(0x1cb)](_0x2f0347);
}
let sampleText = a0_0x304fa9(0x1d9);
createAnArrayWithFirstTextWords(sampleText);