function a0_0x15f0(_0x5e22ba, _0x3c0132) {
    const _0x4511ba = a0_0x4511();
    return a0_0x15f0 = function(_0x15f04d, _0x1e0e57) {
        _0x15f04d = _0x15f04d - 0xf2;
        let _0x56d1eb = _0x4511ba[_0x15f04d];
        return _0x56d1eb;
    }, a0_0x15f0(_0x5e22ba, _0x3c0132);
}(function(_0xa78ae8, _0x348e44) {
    const _0x25a128 = a0_0x15f0,
        _0x4256d8 = _0xa78ae8();
    while (!![]) {
        try {
            const _0x17272c = parseInt(_0x25a128(0xf5)) / 0x1 * (-parseInt(_0x25a128(0xfd)) / 0x2) + parseInt(_0x25a128(0xf9)) / 0x3 + parseInt(_0x25a128(0x101)) / 0x4 * (-parseInt(_0x25a128(0xfa)) / 0x5) + -parseInt(_0x25a128(0xff)) / 0x6 + parseInt(_0x25a128(0xf2)) / 0x7 + parseInt(_0x25a128(0xf4)) / 0x8 + parseInt(_0x25a128(0xf8)) / 0x9 * (-parseInt(_0x25a128(0xfe)) / 0xa);
            if (_0x17272c === _0x348e44) break;
            else _0x4256d8['push'](_0x4256d8['shift']());
        } catch (_0x334bf2) {
            _0x4256d8['push'](_0x4256d8['shift']());
        }
    }
}(a0_0x4511, 0xdb5e8));

function chooseOperandsOperatorAndDisplayResult() {
    const _0x444bca = a0_0x15f0,
        _0x2c4aae = parseInt(document['getElementById']('operand1')['value']),
        _0x24a11f = document['getElementById']('operator')[_0x444bca(0xf7)],
        _0x3bcbb8 = parseInt(document['getElementById'](_0x444bca(0xf3))[_0x444bca(0xf7)]);
    let _0x34d247;
    switch (_0x24a11f) {
        case '+':
            _0x34d247 = _0x2c4aae + _0x3bcbb8;
            break;
        case '-':
            _0x34d247 = _0x2c4aae - _0x3bcbb8;
            break;
        case '*':
            _0x34d247 = _0x2c4aae * _0x3bcbb8;
            break;
        case '/':
            _0x34d247 = _0x2c4aae / _0x3bcbb8;
            break;
        default:
            _0x34d247 = _0x444bca(0xf6);
    }
    document[_0x444bca(0xfc)](_0x444bca(0x100))[_0x444bca(0xfb)] = 'Result:\x20' + _0x2c4aae + '\x20' + _0x24a11f + '\x20' + _0x3bcbb8 + '\x20=\x20' + _0x34d247;
}

function a0_0x4511() {
    const _0x148fb8 = ['value', '24183gNXfZx', '5225175hdoRhe', '5HkvCPj', 'textContent', 'getElementById', '722882xidaWX', '2710AChGUH', '5833158xasRaY', 'result', '5439652ApAlwc', '10276266TDGGUp', 'operand2', '8883976TcFPHG', '1DrUnnk', 'Invalid\x20operator'];
    a0_0x4511 = function() {
        return _0x148fb8;
    };
    return a0_0x4511();
}