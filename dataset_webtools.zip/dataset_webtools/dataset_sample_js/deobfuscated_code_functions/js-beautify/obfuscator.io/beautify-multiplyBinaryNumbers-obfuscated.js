function a0_0x2f6b() {
    const _0x1bb253 = ['12542080cUeUNU', '465773HIdjPo', '1728075IkNiFQ', 'Binary\x20Number\x202:\x20', '622ceIkoZ', 'floor', '195536qWQDOj', '2012ecvzHS', '1663865ILuyeU', 'log', '1429356HmSFeF', 'toString', 'random'];
    a0_0x2f6b = function() {
        return _0x1bb253;
    };
    return a0_0x2f6b();
}

function a0_0xa8aa(_0x3b9782, _0x5655cd) {
    const _0x2f6b4a = a0_0x2f6b();
    return a0_0xa8aa = function(_0xa8aaa9, _0x43842e) {
        _0xa8aaa9 = _0xa8aaa9 - 0x19b;
        let _0x14a91e = _0x2f6b4a[_0xa8aaa9];
        return _0x14a91e;
    }, a0_0xa8aa(_0x3b9782, _0x5655cd);
}(function(_0x25c9b2, _0x2772ad) {
    const _0x500676 = a0_0xa8aa,
        _0x17836e = _0x25c9b2();
    while (!![]) {
        try {
            const _0x34b94e = -parseInt(_0x500676(0x1a1)) / 0x1 * (-parseInt(_0x500676(0x19e)) / 0x2) + parseInt(_0x500676(0x19c)) / 0x3 + parseInt(_0x500676(0x1a0)) / 0x4 + parseInt(_0x500676(0x1a2)) / 0x5 + parseInt(_0x500676(0x1a4)) / 0x6 + parseInt(_0x500676(0x19b)) / 0x7 + -parseInt(_0x500676(0x1a7)) / 0x8;
            if (_0x34b94e === _0x2772ad) break;
            else _0x17836e['push'](_0x17836e['shift']());
        } catch (_0x4a34f7) {
            _0x17836e['push'](_0x17836e['shift']());
        }
    }
}(a0_0x2f6b, 0x4e3a3));

function binaryToDecimal(_0x215053) {
    return parseInt(_0x215053, 0x2);
}

function generateBinaryNumber() {
    const _0x3f81e2 = a0_0xa8aa;
    return Math[_0x3f81e2(0x19f)](Math[_0x3f81e2(0x1a6)]() * 0x64)['toString'](0x2);
}

function multiplyBinaryNumbers() {
    const _0x2e092f = a0_0xa8aa,
        _0x46b00d = generateBinaryNumber(),
        _0x27b5b7 = generateBinaryNumber(),
        _0x6ca8df = binaryToDecimal(_0x46b00d),
        _0x151168 = binaryToDecimal(_0x27b5b7),
        _0x162dbe = _0x6ca8df * _0x151168;
    console['log']('Binary\x20Number\x201:\x20' + _0x46b00d), console[_0x2e092f(0x1a3)](_0x2e092f(0x19d) + _0x27b5b7), console[_0x2e092f(0x1a3)]('Multiplication\x20in\x20Binary:\x20' + (_0x6ca8df * _0x151168)[_0x2e092f(0x1a5)](0x2)), console['log']('Multiplication\x20in\x20Decimal:\x20' + _0x162dbe);
}
multiplyBinaryNumbers();