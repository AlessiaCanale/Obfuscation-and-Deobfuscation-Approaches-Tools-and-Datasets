function a0_0x208d(_0x42946a, _0xbc44b5) {
    const _0x5c1299 = a0_0x5c12();
    return a0_0x208d = function(_0x208d41, _0xcdc925) {
        _0x208d41 = _0x208d41 - 0x7e;
        let _0x169cce = _0x5c1299[_0x208d41];
        return _0x169cce;
    }, a0_0x208d(_0x42946a, _0xbc44b5);
}

function a0_0x5c12() {
    const _0x2c71f7 = ['365043uKxITO', '6558048IaiHUl', '2261130oRhUrX', 'querySelector', 'getContext', 'addEventListener', 'fillStyle', '2790SwTuCS', '8156XtkGcl', '010110', 'random', 'split', 'requestAnimationFrame', 'length', 'fillText', '55QCLBWx', 'rgba(0,\x200,\x200,0.1)', '3005328kqtcUg', '6531kwGPcG', '2LqqMDT', '808056TpBKsA', 'px\x20Gotham', 'floor', 'resize', 'height', '#fff', 'fillRect', 'innerWidth', 'innerHeight', 'width'];
    a0_0x5c12 = function() {
        return _0x2c71f7;
    };
    return a0_0x5c12();
}
const a0_0x258ebf = a0_0x208d;
(function(_0x260b6d, _0x24a75b) {
    const _0x5db0ee = a0_0x208d,
        _0x242e51 = _0x260b6d();
    while (!![]) {
        try {
            const _0xd96e54 = -parseInt(_0x5db0ee(0x97)) / 0x1 * (-parseInt(_0x5db0ee(0x8c)) / 0x2) + -parseInt(_0x5db0ee(0x8d)) / 0x3 + -parseInt(_0x5db0ee(0x81)) / 0x4 * (parseInt(_0x5db0ee(0x88)) / 0x5) + parseInt(_0x5db0ee(0x80)) / 0x6 * (parseInt(_0x5db0ee(0x8b)) / 0x7) + parseInt(_0x5db0ee(0x8a)) / 0x8 + -parseInt(_0x5db0ee(0x98)) / 0x9 + parseInt(_0x5db0ee(0x99)) / 0xa;
            if (_0xd96e54 === _0x24a75b) break;
            else _0x242e51['push'](_0x242e51['shift']());
        } catch (_0x50d41b) {
            _0x242e51['push'](_0x242e51['shift']());
        }
    }
}(a0_0x5c12, 0x5cd36));
let canvas = document[a0_0x258ebf(0x9a)]('canvas'),
    ctx = canvas[a0_0x258ebf(0x9b)]('2d'),
    letters = a0_0x258ebf(0x82),
    height = canvas[a0_0x258ebf(0x91)] = window[a0_0x258ebf(0x95)],
    width = canvas['width'] = window[a0_0x258ebf(0x94)],
    font_size = 0xa,
    columns = width / font_size,
    drops = [],
    frame = 0x1;
letters = letters[a0_0x258ebf(0x84)]('');
for (let i = 0x0; i < columns; i++) {
    drops[i] = 0x1;
}
clear();

function draw() {
    const _0x1c0a7e = a0_0x258ebf;
    if (frame == 0x1) clear(), showLetters();
    else frame == 0x2 && (frame = 0x0);
    frame++, window[_0x1c0a7e(0x85)](draw);
}

function showLetters() {
    const _0x2a8b04 = a0_0x258ebf;
    ctx['fillStyle'] = _0x2a8b04(0x92), ctx['font'] = font_size + _0x2a8b04(0x8e);
    for (let _0x3d6cd4 = 0x0; _0x3d6cd4 < drops[_0x2a8b04(0x86)]; _0x3d6cd4++) {
        let _0x36ce5d = letters[Math[_0x2a8b04(0x8f)](Math[_0x2a8b04(0x83)]() * letters[_0x2a8b04(0x86)])],
            _0x3be01c = drops[_0x3d6cd4] * font_size;
        ctx[_0x2a8b04(0x87)](_0x36ce5d, _0x3d6cd4 * font_size, _0x3be01c), _0x3be01c > height && Math[_0x2a8b04(0x83)]() > 0.956 && (drops[_0x3d6cd4] = 0x0), drops[_0x3d6cd4]++;
    }
}

function clear() {
    const _0x2adefa = a0_0x258ebf;
    ctx[_0x2adefa(0x7f)] = _0x2adefa(0x89), ctx[_0x2adefa(0x93)](0x0, 0x0, width, height);
}
window['requestAnimationFrame'](draw), window[a0_0x258ebf(0x7e)](a0_0x258ebf(0x90), function() {
    const _0x1f987e = a0_0x258ebf;
    height = canvas[_0x1f987e(0x91)] = window[_0x1f987e(0x95)], width = canvas[_0x1f987e(0x96)] = window[_0x1f987e(0x94)];
});