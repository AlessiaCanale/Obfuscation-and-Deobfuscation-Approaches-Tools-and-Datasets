(function(_0x10be54, _0x2363f3) {
    const _0x356fc3 = a0_0x5918,
        _0x1c2a3a = _0x10be54();
    while (!![]) {
        try {
            const _0x57b12f = -parseInt(_0x356fc3(0x9e)) / 0x1 + -parseInt(_0x356fc3(0xa4)) / 0x2 + -parseInt(_0x356fc3(0xa1)) / 0x3 + parseInt(_0x356fc3(0x9f)) / 0x4 + parseInt(_0x356fc3(0x9b)) / 0x5 + -parseInt(_0x356fc3(0xa0)) / 0x6 + parseInt(_0x356fc3(0x9c)) / 0x7;
            if (_0x57b12f === _0x2363f3) break;
            else _0x1c2a3a['push'](_0x1c2a3a['shift']());
        } catch (_0x7b91da) {
            _0x1c2a3a['push'](_0x1c2a3a['shift']());
        }
    }
}(a0_0x153b, 0xc8abd));

function a0_0x5918(_0x5f0516, _0x55fad7) {
    const _0x153b32 = a0_0x153b();
    return a0_0x5918 = function(_0x5918dd, _0x2f4042) {
        _0x5918dd = _0x5918dd - 0x9b;
        let _0x4cece5 = _0x153b32[_0x5918dd];
        return _0x4cece5;
    }, a0_0x5918(_0x5f0516, _0x55fad7);
}

function addWordAfterFirstWordStartingWithPreviousLetter(_0x27e8a4, _0x3a92a2) {
    const _0x52c7db = a0_0x5918;
    let _0x53fd31 = _0x27e8a4[_0x52c7db(0xa6)]('\x20'),
        _0x142f8c = _0x3a92a2[0x0]['charCodeAt'](0x0) - 0x1;
    for (let _0x20e912 = 0x0; _0x20e912 < _0x53fd31[_0x52c7db(0x9d)]; _0x20e912++) {
        if (_0x53fd31[_0x20e912][0x0][_0x52c7db(0xa8)](0x0) === _0x142f8c) {
            _0x53fd31[_0x52c7db(0xa5)](_0x20e912 + 0x1, 0x0, _0x3a92a2);
            break;
        }
    }
    console[_0x52c7db(0xa7)](_0x52c7db(0xa3) + _0x27e8a4), console['log'](_0x52c7db(0xa2) + _0x53fd31['join']('\x20'));
}
addWordAfterFirstWordStartingWithPreviousLetter('apple\x20banana\x20cherry\x20date\x20elephant\x20fig\x20grape\x20honey\x20ice\x20cream', 'cat');

function a0_0x153b() {
    const _0x119329 = ['5259924gbICQv', '5909706ESlPcn', '1574763QuAZAy', 'Text\x20with\x20added\x20word:\x20', 'Original\x20text:\x20', '618958NDDkwp', 'splice', 'split', 'log', 'charCodeAt', '7807260vBEgjR', '9643613nfCXkc', 'length', '1612792lAotQH'];
    a0_0x153b = function() {
        return _0x119329;
    };
    return a0_0x153b();
}