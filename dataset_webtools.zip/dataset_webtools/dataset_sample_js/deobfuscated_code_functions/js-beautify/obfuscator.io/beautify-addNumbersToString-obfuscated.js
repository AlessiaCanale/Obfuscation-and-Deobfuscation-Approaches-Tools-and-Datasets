const a0_0x364223 = a0_0xea28;
(function(_0x81d4df, _0x3fcd83) {
    const _0x330765 = a0_0xea28,
        _0x30c5fa = _0x81d4df();
    while (!![]) {
        try {
            const _0x5cd4af = parseInt(_0x330765(0xe1)) / 0x1 + parseInt(_0x330765(0xe2)) / 0x2 + parseInt(_0x330765(0xea)) / 0x3 + parseInt(_0x330765(0xe8)) / 0x4 + -parseInt(_0x330765(0xe0)) / 0x5 + -parseInt(_0x330765(0xe7)) / 0x6 * (-parseInt(_0x330765(0xe4)) / 0x7) + -parseInt(_0x330765(0xe5)) / 0x8 * (parseInt(_0x330765(0xec)) / 0x9);
            if (_0x5cd4af === _0x3fcd83) break;
            else _0x30c5fa['push'](_0x30c5fa['shift']());
        } catch (_0x2e098e) {
            _0x30c5fa['push'](_0x30c5fa['shift']());
        }
    }
}(a0_0xc64e, 0x2b658));

function addNumbersToString(_0x2ad16b) {
    const _0x330af6 = a0_0xea28,
        _0x2180e7 = 'abcdefghijklmnopqrstuvwxyz';
    let _0x12e5f9 = '';
    for (let _0x4930ff = 0x0; _0x4930ff < _0x2ad16b['length']; _0x4930ff++) {
        const _0x18491a = _0x2ad16b[_0x4930ff],
            _0x19b4aa = _0x2180e7[_0x330af6(0xe6)](_0x18491a) + 0x1;
        _0x12e5f9 += _0x18491a + _0x19b4aa;
    }
    return _0x12e5f9;
}
const originalString1 = a0_0x364223(0xe9),
    modifiedString1 = addNumbersToString(originalString1);
console['log'](a0_0x364223(0xed) + originalString1), console[a0_0x364223(0xeb)](a0_0x364223(0xe3) + modifiedString1);
const originalString2 = 'clazove',
    modifiedString2 = addNumbersToString(originalString2);

function a0_0xea28(_0x54199b, _0x5197bc) {
    const _0xc64e2a = a0_0xc64e();
    return a0_0xea28 = function(_0xea2876, _0x26133f) {
        _0xea2876 = _0xea2876 - 0xe0;
        let _0x4f069b = _0xc64e2a[_0xea2876];
        return _0x4f069b;
    }, a0_0xea28(_0x54199b, _0x5197bc);
}
console['log']('Original\x20String:\x20' + originalString2), console['log'](a0_0x364223(0xe3) + modifiedString2);

function a0_0xc64e() {
    const _0xd942c4 = ['abc', '571437EmUGif', 'log', '5877693UKIZPa', 'Original\x20String:\x20', '947420csbiPX', '337704FgfEEL', '271832qfkBDn', 'Modified\x20String:\x20', '497JfQDVr', '8pOIrPl', 'indexOf', '17982ffvmHe', '573708ZYkinG'];
    a0_0xc64e = function() {
        return _0xd942c4;
    };
    return a0_0xc64e();
}