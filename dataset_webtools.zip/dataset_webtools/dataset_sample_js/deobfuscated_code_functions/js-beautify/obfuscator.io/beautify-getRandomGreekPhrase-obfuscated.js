(function(_0x1afab5, _0x2d7484) {
    const _0x31edda = a0_0x6d3d,
        _0x2edaeb = _0x1afab5();
    while (!![]) {
        try {
            const _0x284ec4 = -parseInt(_0x31edda(0xe1)) / 0x1 + -parseInt(_0x31edda(0xdc)) / 0x2 * (-parseInt(_0x31edda(0xde)) / 0x3) + parseInt(_0x31edda(0xd3)) / 0x4 * (parseInt(_0x31edda(0xdb)) / 0x5) + -parseInt(_0x31edda(0xd8)) / 0x6 + -parseInt(_0x31edda(0xd2)) / 0x7 * (-parseInt(_0x31edda(0xcb)) / 0x8) + parseInt(_0x31edda(0xce)) / 0x9 + parseInt(_0x31edda(0xcf)) / 0xa * (-parseInt(_0x31edda(0xd6)) / 0xb);
            if (_0x284ec4 === _0x2d7484) break;
            else _0x2edaeb['push'](_0x2edaeb['shift']());
        } catch (_0x4c45f6) {
            _0x2edaeb['push'](_0x2edaeb['shift']());
        }
    }
}(a0_0x1e7f, 0x24e88));

function a0_0x6d3d(_0x54f5b6, _0x28a526) {
    const _0x1e7fde = a0_0x1e7f();
    return a0_0x6d3d = function(_0x6d3db4, _0x2b2cd1) {
        _0x6d3db4 = _0x6d3db4 - 0xcb;
        let _0x3d2c7f = _0x1e7fde[_0x6d3db4];
        return _0x3d2c7f;
    }, a0_0x6d3d(_0x54f5b6, _0x28a526);
}

function getRandomGreekPhrase() {
    const _0x289d39 = a0_0x6d3d,
        _0x4cc20e = [{
            'greek': _0x289d39(0xe2),
            'translation': _0x289d39(0xd9)
        }, {
            'greek': 'Ἀριστεὺς\x20μέν\x20τις\x20εἶναι\x20δοκεῖ,\x20κᾆτ᾽\x20οὐκ\x20ἔστιν',
            'translation': _0x289d39(0xd5)
        }, {
            'greek': _0x289d39(0xdd),
            'translation': 'Do\x20not\x20attribute\x20to\x20your\x20father\x20what\x20you\x20have\x20thought\x20up\x20yourself'
        }, {
            'greek': _0x289d39(0xda),
            'translation': _0x289d39(0xe0)
        }, {
            'greek': _0x289d39(0xdf),
            'translation': _0x289d39(0xd4)
        }, {
            'greek': 'Ὅτι\x20μὲν\x20ἀδύνατα\x20δυσωπεῖν\x20πολλά',
            'translation': _0x289d39(0xcd)
        }, {
            'greek': 'Τρίτον\x20μὲν\x20εἶδον\x20Ἄνδρα\x20σοφόν·\x20πάντα\x20δέ\x20κοσμούμενον',
            'translation': _0x289d39(0xcc)
        }],
        _0x15f681 = Math[_0x289d39(0xd0)](Math['random']() * _0x4cc20e[_0x289d39(0xd1)]),
        _0x5a8591 = _0x4cc20e[_0x15f681];
    console[_0x289d39(0xd7)](_0x5a8591['greek']), console[_0x289d39(0xd7)](_0x5a8591[_0x289d39(0xe3)]);
}
getRandomGreekPhrase();

function a0_0x1e7f() {
    const _0x561f83 = ['2270FlBCmL', 'floor', 'length', '7GsJXyF', '4iZPqFG', 'Life\x20is\x20short,\x20but\x20art\x20is\x20long', 'You\x20seem\x20to\x20be\x20a\x20good\x20man,\x20but\x20you\x27re\x20not', '26213FOPrNB', 'log', '73098YuUFTe', 'Know\x20thyself', 'Ἐγκώμιαν\x20εἴπερ\x20δοκεῖς\x20εἰδέναι', '961915AJOVQt', '194qAAwdZ', 'Ἐπὶ\x20πατρὶ\x20γὰρ\x20μὴ\x20βεβουλευμένως', '6354SJzJNC', 'Ὁ\x20βίος\x20βραχύς,\x20ἡ\x20δὲ\x20τέχνη\x20μακρά', 'If\x20you\x20think\x20you\x20know\x20how\x20to\x20praise', '18049Cedmfa', 'Γνῶθι\x20σεαυτόν', 'translation', '2099816wHwlDA', 'I\x20saw\x20a\x20third\x20wise\x20man;\x20but\x20he\x20was\x20a\x20conman', 'Many\x20things\x20are\x20difficult\x20to\x20foresee', '558387jKQftx'];
    a0_0x1e7f = function() {
        return _0x561f83;
    };
    return a0_0x1e7f();
}