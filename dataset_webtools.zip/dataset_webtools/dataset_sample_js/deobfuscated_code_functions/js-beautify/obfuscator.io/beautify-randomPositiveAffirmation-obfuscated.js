(function(_0x28df08, _0x2036cd) {
    const _0x1cf083 = a0_0x2a16,
        _0x5e4c4a = _0x28df08();
    while (!![]) {
        try {
            const _0x3f3dad = parseInt(_0x1cf083(0x1aa)) / 0x1 + -parseInt(_0x1cf083(0x19e)) / 0x2 * (-parseInt(_0x1cf083(0x1a0)) / 0x3) + -parseInt(_0x1cf083(0x1a8)) / 0x4 + parseInt(_0x1cf083(0x1b6)) / 0x5 * (-parseInt(_0x1cf083(0x1a3)) / 0x6) + -parseInt(_0x1cf083(0x1a9)) / 0x7 + parseInt(_0x1cf083(0x1b4)) / 0x8 + -parseInt(_0x1cf083(0x1b1)) / 0x9;
            if (_0x3f3dad === _0x2036cd) break;
            else _0x5e4c4a['push'](_0x5e4c4a['shift']());
        } catch (_0xde83e0) {
            _0x5e4c4a['push'](_0x5e4c4a['shift']());
        }
    }
}(a0_0x5821, 0xd3760));

function a0_0x5821() {
    const _0x2210a5 = ['You\x20are\x20a\x20work\x20in\x20progress,\x20and\x20that\x27s\x20okay.', 'You\x20are\x20deserving\x20of\x20success.', 'You\x20are\x20a\x20warrior,\x20not\x20a\x20worrier.', '3097845XXwRMN', 'length', 'You\x20are\x20worthy\x20of\x20love\x20and\x20happiness.', '13335864TQeXoG', 'You\x20are\x20enough\x20just\x20as\x20you\x20are.', '1490LFlQcm', 'You\x20are\x20surrounded\x20by\x20abundance.', 'You\x20are\x20capable\x20of\x20amazing\x20things.', 'You\x20are\x20loved.', '258XIbxgb', 'You\x20have\x20the\x20power\x20to\x20create\x20change.', '19443MdytxM', 'You\x20are\x20strong\x20and\x20resilient.', 'log', '3282AZDdMh', 'You\x20are\x20on\x20the\x20path\x20to\x20greatness.', 'You\x20are\x20a\x20source\x20of\x20inspiration\x20to\x20others.', 'You\x20are\x20a\x20magnet\x20for\x20positivity.', 'floor', '6138280pMJGjl', '5199103QIzFPU', '1147622Ewwezl', 'You\x20are\x20capable\x20of\x20achieving\x20your\x20dreams.', 'You\x20are\x20braver\x20than\x20you\x20believe.', 'You\x20deserve\x20all\x20the\x20good\x20things\x20that\x20come\x20your\x20way.'];
    a0_0x5821 = function() {
        return _0x2210a5;
    };
    return a0_0x5821();
}

function randomPositiveAffirmation() {
    const _0x52ac6d = a0_0x2a16,
        _0x364fff = [_0x52ac6d(0x19c), _0x52ac6d(0x1b5), _0x52ac6d(0x19d), 'You\x20are\x20a\x20unique\x20and\x20special\x20individual.', _0x52ac6d(0x1a1), _0x52ac6d(0x1ad), _0x52ac6d(0x1ac), _0x52ac6d(0x1b3), _0x52ac6d(0x19f), 'You\x20are\x20a\x20beacon\x20of\x20light\x20in\x20the\x20world.', 'You\x20have\x20so\x20much\x20to\x20offer.', _0x52ac6d(0x1af), _0x52ac6d(0x1ae), _0x52ac6d(0x1b7), _0x52ac6d(0x1a6), _0x52ac6d(0x1a4), _0x52ac6d(0x1a5), _0x52ac6d(0x1ab), _0x52ac6d(0x1b0), 'You\x20are\x20in\x20control\x20of\x20your\x20own\x20happiness.'],
        _0x540133 = Math[_0x52ac6d(0x1a7)](Math['random']() * _0x364fff[_0x52ac6d(0x1b2)]),
        _0x5d4beb = _0x364fff[_0x540133];
    console[_0x52ac6d(0x1a2)](_0x5d4beb);
}

function a0_0x2a16(_0x2168c5, _0x327273) {
    const _0x58210d = a0_0x5821();
    return a0_0x2a16 = function(_0x2a16f3, _0x1cc4f4) {
        _0x2a16f3 = _0x2a16f3 - 0x19c;
        let _0x44a573 = _0x58210d[_0x2a16f3];
        return _0x44a573;
    }, a0_0x2a16(_0x2168c5, _0x327273);
}
randomPositiveAffirmation();