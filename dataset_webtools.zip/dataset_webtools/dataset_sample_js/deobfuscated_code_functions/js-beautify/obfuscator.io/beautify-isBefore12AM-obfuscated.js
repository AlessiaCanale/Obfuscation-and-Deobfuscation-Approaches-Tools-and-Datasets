const a0_0x2538e1 = a0_0x18ae;
(function(_0x24e93d, _0xa65328) {
    const _0x5e0fc6 = a0_0x18ae,
        _0x549bee = _0x24e93d();
    while (!![]) {
        try {
            const _0x1ede84 = -parseInt(_0x5e0fc6(0x195)) / 0x1 + parseInt(_0x5e0fc6(0x18e)) / 0x2 + parseInt(_0x5e0fc6(0x18d)) / 0x3 + parseInt(_0x5e0fc6(0x192)) / 0x4 + parseInt(_0x5e0fc6(0x196)) / 0x5 * (parseInt(_0x5e0fc6(0x191)) / 0x6) + -parseInt(_0x5e0fc6(0x193)) / 0x7 * (-parseInt(_0x5e0fc6(0x18c)) / 0x8) + -parseInt(_0x5e0fc6(0x18f)) / 0x9;
            if (_0x1ede84 === _0xa65328) break;
            else _0x549bee['push'](_0x549bee['shift']());
        } catch (_0x991b27) {
            _0x549bee['push'](_0x549bee['shift']());
        }
    }
}(a0_0x23f8, 0x37627));

function a0_0x18ae(_0x510a14, _0xb44e10) {
    const _0x23f8df = a0_0x23f8();
    return a0_0x18ae = function(_0x18ae23, _0x3d1834) {
        _0x18ae23 = _0x18ae23 - 0x18c;
        let _0x208d96 = _0x23f8df[_0x18ae23];
        return _0x208d96;
    }, a0_0x18ae(_0x510a14, _0xb44e10);
}
const currentTime = new Date(),
    currentHour = currentTime[a0_0x2538e1(0x197)]();

function a0_0x23f8() {
    const _0x1d36e7 = ['9308844ZenLbA', 'It\x27s\x20currently\x20before\x2012\x20AM!', '12mpeUQz', '1604648pxasYv', '69937TnxlTE', 'log', '82275iONGJE', '776765EYztsk', 'getHours', '176DEtMUS', '33729EOkOEw', '801066tGMUWF'];
    a0_0x23f8 = function() {
        return _0x1d36e7;
    };
    return a0_0x23f8();
}
currentHour < 0xc ? console[a0_0x2538e1(0x194)](a0_0x2538e1(0x190)) : console[a0_0x2538e1(0x194)]('It\x27s\x20currently\x20after\x2012\x20AM!');