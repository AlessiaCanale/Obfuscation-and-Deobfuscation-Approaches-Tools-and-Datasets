const a0_0x1d78c3 = a0_0x17ad;
(function(_0x15d481, _0x26984d) {
    const _0x39f71a = a0_0x17ad,
        _0x4cbb5d = _0x15d481();
    while (!![]) {
        try {
            const _0x192357 = -parseInt(_0x39f71a(0xc1)) / 0x1 + -parseInt(_0x39f71a(0xc4)) / 0x2 * (-parseInt(_0x39f71a(0xc0)) / 0x3) + parseInt(_0x39f71a(0xc2)) / 0x4 * (-parseInt(_0x39f71a(0xcd)) / 0x5) + parseInt(_0x39f71a(0xc8)) / 0x6 + -parseInt(_0x39f71a(0xc7)) / 0x7 + parseInt(_0x39f71a(0xc6)) / 0x8 + parseInt(_0x39f71a(0xbf)) / 0x9;
            if (_0x192357 === _0x26984d) break;
            else _0x4cbb5d['push'](_0x4cbb5d['shift']());
        } catch (_0x3e4362) {
            _0x4cbb5d['push'](_0x4cbb5d['shift']());
        }
    }
}(a0_0x4d67, 0x5334f));
const input = document[a0_0x1d78c3(0xc5)]('input[type=\x22checkbox\x22]');

function handleInput() {
    const _0x560d0e = a0_0x1d78c3,
        {
            checked: _0xf61d49
        } = this;
    document['querySelector'](_0x560d0e(0xcb))[_0x560d0e(0xcc)][_0x560d0e(0xc9)] = _0xf61d49 ? _0x560d0e(0xce) : '#d6e7f7';
}

function a0_0x17ad(_0x4ac761, _0x4c6608) {
    const _0x4d6772 = a0_0x4d67();
    return a0_0x17ad = function(_0x17ad82, _0x3b3765) {
        _0x17ad82 = _0x17ad82 - 0xbf;
        let _0x109094 = _0x4d6772[_0x17ad82];
        return _0x109094;
    }, a0_0x17ad(_0x4ac761, _0x4c6608);
}
input[a0_0x1d78c3(0xca)](a0_0x1d78c3(0xc3), handleInput);

function a0_0x4d67() {
    const _0x2a8592 = ['223385DmyevJ', '#151d29', '8339778agSOzO', '519942PBzjVQ', '350004DYzbkH', '52RvfIVA', 'input', '4jvZdjP', 'querySelector', '1940064nElNgD', '2364600gQAIYL', '561852mjlzyt', 'background', 'addEventListener', 'body', 'style'];
    a0_0x4d67 = function() {
        return _0x2a8592;
    };
    return a0_0x4d67();
}