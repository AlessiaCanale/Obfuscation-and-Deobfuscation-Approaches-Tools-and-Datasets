function a0_0x2abc(_0x522be2, _0x4cda6d) {
    const _0x1305cc = a0_0x1305();
    return a0_0x2abc = function(_0x2abc9b, _0x3955a0) {
        _0x2abc9b = _0x2abc9b - 0xf1;
        let _0x40a79a = _0x1305cc[_0x2abc9b];
        return _0x40a79a;
    }, a0_0x2abc(_0x522be2, _0x4cda6d);
}(function(_0x413f4c, _0xc18dfc) {
    const _0x2919b1 = a0_0x2abc,
        _0x57c44a = _0x413f4c();
    while (!![]) {
        try {
            const _0xaf6db4 = -parseInt(_0x2919b1(0xfe)) / 0x1 + -parseInt(_0x2919b1(0xf2)) / 0x2 + parseInt(_0x2919b1(0xf8)) / 0x3 * (-parseInt(_0x2919b1(0xff)) / 0x4) + -parseInt(_0x2919b1(0xfc)) / 0x5 * (parseInt(_0x2919b1(0x100)) / 0x6) + parseInt(_0x2919b1(0xf5)) / 0x7 + -parseInt(_0x2919b1(0xf9)) / 0x8 + -parseInt(_0x2919b1(0xfb)) / 0x9 * (-parseInt(_0x2919b1(0x101)) / 0xa);
            if (_0xaf6db4 === _0xc18dfc) break;
            else _0x57c44a['push'](_0x57c44a['shift']());
        } catch (_0x487ef4) {
            _0x57c44a['push'](_0x57c44a['shift']());
        }
    }
}(a0_0x1305, 0x49a15));

function a0_0x1305() {
    const _0x2b5734 = ['307905GPYtof', 'length', '165167ryMyVh', '440yvmFti', '48zVdcff', '410dFNetn', 'push', 'Words\x20with\x20length\x20', 'split', '1028682DEppFg', 'join', 'hasOwnProperty', '3336585YTiYuE', 'forEach', 'log', '15909mOqAzr', '118136ANgIgo', 'Original\x20text:', '350163bYdfZf'];
    a0_0x1305 = function() {
        return _0x2b5734;
    };
    return a0_0x1305();
}

function createSubtextsWithWordsOfEqualLength(_0x87577) {
    const _0x16f099 = a0_0x2abc;
    let _0x3b7b1d = _0x87577[_0x16f099(0xf1)](/\s+/),
        _0x48290b = {};
    _0x3b7b1d[_0x16f099(0xf6)](_0x39df62 => {
        const _0xd1316b = _0x16f099;
        let _0x12ec64 = _0x39df62[_0xd1316b(0xfd)];
        !_0x48290b[_0x12ec64] && (_0x48290b[_0x12ec64] = []), _0x48290b[_0x12ec64][_0xd1316b(0x102)](_0x39df62);
    });
    let _0x93fe74 = [];
    for (let _0x1b370a in _0x48290b) {
        if (_0x48290b[_0x16f099(0xf4)](_0x1b370a)) {
            let _0x24b51b = _0x16f099(0x103) + _0x1b370a + ':\x20' + _0x48290b[_0x1b370a][_0x16f099(0xf3)](',\x20');
            _0x93fe74[_0x16f099(0x102)](_0x24b51b);
        }
    }
    console[_0x16f099(0xf7)](_0x16f099(0xfa)), console['log'](_0x87577), console[_0x16f099(0xf7)]('\x0aSubtexts\x20created:'), _0x93fe74[_0x16f099(0xf6)](_0x4a4dc => {
        const _0x2c327e = _0x16f099;
        console[_0x2c327e(0xf7)](_0x4a4dc), console['log']();
    });
}
var inputText = 'This\x20is\x20a\x20sample\x20text\x20with\x20at\x20least\x2025\x20words\x20to\x20demonstrate\x20the\x20function.\x20It\x20should\x20create\x20subtexts\x20based\x20on\x20words\x20of\x20equal\x20length\x20found\x20in\x20the\x20text.';
createSubtextsWithWordsOfEqualLength(inputText);