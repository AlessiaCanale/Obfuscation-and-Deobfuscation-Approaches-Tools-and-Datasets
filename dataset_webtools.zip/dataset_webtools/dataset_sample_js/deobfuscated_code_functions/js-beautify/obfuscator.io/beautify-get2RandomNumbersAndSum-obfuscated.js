(function(_0x1b15e9, _0x3f67d8) {
    var _0x3a1717 = a0_0xa25f,
        _0x2f7f44 = _0x1b15e9();
    while (!![]) {
        try {
            var _0x4a6d41 = parseInt(_0x3a1717(0xb5)) / 0x1 + parseInt(_0x3a1717(0xbb)) / 0x2 * (-parseInt(_0x3a1717(0xb4)) / 0x3) + parseInt(_0x3a1717(0xb0)) / 0x4 * (-parseInt(_0x3a1717(0xb1)) / 0x5) + parseInt(_0x3a1717(0xad)) / 0x6 * (-parseInt(_0x3a1717(0xb6)) / 0x7) + -parseInt(_0x3a1717(0xaf)) / 0x8 + -parseInt(_0x3a1717(0xba)) / 0x9 * (-parseInt(_0x3a1717(0xbc)) / 0xa) + parseInt(_0x3a1717(0xb2)) / 0xb;
            if (_0x4a6d41 === _0x3f67d8) break;
            else _0x2f7f44['push'](_0x2f7f44['shift']());
        } catch (_0x16dbcb) {
            _0x2f7f44['push'](_0x2f7f44['shift']());
        }
    }
}(a0_0xe79d, 0x888e5));

function getRandomNumber() {
    var _0x227a5d = a0_0xa25f;
    return Math['floor'](Math[_0x227a5d(0xae)]() * 0x3e9);
}

function get2RandomNumbersAndSum() {
    var _0x3a82b1 = a0_0xa25f,
        _0xd789c8 = getRandomNumber(),
        _0x59b53b = getRandomNumber(),
        _0x2478a3 = _0xd789c8 + _0x59b53b;
    console[_0x3a82b1(0xb7)](_0x3a82b1(0xb8) + _0xd789c8), console['log'](_0x3a82b1(0xb3) + _0x59b53b), console['log']('Try\x20to\x20sum\x20them\x20and\x20check\x20the\x20result\x20that\x20will\x20appear!\x20:)'), setTimeout(function() {
        var _0x48a52b = _0x3a82b1;
        console['log'](_0x48a52b(0xb9) + _0x2478a3);
    }, 0x1388);
}

function a0_0xa25f(_0x282ea6, _0x5c9c76) {
    var _0xe79d6d = a0_0xe79d();
    return a0_0xa25f = function(_0xa25fc, _0x2478c2) {
        _0xa25fc = _0xa25fc - 0xad;
        var _0xc2464d = _0xe79d6d[_0xa25fc];
        return _0xc2464d;
    }, a0_0xa25f(_0x282ea6, _0x5c9c76);
}

function a0_0xe79d() {
    var _0x5ebded = ['log', 'Random\x20number\x201:\x20', 'The\x20sum\x20of\x20the\x20two\x20random\x20numbers\x20is:\x20', '36WGvadU', '765406LTsozs', '178460PERRmk', '2622wiMjoG', 'random', '582464lyfZSB', '29768ntBxKS', '430dxJhaD', '22405735saGmZr', 'Random\x20number\x202:\x20', '6hrQGKm', '153908CkvevL', '3598JdEAMR'];
    a0_0xe79d = function() {
        return _0x5ebded;
    };
    return a0_0xe79d();
}
get2RandomNumbersAndSum();