const a0_0x3539d9 = a0_0x279b;
(function(_0x451ccf, _0x359a2e) {
    const _0x2a99b5 = a0_0x279b,
        _0x20a73b = _0x451ccf();
    while (!![]) {
        try {
            const _0x4a8483 = -parseInt(_0x2a99b5(0x1d8)) / 0x1 + parseInt(_0x2a99b5(0x1c3)) / 0x2 * (-parseInt(_0x2a99b5(0x1c2)) / 0x3) + parseInt(_0x2a99b5(0x1cf)) / 0x4 + parseInt(_0x2a99b5(0x1c7)) / 0x5 + -parseInt(_0x2a99b5(0x1db)) / 0x6 * (-parseInt(_0x2a99b5(0x1c9)) / 0x7) + parseInt(_0x2a99b5(0x1e2)) / 0x8 * (parseInt(_0x2a99b5(0x1d1)) / 0x9) + -parseInt(_0x2a99b5(0x1cb)) / 0xa;
            if (_0x4a8483 === _0x359a2e) break;
            else _0x20a73b['push'](_0x20a73b['shift']());
        } catch (_0x24ed8f) {
            _0x20a73b['push'](_0x20a73b['shift']());
        }
    }
}(a0_0x3b7d, 0xe7251));

function a0_0x3b7d() {
    const _0x490330 = ['404GuhGhi', 'visible', 'onclick', 'easeInOutQuint', '1452775bwqLRA', 'addEventListener', '7tfWqqS', 'easeOutCubic', '11449290UXZtTo', 'replace', 'easeOutQuint', 'classList', '5860660VhNgxh', 'hidden', '9JpAwIs', '15deg', '.content\x20.letter', 'easeInQuint', 'innerHTML', 'forEach', '.slider\x20.item', '1806575WwITln', 'easeInCubic', 'is-active', '9732084QteebG', 'querySelector', 'querySelectorAll', '.slider\x20.nav\x20.prev', '-15deg', 'timeline', '.img', '6124520QKaVPm', '.wrap', 'length', '<span\x20class=\x27letter\x27>$&</span>', 'DOMContentLoaded', 'add', '-.75em', '.slider\x20.nav\x20.next', 'remove', '3639ojKKsY'];
    a0_0x3b7d = function() {
        return _0x490330;
    };
    return a0_0x3b7d();
}

function a0_0x279b(_0xbfbf62, _0x35ab70) {
    const _0x3b7db3 = a0_0x3b7d();
    return a0_0x279b = function(_0x279bb9, _0x10a32c) {
        _0x279bb9 = _0x279bb9 - 0x1bf;
        let _0x3cc115 = _0x3b7db3[_0x279bb9];
        return _0x3cc115;
    }, a0_0x279b(_0xbfbf62, _0x35ab70);
}

function init() {
    const _0x331910 = a0_0x279b,
        _0x286421 = document[_0x331910(0x1dc)]('.slider'),
        _0x4f41b2 = _0x286421[_0x331910(0x1dc)](_0x331910(0x1c0)),
        _0x224532 = _0x286421[_0x331910(0x1dc)](_0x331910(0x1de)),
        _0x2e7844 = _0x286421[_0x331910(0x1dd)](_0x331910(0x1d7));
    let _0x30a8ab = 0x0;
    _0x2e7844[_0x331910(0x1d6)](_0x29d242 => {
        const _0x569651 = _0x331910,
            _0x1b1cf7 = _0x29d242[_0x569651(0x1dc)](_0x569651(0x1e3));
        _0x1b1cf7[_0x569651(0x1d5)] = _0x1b1cf7['textContent'][_0x569651(0x1cc)](/\S/g, _0x569651(0x1e5));
    });

    function _0x3fb3e5(_0x5cbfa6, _0x5b8cff, _0x4b4cb7) {
        const _0x444675 = _0x331910,
            _0x5661cf = _0x5cbfa6['querySelectorAll'](_0x444675(0x1e1)),
            _0x4d1879 = _0x5cbfa6[_0x444675(0x1dd)](_0x444675(0x1d3)),
            _0x14160f = _0x5b8cff['querySelectorAll']('.img'),
            _0x1b422d = _0x5b8cff['querySelectorAll']('.content\x20.letter'),
            _0x1f5a7a = 0x190,
            _0xdc65cd = '-=' + _0x1f5a7a * 0.4,
            _0x1dce5f = _0x1f5a7a * 0.8,
            _0x7376af = anime[_0x444675(0x1e0)]({
                'easing': _0x444675(0x1c6),
                'duration': _0x1f5a7a,
                'complete': _0x4b4cb7
            });
        _0x7376af[_0x444675(0x1e7)]({
            'targets': _0x4d1879,
            'translateY': [0x0, _0x444675(0x1bf)],
            'opacity': [0x1, 0x0],
            'easing': _0x444675(0x1d4),
            'duration': _0x1f5a7a,
            'delay': (_0x7a7ee3, _0xbf6155) => 0xa * (_0xbf6155 + 0x1)
        })[_0x444675(0x1e7)]({
            'targets': _0x5661cf[0x0],
            'translateY': -0x258,
            'translateZ': 0x0,
            'rotate': [0x0, _0x444675(0x1df)],
            'opacity': [0x1, 0x0],
            'easing': 'easeInCubic'
        }, _0xdc65cd)[_0x444675(0x1e7)]({
            'targets': _0x5661cf[0x1],
            'translateY': -0x258,
            'translateZ': 0x0,
            'rotate': [0x0, _0x444675(0x1d2)],
            'opacity': [0x1, 0x0],
            'easing': _0x444675(0x1d9)
        }, '-=' + _0x1dce5f)['add']({
            'targets': _0x5661cf[0x2],
            'translateY': -0x258,
            'translateZ': 0x0,
            'rotate': [0x0, _0x444675(0x1df)],
            'opacity': [0x1, 0x0],
            'easing': _0x444675(0x1d9)
        }, '-=' + _0x1dce5f)[_0x444675(0x1e7)]({
            'targets': _0x5661cf[0x3],
            'translateY': -0x258,
            'translateZ': 0x0,
            'rotate': [0x0, _0x444675(0x1d2)],
            'opacity': [0x1, 0x0],
            'easing': _0x444675(0x1d9)
        }, '-=' + _0x1dce5f)['add']({
            'targets': _0x5cbfa6,
            'opacity': 0x0,
            'visibility': _0x444675(0x1d0),
            'duration': 0xa,
            'easing': 'easeInCubic'
        })[_0x444675(0x1e7)]({
            'targets': _0x5b8cff,
            'opacity': 0x1,
            'visibility': _0x444675(0x1c4),
            'duration': 0xa
        }, _0xdc65cd)[_0x444675(0x1e7)]({
            'targets': _0x14160f[0x0],
            'translateY': [0x258, 0x0],
            'translateZ': 0x0,
            'rotate': [_0x444675(0x1d2), 0x0],
            'opacity': [0x0, 0x1],
            'easing': _0x444675(0x1ca)
        }, _0xdc65cd)[_0x444675(0x1e7)]({
            'targets': _0x14160f[0x1],
            'translateY': [0x258, 0x0],
            'translateZ': 0x0,
            'rotate': [_0x444675(0x1df), 0x0],
            'opacity': [0x0, 0x1],
            'easing': _0x444675(0x1ca)
        }, '-=' + _0x1dce5f)[_0x444675(0x1e7)]({
            'targets': _0x14160f[0x2],
            'translateY': [0x258, 0x0],
            'translateZ': 0x0,
            'rotate': ['15deg', 0x0],
            'opacity': [0x0, 0x1],
            'easing': 'easeOutCubic'
        }, '-=' + _0x1dce5f)[_0x444675(0x1e7)]({
            'targets': _0x14160f[0x3],
            'translateY': [0x258, 0x0],
            'translateZ': 0x0,
            'rotate': ['-15deg', 0x0],
            'opacity': [0x0, 0x1],
            'easing': 'easeOutCubic'
        }, '-=' + _0x1dce5f)[_0x444675(0x1e7)]({
            'targets': _0x1b422d,
            'translateY': ['.75em', 0x0],
            'translateZ': 0x0,
            'opacity': [0x0, 0x1],
            'easing': _0x444675(0x1cd),
            'duration': _0x1f5a7a * 1.5,
            'delay': (_0x59b74d, _0x557576) => 0xa * (_0x557576 + 0x1)
        }, _0xdc65cd);
    }
    let _0x887e02 = ![];

    function _0x47e2ab(_0x38a942) {
        const _0x5c9ca0 = _0x2e7844[_0x30a8ab],
            _0x3a984e = _0x2e7844[_0x38a942];

        function _0x23e60f() {
            const _0x5d257f = a0_0x279b;
            _0x5c9ca0['classList'][_0x5d257f(0x1c1)]('is-active'), _0x3a984e[_0x5d257f(0x1ce)]['add'](_0x5d257f(0x1da)), _0x30a8ab = _0x38a942, _0x887e02 = ![];
        }
        _0x3fb3e5(_0x5c9ca0, _0x3a984e, _0x23e60f);
    }

    function _0x3bf1e3() {
        const _0x3bf2d3 = _0x331910;
        if (_0x887e02) return;
        _0x887e02 = !![];
        const _0x1d0660 = _0x30a8ab === _0x2e7844[_0x3bf2d3(0x1e4)] - 0x1 ? 0x0 : _0x30a8ab + 0x1;
        _0x47e2ab(_0x1d0660);
    }

    function _0x1b77cf() {
        const _0x35ba46 = _0x331910;
        if (_0x887e02) return;
        _0x887e02 = !![];
        const _0x5f06df = _0x30a8ab === 0x0 ? _0x2e7844[_0x35ba46(0x1e4)] - 0x1 : _0x30a8ab - 0x1;
        _0x47e2ab(_0x5f06df);
    }
    _0x4f41b2[_0x331910(0x1c5)] = _0x3bf1e3, _0x224532[_0x331910(0x1c5)] = _0x1b77cf;
}
document[a0_0x3539d9(0x1c8)](a0_0x3539d9(0x1e6), init);