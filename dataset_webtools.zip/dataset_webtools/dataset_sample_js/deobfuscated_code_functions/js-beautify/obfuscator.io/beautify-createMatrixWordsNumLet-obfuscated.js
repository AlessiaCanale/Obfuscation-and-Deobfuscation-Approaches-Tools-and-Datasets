const a0_0x6382ac = a0_0x4d51;
(function(_0x44f223, _0x314961) {
    const _0x54daca = a0_0x4d51,
        _0x4f2544 = _0x44f223();
    while (!![]) {
        try {
            const _0x42b8a8 = -parseInt(_0x54daca(0x157)) / 0x1 + -parseInt(_0x54daca(0x158)) / 0x2 + parseInt(_0x54daca(0x14d)) / 0x3 + -parseInt(_0x54daca(0x152)) / 0x4 * (parseInt(_0x54daca(0x153)) / 0x5) + -parseInt(_0x54daca(0x14b)) / 0x6 + -parseInt(_0x54daca(0x150)) / 0x7 + parseInt(_0x54daca(0x156)) / 0x8;
            if (_0x42b8a8 === _0x314961) break;
            else _0x4f2544['push'](_0x4f2544['shift']());
        } catch (_0x304bd3) {
            _0x4f2544['push'](_0x4f2544['shift']());
        }
    }
}(a0_0x3895, 0x23831));

function createMatrixWordsNumLet(_0x1451d7) {
    const _0x5b5e27 = a0_0x4d51,
        _0x82a20f = _0x1451d7[_0x5b5e27(0x14f)]('\x20'),
        _0x408814 = [
            [],
            []
        ];
    for (let _0x1bc732 of _0x82a20f) {
        _0x408814[0x0][_0x5b5e27(0x155)](_0x1bc732), _0x408814[0x1][_0x5b5e27(0x155)](_0x1bc732[_0x5b5e27(0x151)]);
    }
    return _0x408814;
}
const inputString = a0_0x6382ac(0x14e),
    resultMatrix = createMatrixWordsNumLet(inputString);

function a0_0x3895() {
    const _0x4a91c9 = ['2805toKwlV', 'Input\x20string:', 'push', '6691032UOxkvV', '209245mpVJew', '267506FhEZjc', '1700868vgPrHB', 'log', '471954SyyLAK', 'You\x20can\x20use\x20JavaScript\x20language\x20to\x20create\x20nice\x20things', 'split', '582379cVLUhS', 'length', '988kcqgFA'];
    a0_0x3895 = function() {
        return _0x4a91c9;
    };
    return a0_0x3895();
}

function a0_0x4d51(_0x1e76b4, _0x54e569) {
    const _0x3895f8 = a0_0x3895();
    return a0_0x4d51 = function(_0x4d5165, _0x1fa472) {
        _0x4d5165 = _0x4d5165 - 0x14b;
        let _0x1d190b = _0x3895f8[_0x4d5165];
        return _0x1d190b;
    }, a0_0x4d51(_0x1e76b4, _0x54e569);
}
console[a0_0x6382ac(0x14c)](a0_0x6382ac(0x154)), console[a0_0x6382ac(0x14c)](inputString), console[a0_0x6382ac(0x14c)]('\x0aResult\x20matrix:');
for (let row = 0x0; row < resultMatrix[0x0][a0_0x6382ac(0x151)]; row++) {
    console[a0_0x6382ac(0x14c)](resultMatrix[0x0][row] + '\x20-\x20' + resultMatrix[0x1][row]);
}