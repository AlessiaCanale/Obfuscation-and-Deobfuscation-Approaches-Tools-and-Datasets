function a0_0x54ea(_0x5286df, _0x50737f) {
    const _0x3a218b = a0_0x3a21();
    return a0_0x54ea = function(_0x54eae1, _0x253a76) {
        _0x54eae1 = _0x54eae1 - 0x138;
        let _0x299e53 = _0x3a218b[_0x54eae1];
        return _0x299e53;
    }, a0_0x54ea(_0x5286df, _0x50737f);
}
const a0_0x3966f5 = a0_0x54ea;
(function(_0x2f2495, _0x25bd6b) {
    const _0xf6818a = a0_0x54ea,
        _0x29ecb5 = _0x2f2495();
    while (!![]) {
        try {
            const _0x1c662b = -parseInt(_0xf6818a(0x13c)) / 0x1 + parseInt(_0xf6818a(0x138)) / 0x2 + -parseInt(_0xf6818a(0x13b)) / 0x3 + -parseInt(_0xf6818a(0x13f)) / 0x4 * (parseInt(_0xf6818a(0x143)) / 0x5) + parseInt(_0xf6818a(0x140)) / 0x6 * (parseInt(_0xf6818a(0x141)) / 0x7) + -parseInt(_0xf6818a(0x145)) / 0x8 + parseInt(_0xf6818a(0x146)) / 0x9 * (parseInt(_0xf6818a(0x142)) / 0xa);
            if (_0x1c662b === _0x25bd6b) break;
            else _0x29ecb5['push'](_0x29ecb5['shift']());
        } catch (_0x1d8219) {
            _0x29ecb5['push'](_0x29ecb5['shift']());
        }
    }
}(a0_0x3a21, 0x194df));
const str = 'abc\x27s\x20test#s',
    str1 = a0_0x3966f5(0x13a);

function a0_0x3a21() {
    const _0x4095a0 = ['replace', '792000rypLvV', '1233vxHrUX', '76542DXvolO', '\x0ano\x20specific\x20char:\x20', 'ACLz$\x20@H{oKk', '184266JripMW', '2766vJCRhi', 'log', 'original:\x20', '160LQgrJb', '12186nOZXQx', '441IGjeLx', '18430UqNiXE', '18985exKRQh'];
    a0_0x3a21 = function() {
        return _0x4095a0;
    };
    return a0_0x3a21();
}
console[a0_0x3966f5(0x13d)]('original:\x20' + str + a0_0x3966f5(0x139) + str[a0_0x3966f5(0x144)](/[^a-zA-Z ]/g, '')), console[a0_0x3966f5(0x13d)](a0_0x3966f5(0x13e) + str1 + '\x0ano\x20specific\x20char:\x20' + str1['replace'](/[^a-zA-Z ]/g, ''));