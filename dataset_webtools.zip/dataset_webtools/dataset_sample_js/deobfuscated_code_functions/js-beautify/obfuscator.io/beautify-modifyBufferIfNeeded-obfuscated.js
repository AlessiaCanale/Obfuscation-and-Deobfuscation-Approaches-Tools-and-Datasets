(function(_0x19b398, _0x5afede) {
    const _0x5c495c = a0_0x3cdc,
        _0x4ac76e = _0x19b398();
    while (!![]) {
        try {
            const _0x345e88 = -parseInt(_0x5c495c(0x13a)) / 0x1 * (parseInt(_0x5c495c(0x134)) / 0x2) + -parseInt(_0x5c495c(0x13d)) / 0x3 * (-parseInt(_0x5c495c(0x133)) / 0x4) + -parseInt(_0x5c495c(0x13b)) / 0x5 + -parseInt(_0x5c495c(0x138)) / 0x6 + parseInt(_0x5c495c(0x130)) / 0x7 * (-parseInt(_0x5c495c(0x132)) / 0x8) + parseInt(_0x5c495c(0x12f)) / 0x9 + -parseInt(_0x5c495c(0x139)) / 0xa;
            if (_0x345e88 === _0x5afede) break;
            else _0x4ac76e['push'](_0x4ac76e['shift']());
        } catch (_0xa7da79) {
            _0x4ac76e['push'](_0x4ac76e['shift']());
        }
    }
}(a0_0x3b58, 0x62f52));

function a0_0x3cdc(_0x2e6fe2, _0x44a135) {
    const _0x3b584f = a0_0x3b58();
    return a0_0x3cdc = function(_0x3cdc87, _0x448a30) {
        _0x3cdc87 = _0x3cdc87 - 0x12f;
        let _0x2ff515 = _0x3b584f[_0x3cdc87];
        return _0x2ff515;
    }, a0_0x3cdc(_0x2e6fe2, _0x44a135);
}

function modifyBufferIfNeeded(_0x2cd814, _0x135050) {
    const _0x4871b8 = a0_0x3cdc;
    console[_0x4871b8(0x137)](_0x4871b8(0x136) + _0x2cd814), console[_0x4871b8(0x137)](_0x4871b8(0x13c) + _0x135050);
    if (_0x2cd814 === _0x135050) console[_0x4871b8(0x137)]('No\x20need\x20to\x20modify\x20the\x20buffer.');
    else {
        if (_0x2cd814 > _0x135050) {
            let _0x3f0f48 = _0x2cd814 - _0x135050;
            console[_0x4871b8(0x137)](_0x4871b8(0x131) + _0x3f0f48);
        } else {
            let _0x2821ef = _0x135050 - _0x2cd814;
            console[_0x4871b8(0x137)](_0x4871b8(0x135) + _0x2821ef);
        }
    }
}

function a0_0x3b58() {
    const _0x458e45 = ['49655uRJMJy', '851900nEqRGL', 'Number\x20of\x20elements\x20to\x20insert:\x20', '4668hbPFMv', '7082838QmRRZk', '1246zTnGjL', 'Available\x20space\x20in\x20the\x20buffer\x20after\x20insertion:\x20', '19112xDFQaN', '1692ylJhWy', '2heAufL', 'Increase\x20buffer\x20capacity\x20by:\x20', 'Initial\x20buffer\x20capacity:\x20', 'log', '1440720eDPUMB', '1544430qcHCCR'];
    a0_0x3b58 = function() {
        return _0x458e45;
    };
    return a0_0x3b58();
}
modifyBufferIfNeeded(0xa, 0xa), modifyBufferIfNeeded(0xf, 0xa), modifyBufferIfNeeded(0x5, 0xa);