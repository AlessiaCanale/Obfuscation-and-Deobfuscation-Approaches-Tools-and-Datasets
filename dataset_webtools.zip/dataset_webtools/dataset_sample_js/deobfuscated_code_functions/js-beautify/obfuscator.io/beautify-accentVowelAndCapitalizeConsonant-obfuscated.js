function a0_0x1464(_0x3713b3, _0x51eced) {
    const _0x55bcd4 = a0_0x55bc();
    return a0_0x1464 = function(_0x146495, _0x13d592) {
        _0x146495 = _0x146495 - 0x181;
        let _0x27598c = _0x55bcd4[_0x146495];
        return _0x27598c;
    }, a0_0x1464(_0x3713b3, _0x51eced);
}
const a0_0xb328d1 = a0_0x1464;
(function(_0xa37aa2, _0x4b3041) {
    const _0x44e98f = a0_0x1464,
        _0x2214c2 = _0xa37aa2();
    while (!![]) {
        try {
            const _0x4d3f7c = -parseInt(_0x44e98f(0x18b)) / 0x1 * (-parseInt(_0x44e98f(0x185)) / 0x2) + -parseInt(_0x44e98f(0x187)) / 0x3 + -parseInt(_0x44e98f(0x18d)) / 0x4 * (-parseInt(_0x44e98f(0x181)) / 0x5) + parseInt(_0x44e98f(0x188)) / 0x6 * (-parseInt(_0x44e98f(0x184)) / 0x7) + -parseInt(_0x44e98f(0x186)) / 0x8 + -parseInt(_0x44e98f(0x193)) / 0x9 + parseInt(_0x44e98f(0x183)) / 0xa;
            if (_0x4d3f7c === _0x4b3041) break;
            else _0x2214c2['push'](_0x2214c2['shift']());
        } catch (_0xfd4965) {
            _0x2214c2['push'](_0x2214c2['shift']());
        }
    }
}(a0_0x55bc, 0x5be0e));

function a0_0x55bc() {
    const _0x552b05 = ['3827070mAjENT', '300GnASWt', 'toUpperCase', '10634290SnpcTu', '196vPstmG', '4MdckJd', '690832kwUUhX', '1559907LRnvVw', '104034SFdolK', 'Elephant', 'length', '295965QTnspS', 'world', '15868FYLyDA', 'AUSTRALIA', 'Original\x20word:\x20', 'toLowerCase', 'hello', 'hasOwnProperty'];
    a0_0x55bc = function() {
        return _0x552b05;
    };
    return a0_0x55bc();
}

function accentVowelAndCapitalizeConsonant(_0x400fab) {
    const _0x28bd49 = a0_0x1464,
        _0x5b3c07 = {
            'a': 'á',
            'e': 'è',
            'i': 'í',
            'o': 'ó',
            'u': 'ú'
        };
    let _0x13a2fd = '';
    for (let _0x5dc3ac = 0x0; _0x5dc3ac < _0x400fab[_0x28bd49(0x18a)]; _0x5dc3ac++) {
        let _0x577683 = _0x400fab[_0x5dc3ac]['toLowerCase']();
        _0x5b3c07[_0x28bd49(0x192)](_0x577683) ? _0x13a2fd += _0x5b3c07[_0x577683][_0x28bd49(0x190)]() : _0x13a2fd += _0x400fab[_0x5dc3ac][_0x28bd49(0x182)]();
    }
    console['log'](_0x28bd49(0x18f) + _0x400fab), console['log']('Modified\x20word:\x20' + _0x13a2fd);
}
accentVowelAndCapitalizeConsonant(a0_0xb328d1(0x191)), accentVowelAndCapitalizeConsonant(a0_0xb328d1(0x18c)), accentVowelAndCapitalizeConsonant(a0_0xb328d1(0x189)), accentVowelAndCapitalizeConsonant(a0_0xb328d1(0x18e));