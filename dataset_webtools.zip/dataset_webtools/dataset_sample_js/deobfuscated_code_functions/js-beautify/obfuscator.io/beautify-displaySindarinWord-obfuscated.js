const a0_0x1d855b = a0_0x142d;

function a0_0x142d(_0x2de3d9, _0x421760) {
    const _0x286397 = a0_0x2863();
    return a0_0x142d = function(_0x142dc8, _0x5d5670) {
        _0x142dc8 = _0x142dc8 - 0xb2;
        let _0xca3e43 = _0x286397[_0x142dc8];
        return _0xca3e43;
    }, a0_0x142d(_0x2de3d9, _0x421760);
}(function(_0x49e5f1, _0x909099) {
    const _0xef89da = a0_0x142d,
        _0x2e78a8 = _0x49e5f1();
    while (!![]) {
        try {
            const _0x19f930 = parseInt(_0xef89da(0xd0)) / 0x1 * (parseInt(_0xef89da(0xb7)) / 0x2) + parseInt(_0xef89da(0xb8)) / 0x3 + parseInt(_0xef89da(0xd1)) / 0x4 * (-parseInt(_0xef89da(0xb4)) / 0x5) + -parseInt(_0xef89da(0xc6)) / 0x6 * (parseInt(_0xef89da(0xb5)) / 0x7) + -parseInt(_0xef89da(0xcf)) / 0x8 + parseInt(_0xef89da(0xc9)) / 0x9 + parseInt(_0xef89da(0xcb)) / 0xa;
            if (_0x19f930 === _0x909099) break;
            else _0x2e78a8['push'](_0x2e78a8['shift']());
        } catch (_0x28e37e) {
            _0x2e78a8['push'](_0x2e78a8['shift']());
        }
    }
}(a0_0x2863, 0x9b094));

function displaySindarinWord(_0x56ff52) {
    const _0x15b2d0 = a0_0x142d,
        _0x3f7de5 = {
            'adar': _0x15b2d0(0xc2),
            'alagos': 'corpse',
            'amrûn': 'east',
            'anc': _0x15b2d0(0xc8),
            'band': 'loft',
            'baur': _0x15b2d0(0xc4),
            'brand': _0x15b2d0(0xc3),
            'carn': _0x15b2d0(0xbe),
            'cû': _0x15b2d0(0xc0),
            'dagor': _0x15b2d0(0xce),
            'dûr': _0x15b2d0(0xb2),
            'dúnedain': _0x15b2d0(0xd3),
            'edhel': _0x15b2d0(0xd2),
            'egui': _0x15b2d0(0xb6),
            'erain': _0x15b2d0(0xbb),
            'galad': 'light',
            'gûl': _0x15b2d0(0xbd),
            'hîr': _0x15b2d0(0xbf),
            'ist': 'know',
            'laeg': 'green',
            'lach': 'leaves',
            'miruvor': _0x15b2d0(0xc7),
            'naeth': _0x15b2d0(0xc5),
            'raith': _0x15b2d0(0xb3),
            'sereg': 'blood'
        };
    let _0x37b944 = Math['floor'](Math[_0x15b2d0(0xc1)]() * Object[_0x15b2d0(0xb9)](_0x3f7de5)[_0x15b2d0(0xca)]),
        _0x20c95c = Object['keys'](_0x3f7de5)[_0x37b944];
    console[_0x15b2d0(0xba)]('Sindarin\x20word:\x20' + _0x20c95c + _0x15b2d0(0xbc) + _0x3f7de5[_0x20c95c]), console[_0x15b2d0(0xba)](_0x15b2d0(0xcc) + _0x56ff52 + _0x15b2d0(0xbc) + _0x3f7de5[_0x56ff52]);
}

function a0_0x2863() {
    const _0x54fc71 = ['bow', 'random', 'father', 'tall', 'fist', 'young', '6822lKZbYq', 'mead', 'iron', '523710TkjuDT', 'length', '7493710tihPbF', 'Passed\x20word:\x20', 'miruvor', 'battle', '159616HAWVCs', '3409eMCpZw', '576ztXqwZ', 'elf', 'west-men', 'dark', 'guard', '970SZfnTI', '5971DZsKhp', 'fish', '184aAZcEH', '1594764bohqeR', 'keys', 'log', 'prince', ',\x20Translation:\x20', 'sorcery', 'red', 'lord'];
    a0_0x2863 = function() {
        return _0x54fc71;
    };
    return a0_0x2863();
}
displaySindarinWord(a0_0x1d855b(0xcd));