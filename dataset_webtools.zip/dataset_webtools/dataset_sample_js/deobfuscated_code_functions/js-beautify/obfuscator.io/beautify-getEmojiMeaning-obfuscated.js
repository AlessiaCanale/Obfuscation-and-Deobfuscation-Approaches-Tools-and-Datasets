var a0_0x16a562 = a0_0x2e7b;
(function(_0x18ec89, _0xa1f06) {
    var _0x2a4b4e = a0_0x2e7b,
        _0x493920 = _0x18ec89();
    while (!![]) {
        try {
            var _0x2da2b9 = -parseInt(_0x2a4b4e(0x1df)) / 0x1 * (-parseInt(_0x2a4b4e(0x1e3)) / 0x2) + -parseInt(_0x2a4b4e(0x1e4)) / 0x3 + -parseInt(_0x2a4b4e(0x1eb)) / 0x4 * (parseInt(_0x2a4b4e(0x1e7)) / 0x5) + -parseInt(_0x2a4b4e(0x1ec)) / 0x6 * (-parseInt(_0x2a4b4e(0x1dc)) / 0x7) + -parseInt(_0x2a4b4e(0x1ed)) / 0x8 * (-parseInt(_0x2a4b4e(0x1ea)) / 0x9) + -parseInt(_0x2a4b4e(0x1e2)) / 0xa + parseInt(_0x2a4b4e(0x1e5)) / 0xb;
            if (_0x2da2b9 === _0xa1f06) break;
            else _0x493920['push'](_0x493920['shift']());
        } catch (_0x40abaa) {
            _0x493920['push'](_0x493920['shift']());
        }
    }
}(a0_0x2a31, 0xbbabe));

function getEmojiMeaning(_0x4cc1bf) {
    var _0x31d0a9 = a0_0x2e7b;
    if (_0x4cc1bf === ':)') return _0x31d0a9(0x1ef);
    else {
        if (_0x4cc1bf === ':(') return _0x31d0a9(0x1dd);
        else {
            if (_0x4cc1bf === _0x31d0a9(0x1e8)) return _0x31d0a9(0x1e9);
            else return _0x4cc1bf === ':D' ? _0x31d0a9(0x1ee) : 'Sorry,\x20I\x20don\x27t\x20recognize\x20that\x20emoji.';
        }
    }
}
console[a0_0x16a562(0x1e0)](a0_0x16a562(0x1e1) + getEmojiMeaning(':)')), console['log'](':(\x20' + getEmojiMeaning(':(')), console[a0_0x16a562(0x1e0)](a0_0x16a562(0x1de) + getEmojiMeaning(a0_0x16a562(0x1e8))), console['log'](a0_0x16a562(0x1e6) + getEmojiMeaning(':D'));

function a0_0x2e7b(_0x280b30, _0x384cbe) {
    var _0x2a3116 = a0_0x2a31();
    return a0_0x2e7b = function(_0x2e7b5d, _0x14573e) {
        _0x2e7b5d = _0x2e7b5d - 0x1dc;
        var _0x4e8368 = _0x2a3116[_0x2e7b5d];
        return _0x4e8368;
    }, a0_0x2e7b(_0x280b30, _0x384cbe);
}

function a0_0x2a31() {
    var _0x5bfc4c = ['5247224urKOia', 'laughing\x20is\x20amazing\x20and\x20we\x20all\x20have\x20to\x20want\x20to\x20do\x20it\x20every\x20day!', 'what\x20a\x20beautiful\x20smile!', '2166563sCwGzU', 'you\x20are\x20great\x20and\x20you\x20will\x20return\x20to\x20smile\x20soon,\x20I\x27m\x20sure\x20of\x20it!', ':\x27(\x20', '1fwTWwI', 'log', ':)\x20', '7587570bMrtMy', '2598774AwhCLB', '4002786XICTzG', '8885690qwIzYG', ':D\x20', '48695ROyVUj', ':\x27(', 'Let\x20out\x20all\x20your\x20tears\x20and\x20then\x20look\x20at\x20yourself\x20in\x20the\x20mirror\x20because\x20the\x20person\x20you\x20see\x20reflected\x20is\x20amazing\x20and\x20should\x20not\x20allow\x20anyone\x20to\x20make\x20her\x20feel\x20bad.', '18pQJGWN', '356VSukqH', '6vzepCB'];
    a0_0x2a31 = function() {
        return _0x5bfc4c;
    };
    return a0_0x2a31();
}