function a0_0x284b(_0xe64a94, _0x3e4987) {
    const _0x184817 = a0_0x1848();
    return a0_0x284b = function(_0x284be9, _0x4b605e) {
        _0x284be9 = _0x284be9 - 0x8d;
        let _0x2c81f2 = _0x184817[_0x284be9];
        return _0x2c81f2;
    }, a0_0x284b(_0xe64a94, _0x3e4987);
}
const a0_0xccdb96 = a0_0x284b;
(function(_0x161d87, _0x859181) {
    const _0x5c235e = a0_0x284b,
        _0x150df1 = _0x161d87();
    while (!![]) {
        try {
            const _0x1afc61 = parseInt(_0x5c235e(0x9e)) / 0x1 + -parseInt(_0x5c235e(0x99)) / 0x2 + -parseInt(_0x5c235e(0xa5)) / 0x3 + parseInt(_0x5c235e(0x95)) / 0x4 + parseInt(_0x5c235e(0x9d)) / 0x5 + -parseInt(_0x5c235e(0xa4)) / 0x6 * (-parseInt(_0x5c235e(0x8e)) / 0x7) + -parseInt(_0x5c235e(0x9f)) / 0x8;
            if (_0x1afc61 === _0x859181) break;
            else _0x150df1['push'](_0x150df1['shift']());
        } catch (_0x1a486c) {
            _0x150df1['push'](_0x150df1['shift']());
        }
    }
}(a0_0x1848, 0x777cf));
const zeroPadded = _0x3315c0 => _0x3315c0 >= 0xa ? _0x3315c0[a0_0xccdb96(0xa8)]() : '0' + _0x3315c0,
    twelveClock = _0x47c21e => {
        if (_0x47c21e === 0x0) return 0xc;
        if (_0x47c21e > 0xc) return _0x47c21e - 0xc;
        return _0x47c21e;
    },
    clockFace = document[a0_0xccdb96(0x9b)](a0_0xccdb96(0xa3));
for (let i = 0x0; i < 0xc; i += 0x1) {
    clockFace[a0_0xccdb96(0xa9)] += a0_0xccdb96(0x8d) + (-0x5a + 0x1e * (i + 0x1)) + a0_0xccdb96(0xa2) + (0x5a - 0x1e * (i + 0x1)) + a0_0xccdb96(0x90) + zeroPadded(i + 0x1) + a0_0xccdb96(0xa0);
}
const now = new Date(),
    hours = now[a0_0xccdb96(0x97)](),
    minutes = now[a0_0xccdb96(0x98)](),
    seconds = now['getSeconds'](),
    time = {
        'hours': twelveClock(hours),
        'minutes': minutes,
        'seconds': seconds
    },
    rotation = {
        'hours': twelveClock(hours),
        'minutes': minutes,
        'seconds': seconds
    },
    entries = Object['entries'](time);
entries[a0_0xccdb96(0x8f)](([_0x1dec6f, _0x30a843]) => {
    const _0x210c81 = a0_0xccdb96;
    anime({
        'targets': 'g.' + _0x1dec6f,
        'transform': _0x1dec6f === _0x210c81(0xa6) ? _0x210c81(0x92) + (-0xf + _0x30a843 * 0x1e) + ')' : _0x210c81(0x92) + _0x30a843 * 0x6 + ')',
        'duration': 0x7d0
    });
    const _0x18f35a = document[_0x210c81(0x9b)](_0x210c81(0x9c) + _0x1dec6f);
    _0x18f35a[_0x210c81(0x96)] = zeroPadded(_0x30a843);
});
const buttons = document[a0_0xccdb96(0x91)](a0_0xccdb96(0xa7));

function updateValues(_0x15e9c5) {
    const _0x2a675c = a0_0xccdb96,
        {
            key: _0x7c7dbd,
            operation: _0x1bbcfb
        } = _0x15e9c5,
        {
            timeValue: _0x35e11d,
            rotationValue: _0x17cbf9
        } = _0x15e9c5,
        _0x259768 = _0x1bbcfb === '+' ? _0x17cbf9 + 0x1 : _0x17cbf9 - 0x1;
    let _0xeb0b8f = _0x1bbcfb === '+' ? _0x35e11d + 0x1 : _0x35e11d - 0x1;
    return _0x7c7dbd === _0x2a675c(0xa6) ? _0xeb0b8f = _0xeb0b8f > 0xc ? 0x1 : _0xeb0b8f === 0x0 ? 0xc : _0xeb0b8f : _0xeb0b8f = _0xeb0b8f > 0x3b ? 0x0 : _0xeb0b8f < 0x0 ? 0x3b : _0xeb0b8f, {
        'value': _0xeb0b8f,
        'degrees': _0x259768
    };
}

function handleClick() {
    const _0x336f12 = a0_0xccdb96,
        _0x5bccd2 = this['parentElement'][_0x336f12(0x94)]('data-control'),
        _0x52af35 = this[_0x336f12(0x96)],
        _0x5184ef = time[_0x5bccd2],
        _0x4c83b3 = rotation[_0x5bccd2],
        _0x50f1fa = {
            'key': _0x5bccd2,
            'operation': _0x52af35,
            'timeValue': _0x5184ef,
            'rotationValue': _0x4c83b3
        },
        {
            value: _0x235b80,
            degrees: _0x14877b
        } = updateValues(_0x50f1fa);
    time[_0x5bccd2] = _0x235b80, rotation[_0x5bccd2] = _0x14877b, anime({
        'targets': 'g.' + _0x5bccd2,
        'transform': _0x5bccd2 === _0x336f12(0xa6) ? _0x336f12(0x92) + (-0xf + _0x14877b * 0x1e) + ')' : _0x336f12(0x92) + _0x14877b * 0x6 + ')',
        'duration': 0x190,
        'begin': () => buttons['forEach'](_0x53b0fd => _0x53b0fd[_0x336f12(0x93)]('click', handleClick)),
        'complete': () => buttons[_0x336f12(0x8f)](_0x3667c3 => _0x3667c3[_0x336f12(0x9a)](_0x336f12(0xa1), handleClick))
    });
    const _0x1b014a = document[_0x336f12(0x9b)](_0x336f12(0x9c) + _0x5bccd2);
    _0x1b014a['textContent'] = zeroPadded(_0x235b80);
}
buttons[a0_0xccdb96(0x8f)](_0x592496 => _0x592496['addEventListener'](a0_0xccdb96(0xa1), handleClick));

function a0_0x1848() {
    const _0x46442b = [')\x20translate(34\x200)\x20rotate(', 'svg\x20g.clock--face', '84uvfsSK', '1071132TAmTPj', 'hours', 'button', 'toString', 'innerHTML', '\x0a\x20\x20\x20\x20<text\x0a\x20\x20\x20\x20\x20\x20\x20\x20transform=\x22rotate(', '153797FUCFza', 'forEach', ')\x22\x20>\x0a\x20\x20\x20\x20\x20\x20\x20\x20', 'querySelectorAll', 'rotate(', 'removeEventListener', 'getAttribute', '2483084lhtpPq', 'textContent', 'getHours', 'getMinutes', '828460xVZEby', 'addEventListener', 'querySelector', 'span.control--', '4258915Avdyoy', '769555yylbVn', '10312048tduJHl', '\x0a\x20\x20\x20\x20</text>\x0a\x20\x20', 'click'];
    a0_0x1848 = function() {
        return _0x46442b;
    };
    return a0_0x1848();
}