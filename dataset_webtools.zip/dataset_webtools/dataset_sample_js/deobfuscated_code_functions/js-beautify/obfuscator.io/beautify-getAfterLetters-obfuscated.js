(function(_0x242bf8, _0x553e8c) {
    const _0x140ab7 = a0_0x1702,
        _0x11cab8 = _0x242bf8();
    while (!![]) {
        try {
            const _0x1490b1 = parseInt(_0x140ab7(0x136)) / 0x1 + -parseInt(_0x140ab7(0x13e)) / 0x2 * (parseInt(_0x140ab7(0x13d)) / 0x3) + -parseInt(_0x140ab7(0x145)) / 0x4 * (-parseInt(_0x140ab7(0x13b)) / 0x5) + parseInt(_0x140ab7(0x138)) / 0x6 + parseInt(_0x140ab7(0x141)) / 0x7 + parseInt(_0x140ab7(0x143)) / 0x8 + -parseInt(_0x140ab7(0x146)) / 0x9 * (parseInt(_0x140ab7(0x142)) / 0xa);
            if (_0x1490b1 === _0x553e8c) break;
            else _0x11cab8['push'](_0x11cab8['shift']());
        } catch (_0x4c41a4) {
            _0x11cab8['push'](_0x11cab8['shift']());
        }
    }
}(a0_0x2f70, 0x74ce0));

function a0_0x1702(_0x48ca92, _0x1c4e2f) {
    const _0x2f70a0 = a0_0x2f70();
    return a0_0x1702 = function(_0x1702b0, _0x3fd6bf) {
        _0x1702b0 = _0x1702b0 - 0x136;
        let _0x24511d = _0x2f70a0[_0x1702b0];
        return _0x24511d;
    }, a0_0x1702(_0x48ca92, _0x1c4e2f);
}

function getAfterLetters(_0x1762df) {
    const _0x22f73a = a0_0x1702;
    _0x1762df = _0x1762df[_0x22f73a(0x137)]();
    if (_0x1762df < 'A' || _0x1762df > 'Z') {
        console[_0x22f73a(0x13f)](_0x22f73a(0x13c));
        return;
    }
    let _0x40e371 = '';
    for (let _0x4342f1 = _0x1762df[_0x22f73a(0x140)](0x0); _0x4342f1 <= 'Z' ['charCodeAt'](0x0); _0x4342f1++) {
        _0x40e371 += String['fromCharCode'](_0x4342f1) + '\x20';
    }
    console[_0x22f73a(0x13f)](_0x22f73a(0x13a) + _0x1762df), console[_0x22f73a(0x13f)]('Letters\x20from\x20' + _0x1762df + _0x22f73a(0x144) + _0x40e371[_0x22f73a(0x139)]());
}

function a0_0x2f70() {
    const _0x1ee07e = ['5068511UQefVK', '4570HdEAHP', '2976872THUmXZ', '\x20to\x20Z:\x20', '120SqZlEY', '23526UzgWwa', '147304YSiXYO', 'toUpperCase', '3127122IlxPCV', 'trim', 'Letter\x20given:\x20', '120565fQRFxv', 'Please\x20enter\x20a\x20valid\x20letter\x20of\x20the\x20alphabet.', '3nVAFRN', '1630066LMxdqV', 'log', 'charCodeAt'];
    a0_0x2f70 = function() {
        return _0x1ee07e;
    };
    return a0_0x2f70();
}
getAfterLetters('c'), getAfterLetters('a'), getAfterLetters('l');