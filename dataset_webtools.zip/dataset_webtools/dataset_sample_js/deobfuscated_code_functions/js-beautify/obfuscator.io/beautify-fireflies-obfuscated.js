(function(_0x55857a, _0x3845f5) {
    var _0x49b8d1 = a0_0x49b3,
        _0x14dbd2 = _0x55857a();
    while (!![]) {
        try {
            var _0x5bf494 = parseInt(_0x49b8d1(0x128)) / 0x1 * (parseInt(_0x49b8d1(0x126)) / 0x2) + parseInt(_0x49b8d1(0x117)) / 0x3 * (parseInt(_0x49b8d1(0x122)) / 0x4) + -parseInt(_0x49b8d1(0x116)) / 0x5 + parseInt(_0x49b8d1(0x10f)) / 0x6 * (parseInt(_0x49b8d1(0x121)) / 0x7) + -parseInt(_0x49b8d1(0x11c)) / 0x8 + -parseInt(_0x49b8d1(0x120)) / 0x9 + -parseInt(_0x49b8d1(0x112)) / 0xa;
            if (_0x5bf494 === _0x3845f5) break;
            else _0x14dbd2['push'](_0x14dbd2['shift']());
        } catch (_0x50cf3a) {
            _0x14dbd2['push'](_0x14dbd2['shift']());
        }
    }
}(a0_0x40b4, 0x7abb1));

function a0_0x40b4() {
    var _0x4092a4 = ['583923bGszpt', 'floor', 'box-shadow:\x200px\x200px\x207px\x207px\x20rgba(', 'style=\x27background-color:\x20rgba(', 'height', '174216SVdczt', 'prepend', '.pageTop\x20h1', 'show', '106686GdGlJj', '91rTuZOi', '12RjpGGL', 'left:\x20', 'cos', 'fadeOut', '21312XAAWZh', 'px;', '89kwSrzS', 'remove', '378090FZZZAr', 'delay', 'hide', '10492480PqahRy', 'top:\x20', '.backDrop', 'sin', '3829590huKlUz'];
    a0_0x40b4 = function() {
        return _0x4092a4;
    };
    return a0_0x40b4();
}

function a0_0x49b3(_0x38142f, _0x1fb317) {
    var _0x40b4b0 = a0_0x40b4();
    return a0_0x49b3 = function(_0x49b379, _0x573923) {
        _0x49b379 = _0x49b379 - 0x10f;
        var _0x49777f = _0x40b4b0[_0x49b379];
        return _0x49777f;
    }, a0_0x49b3(_0x38142f, _0x1fb317);
}
var addPixel = function(_0x23324c, _0x27f121) {
        var _0x243d32 = a0_0x49b3;
        $(_0x243d32(0x114))[_0x243d32(0x11d)]('<div\x20class=\x27pixel\x27\x20' + _0x243d32(0x11a) + _0x23324c[0x0] + ',\x20' + _0x23324c[0x1] + ',\x20' + _0x23324c[0x2] + ',\x20' + '0.65);\x20' + _0x243d32(0x113) + _0x27f121[0x1] + 'px;\x20' + _0x243d32(0x123) + _0x27f121[0x0] + _0x243d32(0x127) + _0x243d32(0x119) + (_0x23324c[0x0] - 0x5) + ',\x20' + (_0x23324c[0x1] - 0x5) + ',\x20' + (_0x23324c[0x2] - 0x5) + ',\x20' + '0.55);\x20' + '\x27></div>');
    },
    randNum = function(_0x9c5a83, _0x51abc0) {
        var _0x79d6a2 = a0_0x49b3;
        return Math[_0x79d6a2(0x118)](Math['random']() * (_0x51abc0 - _0x9c5a83) + _0x9c5a83);
    },
    letFly = function() {
        var _0x64f65d = setInterval(function() {
            var _0x26f84b = a0_0x49b3,
                _0x54046c = randNum(0x0, 0x169),
                _0x1859f0 = randNum(0x64, 0x1c2),
                _0x2398d2 = $(window)['width'](),
                _0x2155fc = $(window)[_0x26f84b(0x11b)](),
                _0x212e70 = Math[_0x26f84b(0x124)](_0x54046c * Math['PI'] / 0xb4) * _0x1859f0,
                _0x25115e = Math[_0x26f84b(0x115)](_0x54046c * Math['PI'] / 0xb4) * (_0x1859f0 / 1.5),
                _0x24e697 = [randNum(0x28, 0x50), randNum(0x64, 0x8c), randNum(0x78, 0xa0)],
                _0x51b944 = [randNum(0x0, _0x2398d2), randNum(0x0, _0x2155fc)];
            addPixel(_0x24e697, _0x51b944), $('.pixel:first')[_0x26f84b(0x11f)](0x2ee)['velocity']({
                'left': '+=' + _0x212e70 + 'px',
                'top': '+=' + _0x25115e + 'px'
            }, 0x1770, function() {
                var _0x4a4756 = _0x26f84b;
                $(this)[_0x4a4756(0x111)](0x3e8, function() {
                    var _0x26a977 = _0x4a4756;
                    $(this)[_0x26a977(0x129)]();
                });
            });
        }, 0x64);
    },
    hideTitle = function() {
        var _0x537ce2 = a0_0x49b3;
        $(_0x537ce2(0x11e))[_0x537ce2(0x110)](0xfa0)[_0x537ce2(0x125)](0x3e8);
    };
hideTitle(), letFly();