const a0_0x2c7dcf = a0_0x42c3;

function a0_0x42c3(_0x4bbffd, _0x1632f3) {
    const _0x3aed70 = a0_0x3aed();
    return a0_0x42c3 = function(_0x42c3e4, _0x287743) {
        _0x42c3e4 = _0x42c3e4 - 0xc7;
        let _0xab4cb8 = _0x3aed70[_0x42c3e4];
        return _0xab4cb8;
    }, a0_0x42c3(_0x4bbffd, _0x1632f3);
}

function a0_0x3aed() {
    const _0xd6330d = ['53703780biihnw', '106022EhStRQ', 'length', '7741245xtyWPN', '22292ttxPrv', '1069464DPpeuj', '9MoVQUX', '189hoYKrO', '140iaaGBA', 'push', '654DQinlr', 'This\x20is\x20a\x20short\x20sentence\x0aHere\x27s\x20a\x20longer\x20sentence\x20with\x20more\x20words\x0aAnd\x20this\x20one\x20is\x20quite\x20lengthy\x20with\x20lots\x20of\x20details', 'join', 'repeat', '8LPzrXq', 'split', 'log', 'Original\x20sentences:', '114233WJfgAz', '11519416DsrafC'];
    a0_0x3aed = function() {
        return _0xd6330d;
    };
    return a0_0x3aed();
}(function(_0x5c1b15, _0x6ea165) {
    const _0x8fc4df = a0_0x42c3,
        _0x38acba = _0x5c1b15();
    while (!![]) {
        try {
            const _0x5b69d2 = parseInt(_0x8fc4df(0xc7)) / 0x1 * (-parseInt(_0x8fc4df(0xce)) / 0x2) + parseInt(_0x8fc4df(0xd4)) / 0x3 * (parseInt(_0x8fc4df(0xd1)) / 0x4) + -parseInt(_0x8fc4df(0xd0)) / 0x5 + parseInt(_0x8fc4df(0xd7)) / 0x6 * (-parseInt(_0x8fc4df(0xcb)) / 0x7) + parseInt(_0x8fc4df(0xcc)) / 0x8 * (-parseInt(_0x8fc4df(0xd3)) / 0x9) + parseInt(_0x8fc4df(0xd5)) / 0xa * (parseInt(_0x8fc4df(0xd2)) / 0xb) + parseInt(_0x8fc4df(0xcd)) / 0xc;
            if (_0x5b69d2 === _0x6ea165) break;
            else _0x38acba['push'](_0x38acba['shift']());
        } catch (_0x580888) {
            _0x38acba['push'](_0x38acba['shift']());
        }
    }
}(a0_0x3aed, 0xf34a3));

function addDotDashBelow(_0x41aba5) {
    const _0x5a5e1b = a0_0x42c3;
    let _0x245e03 = _0x41aba5[_0x5a5e1b(0xc8)]('\x0a'),
        _0x741dd8 = [];
    for (let _0x49fed9 = 0x0; _0x49fed9 < _0x245e03['length']; _0x49fed9++) {
        let _0x1c67b7 = _0x245e03[_0x49fed9],
            _0xec0eb9 = '.-' [_0x5a5e1b(0xda)](_0x1c67b7[_0x5a5e1b(0xcf)]);
        _0x741dd8['push'](_0x1c67b7), _0x741dd8[_0x5a5e1b(0xd6)](_0xec0eb9);
    }
    console[_0x5a5e1b(0xc9)](_0x5a5e1b(0xca)), console['log'](_0x245e03[_0x5a5e1b(0xd9)]('\x0a')), console['log']('\x0aSentences\x20with\x20.-\x20sequences:'), console[_0x5a5e1b(0xc9)](_0x741dd8[_0x5a5e1b(0xd9)]('\x0a'));
}
var inputSentences = a0_0x2c7dcf(0xd8);
addDotDashBelow(inputSentences);