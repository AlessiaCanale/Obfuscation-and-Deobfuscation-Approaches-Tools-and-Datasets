const a0_0x28d698 = a0_0x4875;
(function(_0x2280ac, _0x4fc55c) {
    const _0x256aeb = a0_0x4875,
        _0x229e9a = _0x2280ac();
    while (!![]) {
        try {
            const _0x431d19 = -parseInt(_0x256aeb(0x12b)) / 0x1 + parseInt(_0x256aeb(0x125)) / 0x2 + parseInt(_0x256aeb(0x129)) / 0x3 * (parseInt(_0x256aeb(0x12c)) / 0x4) + -parseInt(_0x256aeb(0x128)) / 0x5 + -parseInt(_0x256aeb(0x12e)) / 0x6 + parseInt(_0x256aeb(0x12a)) / 0x7 * (parseInt(_0x256aeb(0x127)) / 0x8) + -parseInt(_0x256aeb(0x126)) / 0x9;
            if (_0x431d19 === _0x4fc55c) break;
            else _0x229e9a['push'](_0x229e9a['shift']());
        } catch (_0x1f0b15) {
            _0x229e9a['push'](_0x229e9a['shift']());
        }
    }
}(a0_0x42c7, 0xe769d));
const number = 0xc;
let n1 = 0x0,
    n2 = 0x1,
    nextTerm, count = 0x2;

function a0_0x4875(_0x354ba3, _0x2ea2b7) {
    const _0x42c76e = a0_0x42c7();
    return a0_0x4875 = function(_0x4875e9, _0x1a9cd7) {
        _0x4875e9 = _0x4875e9 - 0x125;
        let _0x1840e7 = _0x42c76e[_0x4875e9];
        return _0x1840e7;
    }, a0_0x4875(_0x354ba3, _0x2ea2b7);
}
console[a0_0x28d698(0x12d)]('Fibonacci\x20Series:'), console['log'](n1), console['log'](n2), nextTerm = n1 + n2;

function a0_0x42c7() {
    const _0x3387ff = ['3365422euhhNU', '1524996dBiLXP', '32Xuqxgt', '8298940tfBben', '63uHcxyE', '1137549xYpvNp', '895434bkXYaP', '335796ZvLgsV', 'log', '2538798NWjYCn'];
    a0_0x42c7 = function() {
        return _0x3387ff;
    };
    return a0_0x42c7();
}
while (count <= number) {
    console[a0_0x28d698(0x12d)](nextTerm), n1 = n2, n2 = nextTerm, nextTerm = n1 + n2, count++;
}