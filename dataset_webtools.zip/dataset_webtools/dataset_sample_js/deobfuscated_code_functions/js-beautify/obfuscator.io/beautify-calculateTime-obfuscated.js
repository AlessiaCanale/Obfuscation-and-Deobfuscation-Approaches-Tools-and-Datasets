function a0_0x1540(_0x32b7ce, _0x2e9222) {
    const _0x1f4896 = a0_0x1f48();
    return a0_0x1540 = function(_0x154018, _0x58cb29) {
        _0x154018 = _0x154018 - 0x15f;
        let _0x26cab7 = _0x1f4896[_0x154018];
        return _0x26cab7;
    }, a0_0x1540(_0x32b7ce, _0x2e9222);
}

function a0_0x1f48() {
    const _0x386285 = ['5993sZfklq', '2421MHhcwQ', '7976xFIGcV', 'getTime', '13476cPRMEQ', 'log', '165gcyiYV', '77BqQexF', '327HexkVp', '7572LgwYxq', '25\x20seconds\x20have\x20passed', '2111395suRRjr', '10832pTrSIX', '28455ptKBFD', 'Timer\x20started.\x20Wait\x20for\x2025\x20seconds...', '50210DlbHVQ', '12HTfHGH'];
    a0_0x1f48 = function() {
        return _0x386285;
    };
    return a0_0x1f48();
}(function(_0x4b42e3, _0x5af227) {
    const _0x241cc8 = a0_0x1540,
        _0x1b7bac = _0x4b42e3();
    while (!![]) {
        try {
            const _0x28b0db = -parseInt(_0x241cc8(0x169)) / 0x1 * (parseInt(_0x241cc8(0x164)) / 0x2) + parseInt(_0x241cc8(0x16a)) / 0x3 * (parseInt(_0x241cc8(0x166)) / 0x4) + -parseInt(_0x241cc8(0x16d)) / 0x5 + -parseInt(_0x241cc8(0x161)) / 0x6 * (-parseInt(_0x241cc8(0x16f)) / 0x7) + parseInt(_0x241cc8(0x16e)) / 0x8 * (parseInt(_0x241cc8(0x163)) / 0x9) + -parseInt(_0x241cc8(0x160)) / 0xa * (parseInt(_0x241cc8(0x168)) / 0xb) + -parseInt(_0x241cc8(0x16b)) / 0xc * (-parseInt(_0x241cc8(0x162)) / 0xd);
            if (_0x28b0db === _0x5af227) break;
            else _0x1b7bac['push'](_0x1b7bac['shift']());
        } catch (_0x7cdba1) {
            _0x1b7bac['push'](_0x1b7bac['shift']());
        }
    }
}(a0_0x1f48, 0x37206));

function calculateTime() {
    const _0x432712 = a0_0x1540;
    let _0x2f402a = new Date()[_0x432712(0x165)]();
    console[_0x432712(0x167)](_0x432712(0x15f)), setTimeout(() => {
        const _0x40b73b = _0x432712;
        let _0x11c2dc = new Date()['getTime'](),
            _0x1b586b = (_0x11c2dc - _0x2f402a) / 0x3e8;
        console[_0x40b73b(0x167)](_0x40b73b(0x16c));
    }, 0x61a8);
}
calculateTime();