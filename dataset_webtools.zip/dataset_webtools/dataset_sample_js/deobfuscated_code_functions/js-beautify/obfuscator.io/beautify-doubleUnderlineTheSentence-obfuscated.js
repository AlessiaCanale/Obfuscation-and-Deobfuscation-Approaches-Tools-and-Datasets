const a0_0x248e0 = a0_0x3e85;
(function(_0x37e914, _0x214a9f) {
    const _0x102114 = a0_0x3e85,
        _0x32a90c = _0x37e914();
    while (!![]) {
        try {
            const _0x4a0909 = parseInt(_0x102114(0x1a9)) / 0x1 + parseInt(_0x102114(0x1ad)) / 0x2 + parseInt(_0x102114(0x1a8)) / 0x3 + parseInt(_0x102114(0x1b0)) / 0x4 + parseInt(_0x102114(0x1ae)) / 0x5 + parseInt(_0x102114(0x1b4)) / 0x6 + -parseInt(_0x102114(0x1ab)) / 0x7 * (parseInt(_0x102114(0x1af)) / 0x8);
            if (_0x4a0909 === _0x214a9f) break;
            else _0x32a90c['push'](_0x32a90c['shift']());
        } catch (_0x14dbe2) {
            _0x32a90c['push'](_0x32a90c['shift']());
        }
    }
}(a0_0x5a08, 0xf3549));

function a0_0x3e85(_0x4a29df, _0x408b3d) {
    const _0x5a0848 = a0_0x5a08();
    return a0_0x3e85 = function(_0x3e853d, _0x29ad61) {
        _0x3e853d = _0x3e853d - 0x1a8;
        let _0xb14578 = _0x5a0848[_0x3e853d];
        return _0xb14578;
    }, a0_0x3e85(_0x4a29df, _0x408b3d);
}

function doubleUnderlineTheSentence(_0x363535) {
    const _0x8657dd = a0_0x3e85,
        _0xf89788 = _0x363535[_0x8657dd(0x1b3)],
        _0x4eb039 = '=' [_0x8657dd(0x1ac)](_0xf89788);
    console[_0x8657dd(0x1aa)](_0x363535), console[_0x8657dd(0x1aa)](_0x4eb039);
}

function a0_0x5a08() {
    const _0x4401eb = ['repeat', '1348664iLvYdJ', '6651810eXoPAx', '264AhEmkX', '6908176Dhdzzw', 'imagine\x20all\x20the\x20people\x20living\x20life\x20in\x20peace', 'This\x20is\x20a\x20longer\x20sentence\x20to\x20test\x20the\x20function.', 'length', '11335128sxJQbu', '5800773hTqTxf', '1345301eURLai', 'log', '1676423fYQbhw'];
    a0_0x5a08 = function() {
        return _0x4401eb;
    };
    return a0_0x5a08();
}
console['log']('Testing\x20with\x20different\x20sentences:'), doubleUnderlineTheSentence(a0_0x248e0(0x1b1)), doubleUnderlineTheSentence('short'), doubleUnderlineTheSentence(a0_0x248e0(0x1b2));