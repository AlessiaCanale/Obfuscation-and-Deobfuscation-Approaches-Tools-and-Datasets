const a0_0x5ea84f = a0_0x366c;

function a0_0x366c(_0x5d9155, _0x116533) {
    const _0x212b14 = a0_0x212b();
    return a0_0x366c = function(_0x366cb7, _0x3ced78) {
        _0x366cb7 = _0x366cb7 - 0x12f;
        let _0x23b01a = _0x212b14[_0x366cb7];
        return _0x23b01a;
    }, a0_0x366c(_0x5d9155, _0x116533);
}(function(_0x5a7cda, _0x29cf0a) {
    const _0x104a4d = a0_0x366c,
        _0xf954ed = _0x5a7cda();
    while (!![]) {
        try {
            const _0xc66757 = -parseInt(_0x104a4d(0x131)) / 0x1 * (parseInt(_0x104a4d(0x136)) / 0x2) + -parseInt(_0x104a4d(0x135)) / 0x3 + -parseInt(_0x104a4d(0x133)) / 0x4 * (-parseInt(_0x104a4d(0x137)) / 0x5) + parseInt(_0x104a4d(0x12f)) / 0x6 * (parseInt(_0x104a4d(0x13a)) / 0x7) + parseInt(_0x104a4d(0x139)) / 0x8 + parseInt(_0x104a4d(0x134)) / 0x9 * (parseInt(_0x104a4d(0x13b)) / 0xa) + -parseInt(_0x104a4d(0x130)) / 0xb * (parseInt(_0x104a4d(0x138)) / 0xc);
            if (_0xc66757 === _0x29cf0a) break;
            else _0xf954ed['push'](_0xf954ed['shift']());
        } catch (_0xaa9030) {
            _0xf954ed['push'](_0xf954ed['shift']());
        }
    }
}(a0_0x212b, 0x9fe0a));

function a0_0x212b() {
    const _0x5046cc = ['9vJPYGz', '2228592jbdDvF', '44XUffJw', '515zGMoIw', '216VRYUBm', '6226976PQQoct', '57827dinEjF', '9503020FvCMDu', 'matches', '294EEnWYy', '188023VheADJ', '21335wsEWLb', 'matchMedia', '1604WijKnP'];
    a0_0x212b = function() {
        return _0x5046cc;
    };
    return a0_0x212b();
}
const isDarkMode = window[a0_0x5ea84f(0x132)] && window['matchMedia']('(prefers-color-scheme:\x20dark)')[a0_0x5ea84f(0x13c)];
console['log'](isDarkMode);