/**
 * @preserve
 * Project: Bootstrap Hover Dropdown
 * Author: Cameron Spear
 * Version: v2.0.11
 * Contributors: Mattia Larentis
 * Dependencies: Bootstrap's Dropdown plugin, jQuery
 * Description: A simple plugin to enable Bootstrap dropdowns to active on hover and provide a nice user experience.
 * License: MIT
 * Homepage: http://cameronspear.com/blog/bootstrap-dropdown-on-hover-plugin/
 */
var a0_0x43d417 = a0_0x53ac;

function a0_0x5ec8() {
    var _0x1e6e1d = ['data', 'setTimeout', '4014329RHRSIp', '#tt-media\x20li', '#tt-books\x20li', 'open', '2189832iPTLJR', '65peQweH', 'clearTimeout', '9RdqfUg', 'removeClass', 'children', 'length', 'add', 'click', 'hide', 'ontouchstart', 'addClass', '1FRBfSo', 'show.bs.dropdown', '#tt-home\x20li', ':focus', '5246458EoqWCD', 'blur', 'parent', 'find', '#tt-', '.dropdown', 'delay', 'target', '151640BYZdog', 'ready', 'stopPropagation', 'hover', 'trigger', '110sDzjEl', 'hide.bs.dropdown', 'tt-nav__itemcount-', '#tt-blog\x20li', '#tt-contact\x20li', '#tt-goodies\x20li', '[data-hover=\x22dropdown\x22]', 'close-others', 'hasClass', 'dropdownHover', 'siblings', '.dropdown-submenu', '.dropdown-menu', 'is-clicked', '7303782JOIPjt', '3067113MDINPJ', '712542OiLCwy', 'instantlyCloseOthers', 'each', 'extend'];
    a0_0x5ec8 = function() {
        return _0x1e6e1d;
    };
    return a0_0x5ec8();
}(function(_0x257f0e, _0x495d6d) {
    var _0x276c1b = a0_0x53ac,
        _0x2524f4 = _0x257f0e();
    while (!![]) {
        try {
            var _0x4d9149 = -parseInt(_0x276c1b(0xd3)) / 0x1 * (-parseInt(_0x276c1b(0xf4)) / 0x2) + -parseInt(_0x276c1b(0xf3)) / 0x3 + parseInt(_0x276c1b(0xdf)) / 0x4 * (-parseInt(_0x276c1b(0xc8)) / 0x5) + -parseInt(_0x276c1b(0xf2)) / 0x6 + -parseInt(_0x276c1b(0xd7)) / 0x7 + parseInt(_0x276c1b(0xc7)) / 0x8 * (-parseInt(_0x276c1b(0xca)) / 0x9) + -parseInt(_0x276c1b(0xe4)) / 0xa * (-parseInt(_0x276c1b(0xc3)) / 0xb);
            if (_0x4d9149 === _0x495d6d) break;
            else _0x2524f4['push'](_0x2524f4['shift']());
        } catch (_0x1fedcb) {
            _0x2524f4['push'](_0x2524f4['shift']());
        }
    }
}(a0_0x5ec8, 0x961df));

function a0_0x53ac(_0x751178, _0x2c2452) {
    var _0x5ec87a = a0_0x5ec8();
    return a0_0x53ac = function(_0x53acaa, _0x3f6bf7) {
        _0x53acaa = _0x53acaa - 0xc1;
        var _0x81d8a4 = _0x5ec87a[_0x53acaa];
        return _0x81d8a4;
    }, a0_0x53ac(_0x751178, _0x2c2452);
};
(function(_0x8da935, _0x2fff91, _0x283cf0) {
    var _0x563fc5 = a0_0x53ac,
        _0x31b93b = _0x8da935();
    _0x8da935['fn'][_0x563fc5(0xed)] = function(_0x393c1a) {
        var _0x5e9a4e = _0x563fc5;
        if ('ontouchstart' in document) return this;
        return _0x31b93b = _0x31b93b[_0x5e9a4e(0xce)](this['parent']()), this[_0x5e9a4e(0xf6)](function() {
            var _0x44b418 = _0x5e9a4e,
                _0x2f924d = _0x8da935(this),
                _0x169b81 = _0x2f924d[_0x44b418(0xd9)](),
                _0x3ef3ab = {
                    'delay': 0x1f4,
                    'instantlyCloseOthers': !![]
                },
                _0x5a6ca3 = {
                    'delay': _0x8da935(this)['data'](_0x44b418(0xdd)),
                    'instantlyCloseOthers': _0x8da935(this)[_0x44b418(0xc1)](_0x44b418(0xeb))
                },
                _0x9644b4 = _0x44b418(0xd4),
                _0x5d7168 = _0x44b418(0xe5),
                _0x567d8b = _0x8da935[_0x44b418(0xf7)](!![], {}, _0x3ef3ab, _0x393c1a, _0x5a6ca3),
                _0x528023;
            _0x169b81[_0x44b418(0xe2)](function(_0x2fdd04) {
                if (!_0x169b81['hasClass']('open') && !_0x2f924d['is'](_0x2fdd04['target'])) return !![];
                _0x1136f9(_0x2fdd04);
            }, function() {
                var _0x2c2ddb = _0x44b418;
                _0x528023 = _0x2fff91[_0x2c2ddb(0xc2)](function() {
                    var _0x38fdc1 = _0x2c2ddb;
                    _0x169b81[_0x38fdc1(0xcb)]('open'), _0x2f924d[_0x38fdc1(0xe3)](_0x5d7168);
                }, _0x567d8b['delay']);
            }), _0x2f924d[_0x44b418(0xe2)](function(_0x577907) {
                var _0x49c1e3 = _0x44b418;
                if (!_0x169b81[_0x49c1e3(0xec)]('open') && !_0x169b81['is'](_0x577907[_0x49c1e3(0xde)])) return !![];
                _0x1136f9(_0x577907);
            }), _0x169b81[_0x44b418(0xda)](_0x44b418(0xef))[_0x44b418(0xf6)](function() {
                var _0x29bfc8 = _0x8da935(this),
                    _0x5deb1b;
                _0x29bfc8['hover'](function() {
                    var _0x3a91a5 = a0_0x53ac;
                    _0x2fff91['clearTimeout'](_0x5deb1b), _0x29bfc8['children'](_0x3a91a5(0xf0))['show'](), _0x29bfc8['siblings']()[_0x3a91a5(0xcc)](_0x3a91a5(0xf0))[_0x3a91a5(0xd0)]();
                }, function() {
                    var _0x41c96a = a0_0x53ac,
                        _0x3306c6 = _0x29bfc8[_0x41c96a(0xcc)](_0x41c96a(0xf0));
                    _0x5deb1b = _0x2fff91[_0x41c96a(0xc2)](function() {
                        var _0x4b03ec = _0x41c96a;
                        _0x3306c6[_0x4b03ec(0xd0)]();
                    }, _0x567d8b[_0x41c96a(0xdd)]);
                });
            });

            function _0x1136f9(_0x5559f8) {
                var _0x44c0c5 = _0x44b418;
                _0x31b93b[_0x44c0c5(0xda)](_0x44c0c5(0xd6))[_0x44c0c5(0xd8)]();
                if (_0x567d8b[_0x44c0c5(0xf5)] === !![]) _0x31b93b[_0x44c0c5(0xcb)](_0x44c0c5(0xc6));
                _0x2fff91[_0x44c0c5(0xc9)](_0x528023), _0x169b81[_0x44c0c5(0xd2)](_0x44c0c5(0xc6)), _0x2f924d[_0x44c0c5(0xe3)](_0x9644b4);
            }
        });
    }, _0x8da935(document)[_0x563fc5(0xe0)](function() {
        var _0x3cab96 = _0x563fc5;
        _0x8da935(_0x3cab96(0xea))[_0x3cab96(0xed)]();
    });
}(jQuery, this), $(document)[a0_0x43d417(0xe0)](function() {
    var _0x364ab5 = a0_0x43d417,
        _0x21c397 = {
            'home': $(_0x364ab5(0xd5))[_0x364ab5(0xcd)],
            'blog': $(_0x364ab5(0xe7))['length'],
            'books': $(_0x364ab5(0xc5))['length'],
            'goodies': $(_0x364ab5(0xe9))[_0x364ab5(0xcd)],
            'media': $(_0x364ab5(0xc4))[_0x364ab5(0xcd)],
            'news': $('#tt-news\x20li')['length'],
            'contact': $(_0x364ab5(0xe8))[_0x364ab5(0xcd)]
        };
    jQuery['each'](_0x21c397, function(_0x2d162a, _0x179637) {
        var _0x32c752 = _0x364ab5;
        $(_0x32c752(0xdb) + _0x2d162a)['addClass'](_0x32c752(0xe6) + _0x179637);
    }), $(_0x364ab5(0xdc))['on']({
        'hide.bs.dropdown': function(_0x381301) {
            var _0x24b924 = _0x364ab5;
            $(this)['on'](_0x24b924(0xcf), function(_0x5078dd) {
                var _0x47f906 = _0x24b924,
                    _0x440416 = $(this);
                $(this)['toggleClass'](_0x47f906(0xf1))[_0x47f906(0xee)]('.dropdown')[_0x47f906(0xcb)]('is-clicked');
                if (_0x47f906(0xd1) in document && _0x440416[_0x47f906(0xec)](_0x47f906(0xc6), _0x47f906(0xf1))) _0x5078dd['stopPropagation']();
                else return this;
            });
        }
    }), $(_0x364ab5(0xdc))['on']({
        'show.bs.dropdown': function(_0x41125d) {
            var _0x359c41 = _0x364ab5;
            $(this)['on'](_0x359c41(0xcf), function(_0x3b5c52) {
                var _0x5cee3e = _0x359c41;
                if ('ontouchstart' in document) return this;
                else _0x3b5c52[_0x5cee3e(0xe1)]();
            });
        }
    });
}));