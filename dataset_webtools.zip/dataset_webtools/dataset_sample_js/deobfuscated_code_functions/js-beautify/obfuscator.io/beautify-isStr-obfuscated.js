const a0_0x1b6e8e = a0_0x49e3;
(function(_0x37da05, _0x22624d) {
    const _0x3521a6 = a0_0x49e3,
        _0x16e70b = _0x37da05();
    while (!![]) {
        try {
            const _0x4abf10 = -parseInt(_0x3521a6(0x90)) / 0x1 * (-parseInt(_0x3521a6(0x93)) / 0x2) + -parseInt(_0x3521a6(0x96)) / 0x3 + parseInt(_0x3521a6(0x91)) / 0x4 + parseInt(_0x3521a6(0x92)) / 0x5 + parseInt(_0x3521a6(0x9b)) / 0x6 + parseInt(_0x3521a6(0x97)) / 0x7 * (-parseInt(_0x3521a6(0x9a)) / 0x8) + -parseInt(_0x3521a6(0x98)) / 0x9 * (-parseInt(_0x3521a6(0x9c)) / 0xa);
            if (_0x4abf10 === _0x22624d) break;
            else _0x16e70b['push'](_0x16e70b['shift']());
        } catch (_0x10a934) {
            _0x16e70b['push'](_0x16e70b['shift']());
        }
    }
}(a0_0x1186, 0xc3fb5));
const isStr = _0x158cb7 => typeof _0x158cb7 === a0_0x1b6e8e(0x95);
console[a0_0x1b6e8e(0x99)](a0_0x1b6e8e(0x94) + isStr('JavaScript')), console['log']('345\x20is\x20string:\x20' + isStr(0x159)), console[a0_0x1b6e8e(0x99)]('true\x20is\x20string:\x20' + isStr(!![]));

function a0_0x49e3(_0x14f7e7, _0x4e6471) {
    const _0x118618 = a0_0x1186();
    return a0_0x49e3 = function(_0x49e359, _0x3ac585) {
        _0x49e359 = _0x49e359 - 0x90;
        let _0x2a5b4d = _0x118618[_0x49e359];
        return _0x2a5b4d;
    }, a0_0x49e3(_0x14f7e7, _0x4e6471);
}

function a0_0x1186() {
    const _0x1c0b4d = ['136XCnnMl', '944328pTiGHt', '10skcxrU', '1rUmVuh', '46704pVvItG', '5198690ubqTzV', '649172BLUTtc', 'JavaScript\x20is\x20string:\x20', 'string', '2173941rRosAu', '146279pgWqEL', '3143241eBhXBN', 'log'];
    a0_0x1186 = function() {
        return _0x1c0b4d;
    };
    return a0_0x1186();
}