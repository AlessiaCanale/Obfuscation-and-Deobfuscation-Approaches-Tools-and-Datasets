(function(_0x3d60a9, _0x431c51) {
    const _0x1f2b18 = a0_0x1b53,
        _0x344b6c = _0x3d60a9();
    while (!![]) {
        try {
            const _0x27d134 = parseInt(_0x1f2b18(0x93)) / 0x1 * (-parseInt(_0x1f2b18(0x91)) / 0x2) + -parseInt(_0x1f2b18(0x89)) / 0x3 + -parseInt(_0x1f2b18(0x8c)) / 0x4 * (-parseInt(_0x1f2b18(0x96)) / 0x5) + parseInt(_0x1f2b18(0x8d)) / 0x6 * (-parseInt(_0x1f2b18(0x94)) / 0x7) + parseInt(_0x1f2b18(0x97)) / 0x8 * (-parseInt(_0x1f2b18(0x92)) / 0x9) + parseInt(_0x1f2b18(0x90)) / 0xa + parseInt(_0x1f2b18(0x98)) / 0xb * (parseInt(_0x1f2b18(0x8e)) / 0xc);
            if (_0x27d134 === _0x431c51) break;
            else _0x344b6c['push'](_0x344b6c['shift']());
        } catch (_0x397afc) {
            _0x344b6c['push'](_0x344b6c['shift']());
        }
    }
}(a0_0x4c4b, 0xb16ec));

function a0_0x1b53(_0x46f625, _0x1d200f) {
    const _0x4c4bbe = a0_0x4c4b();
    return a0_0x1b53 = function(_0x1b5364, _0x28e490) {
        _0x1b5364 = _0x1b5364 - 0x86;
        let _0x4dcf95 = _0x4c4bbe[_0x1b5364];
        return _0x4dcf95;
    }, a0_0x1b53(_0x46f625, _0x1d200f);
}

function a0_0x4c4b() {
    const _0x1b33ff = ['2wFVGGP', '4550283hHmNYr', '184682vhnfGx', '9602873JHIWwW', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', '1245SsBRnv', '16uLAUjI', '3353295YjksXZ', 'length', 'indexOf', 'Converted\x20Text:', '641742zgPrZT', 'charAt', 'toString', '11364MNoomV', '6XjwXbk', '60OlNzOV', 'Original\x20Text:', '12767390aHRjtg'];
    a0_0x4c4b = function() {
        return _0x1b33ff;
    };
    return a0_0x4c4b();
}

function convertUppercaseToNumber(_0x2ec552) {
    const _0xdb47bc = a0_0x1b53,
        _0x4f591b = _0xdb47bc(0x95);
    let _0xdb6c91 = '';
    for (let _0x11064d = 0x0; _0x11064d < _0x2ec552[_0xdb47bc(0x86)]; _0x11064d++) {
        const _0x20fe60 = _0x2ec552[_0xdb47bc(0x8a)](_0x11064d),
            _0x272b90 = _0x4f591b[_0xdb47bc(0x87)](_0x20fe60);
        _0x272b90 !== -0x1 ? _0xdb6c91 += (_0x272b90 + 0x1)[_0xdb47bc(0x8b)]() : _0xdb6c91 += _0x20fe60;
    }
    console['log'](_0xdb47bc(0x8f), _0x2ec552), console['log'](_0xdb47bc(0x88), _0xdb6c91);
}
const text = 'Lorem\x20Ipsum\x20is\x20simply\x20dummy\x20text\x20of\x20the\x20Printing\x20and\x20typesetting\x20industry.\x20Lorem\x20Ipsum\x20Has\x20Been\x20the\x20industry\x27s\x20standard\x20dummy\x20text\x20ever\x20since\x20the\x201500s.';
convertUppercaseToNumber(text);