const a0_0x3f20eb = a0_0x3e3b;
(function(_0x5b7628, _0x5e8bc5) {
    const _0x4c92fb = a0_0x3e3b,
        _0x3d0b37 = _0x5b7628();
    while (!![]) {
        try {
            const _0x183200 = -parseInt(_0x4c92fb(0x1ad)) / 0x1 * (parseInt(_0x4c92fb(0x19d)) / 0x2) + -parseInt(_0x4c92fb(0x1a5)) / 0x3 * (parseInt(_0x4c92fb(0x1a6)) / 0x4) + -parseInt(_0x4c92fb(0x1ab)) / 0x5 * (-parseInt(_0x4c92fb(0x19f)) / 0x6) + -parseInt(_0x4c92fb(0x1ac)) / 0x7 * (parseInt(_0x4c92fb(0x1a9)) / 0x8) + -parseInt(_0x4c92fb(0x19e)) / 0x9 + -parseInt(_0x4c92fb(0x1a1)) / 0xa * (-parseInt(_0x4c92fb(0x1a7)) / 0xb) + parseInt(_0x4c92fb(0x1a4)) / 0xc;
            if (_0x183200 === _0x5e8bc5) break;
            else _0x3d0b37['push'](_0x3d0b37['shift']());
        } catch (_0x4f7651) {
            _0x3d0b37['push'](_0x3d0b37['shift']());
        }
    }
}(a0_0x54c4, 0x976a7));

function a0_0x54c4() {
    const _0x416e2b = ['3397554ZMwCyH', '1641330BjKcnB', 'split', '70voawuO', 'Geeks\x20for\x20Geeks\x20Portal', 'join', '21136152tWMgqV', '87hKrasF', '147116EQptwg', '1726505DAjmwO', 'log', '280CfZStj', 'original\x20text:\x20', '15VuPYxo', '207291qtTOdy', '205TJWEAV', '5658TuttyT'];
    a0_0x54c4 = function() {
        return _0x416e2b;
    };
    return a0_0x54c4();
}
let originalText = a0_0x3f20eb(0x1a2);
console[a0_0x3f20eb(0x1a8)](a0_0x3f20eb(0x1aa) + originalText);

function a0_0x3e3b(_0x129416, _0x37cf4e) {
    const _0x54c4bf = a0_0x54c4();
    return a0_0x3e3b = function(_0x3e3b7e, _0x214876) {
        _0x3e3b7e = _0x3e3b7e - 0x19d;
        let _0x5b47a3 = _0x54c4bf[_0x3e3b7e];
        return _0x5b47a3;
    }, a0_0x3e3b(_0x129416, _0x37cf4e);
}
let removedSpacesText = originalText[a0_0x3f20eb(0x1a0)]('\x20')[a0_0x3f20eb(0x1a3)]('');
console['log']('text\x20without\x20spaces:\x20' + removedSpacesText);