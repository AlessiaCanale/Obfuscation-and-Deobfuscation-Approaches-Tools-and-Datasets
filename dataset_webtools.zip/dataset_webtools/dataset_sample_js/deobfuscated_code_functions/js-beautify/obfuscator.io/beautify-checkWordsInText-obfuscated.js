const a0_0x288e4f = a0_0x4b92;
(function(_0x38caef, _0x42d85d) {
    const _0x41fb35 = a0_0x4b92,
        _0x45acae = _0x38caef();
    while (!![]) {
        try {
            const _0x8287d0 = -parseInt(_0x41fb35(0x131)) / 0x1 * (parseInt(_0x41fb35(0x132)) / 0x2) + parseInt(_0x41fb35(0x12a)) / 0x3 * (parseInt(_0x41fb35(0x129)) / 0x4) + parseInt(_0x41fb35(0x12f)) / 0x5 + -parseInt(_0x41fb35(0x126)) / 0x6 * (-parseInt(_0x41fb35(0x12b)) / 0x7) + parseInt(_0x41fb35(0x130)) / 0x8 + parseInt(_0x41fb35(0x127)) / 0x9 + parseInt(_0x41fb35(0x139)) / 0xa * (-parseInt(_0x41fb35(0x12d)) / 0xb);
            if (_0x8287d0 === _0x42d85d) break;
            else _0x45acae['push'](_0x45acae['shift']());
        } catch (_0x9235e8) {
            _0x45acae['push'](_0x45acae['shift']());
        }
    }
}(a0_0x2ddb, 0x480ef));

function a0_0x4b92(_0x2d9f47, _0x23cb80) {
    const _0x2ddb30 = a0_0x2ddb();
    return a0_0x4b92 = function(_0x4b9265, _0x37533d) {
        _0x4b9265 = _0x4b9265 - 0x125;
        let _0x3bd8cc = _0x2ddb30[_0x4b9265];
        return _0x3bd8cc;
    }, a0_0x4b92(_0x2d9f47, _0x23cb80);
}

function a0_0x2ddb() {
    const _0x1b1601 = ['text', 'sample', '48430GyAslh', 'forEach', 'words', '52428VgbLff', '3905073uMUYuu', 'example', '23908PqopIz', '3pMIWpI', '266EbgdPz', '\x20is\x20present\x20in\x20the\x20text.', '1727PKeibC', 'log', '1262510Zdbheg', '550232xZMZQC', '1639enkvnH', '46mWhrzz', 'includes', '\x20is\x20not\x20present\x20in\x20the\x20text.', 'This\x20is\x20a\x20sample\x20text\x20with\x20100\x20words\x20in\x20it.', 'join'];
    a0_0x2ddb = function() {
        return _0x1b1601;
    };
    return a0_0x2ddb();
}

function checkWordsInText(_0x16ac86, _0x5e9583) {
    const _0x17fb8e = a0_0x4b92;
    console[_0x17fb8e(0x12e)]('Text:\x20' + _0x16ac86), console['log']('Array:\x20' + _0x5e9583[_0x17fb8e(0x136)](',\x20')), _0x5e9583[_0x17fb8e(0x13a)](_0x24d1bf => {
        const _0xd8736e = _0x17fb8e;
        _0x16ac86[_0xd8736e(0x133)](_0x24d1bf) ? console['log'](_0x24d1bf + _0xd8736e(0x12c)) : console['log'](_0x24d1bf + _0xd8736e(0x134));
    });
}
const text = a0_0x288e4f(0x135),
    wordsArray = [a0_0x288e4f(0x138), a0_0x288e4f(0x137), a0_0x288e4f(0x128), a0_0x288e4f(0x125), 'in'];
checkWordsInText(text, wordsArray);