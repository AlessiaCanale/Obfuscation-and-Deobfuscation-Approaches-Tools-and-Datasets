var a0_0xca637c = a0_0x2eb8;

function a0_0x2eb8(_0x173ac0, _0x39340a) {
    var _0x513935 = a0_0x5139();
    return a0_0x2eb8 = function(_0x2eb88c, _0x20ef11) {
        _0x2eb88c = _0x2eb88c - 0x1ee;
        var _0x10ae49 = _0x513935[_0x2eb88c];
        return _0x10ae49;
    }, a0_0x2eb8(_0x173ac0, _0x39340a);
}

function a0_0x5139() {
    var _0x593155 = ['querySelectorAll', '22696OiQhAn', 'translateY(0)', '.container', 'box', '20ayNIYj', 'opacity', '777890SvDqxu', '12471168fjSWhT', '297308eCxAgf', 'transform', '143VySdDO', '8kAzFbB', '5706UABHdM', '3JvqASE', '1336492NtycPN', '2874684dcNncU', 'style', '8727838WETQhq', 'div', 'length', '.box'];
    a0_0x5139 = function() {
        return _0x593155;
    };
    return a0_0x5139();
}(function(_0x35ddaf, _0x1c0494) {
    var _0xe7bf94 = a0_0x2eb8,
        _0x34c278 = _0x35ddaf();
    while (!![]) {
        try {
            var _0x1c4889 = parseInt(_0xe7bf94(0x1f1)) / 0x1 * (-parseInt(_0xe7bf94(0x1ee)) / 0x2) + -parseInt(_0xe7bf94(0x1f3)) / 0x3 * (parseInt(_0xe7bf94(0x1f4)) / 0x4) + -parseInt(_0xe7bf94(0x200)) / 0x5 * (-parseInt(_0xe7bf94(0x1f5)) / 0x6) + -parseInt(_0xe7bf94(0x1f7)) / 0x7 + -parseInt(_0xe7bf94(0x1fc)) / 0x8 * (-parseInt(_0xe7bf94(0x1f2)) / 0x9) + -parseInt(_0xe7bf94(0x202)) / 0xa * (parseInt(_0xe7bf94(0x1f0)) / 0xb) + parseInt(_0xe7bf94(0x203)) / 0xc;
            if (_0x1c4889 === _0x1c0494) break;
            else _0x34c278['push'](_0x34c278['shift']());
        } catch (_0x10b70b) {
            _0x34c278['push'](_0x34c278['shift']());
        }
    }
}(a0_0x5139, 0xed884));
var numBoxes = 0x6,
    container = document['querySelector'](a0_0xca637c(0x1fe));
for (var i = 0x0; i < numBoxes; i++) {
    var box = document['createElement'](a0_0xca637c(0x1f8));
    box['classList']['add'](a0_0xca637c(0x1ff)), container['appendChild'](box);
}
var boxes = document[a0_0xca637c(0x1fb)](a0_0xca637c(0x1fa)),
    count = 0x0,
    timer = setInterval(function() {
        var _0xab6740 = a0_0xca637c;
        count < boxes[_0xab6740(0x1f9)] ? (boxes[count][_0xab6740(0x1f6)][_0xab6740(0x1ef)] = _0xab6740(0x1fd), boxes[count][_0xab6740(0x1f6)][_0xab6740(0x201)] = 0x1) : clearInterval(timer), count++;
    }, 0x64);