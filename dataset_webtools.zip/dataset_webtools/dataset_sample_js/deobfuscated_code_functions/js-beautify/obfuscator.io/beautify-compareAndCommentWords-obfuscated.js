const a0_0x5426a2 = a0_0x3f37;
(function(_0x4bcf28, _0x1b6575) {
    const _0x2962bc = a0_0x3f37,
        _0xdb297e = _0x4bcf28();
    while (!![]) {
        try {
            const _0x200a38 = -parseInt(_0x2962bc(0x13f)) / 0x1 + -parseInt(_0x2962bc(0x14c)) / 0x2 * (-parseInt(_0x2962bc(0x147)) / 0x3) + parseInt(_0x2962bc(0x139)) / 0x4 * (-parseInt(_0x2962bc(0x146)) / 0x5) + parseInt(_0x2962bc(0x143)) / 0x6 + parseInt(_0x2962bc(0x140)) / 0x7 + parseInt(_0x2962bc(0x13e)) / 0x8 * (-parseInt(_0x2962bc(0x148)) / 0x9) + parseInt(_0x2962bc(0x145)) / 0xa * (parseInt(_0x2962bc(0x13c)) / 0xb);
            if (_0x200a38 === _0x1b6575) break;
            else _0xdb297e['push'](_0xdb297e['shift']());
        } catch (_0x5bfafd) {
            _0xdb297e['push'](_0xdb297e['shift']());
        }
    }
}(a0_0x4f12, 0x39a8b));

function a0_0x4f12() {
    const _0x2c28a1 = ['2907681JknSSB', '\x20,\x20words2:\x20', 'word1:\x20', '1970706CKDDrq', 'abs', '60VTwsgX', '25PetXIP', '15QWhldF', '81bZgtRb', 'push', 'The\x20words\x20have\x20no\x20different\x20letters.', 'length', '38580mPjGKd', 'hello', 'log', '265000KHtfzS', 'The\x20words\x20have\x20the\x20same\x20length.', 'The\x20words\x20have\x20different\x20lengths.\x20The\x20difference\x20in\x20length\x20is\x20', '78507MIAYar', 'world', '105240VinjIz', '197290kzHSvG'];
    a0_0x4f12 = function() {
        return _0x2c28a1;
    };
    return a0_0x4f12();
}

function a0_0x3f37(_0xa2005e, _0x1c6d26) {
    const _0x4f125f = a0_0x4f12();
    return a0_0x3f37 = function(_0x3f3736, _0x4f0477) {
        _0x3f3736 = _0x3f3736 - 0x138;
        let _0x4d4b9b = _0x4f125f[_0x3f3736];
        return _0x4d4b9b;
    }, a0_0x3f37(_0xa2005e, _0x1c6d26);
}

function compareAndCommentWords(_0x3a125b, _0x308eb9) {
    const _0x48e0bb = a0_0x3f37;
    console[_0x48e0bb(0x138)](_0x48e0bb(0x142) + _0x3a125b + _0x48e0bb(0x141) + _0x308eb9);
    if (_0x3a125b[_0x48e0bb(0x14b)] === _0x308eb9['length']) console[_0x48e0bb(0x138)](_0x48e0bb(0x13a));
    else {
        let _0x557f30 = Math[_0x48e0bb(0x144)](_0x3a125b['length'] - _0x308eb9[_0x48e0bb(0x14b)]);
        console['log'](_0x48e0bb(0x13b) + _0x557f30 + '.');
    }
    let _0x3d7686 = [],
        _0x140372 = [];
    for (let _0x2468ab of _0x3a125b) {
        _0x308eb9['includes'](_0x2468ab) ? _0x3d7686[_0x48e0bb(0x149)](_0x2468ab) : _0x140372['push'](_0x2468ab);
    }
    console[_0x48e0bb(0x138)]('Common\x20letters:', _0x3d7686), _0x140372['length'] > 0x0 ? console[_0x48e0bb(0x138)]('Different\x20letters:', _0x140372) : console[_0x48e0bb(0x138)](_0x48e0bb(0x14a));
}
compareAndCommentWords(a0_0x5426a2(0x14d), 'Hi'), compareAndCommentWords(a0_0x5426a2(0x13d), a0_0x5426a2(0x13d));