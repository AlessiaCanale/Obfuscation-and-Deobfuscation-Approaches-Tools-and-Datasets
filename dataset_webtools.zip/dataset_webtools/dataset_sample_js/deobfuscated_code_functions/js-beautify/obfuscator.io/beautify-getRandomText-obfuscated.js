(function(_0x32f661, _0x1b34b2) {
    const _0x245c64 = a0_0x453e,
        _0xe434fe = _0x32f661();
    while (!![]) {
        try {
            const _0x292a1a = parseInt(_0x245c64(0xde)) / 0x1 * (-parseInt(_0x245c64(0xef)) / 0x2) + parseInt(_0x245c64(0xdd)) / 0x3 + -parseInt(_0x245c64(0xe2)) / 0x4 * (parseInt(_0x245c64(0xdf)) / 0x5) + parseInt(_0x245c64(0xed)) / 0x6 + -parseInt(_0x245c64(0xe4)) / 0x7 * (parseInt(_0x245c64(0xec)) / 0x8) + parseInt(_0x245c64(0xe7)) / 0x9 * (-parseInt(_0x245c64(0xeb)) / 0xa) + -parseInt(_0x245c64(0xea)) / 0xb * (-parseInt(_0x245c64(0xe0)) / 0xc);
            if (_0x292a1a === _0x1b34b2) break;
            else _0xe434fe['push'](_0xe434fe['shift']());
        } catch (_0x4a36be) {
            _0xe434fe['push'](_0xe434fe['shift']());
        }
    }
}(a0_0x2703, 0x6aff9));

function getRandomText() {
    const _0x11a46a = a0_0x453e,
        _0x2c6750 = _0x11a46a(0xe1),
        _0x3be6db = _0x2c6750[_0x11a46a(0xe8)]('.\x20'),
        _0x3c8ef4 = [];
    for (let _0x1a29a8 = 0x0; _0x1a29a8 < 0x5; _0x1a29a8++) {
        const _0x11ff5d = Math[_0x11a46a(0xe9)](Math[_0x11a46a(0xe6)]() * _0x3be6db[_0x11a46a(0xe5)]);
        _0x3c8ef4[_0x11a46a(0xf0)](_0x3be6db[_0x11ff5d]);
    }
    const _0x3ac982 = _0x3c8ef4[_0x11a46a(0xee)](_0x11a46a(0xe3));
    return console[_0x11a46a(0xf1)](_0x3ac982), _0x3ac982;
}

function a0_0x453e(_0x211381, _0x51b799) {
    const _0x270327 = a0_0x2703();
    return a0_0x453e = function(_0x453ed9, _0x2d04aa) {
        _0x453ed9 = _0x453ed9 - 0xdd;
        let _0x474dab = _0x270327[_0x453ed9];
        return _0x474dab;
    }, a0_0x453e(_0x211381, _0x51b799);
}
getRandomText();

function a0_0x2703() {
    const _0x38212e = ['push', 'log', '2492667uKSKRN', '17GbcCOs', '15Vjiujf', '33780HgGJLX', 'Lorem\x20ipsum\x20dolor\x20sit\x20amet,\x20consectetur\x20adipiscing\x20elit.\x20Nulla\x20facilisi.\x20Proin\x20vitae\x20augue\x20eget\x20elit\x20sodales\x20condimentum.\x20Sed\x20ut\x20convallis\x20lacus.\x20Mauris\x20euismod\x20metus\x20ac\x20mi\x20rhoncus,\x20sed\x20pellentesque\x20nunc\x20egestas.\x20Vestibulum\x20auctor\x20magna\x20a\x20neque\x20hendrerit,\x20sit\x20amet\x20viverra\x20libero\x20vestibulum.\x20Phasellus\x20sagittis\x20nisi\x20nec\x20ultricies\x20pellentesque.\x20Nulla\x20facilisi.\x20Interdum\x20et\x20malesuada\x20fames\x20ac\x20ante\x20ipsum\x20primis\x20in\x20faucibus.\x20Cras\x20in\x20ipsum\x20purus.\x20Maecenas\x20nec\x20risus\x20vel\x20eros\x20ultrices\x20fermentum.', '1100244sFgZVj', '.\x0a\x0a', '7JzbcAo', 'length', 'random', '27TNzgTG', 'split', 'floor', '3949cFvnuF', '188920WrbWxh', '4598992DmHQwL', '3198666eFJuvL', 'join', '56422MiiQoC'];
    a0_0x2703 = function() {
        return _0x38212e;
    };
    return a0_0x2703();
}