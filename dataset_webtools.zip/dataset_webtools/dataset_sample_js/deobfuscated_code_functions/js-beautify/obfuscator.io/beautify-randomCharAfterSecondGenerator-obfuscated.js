(function(_0x5dbef0, _0x56f842) {
    const _0xcd442d = a0_0x373f,
        _0x4a2b8d = _0x5dbef0();
    while (!![]) {
        try {
            const _0x530c5e = parseInt(_0xcd442d(0x1ef)) / 0x1 * (-parseInt(_0xcd442d(0x1f5)) / 0x2) + parseInt(_0xcd442d(0x1f1)) / 0x3 * (-parseInt(_0xcd442d(0x1ee)) / 0x4) + parseInt(_0xcd442d(0x1f7)) / 0x5 + -parseInt(_0xcd442d(0x1f2)) / 0x6 + parseInt(_0xcd442d(0x1f3)) / 0x7 + parseInt(_0xcd442d(0x1f4)) / 0x8 * (-parseInt(_0xcd442d(0x1ea)) / 0x9) + parseInt(_0xcd442d(0x1f6)) / 0xa;
            if (_0x530c5e === _0x56f842) break;
            else _0x4a2b8d['push'](_0x4a2b8d['shift']());
        } catch (_0x42c234) {
            _0x4a2b8d['push'](_0x4a2b8d['shift']());
        }
    }
}(a0_0x4599, 0x4c7ab));

function randomCharAfterSecondGenerator() {
    let _0x4cb0fd = '',
        _0x1d68f9 = 0x0;
    const _0x5a8a55 = setInterval(() => {
        const _0x343d83 = a0_0x373f,
            _0x1cc57f = String[_0x343d83(0x1ec)](Math['floor'](Math['random']() * 0x1a) + 0x61);
        _0x4cb0fd += _0x1cc57f, _0x1d68f9++, console[_0x343d83(0x1f0)]('Character\x20generated\x20at\x20' + _0x1d68f9 + _0x343d83(0x1ed) + _0x1cc57f), _0x1d68f9 === 0xa && (clearInterval(_0x5a8a55), console['log'](_0x343d83(0x1eb)), console[_0x343d83(0x1f0)]('Resulting\x20string:\x20' + _0x4cb0fd));
    }, 0x3e8);
}

function a0_0x4599() {
    const _0x5e4811 = ['3208278FhITva', '4192587lutirN', '8WUtXGA', '2tbniJM', '7089440rMcdOJ', '2377220PpwjKS', '2985705oExQhC', '10\x20seconds\x20have\x20passed.', 'fromCharCode', '\x20second:\x20', '4636ebruJn', '62359ytzhed', 'log', '1401aGYBuY'];
    a0_0x4599 = function() {
        return _0x5e4811;
    };
    return a0_0x4599();
}

function a0_0x373f(_0x120672, _0x429300) {
    const _0x45997b = a0_0x4599();
    return a0_0x373f = function(_0x373f6f, _0x326f4f) {
        _0x373f6f = _0x373f6f - 0x1ea;
        let _0x255185 = _0x45997b[_0x373f6f];
        return _0x255185;
    }, a0_0x373f(_0x120672, _0x429300);
}
randomCharAfterSecondGenerator();