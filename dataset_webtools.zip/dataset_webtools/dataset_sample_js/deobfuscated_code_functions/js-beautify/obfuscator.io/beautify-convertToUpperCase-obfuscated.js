const a0_0x1bda63 = a0_0x35fc;
(function(_0x3f8e1f, _0x59b1ab) {
    const _0x149de7 = a0_0x35fc,
        _0x3ee32e = _0x3f8e1f();
    while (!![]) {
        try {
            const _0x493864 = parseInt(_0x149de7(0x17b)) / 0x1 + -parseInt(_0x149de7(0x182)) / 0x2 * (parseInt(_0x149de7(0x17e)) / 0x3) + parseInt(_0x149de7(0x181)) / 0x4 * (parseInt(_0x149de7(0x176)) / 0x5) + -parseInt(_0x149de7(0x17c)) / 0x6 + parseInt(_0x149de7(0x178)) / 0x7 * (-parseInt(_0x149de7(0x173)) / 0x8) + parseInt(_0x149de7(0x174)) / 0x9 * (-parseInt(_0x149de7(0x180)) / 0xa) + parseInt(_0x149de7(0x177)) / 0xb;
            if (_0x493864 === _0x59b1ab) break;
            else _0x3ee32e['push'](_0x3ee32e['shift']());
        } catch (_0x290487) {
            _0x3ee32e['push'](_0x3ee32e['shift']());
        }
    }
}(a0_0x56f9, 0xf2250));

function a0_0x56f9() {
    const _0x3142ad = ['1749248HjrqEG', '9460836zggOLX', 'Uppercase\x20text:\x20', '51ekVIkY', 'The\x20world\x20is\x20a\x20place\x20full\x20of\x20colors,\x20sounds,\x20and\x20emotions.\x20Every\x20day\x20we\x20face\x20challenges,\x20but\x20also\x20moments\x20of\x20joy\x20and\x20hope.\x20It\x20is\x20important\x20to\x20appreciate\x20the\x20little\x20things\x20in\x20life,\x20like\x20the\x20warmth\x20of\x20a\x20sincere\x20hug\x20or\x20the\x20fragrance\x20of\x20a\x20blooming\x20flower.\x20Love\x20and\x20friendship\x20are\x20the\x20pillars\x20on\x20which\x20we\x20build\x20our\x20existence,\x20and\x20it\x20is\x20they\x20that\x20allow\x20us\x20to\x20overcome\x20every\x20obstacle.\x20Let\x27s\x20never\x20stop\x20believing\x20in\x20the\x20power\x20of\x20goodness\x20and\x20the\x20strength\x20of\x20unity,\x20because\x20it\x20is\x20only\x20together\x20that\x20we\x20can\x20truly\x20be\x20happy.', '55040GtDOSo', '16DGwaHB', '4138POPiGU', '18824wTkfMA', '423NfpPSp', 'Original\x20text:\x20', '2326760hqhLFk', '13589554wAqyhs', '5901bCqgww', 'log', 'toUpperCase'];
    a0_0x56f9 = function() {
        return _0x3142ad;
    };
    return a0_0x56f9();
}

function convertToUpperCase(_0x291a4e) {
    const _0x16a199 = a0_0x35fc,
        _0x139261 = _0x291a4e[_0x16a199(0x17a)]();
    console[_0x16a199(0x179)](_0x16a199(0x175) + _0x291a4e), console['log'](_0x16a199(0x17d) + _0x139261);
}

function a0_0x35fc(_0xd09341, _0x5c7c1b) {
    const _0x56f9b8 = a0_0x56f9();
    return a0_0x35fc = function(_0x35fc46, _0x441b96) {
        _0x35fc46 = _0x35fc46 - 0x173;
        let _0x8f825e = _0x56f9b8[_0x35fc46];
        return _0x8f825e;
    }, a0_0x35fc(_0xd09341, _0x5c7c1b);
}
convertToUpperCase(a0_0x1bda63(0x17f));