(function(_0xa1ca67, _0x254bcf) {
    const _0x322cdc = a0_0xeba2,
        _0xbeb6e8 = _0xa1ca67();
    while (!![]) {
        try {
            const _0x4b5ed2 = parseInt(_0x322cdc(0xa3)) / 0x1 * (parseInt(_0x322cdc(0xa6)) / 0x2) + -parseInt(_0x322cdc(0xb1)) / 0x3 + parseInt(_0x322cdc(0xa8)) / 0x4 * (-parseInt(_0x322cdc(0xa4)) / 0x5) + -parseInt(_0x322cdc(0xac)) / 0x6 * (parseInt(_0x322cdc(0xb0)) / 0x7) + parseInt(_0x322cdc(0xae)) / 0x8 * (-parseInt(_0x322cdc(0xaa)) / 0x9) + parseInt(_0x322cdc(0xad)) / 0xa + parseInt(_0x322cdc(0xaf)) / 0xb;
            if (_0x4b5ed2 === _0x254bcf) break;
            else _0xbeb6e8['push'](_0xbeb6e8['shift']());
        } catch (_0x1aeb09) {
            _0xbeb6e8['push'](_0xbeb6e8['shift']());
        }
    }
}(a0_0x14ad, 0x5d983));

function a0_0x14ad() {
    const _0x5da121 = ['7APoKXV', '2273097ZcVbjC', '2083cTChtt', '15gLsBwt', 'floor', '122GxFfHT', 'Birds\x20fly\x20in\x20every\x20direction!', '781672KGpaFh', 'log', '9CvzgeE', 'length', '900174wibWdd', '3427800BXjaMM', '5343064EVhgsC', '22829235HJKWlI'];
    a0_0x14ad = function() {
        return _0x5da121;
    };
    return a0_0x14ad();
}

function a0_0xeba2(_0x4f7652, _0x258217) {
    const _0x14ad08 = a0_0x14ad();
    return a0_0xeba2 = function(_0xeba2db, _0x11e942) {
        _0xeba2db = _0xeba2db - 0xa3;
        let _0x18173b = _0x14ad08[_0xeba2db];
        return _0x18173b;
    }, a0_0xeba2(_0x4f7652, _0x258217);
}

function BirdsFly() {
    const _0x2d2ef0 = a0_0xeba2,
        _0x38b413 = ['\x20', '\x20', '^', 'v'],
        _0x3e616f = ['M', '£', 'X', 'Y', '@', '#'];
    let _0x1f5698 = '';
    for (let _0x53ad50 = 0x1; _0x53ad50 <= 0x5; _0x53ad50++) {
        let _0xaff6ef = '';
        if (_0x53ad50 === 0x5)
            for (let _0x22b4c1 = 0x1; _0x22b4c1 <= 0xa; _0x22b4c1++) {
                let _0x72d4a9 = Math[_0x2d2ef0(0xa5)](Math['random']() * _0x3e616f['length']);
                _0xaff6ef += _0x3e616f[_0x72d4a9];
            } else
                for (let _0x43fe66 = 0x1; _0x43fe66 <= 0xa; _0x43fe66++) {
                    let _0x13702d = Math['floor'](Math['random']() * _0x38b413[_0x2d2ef0(0xab)]);
                    _0xaff6ef += _0x38b413[_0x13702d];
                }
        _0x1f5698 += _0xaff6ef + '\x0a';
    }
    _0x1f5698 += _0x2d2ef0(0xa7), console[_0x2d2ef0(0xa9)](_0x1f5698);
}
BirdsFly();