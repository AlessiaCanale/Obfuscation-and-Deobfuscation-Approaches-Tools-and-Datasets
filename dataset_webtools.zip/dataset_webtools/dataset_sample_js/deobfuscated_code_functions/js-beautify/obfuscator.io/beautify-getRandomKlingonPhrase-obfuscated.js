(function(_0x1b2965, _0x1a8a59) {
    const _0x2ed0bb = a0_0x53d3,
        _0x5959cb = _0x1b2965();
    while (!![]) {
        try {
            const _0x13728a = -parseInt(_0x2ed0bb(0x1f9)) / 0x1 * (-parseInt(_0x2ed0bb(0x1f6)) / 0x2) + parseInt(_0x2ed0bb(0x1f2)) / 0x3 * (parseInt(_0x2ed0bb(0x1fd)) / 0x4) + -parseInt(_0x2ed0bb(0x1f4)) / 0x5 + parseInt(_0x2ed0bb(0x1f5)) / 0x6 + -parseInt(_0x2ed0bb(0x1ed)) / 0x7 * (-parseInt(_0x2ed0bb(0x1ee)) / 0x8) + -parseInt(_0x2ed0bb(0x1fa)) / 0x9 * (parseInt(_0x2ed0bb(0x1f8)) / 0xa) + parseInt(_0x2ed0bb(0x1f0)) / 0xb * (-parseInt(_0x2ed0bb(0x1fc)) / 0xc);
            if (_0x13728a === _0x1a8a59) break;
            else _0x5959cb['push'](_0x5959cb['shift']());
        } catch (_0x325ed2) {
            _0x5959cb['push'](_0x5959cb['shift']());
        }
    }
}(a0_0x137a, 0xe777e));

function getRandomKlingonPhrase() {
    const _0x2cb71f = a0_0x53d3,
        _0x109dd5 = {
            'nuqneH': _0x2cb71f(0x1fb),
            'Qapla\x27!': 'Success!',
            'Heghlu\x27meH\x20QaQ\x20jajvam': _0x2cb71f(0x1f1),
            'Qo\x27noS\x20be\x27nal': _0x2cb71f(0x1ec),
            'yIghojmoH': 'Let\x27s\x20attack',
            'majQa\x27': _0x2cb71f(0x1ef),
            'tlhIngan\x20maH!': _0x2cb71f(0x1ea)
        },
        _0x50ffe7 = Math[_0x2cb71f(0x1f7)](Math['random']() * Object[_0x2cb71f(0x1eb)](_0x109dd5)['length']),
        _0x1ecb70 = Object[_0x2cb71f(0x1eb)](_0x109dd5)[_0x50ffe7],
        _0xe56e02 = _0x109dd5[_0x1ecb70];
    console[_0x2cb71f(0x1e9)](_0x2cb71f(0x1e8) + _0x1ecb70), console['log'](_0x2cb71f(0x1f3) + _0xe56e02);
}

function a0_0x137a() {
    const _0x2522b8 = ['4mfsgWE', 'Random\x20Klingon\x20Phrase:\x20', 'log', 'We\x20are\x20Klingons!', 'keys', 'Greetings\x20from\x20Kronos', '959EpDYhd', '107056JdQmfB', 'Well\x20done', '9097uJChoS', 'Today\x20is\x20a\x20good\x20day\x20to\x20die', '2222538GTldez', 'Translation:\x20', '2308800FEfyAN', '5514618yvomwl', '2nuajhu', 'floor', '107770YtYvCQ', '564677DNMiJn', '18qCrVLF', 'What\x20do\x20you\x20want?', '38112eRHmkB'];
    a0_0x137a = function() {
        return _0x2522b8;
    };
    return a0_0x137a();
}

function a0_0x53d3(_0x16855e, _0xa7e91c) {
    const _0x137abb = a0_0x137a();
    return a0_0x53d3 = function(_0x53d33b, _0x327688) {
        _0x53d33b = _0x53d33b - 0x1e8;
        let _0xa5f0e1 = _0x137abb[_0x53d33b];
        return _0xa5f0e1;
    }, a0_0x53d3(_0x16855e, _0xa7e91c);
}
getRandomKlingonPhrase();