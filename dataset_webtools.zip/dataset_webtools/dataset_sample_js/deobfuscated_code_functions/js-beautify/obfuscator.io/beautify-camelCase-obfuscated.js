const a0_0x19afd9 = a0_0x35d4;

function a0_0x35d4(_0x3d97ea, _0x21b49e) {
    const _0x3b6b6b = a0_0x3b6b();
    return a0_0x35d4 = function(_0x35d45e, _0x35aa4d) {
        _0x35d45e = _0x35d45e - 0xd2;
        let _0x4e97f0 = _0x3b6b6b[_0x35d45e];
        return _0x4e97f0;
    }, a0_0x35d4(_0x3d97ea, _0x21b49e);
}(function(_0x520302, _0x3b7791) {
    const _0x302bc9 = a0_0x35d4,
        _0x474039 = _0x520302();
    while (!![]) {
        try {
            const _0x5aaf55 = -parseInt(_0x302bc9(0xdc)) / 0x1 * (-parseInt(_0x302bc9(0xdb)) / 0x2) + parseInt(_0x302bc9(0xda)) / 0x3 * (-parseInt(_0x302bc9(0xd7)) / 0x4) + -parseInt(_0x302bc9(0xe1)) / 0x5 + parseInt(_0x302bc9(0xdd)) / 0x6 + parseInt(_0x302bc9(0xd2)) / 0x7 * (parseInt(_0x302bc9(0xe0)) / 0x8) + -parseInt(_0x302bc9(0xd6)) / 0x9 + -parseInt(_0x302bc9(0xd3)) / 0xa * (-parseInt(_0x302bc9(0xde)) / 0xb);
            if (_0x5aaf55 === _0x3b7791) break;
            else _0x474039['push'](_0x474039['shift']());
        } catch (_0x5cd9e0) {
            _0x474039['push'](_0x474039['shift']());
        }
    }
}(a0_0x3b6b, 0x61c65));
let str = a0_0x19afd9(0xd8);

function a0_0x3b6b() {
    const _0x5ec0cb = ['7143pUWPOn', '505680BXjcvF', '17697229eiXfec', '\x0aresult:\x20', '96nayESj', '3699545DCCjqS', '287441aeOZDM', '10jcnpPa', 'replace', 'original:\x20', '4799736GDREfp', '8JXjrNu', 'Click\x20the\x20button\x20to\x20convert\x20to\x20camelCase', 'log', '971841CQiOjD', '38qUsIea'];
    a0_0x3b6b = function() {
        return _0x5ec0cb;
    };
    return a0_0x3b6b();
}

function camelCase(_0x4cd97b) {
    const _0xc5fe02 = a0_0x19afd9;
    return _0x4cd97b['replace'](/(?:^\w|[A-Z]|\b\w)/g, function(_0x347bd7, _0x55c319) {
        return _0x55c319 == 0x0 ? _0x347bd7['toLowerCase']() : _0x347bd7['toUpperCase']();
    })[_0xc5fe02(0xd4)](/\s+/g, '');
}

function gfg_Run() {
    const _0xbc15c0 = a0_0x19afd9;
    console[_0xbc15c0(0xd9)](_0xbc15c0(0xd5) + str + _0xbc15c0(0xdf) + camelCase(str));
}
gfg_Run();