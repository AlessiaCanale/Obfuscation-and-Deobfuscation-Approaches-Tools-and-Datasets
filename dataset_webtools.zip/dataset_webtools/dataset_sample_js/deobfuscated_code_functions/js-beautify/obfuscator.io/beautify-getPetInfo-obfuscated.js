const a0_0x32ce4a = a0_0x21ef;
(function(_0x1c16b9, _0x3a6202) {
    const _0xf4b6fa = a0_0x21ef,
        _0x4c5d06 = _0x1c16b9();
    while (!![]) {
        try {
            const _0x4b003b = -parseInt(_0xf4b6fa(0x159)) / 0x1 * (parseInt(_0xf4b6fa(0x165)) / 0x2) + parseInt(_0xf4b6fa(0x154)) / 0x3 + -parseInt(_0xf4b6fa(0x151)) / 0x4 + parseInt(_0xf4b6fa(0x155)) / 0x5 * (parseInt(_0xf4b6fa(0x166)) / 0x6) + -parseInt(_0xf4b6fa(0x162)) / 0x7 * (-parseInt(_0xf4b6fa(0x15f)) / 0x8) + -parseInt(_0xf4b6fa(0x153)) / 0x9 + -parseInt(_0xf4b6fa(0x15a)) / 0xa;
            if (_0x4b003b === _0x3a6202) break;
            else _0x4c5d06['push'](_0x4c5d06['shift']());
        } catch (_0x2e890f) {
            _0x4c5d06['push'](_0x4c5d06['shift']());
        }
    }
}(a0_0x54a7, 0xf3b4f));

function a0_0x21ef(_0x3bfe17, _0x50cac6) {
    const _0x54a701 = a0_0x54a7();
    return a0_0x21ef = function(_0x21ef7c, _0x3b7114) {
        _0x21ef7c = _0x21ef7c - 0x151;
        let _0x215b5a = _0x54a701[_0x21ef7c];
        return _0x215b5a;
    }, a0_0x21ef(_0x3bfe17, _0x50cac6);
}

function getPetInfo(_0x2f797d) {
    const _0x37cea7 = a0_0x21ef,
        _0x594a32 = {
            'Siamese': _0x37cea7(0x167),
            'Maine\x20Coon': _0x37cea7(0x169),
            'Persian': _0x37cea7(0x16a),
            'Sphynx': _0x37cea7(0x15b),
            'Bengal': 'Bengal\x20cats\x20have\x20a\x20striking\x20leopard-like\x20coat\x20and\x20are\x20highly\x20energetic\x20and\x20playful.'
        },
        _0x488eba = {
            'Labrador\x20Retriever': _0x37cea7(0x15e),
            'German\x20Shepherd': 'German\x20Shepherds\x20are\x20intelligent\x20and\x20loyal\x20dogs\x20often\x20used\x20in\x20police\x20work\x20and\x20as\x20service\x20animals.',
            'Golden\x20Retriever': _0x37cea7(0x16b),
            'French\x20Bulldog': _0x37cea7(0x160),
            'Poodle': 'Poodles\x20are\x20known\x20for\x20their\x20intelligence\x20and\x20hypoallergenic\x20coat,\x20making\x20them\x20popular\x20pets\x20for\x20those\x20with\x20allergies.'
        };
    let _0x6fd047, _0x144a94;
    if (_0x2f797d === _0x37cea7(0x156)) _0x6fd047 = Object['keys'](_0x594a32)[Math[_0x37cea7(0x164)](Math[_0x37cea7(0x15d)]() * Object[_0x37cea7(0x152)](_0x594a32)[_0x37cea7(0x161)])], _0x144a94 = _0x594a32[_0x6fd047];
    else {
        if (_0x2f797d === _0x37cea7(0x163)) _0x6fd047 = Object[_0x37cea7(0x152)](_0x488eba)[Math[_0x37cea7(0x164)](Math[_0x37cea7(0x15d)]() * Object[_0x37cea7(0x152)](_0x488eba)[_0x37cea7(0x161)])], _0x144a94 = _0x488eba[_0x6fd047];
        else return _0x37cea7(0x158);
    }
    console[_0x37cea7(0x157)](_0x37cea7(0x15c) + _0x2f797d), console['log']('Random\x20breed\x20selected:\x20' + _0x6fd047), console[_0x37cea7(0x157)](_0x37cea7(0x168) + _0x144a94);
}

function a0_0x54a7() {
    const _0x3d1103 = ['keys', '6710337XzCimq', '3664176kGmojZ', '15psXACP', 'miao', 'log', 'Invalid\x20sound.\x20Please\x20use\x20\x27miao\x27\x20for\x20cats\x20or\x20\x27bau\x27\x20for\x20dogs.', '3539xqaSbG', '7633590zefuKa', 'Sphynx\x20cats\x20are\x20hairless\x20and\x20wrinkled,\x20making\x20them\x20very\x20unique\x20and\x20distinct.', 'The\x20sound\x20passed\x20as\x20parameter:\x20', 'random', 'Labradors\x20are\x20known\x20for\x20their\x20friendly\x20and\x20outgoing\x20personality,\x20making\x20them\x20great\x20family\x20pets.', '1371424HepwHf', 'French\x20Bulldogs\x20are\x20small,\x20muscular\x20dogs\x20with\x20a\x20smooth\x20coat\x20and\x20a\x20playful\x20yet\x20easygoing\x20temperament.', 'length', '56YBvCbR', 'bau', 'floor', '164JfwRJn', '3595146qiAZIg', 'Siamese\x20cats\x20are\x20known\x20for\x20their\x20striking\x20blue\x20almond-shaped\x20eyes\x20and\x20short,\x20low-maintenance\x20coat.', 'Breed\x20information:\x20', 'Maine\x20Coons\x20are\x20one\x20of\x20the\x20largest\x20domesticated\x20cat\x20breeds,\x20known\x20for\x20their\x20friendly\x20and\x20sociable\x20nature.', 'Persian\x20cats\x20have\x20long,\x20luxurious\x20fur\x20and\x20a\x20sweet,\x20laid-back\x20personality.', 'Golden\x20Retrievers\x20are\x20friendly,\x20intelligent,\x20and\x20devoted\x20companions.', '6372064yqqGfN'];
    a0_0x54a7 = function() {
        return _0x3d1103;
    };
    return a0_0x54a7();
}
getPetInfo(a0_0x32ce4a(0x156)), getPetInfo(a0_0x32ce4a(0x163));