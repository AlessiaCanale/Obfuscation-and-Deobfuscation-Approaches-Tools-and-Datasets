(function(_0x447ede, _0x30b6c6) {
    var _0x107a66 = a0_0x4c98,
        _0x2bbacd = _0x447ede();
    while (!![]) {
        try {
            var _0xaa3d69 = -parseInt(_0x107a66(0x1cd)) / 0x1 * (parseInt(_0x107a66(0x1d2)) / 0x2) + -parseInt(_0x107a66(0x1d3)) / 0x3 + parseInt(_0x107a66(0x1d6)) / 0x4 * (-parseInt(_0x107a66(0x1d0)) / 0x5) + parseInt(_0x107a66(0x1d1)) / 0x6 + parseInt(_0x107a66(0x1d4)) / 0x7 + -parseInt(_0x107a66(0x1d8)) / 0x8 * (-parseInt(_0x107a66(0x1cc)) / 0x9) + -parseInt(_0x107a66(0x1d7)) / 0xa * (-parseInt(_0x107a66(0x1cf)) / 0xb);
            if (_0xaa3d69 === _0x30b6c6) break;
            else _0x2bbacd['push'](_0x2bbacd['shift']());
        } catch (_0x833bc) {
            _0x2bbacd['push'](_0x2bbacd['shift']());
        }
    }
}(a0_0x8bf4, 0x1d90f));

function a0_0x8bf4() {
    var _0x12e115 = ['1zFAxJT', 'Original\x20sentence:\x20', '55QcTcTi', '545LHzCiO', '162042IFDkpg', '87272azXddH', '588012imPAHE', '248164UrhSPN', 'log', '1868DmHMBd', '582130JhleFW', '232488kFTFUw', 'Modified\x20sentence:\x20', 'replace', '18SfwWXn'];
    a0_0x8bf4 = function() {
        return _0x12e115;
    };
    return a0_0x8bf4();
}

function a0_0x4c98(_0x17b41b, _0x513552) {
    var _0x8bf45e = a0_0x8bf4();
    return a0_0x4c98 = function(_0x4c9852, _0x395e81) {
        _0x4c9852 = _0x4c9852 - 0x1ca;
        var _0x285313 = _0x8bf45e[_0x4c9852];
        return _0x285313;
    }, a0_0x4c98(_0x17b41b, _0x513552);
}

function changeTwoDotsWithSemicolon(_0x12cc53) {
    var _0x16b4a7 = a0_0x4c98,
        _0x31723f = _0x12cc53[_0x16b4a7(0x1cb)](/:/g, ';');
    console[_0x16b4a7(0x1d5)](_0x16b4a7(0x1ce) + _0x12cc53), console[_0x16b4a7(0x1d5)](_0x16b4a7(0x1ca) + _0x31723f);
}
var inputSentence = 'This:is:a:sentence:with:many:colons:';
changeTwoDotsWithSemicolon(inputSentence);