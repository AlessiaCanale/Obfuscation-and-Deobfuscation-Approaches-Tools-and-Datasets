const a0_0x9bc321 = a0_0x1943;
(function(_0x3b01e1, _0xe37cf1) {
    const _0x3c46d0 = a0_0x1943,
        _0x2b8689 = _0x3b01e1();
    while (!![]) {
        try {
            const _0x35eda6 = parseInt(_0x3c46d0(0x1e6)) / 0x1 * (parseInt(_0x3c46d0(0x1e9)) / 0x2) + -parseInt(_0x3c46d0(0x1db)) / 0x3 * (parseInt(_0x3c46d0(0x1e4)) / 0x4) + parseInt(_0x3c46d0(0x1de)) / 0x5 + parseInt(_0x3c46d0(0x1d4)) / 0x6 + -parseInt(_0x3c46d0(0x1d6)) / 0x7 + parseInt(_0x3c46d0(0x1d3)) / 0x8 * (parseInt(_0x3c46d0(0x1e8)) / 0x9) + -parseInt(_0x3c46d0(0x1e7)) / 0xa * (parseInt(_0x3c46d0(0x1eb)) / 0xb);
            if (_0x35eda6 === _0xe37cf1) break;
            else _0x2b8689['push'](_0x2b8689['shift']());
        } catch (_0x27f31f) {
            _0x2b8689['push'](_0x2b8689['shift']());
        }
    }
}(a0_0x590c, 0xe7b8c));

function a0_0x1943(_0x3f00bf, _0x787c0c) {
    const _0x590c3c = a0_0x590c();
    return a0_0x1943 = function(_0x19437c, _0x338570) {
        _0x19437c = _0x19437c - 0x1d0;
        let _0x551d6c = _0x590c3c[_0x19437c];
        return _0x551d6c;
    }, a0_0x1943(_0x3f00bf, _0x787c0c);
}
const canvas = document[a0_0x9bc321(0x1ea)](a0_0x9bc321(0x1d0)),
    ctx = canvas[a0_0x9bc321(0x1da)]('2d');
let raf;
const ball = {
    'x': 0x64,
    'y': 0x64,
    'vx': 0x5,
    'vy': 0x2,
    'radius': 0x19,
    'color': a0_0x9bc321(0x1d2),
    'draw'() {
        const _0x36b90b = a0_0x9bc321;
        ctx[_0x36b90b(0x1df)](), ctx['arc'](this['x'], this['y'], this[_0x36b90b(0x1d7)], 0x0, Math['PI'] * 0x2, !![]), ctx[_0x36b90b(0x1d5)](), ctx['fillStyle'] = this[_0x36b90b(0x1e3)], ctx[_0x36b90b(0x1e2)]();
    }
};

function draw() {
    const _0x9052a5 = a0_0x9bc321;
    ctx['clearRect'](0x0, 0x0, canvas['width'], canvas['height']), ball[_0x9052a5(0x1d1)](), ball['x'] += ball['vx'], ball['y'] += ball['vy'], ball['vy'] *= 0.99, ball['vy'] += 0.25, (ball['y'] + ball['vy'] > canvas[_0x9052a5(0x1e5)] - ball[_0x9052a5(0x1d7)] || ball['y'] + ball['vy'] < ball['radius']) && (ball['vy'] = -ball['vy']), (ball['x'] + ball['vx'] > canvas[_0x9052a5(0x1e0)] - ball[_0x9052a5(0x1d7)] || ball['x'] + ball['vx'] < ball[_0x9052a5(0x1d7)]) && (ball['vx'] = -ball['vx']), raf = window['requestAnimationFrame'](draw);
}

function a0_0x590c() {
    const _0x52b178 = ['addEventListener', 'getContext', '2234523zkTKXJ', 'cancelAnimationFrame', 'mouseover', '8645165SZJxgp', 'beginPath', 'width', 'requestAnimationFrame', 'fill', 'color', '4Xbsksw', 'height', '1046YJflIR', '16891670stKMAi', '144QJVmex', '2574RKtwAQ', 'getElementById', '11sRluhh', 'canvas', 'draw', 'blue', '376368arUNdB', '4367856yozYGI', 'closePath', '8209649EeBxOU', 'radius', 'mouseout'];
    a0_0x590c = function() {
        return _0x52b178;
    };
    return a0_0x590c();
}
canvas[a0_0x9bc321(0x1d9)](a0_0x9bc321(0x1dd), _0x325492 => {
    const _0x1f86d1 = a0_0x9bc321;
    raf = window[_0x1f86d1(0x1e1)](draw);
}), canvas[a0_0x9bc321(0x1d9)](a0_0x9bc321(0x1d8), _0x27c3a3 => {
    const _0x512c8a = a0_0x9bc321;
    window[_0x512c8a(0x1dc)](raf);
}), ball['draw']();