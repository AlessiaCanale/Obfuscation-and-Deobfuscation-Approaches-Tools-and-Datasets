function a0_0x3ef6(_0x4ecfdb, _0x16aa13) {
    var _0x4d9c5d = a0_0x4d9c();
    return a0_0x3ef6 = function(_0x3ef636, _0x1361c7) {
        _0x3ef636 = _0x3ef636 - 0xdf;
        var _0x1e7ca1 = _0x4d9c5d[_0x3ef636];
        return _0x1e7ca1;
    }, a0_0x3ef6(_0x4ecfdb, _0x16aa13);
}
var a0_0x3498ff = a0_0x3ef6;
(function(_0x2b38d5, _0x56683b) {
    var _0x2c279b = a0_0x3ef6,
        _0x57e98b = _0x2b38d5();
    while (!![]) {
        try {
            var _0x3c8a9a = parseInt(_0x2c279b(0xe8)) / 0x1 + -parseInt(_0x2c279b(0xe1)) / 0x2 * (parseInt(_0x2c279b(0xe4)) / 0x3) + parseInt(_0x2c279b(0xe2)) / 0x4 + parseInt(_0x2c279b(0xe0)) / 0x5 + parseInt(_0x2c279b(0xe9)) / 0x6 + parseInt(_0x2c279b(0xe3)) / 0x7 + parseInt(_0x2c279b(0xe6)) / 0x8 * (-parseInt(_0x2c279b(0xe7)) / 0x9);
            if (_0x3c8a9a === _0x56683b) break;
            else _0x57e98b['push'](_0x57e98b['shift']());
        } catch (_0xb4558a) {
            _0x57e98b['push'](_0x57e98b['shift']());
        }
    }
}(a0_0x4d9c, 0x85bad));

function a0_0x4d9c() {
    var _0x49773 = ['913980HUwyeB', '3392178dqCOmf', '.kick', 'querySelector', 'easeInCubic', '.ball', '.wrapper', '4870945gZkBPB', '655934imkGNK', '1054912BeHKTH', '2928723kLqmMh', '3WVPXro', 'offsetWidth', '40mvxVxo', '4067865orRxLx'];
    a0_0x4d9c = function() {
        return _0x49773;
    };
    return a0_0x4d9c();
}

function calculateXPos(_0x48ed2c, _0x46d491) {
    return _0x46d491 - _0x48ed2c;
}
var container = document[a0_0x3498ff(0xeb)](a0_0x3498ff(0xdf)),
    ballImg = document[a0_0x3498ff(0xeb)](a0_0x3498ff(0xed)),
    containerWidth = container[a0_0x3498ff(0xe5)],
    ballWidth = ballImg[a0_0x3498ff(0xe5)];
imagesLoaded(document, function() {
    var _0x2e6713 = a0_0x3498ff,
        _0x2c1e04 = anime({
            'targets': _0x2e6713(0xea),
            'scale': 1.2,
            'duration': 0x12c,
            'easing': _0x2e6713(0xec),
            'complete': function() {
                anime({
                    'targets': '.ball',
                    'translateX': calculateXPos(ballWidth, containerWidth),
                    'scale': 1.5,
                    'easing': 'easeOutBounce',
                    'delay': 0x96
                });
            }
        });
});