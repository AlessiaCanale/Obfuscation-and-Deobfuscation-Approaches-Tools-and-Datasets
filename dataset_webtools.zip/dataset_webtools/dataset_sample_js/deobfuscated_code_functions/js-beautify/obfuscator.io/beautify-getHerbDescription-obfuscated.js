function a0_0xdb86() {
    const _0x2381e5 = ['565463ZpmtKZ', '19005312bEqvkB', 'Sage\x20has\x20been\x20linked\x20to\x20improved\x20brain\x20function\x20and\x20memory.', 'length', '13022688iGRDAk', 'Rosemary\x20may\x20improve\x20memory\x20and\x20mood.', 'Thyme\x20has\x20antibacterial\x20and\x20antifungal\x20properties.', '583690nUsyBL', '8734410rSVRKi', '1896105wcSSkR', 'log', 'floor', 'Coriander\x20may\x20help\x20lower\x20blood\x20sugar\x20levels\x20and\x20reduce\x20inflammation.', '2303760oLXodN', 'Oregano\x20is\x20high\x20in\x20antioxidants\x20and\x20may\x20help\x20fight\x20infections.', 'Dill\x20can\x20help\x20with\x20digestion\x20and\x20may\x20have\x20antimicrobial\x20properties.', '64IKDYGf', 'Basil\x20has\x20anti-inflammatory\x20and\x20antioxidant\x20properties.'];
    a0_0xdb86 = function() {
        return _0x2381e5;
    };
    return a0_0xdb86();
}

function a0_0x1961(_0x5ea4c3, _0x305100) {
    const _0xdb8630 = a0_0xdb86();
    return a0_0x1961 = function(_0x196157, _0x12e31f) {
        _0x196157 = _0x196157 - 0x1e6;
        let _0x2e5a81 = _0xdb8630[_0x196157];
        return _0x2e5a81;
    }, a0_0x1961(_0x5ea4c3, _0x305100);
}(function(_0x36b5f1, _0x4bb99b) {
    const _0x5748c3 = a0_0x1961,
        _0x498e7c = _0x36b5f1();
    while (!![]) {
        try {
            const _0x127863 = parseInt(_0x5748c3(0x1f3)) / 0x1 + -parseInt(_0x5748c3(0x1ee)) / 0x2 + parseInt(_0x5748c3(0x1ea)) / 0x3 + parseInt(_0x5748c3(0x1f1)) / 0x4 * (parseInt(_0x5748c3(0x1e8)) / 0x5) + -parseInt(_0x5748c3(0x1e9)) / 0x6 + -parseInt(_0x5748c3(0x1f7)) / 0x7 + parseInt(_0x5748c3(0x1f4)) / 0x8;
            if (_0x127863 === _0x4bb99b) break;
            else _0x498e7c['push'](_0x498e7c['shift']());
        } catch (_0x2bc654) {
            _0x498e7c['push'](_0x498e7c['shift']());
        }
    }
}(a0_0xdb86, 0xed8ab));

function getHerbDescription() {
    const _0x3b6e9c = a0_0x1961,
        _0x279db0 = {
            'Basil': _0x3b6e9c(0x1f2),
            'Rosemary': _0x3b6e9c(0x1e6),
            'Mint': 'Mint\x20can\x20aid\x20in\x20digestion\x20and\x20freshen\x20breath.',
            'Thyme': _0x3b6e9c(0x1e7),
            'Oregano': _0x3b6e9c(0x1ef),
            'Parsley': 'Parsley\x20is\x20rich\x20in\x20vitamins\x20and\x20minerals.',
            'Sage': _0x3b6e9c(0x1f5),
            'Coriander': _0x3b6e9c(0x1ed),
            'Chives': 'Chives\x20are\x20high\x20in\x20vitamins\x20A\x20and\x20C.',
            'Dill': _0x3b6e9c(0x1f0)
        },
        _0x436e1f = Object['keys'](_0x279db0),
        _0x4cfc1b = Math[_0x3b6e9c(0x1ec)](Math['random']() * _0x436e1f[_0x3b6e9c(0x1f6)]),
        _0x153e13 = _0x436e1f[_0x4cfc1b],
        _0x1c3fd0 = _0x279db0[_0x153e13];
    console[_0x3b6e9c(0x1eb)](_0x153e13 + ':\x20' + _0x1c3fd0);
}
getHerbDescription();