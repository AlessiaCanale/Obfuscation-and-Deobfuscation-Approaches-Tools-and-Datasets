const a0_0x1f2d0c = a0_0x596d;
(function(_0x5476bb, _0x55ec65) {
    const _0x19a0da = a0_0x596d,
        _0x5893b = _0x5476bb();
    while (!![]) {
        try {
            const _0x48c562 = parseInt(_0x19a0da(0xaf)) / 0x1 * (-parseInt(_0x19a0da(0xb9)) / 0x2) + parseInt(_0x19a0da(0xb0)) / 0x3 * (-parseInt(_0x19a0da(0xbb)) / 0x4) + -parseInt(_0x19a0da(0xae)) / 0x5 + -parseInt(_0x19a0da(0xb1)) / 0x6 * (parseInt(_0x19a0da(0xc1)) / 0x7) + parseInt(_0x19a0da(0xb3)) / 0x8 * (parseInt(_0x19a0da(0xbd)) / 0x9) + parseInt(_0x19a0da(0xb6)) / 0xa + parseInt(_0x19a0da(0xb4)) / 0xb;
            if (_0x48c562 === _0x55ec65) break;
            else _0x5893b['push'](_0x5893b['shift']());
        } catch (_0x19df63) {
            _0x5893b['push'](_0x5893b['shift']());
        }
    }
}(a0_0x3c41, 0x6253b));
let container = document[a0_0x1f2d0c(0xab)](a0_0x1f2d0c(0xb8)),
    ballLength = 0xa0;

function a0_0x596d(_0x66b972, _0x10b058) {
    const _0x3c41dd = a0_0x3c41();
    return a0_0x596d = function(_0x596df4, _0x418434) {
        _0x596df4 = _0x596df4 - 0xa9;
        let _0x48ff3e = _0x3c41dd[_0x596df4];
        return _0x48ff3e;
    }, a0_0x596d(_0x66b972, _0x10b058);
}

function a0_0x3c41() {
    const _0x1ea977 = ['3705640uHUWhr', '.ball', '#container', '2HWTeuq', 'createElement', '20WNjTXs', 'classList', '1880172fhcOmu', 'log', 'blue', 'sin', '142702xhNOul', 'cos', 'linear', 'ball-', 'querySelector', 'easings', 'add', '2626005ljAEAA', '150845QdZltg', '123069HqVazg', '12iJeNuo', 'normal', '8vuTNaD', '8197288waZZHK', 'ball'];
    a0_0x3c41 = function() {
        return _0x1ea977;
    };
    return a0_0x3c41();
}
for (let i = 0x0; i < ballLength; i++) {
    let div = document[a0_0x1f2d0c(0xba)]('div'),
        color = 'red';
    div[a0_0x1f2d0c(0xbc)][a0_0x1f2d0c(0xad)](a0_0x1f2d0c(0xb5));
    if (i % 0x2) color = a0_0x1f2d0c(0xbf);
    div[a0_0x1f2d0c(0xbc)]['add'](a0_0x1f2d0c(0xaa) + color), container['appendChild'](div);
}
let ballAnimation = anime({
        'targets': a0_0x1f2d0c(0xb7),
        'translateX': {
            'value': (_0x1f3ae7, _0x50ae1f) => {
                const _0x288e7f = a0_0x1f2d0c;
                let _0x5c9928 = Math[_0x288e7f(0xc2)](0xa * Math['PI'] / (ballLength - 0x1) * _0x50ae1f);
                return _0x5c9928 * (0xdc * _0x50ae1f / (ballLength - 0x1));
            },
            'duration': 0x1
        },
        'translateY': {
            'value': (_0x1cd387, _0x53f96f) => {
                const _0x4e3493 = a0_0x1f2d0c;
                let _0x540c45 = Math[_0x4e3493(0xc0)](0xa * Math['PI'] / (ballLength - 0x1) * _0x53f96f);
                return _0x540c45 * (0xdc * _0x53f96f / (ballLength - 0x1));
            },
            'duration': 0x1
        },
        'scale': {
            'value': [0x0, 0x1],
            'delay': (_0x1b3801, _0x29cb53) => {
                return 0x258 * _0x29cb53 / (ballLength - 0x1);
            },
            'duration': 0xbb8
        },
        'opacity': {
            'value': (_0x26e5d1, _0x120efe) => {
                return 0x1;
            }
        },
        'direction': a0_0x1f2d0c(0xb2),
        'elasticity': 0x2bc,
        'loop': !![]
    }),
    containerAnimation = anime({
        'targets': a0_0x1f2d0c(0xb8),
        'rotate': 0x168,
        'duration': 0x2710,
        'direction': a0_0x1f2d0c(0xb2),
        'easing': a0_0x1f2d0c(0xa9),
        'elasticity': 0x0,
        'loop': !![]
    });
console[a0_0x1f2d0c(0xbe)](anime[a0_0x1f2d0c(0xac)]);