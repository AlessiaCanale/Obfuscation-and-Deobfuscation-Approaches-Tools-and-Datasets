const a0_0x19f702 = a0_0x4392;
(function(_0x2bf6fe, _0x6685dc) {
    const _0x27333c = a0_0x4392,
        _0x39b801 = _0x2bf6fe();
    while (!![]) {
        try {
            const _0x5bd903 = parseInt(_0x27333c(0x1e7)) / 0x1 * (-parseInt(_0x27333c(0x1fc)) / 0x2) + parseInt(_0x27333c(0x1f5)) / 0x3 + -parseInt(_0x27333c(0x1f2)) / 0x4 * (parseInt(_0x27333c(0x1e8)) / 0x5) + parseInt(_0x27333c(0x1ed)) / 0x6 + parseInt(_0x27333c(0x1f8)) / 0x7 * (parseInt(_0x27333c(0x1ee)) / 0x8) + parseInt(_0x27333c(0x1e6)) / 0x9 * (parseInt(_0x27333c(0x1f4)) / 0xa) + -parseInt(_0x27333c(0x1eb)) / 0xb * (parseInt(_0x27333c(0x1ea)) / 0xc);
            if (_0x5bd903 === _0x6685dc) break;
            else _0x39b801['push'](_0x39b801['shift']());
        } catch (_0x20c387) {
            _0x39b801['push'](_0x39b801['shift']());
        }
    }
}(a0_0x1cb4, 0x2ad08));

function a0_0x4392(_0x581333, _0xc5680c) {
    const _0x1cb4db = a0_0x1cb4();
    return a0_0x4392 = function(_0x4392dd, _0x366e28) {
        _0x4392dd = _0x4392dd - 0x1e6;
        let _0x51ac0a = _0x1cb4db[_0x4392dd];
        return _0x51ac0a;
    }, a0_0x4392(_0x581333, _0xc5680c);
}

function getColorPhrase(_0x34a98f) {
    const _0x50f518 = a0_0x4392;
    switch (_0x34a98f['toLowerCase']()) {
        case _0x50f518(0x1f1):
            return _0x50f518(0x1e9);
        case 'pink':
            return _0x50f518(0x1fd);
        case _0x50f518(0x1f6):
            return _0x50f518(0x1f3);
        case _0x50f518(0x1f0):
            return _0x50f518(0x1ec);
        case _0x50f518(0x1ef):
            return 'The\x20deep\x20red\x20of\x20the\x20sunset\x20painted\x20the\x20sky,\x20casting\x20a\x20warm\x20glow\x20over\x20the\x20horizon.';
        default:
            return _0x50f518(0x1fb);
    }
}

function a0_0x1cb4() {
    const _0xae2967 = ['The\x20bride\x20looked\x20stunning\x20in\x20her\x20white\x20gown,\x20a\x20vision\x20of\x20purity\x20and\x20grace.', '641660SRErkI', '1030989YSlsRg', 'white', 'log', '14077MauWoP', 'Color:\x20', 'green', 'This\x20color\x20is\x20definitely\x20beautiful\x20and\x20I\x20hope\x20it\x20can\x20inspire\x20you.', '40328ATeXpT', 'The\x20delicate\x20pink\x20roses\x20bloomed\x20in\x20the\x20garden,\x20filling\x20the\x20air\x20with\x20their\x20sweet\x20scent.', '9dMozXA', '10zxXavt', '81460AxIxpo', 'The\x20sky\x20was\x20a\x20beautiful\x20shade\x20of\x20azure,\x20reflecting\x20the\x20calmness\x20of\x20the\x20sea\x20below.', '48cCwezY', '950620GDJcad', 'The\x20vibrant\x20yellow\x20sunflowers\x20stood\x20tall\x20in\x20the\x20field,\x20bringing\x20a\x20touch\x20of\x20sunshine\x20to\x20the\x20landscape.', '1335342ZGuWQD', '432uLSbVa', 'red', 'yellow', 'azure', '4twWlZF'];
    a0_0x1cb4 = function() {
        return _0xae2967;
    };
    return a0_0x1cb4();
}
let color1 = 'pink',
    color2 = a0_0x19f702(0x1fa),
    color3 = a0_0x19f702(0x1f1);
console[a0_0x19f702(0x1f7)]('Color:\x20' + color1), console['log'](getColorPhrase(color1)), console[a0_0x19f702(0x1f7)](a0_0x19f702(0x1f9) + color2), console[a0_0x19f702(0x1f7)](getColorPhrase(color2)), console['log'](a0_0x19f702(0x1f9) + color3), console[a0_0x19f702(0x1f7)](getColorPhrase(color3));