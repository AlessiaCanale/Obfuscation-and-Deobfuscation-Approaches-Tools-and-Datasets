var a0_0x4a6b8c = a0_0x4bc2;
(function(_0x580b1d, _0x5e2a2f) {
    var _0x9e3665 = a0_0x4bc2,
        _0x1a4094 = _0x580b1d();
    while (!![]) {
        try {
            var _0x12b96f = -parseInt(_0x9e3665(0x17b)) / 0x1 * (-parseInt(_0x9e3665(0x195)) / 0x2) + -parseInt(_0x9e3665(0x19a)) / 0x3 * (parseInt(_0x9e3665(0x189)) / 0x4) + parseInt(_0x9e3665(0x18e)) / 0x5 * (-parseInt(_0x9e3665(0x18a)) / 0x6) + -parseInt(_0x9e3665(0x18f)) / 0x7 + -parseInt(_0x9e3665(0x184)) / 0x8 + -parseInt(_0x9e3665(0x178)) / 0x9 * (parseInt(_0x9e3665(0x185)) / 0xa) + parseInt(_0x9e3665(0x180)) / 0xb;
            if (_0x12b96f === _0x5e2a2f) break;
            else _0x1a4094['push'](_0x1a4094['shift']());
        } catch (_0xab887c) {
            _0x1a4094['push'](_0x1a4094['shift']());
        }
    }
}(a0_0x3c46, 0x3ebb4));
var screenW = window[a0_0x4a6b8c(0x176)],
    xCenter = screenW / 0x2,
    animationContainer = document['getElementById'](a0_0x4a6b8c(0x186)),
    emojiPolice1 = document['getElementById'](a0_0x4a6b8c(0x193))['cloneNode'](!![]),
    emojiPolice2 = document[a0_0x4a6b8c(0x18b)]('emojiPolice')[a0_0x4a6b8c(0x18d)](!![]),
    emojiPolice3 = document[a0_0x4a6b8c(0x18b)](a0_0x4a6b8c(0x193))[a0_0x4a6b8c(0x18d)](!![]),
    emojiGun1 = document['getElementById'](a0_0x4a6b8c(0x19c))[a0_0x4a6b8c(0x18d)](!![]),
    emojiGun2 = document[a0_0x4a6b8c(0x18b)](a0_0x4a6b8c(0x19c))[a0_0x4a6b8c(0x18d)](!![]),
    emojiGun3 = document['getElementById'](a0_0x4a6b8c(0x19c))[a0_0x4a6b8c(0x18d)](!![]),
    emojiExplosion2 = document[a0_0x4a6b8c(0x18b)](a0_0x4a6b8c(0x191))['cloneNode'](!![]),
    emojiExplosion3 = document[a0_0x4a6b8c(0x18b)](a0_0x4a6b8c(0x191))[a0_0x4a6b8c(0x18d)](!![]);
emojiPolice1['id'] = a0_0x4a6b8c(0x187), emojiPolice2['id'] = a0_0x4a6b8c(0x188), emojiPolice3['id'] = a0_0x4a6b8c(0x196), emojiGun1['id'] = a0_0x4a6b8c(0x181), emojiGun2['id'] = 'emojiGun2', emojiGun3['id'] = a0_0x4a6b8c(0x175), emojiExplosion2['id'] = 'emojiExplosion2', emojiExplosion3['id'] = 'emojiExplosion3', animationContainer[a0_0x4a6b8c(0x19d)](emojiPolice1), animationContainer['appendChild'](emojiPolice2), animationContainer[a0_0x4a6b8c(0x19d)](emojiPolice3), animationContainer[a0_0x4a6b8c(0x18c)](emojiGun1, animationContainer[a0_0x4a6b8c(0x17e)]), animationContainer[a0_0x4a6b8c(0x18c)](emojiGun2, animationContainer[a0_0x4a6b8c(0x17e)]), animationContainer['insertBefore'](emojiGun3, animationContainer[a0_0x4a6b8c(0x17e)]), animationContainer[a0_0x4a6b8c(0x19d)](emojiExplosion2), animationContainer['appendChild'](emojiExplosion3);

function a0_0x3c46() {
    var _0x489e9a = ['#5bb12f', 'emojiGun3', 'innerWidth', 'none', '18378XqYcxu', 'random', 'getElementsByTagName', '118343gOCXKx', 'block', 'from', 'firstChild', '-=36', '14144559agqeBq', 'emojiGun1', 'easeIn', '#000', '3387888UtjpkZ', '1220SpQCmJ', 'emojiAnimation', 'emojiPolice1', 'emojiPolice2', '12MIaRQM', '48yBmQTQ', 'getElementById', 'insertBefore', 'cloneNode', '88045XdQkVa', '3039386IZdwwm', 'body', 'emojiExplosion1', 'easeInOut', 'emojiPolice', 'fromTo', '8lniWmN', 'emojiPolice3', '#c21c3b', 'easeOut', '#009ACD', '254613VBJCtC', '#666', 'emojiGun', 'appendChild'];
    a0_0x3c46 = function() {
        return _0x489e9a;
    };
    return a0_0x3c46();
}

function a0_0x4bc2(_0x3424bb, _0x2b534f) {
    var _0x3c46b = a0_0x3c46();
    return a0_0x4bc2 = function(_0x4bc213, _0x1cf8c0) {
        _0x4bc213 = _0x4bc213 - 0x174;
        var _0x2588a9 = _0x3c46b[_0x4bc213];
        return _0x2588a9;
    }, a0_0x4bc2(_0x3424bb, _0x2b534f);
}
var tl = new TimelineMax({
    'repeat': -0x1
})['to']([emojiMoney, emojiGun1, emojiGun2, emojiGun3, emojiExplosion1, emojiExplosion2, emojiExplosion3], 0x0, {
    'display': 'none'
})['to'](emojiAnimation, 0x0, {
    'display': a0_0x4a6b8c(0x17c)
})[a0_0x4a6b8c(0x17d)](emojiBank, 0x1, {
    'autoAlpha': 0x0,
    'rotationX': -0x5a,
    'delay': 0.5,
    'ease': Power4[a0_0x4a6b8c(0x198)]
})[a0_0x4a6b8c(0x194)](emojiRobber, 1.5, {
    'left': screenW + 0x64
}, {
    'left': xCenter + 0x6e,
    'delay': 0x1,
    'ease': Power4[a0_0x4a6b8c(0x198)]
})['fromTo'](emojiGun, 1.5, {
    'display': a0_0x4a6b8c(0x177),
    'left': screenW + 0x64
}, {
    'display': a0_0x4a6b8c(0x17c),
    'left': xCenter + 0x6e,
    'ease': Power4['easeOut']
}, 2.5)['to'](emojiRobber, 0.5, {
    'left': xCenter + 0xbe,
    'ease': Back['easeOut'],
    'delay': 0x1
})[a0_0x4a6b8c(0x194)](emojiGun, 0.5, {
    'rotation': -0x2d,
    'left': xCenter + 0x7d
}, {
    'rotation': 0x0,
    'left': xCenter + 0x6e,
    'ease': Back[a0_0x4a6b8c(0x198)],
    'delay': -0.5
})['to'](emojiRobber, 0.5, {
    'left': xCenter,
    'delay': 0x1
})['to'](emojiGun, 0.25, {
    'left': xCenter,
    'delay': -0.5
})['to'](emojiGun, 0x0, {
    'rotationY': -0xb4,
    'display': a0_0x4a6b8c(0x177)
})['to'](emojiRobber, 0x0, {
    'display': a0_0x4a6b8c(0x177)
})['to'](emojiBank, 0.1, {
    'left': xCenter - 0xa,
    'ease': Power4[a0_0x4a6b8c(0x182)]
})['to'](emojiBank, 0.1, {
    'left': xCenter + 0xa,
    'ease': Power4[a0_0x4a6b8c(0x182)]
})['to'](emojiBank, 0.1, {
    'left': xCenter - 0x14,
    'ease': Power4[a0_0x4a6b8c(0x182)]
})['to'](emojiBank, 0.1, {
    'left': xCenter + 0x14,
    'ease': Power4[a0_0x4a6b8c(0x182)]
})['to'](emojiBank, 0.1, {
    'left': xCenter,
    'ease': Power4[a0_0x4a6b8c(0x198)]
})['to'](emojiBank, 0.1, {
    'left': xCenter - 0xa,
    'ease': Power4[a0_0x4a6b8c(0x182)],
    'delay': 0.25
})['to'](emojiBank, 0.1, {
    'left': xCenter + 0xa,
    'ease': Power4[a0_0x4a6b8c(0x182)]
})['to'](emojiBank, 0.1, {
    'left': xCenter - 0x14,
    'ease': Power4[a0_0x4a6b8c(0x182)]
})['to'](emojiBank, 0.1, {
    'left': xCenter + 0x14,
    'ease': Power4[a0_0x4a6b8c(0x182)]
})['to'](emojiBank, 0.1, {
    'left': xCenter,
    'ease': Power4[a0_0x4a6b8c(0x198)]
})['to']([emojiGun, emojiRobber, emojiMoney], 0x0, {
    'display': a0_0x4a6b8c(0x17c)
})['to'](emojiGun, 0.6, {
    'left': xCenter + 0x14a,
    'delay': 0.5
})['to'](emojiRobber, 0.4, {
    'left': xCenter + 0xdc,
    'delay': -0.4
})['to'](emojiMoney, 0.2, {
    'left': xCenter + 0x6e,
    'delay': -0.2
})[a0_0x4a6b8c(0x194)](emojiCar, 0.5, {
    'left': screenW + 0x64
}, {
    'left': xCenter + 0x1b8,
    'delay': 0x1,
    'ease': Power4['easeOut']
})['to'](emojiMoney, 0.6, {
    'left': xCenter + 0x1b8,
    'delay': 0.5
})['to'](emojiRobber, 0.4, {
    'left': xCenter + 0x1b8,
    'delay': -0.6
})['to'](emojiGun, 0.2, {
    'left': xCenter + 0x1b8,
    'delay': -0.6
})['to']([emojiGun, emojiRobber, emojiMoney], 0x0, {
    'display': a0_0x4a6b8c(0x177)
})['to'](emojiCar, 0.5, {
    'rotationY': -0xb4,
    'ease': Power4['easeInOut']
})['to'](emojiCar, 0.25, {
    'left': screenW + 0x6e,
    'ease': Power4[a0_0x4a6b8c(0x182)]
})['to'](emojiBank, 0.75, {
    'left': '-=220',
    'autoAlpha': 0x0,
    'ease': Power4[a0_0x4a6b8c(0x182)],
    'delay': -0.5
})['to'](emojiCar, 0x0, {
    'rotationY': 0x0
})['to'](document[a0_0x4a6b8c(0x17a)](a0_0x4a6b8c(0x190))[0x0], 0.5, {
    'backgroundColor': a0_0x4a6b8c(0x199)
})['to'](emojiCar, 0x2, {
    'left': -0xdc,
    'ease': Power1[a0_0x4a6b8c(0x182)]
})[a0_0x4a6b8c(0x194)](emojiPolice, 0x2, {
    'left': screenW + 0xdc
}, {
    'left': -0x6e,
    'delay': -0x2,
    'ease': Power1[a0_0x4a6b8c(0x182)]
})['to'](emojiCar, 0x0, {
    'rotationY': -0xb4,
    'delay': 0.5
})['fromTo'](emojiPolice1, 0x1, {
    'left': screenW + 0xdc
}, {
    'left': xCenter - 0x6e,
    'ease': Power4[a0_0x4a6b8c(0x198)]
})[a0_0x4a6b8c(0x194)](emojiPolice2, 0x1, {
    'left': screenW + 0xdc
}, {
    'left': xCenter,
    'ease': Power4[a0_0x4a6b8c(0x198)],
    'delay': -0.75
})[a0_0x4a6b8c(0x194)](emojiPolice3, 0x1, {
    'left': screenW + 0xdc
}, {
    'left': xCenter + 0x6e,
    'ease': Power4[a0_0x4a6b8c(0x198)],
    'delay': -0.75
})['to'](emojiCar, 0x1, {
    'left': xCenter - 0x168,
    'ease': Back[a0_0x4a6b8c(0x198)],
    'delay': -0x1
})['to'](emojiGun1, 0x0, {
    'display': a0_0x4a6b8c(0x17c),
    'rotation': -0x2d,
    'left': xCenter - 0x6e
})['to'](emojiGun1, 0.5, {
    'rotation': 0x0,
    'ease': Back['easeOut']
})['to'](emojiPolice1, 0.5, {
    'left': xCenter - 0xa,
    'ease': Power4[a0_0x4a6b8c(0x192)],
    'delay': -0.5
})['to'](emojiPolice2, 0.5, {
    'left': xCenter + 0x64,
    'ease': Power4[a0_0x4a6b8c(0x192)],
    'delay': -0.5
})['to'](emojiPolice3, 0.5, {
    'left': xCenter + 0xd2,
    'ease': Power4['easeInOut'],
    'delay': -0.5
})['to'](emojiGun2, 0x0, {
    'display': a0_0x4a6b8c(0x17c),
    'rotation': -0x2d,
    'left': xCenter + 0x64
})['to'](emojiGun2, 0.5, {
    'rotation': 0x0,
    'ease': Back['easeOut']
})['to'](emojiPolice2, 0.5, {
    'left': xCenter + 0xd2,
    'ease': Power4[a0_0x4a6b8c(0x192)],
    'delay': -0.5
})['to'](emojiPolice3, 0.5, {
    'left': xCenter + 0x140,
    'ease': Power4[a0_0x4a6b8c(0x192)],
    'delay': -0.5
})['to'](emojiGun3, 0x0, {
    'display': a0_0x4a6b8c(0x17c),
    'rotation': -0x2d,
    'left': xCenter + 0x140
})['to'](emojiGun3, 0.5, {
    'rotation': 0x0,
    'ease': Back[a0_0x4a6b8c(0x198)]
})['to'](emojiPolice3, 0.5, {
    'left': xCenter + 0x1a4,
    'ease': Power4['easeInOut'],
    'delay': -0.5
})['to'](emojiExplosion1, 0x0, {
    'display': 'block',
    'marginTop': Math['random']() * 0x78 - 0x64,
    'left': xCenter - 0xdc - Math[a0_0x4a6b8c(0x179)]() * 0x78,
    'delay': 0.25
})['to'](emojiExplosion2, 0x0, {
    'display': a0_0x4a6b8c(0x17c),
    'marginTop': Math[a0_0x4a6b8c(0x179)]() * 0x78 - 0x64,
    'left': xCenter - 0xdc - Math[a0_0x4a6b8c(0x179)]() * 0x78,
    'delay': 0.025
})['to'](emojiExplosion3, 0x0, {
    'display': a0_0x4a6b8c(0x17c),
    'marginTop': Math['random']() * 0x78 - 0x64,
    'left': xCenter - 0xdc - Math[a0_0x4a6b8c(0x179)]() * 0x78,
    'delay': 0.05
})['to'](emojiExplosion1, 0x0, {
    'display': a0_0x4a6b8c(0x17c),
    'marginTop': Math[a0_0x4a6b8c(0x179)]() * 0x78 - 0x64,
    'left': xCenter - 0xdc - Math['random']() * 0x78,
    'delay': 0.075
})['to'](emojiExplosion2, 0x0, {
    'display': a0_0x4a6b8c(0x17c),
    'marginTop': Math[a0_0x4a6b8c(0x179)]() * 0x78 - 0x64,
    'left': xCenter - 0xdc - Math['random']() * 0x78,
    'delay': 0.1
})['to'](emojiExplosion3, 0x0, {
    'display': 'block',
    'marginTop': Math[a0_0x4a6b8c(0x179)]() * 0x78 - 0x64,
    'left': xCenter - 0xdc - Math[a0_0x4a6b8c(0x179)]() * 0x78,
    'delay': 0.125
})['to'](emojiExplosion1, 0x0, {
    'display': a0_0x4a6b8c(0x17c),
    'marginTop': Math[a0_0x4a6b8c(0x179)]() * 0x78 - 0x64,
    'left': xCenter - 0xdc - Math[a0_0x4a6b8c(0x179)]() * 0x78,
    'delay': 0.15
})['to'](emojiExplosion2, 0x0, {
    'display': a0_0x4a6b8c(0x17c),
    'marginTop': Math[a0_0x4a6b8c(0x179)]() * 0x78 - 0x64,
    'left': xCenter - 0xdc - Math['random']() * 0x78,
    'delay': 0.175
})['to'](emojiExplosion3, 0x0, {
    'display': 'block',
    'marginTop': Math[a0_0x4a6b8c(0x179)]() * 0x78 - 0x64,
    'left': xCenter - 0xdc - Math[a0_0x4a6b8c(0x179)]() * 0x78,
    'delay': 0.2
})['to'](emojiExplosion1, 0x0, {
    'display': a0_0x4a6b8c(0x177),
    'delay': 0.025
})['to'](emojiExplosion2, 0x0, {
    'display': a0_0x4a6b8c(0x177),
    'delay': 0.025
})['to'](emojiExplosion3, 0x0, {
    'display': 'none',
    'delay': 0.025
})['to'](emojiCar, 0.5, {
    'rotation': 0xb4,
    'ease': Elastic[a0_0x4a6b8c(0x198)],
    'delay': 0.5
})['to'](document[a0_0x4a6b8c(0x17a)](a0_0x4a6b8c(0x190))[0x0], 0.5, {
    'backgroundColor': a0_0x4a6b8c(0x197)
})[a0_0x4a6b8c(0x194)](emojiAmbulance, 0.5, {
    'left': -0xdc,
    'ease': Power4[a0_0x4a6b8c(0x198)],
    'rotationY': 0xb4,
    'delay': 0.5
}, {
    'left': xCenter - 0x168,
    'delay': 0x1
})['to'](emojiGun1, 0.5, {
    'left': xCenter - 0xa,
    'ease': Power4[a0_0x4a6b8c(0x192)],
    'delay': 0.5
})['to'](emojiGun2, 0x0, {
    'left': xCenter + 0xd2,
    'ease': Power4['easeInOut'],
    'delay': -0.25
})['to'](emojiGun3, 0x0, {
    'left': xCenter + 0x1a4,
    'ease': Power4[a0_0x4a6b8c(0x192)],
    'delay': -0.25
})['to']([emojiPolice1, emojiPolice2, emojiPolice3], 0.25, {
    'rotationY': 0xb4,
    'delay': -0.1
})['to']([emojiCar, emojiGun1, emojiGun2, emojiGun3], 0x0, {
    'display': a0_0x4a6b8c(0x177),
    'delay': 0.5
})['to'](emojiAmbulance, 0.5, {
    'left': screenW + 0x64,
    'ease': Power2[a0_0x4a6b8c(0x182)]
})['to'](emojiPolice1, 0.5, {
    'left': screenW + 0x12c,
    'ease': Power2[a0_0x4a6b8c(0x182)],
    'delay': -0.5
})['to'](emojiPolice2, 0.5, {
    'left': screenW + 0x1f4,
    'ease': Power2['easeIn'],
    'delay': -0.5
})['to'](emojiPolice3, 0.5, {
    'left': screenW + 0x2bc,
    'ease': Power2[a0_0x4a6b8c(0x182)],
    'delay': -0.5
})[a0_0x4a6b8c(0x17d)](emojiHospital, 0.5, {
    'autoAlpha': 0x0,
    'delay': 0.5
})['to'](emojiAmbulance, 0x0, {
    'rotationY': 0x0
})['to'](emojiAmbulance, 0x1, {
    'left': xCenter,
    'ease': Power4[a0_0x4a6b8c(0x198)],
    'delay': 0.5
})['from'](emojiFearful, 0.5, {
    'autoAlpha': 0x0,
    'delay': 1.5
})['fromTo'](emojiGavel, 0.5, {
    'left': screenW + 0x64
}, {
    'left': xCenter + 0x6e,
    'ease': Power4['easeOut']
})['to'](emojiGavel, 0.25, {
    'marginTop': a0_0x4a6b8c(0x17f),
    'rotation': 0x1e,
    'ease': Power4[a0_0x4a6b8c(0x198)],
    'delay': -0.25
})['to'](emojiGavel, 0.5, {
    'marginTop': '+=36',
    'rotation': 0x0,
    'ease': Bounce[a0_0x4a6b8c(0x198)],
    'delay': 0.25
})[a0_0x4a6b8c(0x17d)](emojiCrying, 0.5, {
    'autoAlpha': 0x0
})['from'](jailbars, 0x1, {
    'top': -0x96,
    'ease': Bounce[a0_0x4a6b8c(0x198)]
})['to'](document[a0_0x4a6b8c(0x17a)](a0_0x4a6b8c(0x190))[0x0], 0x1, {
    'backgroundColor': a0_0x4a6b8c(0x19b),
    'delay': -0x1
})['to']([emojiFearful, emojiHospital, emojiAmbulance], 0x0, {
    'display': a0_0x4a6b8c(0x177)
})['to']([emojiCrying, jailbars, emojiGavel], 0x1, {
    'rotationX': 0x5a,
    'autoAlpha': 0x0,
    'ease': Power4[a0_0x4a6b8c(0x182)],
    'delay': 0x2
})['to'](document[a0_0x4a6b8c(0x17a)](a0_0x4a6b8c(0x190))[0x0], 0x1, {
    'backgroundColor': a0_0x4a6b8c(0x183)
})['to'](document[a0_0x4a6b8c(0x17a)](a0_0x4a6b8c(0x190))[0x0], 0x1, {
    'backgroundColor': a0_0x4a6b8c(0x174),
    'delay': 0.5
});