var a0_0x4bcf45 = a0_0x5871;
(function(_0x43a303, _0x17de8) {
    var _0x401285 = a0_0x5871,
        _0x5c17a9 = _0x43a303();
    while (!![]) {
        try {
            var _0x2136dd = -parseInt(_0x401285(0x1f4)) / 0x1 + parseInt(_0x401285(0x1f6)) / 0x2 + parseInt(_0x401285(0x1f2)) / 0x3 + parseInt(_0x401285(0x1f0)) / 0x4 + parseInt(_0x401285(0x1ea)) / 0x5 * (parseInt(_0x401285(0x1f5)) / 0x6) + -parseInt(_0x401285(0x1f7)) / 0x7 + -parseInt(_0x401285(0x1eb)) / 0x8 * (parseInt(_0x401285(0x1ed)) / 0x9);
            if (_0x2136dd === _0x17de8) break;
            else _0x5c17a9['push'](_0x5c17a9['shift']());
        } catch (_0x1342ab) {
            _0x5c17a9['push'](_0x5c17a9['shift']());
        }
    }
}(a0_0x3cd9, 0xefe4a));
var colorTestEls = document['querySelectorAll'](a0_0x4bcf45(0x1fa));

function createTest(_0x5bea50) {
    var _0x167a87 = a0_0x4bcf45,
        _0x2b91e1 = _0x5bea50['innerHTML'],
        _0x58ea64 = _0x2b91e1['split'](_0x167a87(0x1f3)),
        _0xb7d377 = document['createElement'](_0x167a87(0x1f1));
    _0xb7d377[_0x167a87(0x1f8)][_0x167a87(0x1ee)]('color-el'), _0x5bea50[_0x167a87(0x1ec)](_0xb7d377), anime({
        'targets': _0xb7d377,
        'backgroundColor': [_0x58ea64[0x0], _0x58ea64[0x1]],
        'scale': [0.97, 0.75],
        'direction': 'alternate',
        'easing': _0x167a87(0x1f9),
        'duration': 0xfa0,
        'loop': !![]
    });
}

function a0_0x3cd9() {
    var _0x562fc1 = ['length', '6367324mMmyrc', 'div', '1515567gsEuvS', '<br>▾<br>', '553140SSVCcF', '2788218GkdhTn', '563846oDJuNp', '3807972lwLsYb', 'classList', 'easeInOutSine', '.color-test', '5cWEJHZ', '1527816YxQswD', 'appendChild', '36RSylTy', 'add'];
    a0_0x3cd9 = function() {
        return _0x562fc1;
    };
    return a0_0x3cd9();
}

function a0_0x5871(_0x5c4774, _0x579e23) {
    var _0x3cd97a = a0_0x3cd9();
    return a0_0x5871 = function(_0x587162, _0x103f44) {
        _0x587162 = _0x587162 - 0x1ea;
        var _0x12bf5e = _0x3cd97a[_0x587162];
        return _0x12bf5e;
    }, a0_0x5871(_0x5c4774, _0x579e23);
}
for (var i = 0x0; i < colorTestEls[a0_0x4bcf45(0x1ef)]; i++) createTest(colorTestEls[i]);