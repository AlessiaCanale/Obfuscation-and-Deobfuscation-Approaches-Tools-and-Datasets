const a0_0xf75a3c = a0_0x4f4f;
(function(_0x1d7a87, _0xfc1037) {
    const _0x56564d = a0_0x4f4f,
        _0x41d8fb = _0x1d7a87();
    while (!![]) {
        try {
            const _0xb3780d = -parseInt(_0x56564d(0xd6)) / 0x1 + parseInt(_0x56564d(0xd9)) / 0x2 + -parseInt(_0x56564d(0xdc)) / 0x3 + parseInt(_0x56564d(0xd8)) / 0x4 + parseInt(_0x56564d(0xd3)) / 0x5 + parseInt(_0x56564d(0xd7)) / 0x6 * (parseInt(_0x56564d(0xda)) / 0x7) + -parseInt(_0x56564d(0xd2)) / 0x8 * (parseInt(_0x56564d(0xd0)) / 0x9);
            if (_0xb3780d === _0xfc1037) break;
            else _0x41d8fb['push'](_0x41d8fb['shift']());
        } catch (_0x1f9d1e) {
            _0x41d8fb['push'](_0x41d8fb['shift']());
        }
    }
}(a0_0x27a0, 0x8a7dc));

function a0_0x27a0() {
    const _0x20ffa1 = ['9665604fIQYBH', 'Javascript\x20tips', '16aNqaYW', '4027410NZmRJw', 'Paul\x20Knulst', '2021-11-19', '13784GchLWC', '115854xFKeEU', '2329672XHcJMR', '2002634LawJsZ', '357SXsbsP', 'Male', '1935060nkvRfl'];
    a0_0x27a0 = function() {
        return _0x20ffa1;
    };
    return a0_0x27a0();
}

function a0_0x4f4f(_0x231aa5, _0x599d0d) {
    const _0x27a054 = a0_0x27a0();
    return a0_0x4f4f = function(_0x4f4f18, _0x1db512) {
        _0x4f4f18 = _0x4f4f18 - 0xd0;
        let _0x2ab26c = _0x27a054[_0x4f4f18];
        return _0x2ab26c;
    }, a0_0x4f4f(_0x231aa5, _0x599d0d);
}
const user = {
        'name': a0_0xf75a3c(0xd4),
        'gender': a0_0xf75a3c(0xdb)
    },
    article = {
        'title': a0_0xf75a3c(0xd1),
        'date': a0_0xf75a3c(0xd5)
    },
    summary = {
        ...user,
        ...article
    };
console['log'](summary);