const a0_0x41dfcc = a0_0x3bfc;
(function(_0x5c41c3, _0x1e172b) {
    const _0x292155 = a0_0x3bfc,
        _0x2d6933 = _0x5c41c3();
    while (!![]) {
        try {
            const _0x5cc098 = parseInt(_0x292155(0xe8)) / 0x1 * (-parseInt(_0x292155(0xdd)) / 0x2) + parseInt(_0x292155(0xe9)) / 0x3 + -parseInt(_0x292155(0xdc)) / 0x4 * (-parseInt(_0x292155(0xe6)) / 0x5) + parseInt(_0x292155(0xe1)) / 0x6 + parseInt(_0x292155(0xe5)) / 0x7 + parseInt(_0x292155(0xe4)) / 0x8 * (parseInt(_0x292155(0xe2)) / 0x9) + -parseInt(_0x292155(0xdf)) / 0xa * (parseInt(_0x292155(0xe7)) / 0xb);
            if (_0x5cc098 === _0x1e172b) break;
            else _0x2d6933['push'](_0x2d6933['shift']());
        } catch (_0x31cb53) {
            _0x2d6933['push'](_0x2d6933['shift']());
        }
    }
}(a0_0x21d8, 0xe7bd4));

function addLetterCountAfterWord(_0x4d4351) {
    const _0x5632b3 = a0_0x3bfc,
        _0x442426 = _0x4d4351['split']('\x20');
    let _0x39b5a1 = '';
    for (let _0x41653d = 0x0; _0x41653d < _0x442426[_0x5632b3(0xe0)]; _0x41653d++) {
        const _0x5e8a42 = _0x442426[_0x41653d],
            _0x2d0bda = _0x5e8a42[_0x5632b3(0xe0)];
        _0x39b5a1 += _0x5e8a42 + '\x20' + _0x2d0bda + '\x20';
    }
    return _0x39b5a1[_0x5632b3(0xdb)]();
}

function a0_0x3bfc(_0x5cd46b, _0x3bf7a0) {
    const _0x21d88e = a0_0x21d8();
    return a0_0x3bfc = function(_0x3bfcba, _0xbe29ed) {
        _0x3bfcba = _0x3bfcba - 0xdb;
        let _0x309152 = _0x21d88e[_0x3bfcba];
        return _0x309152;
    }, a0_0x3bfc(_0x5cd46b, _0x3bf7a0);
}
const originalText = a0_0x41dfcc(0xde),
    newText = addLetterCountAfterWord(originalText);
console['log'](a0_0x41dfcc(0xea)), console[a0_0x41dfcc(0xeb)](originalText), console[a0_0x41dfcc(0xeb)](a0_0x41dfcc(0xe3)), console[a0_0x41dfcc(0xeb)](newText);

function a0_0x21d8() {
    const _0x18e0b1 = ['log', 'trim', '148VZvYFM', '3516202LpDmxE', 'Exploring\x20the\x20depths\x20of\x20the\x20universe,\x20uncovering\x20mysteries,\x20and\x20pushing\x20boundaries\x20to\x20advance\x20human\x20knowledge\x20and\x20understanding\x20of\x20the\x20world.', '1211510fviNwe', 'length', '4346676gpagPi', '333ThYKNw', '\x0aText\x20with\x20letter\x20counts:', '401440mdcXox', '9652188zrBnGO', '58540XPQVBo', '319bfsoYr', '1WFBdfj', '5482494ubpkpZ', 'Original\x20Text:'];
    a0_0x21d8 = function() {
        return _0x18e0b1;
    };
    return a0_0x21d8();
}