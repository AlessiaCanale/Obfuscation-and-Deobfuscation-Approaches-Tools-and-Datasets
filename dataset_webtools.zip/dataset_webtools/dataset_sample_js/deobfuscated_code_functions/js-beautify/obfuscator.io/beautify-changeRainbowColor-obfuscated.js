(function(_0x100351, _0x1f168f) {
    const _0x1e517b = a0_0x4164,
        _0x8012a6 = _0x100351();
    while (!![]) {
        try {
            const _0x3a1022 = parseInt(_0x1e517b(0x1fb)) / 0x1 + -parseInt(_0x1e517b(0x1fc)) / 0x2 * (-parseInt(_0x1e517b(0x1f1)) / 0x3) + parseInt(_0x1e517b(0x1f5)) / 0x4 + -parseInt(_0x1e517b(0x1f0)) / 0x5 + -parseInt(_0x1e517b(0x1ee)) / 0x6 + -parseInt(_0x1e517b(0x1fd)) / 0x7 * (-parseInt(_0x1e517b(0x1f8)) / 0x8) + parseInt(_0x1e517b(0x1ea)) / 0x9 * (-parseInt(_0x1e517b(0x1ef)) / 0xa);
            if (_0x3a1022 === _0x1f168f) break;
            else _0x8012a6['push'](_0x8012a6['shift']());
        } catch (_0x54a5fb) {
            _0x8012a6['push'](_0x8012a6['shift']());
        }
    }
}(a0_0x3537, 0xb350a));
let rainbowTextClicked = ![];

function a0_0x4164(_0x26e6bf, _0x5e9785) {
    const _0x35372d = a0_0x3537();
    return a0_0x4164 = function(_0x41647a, _0x251a22) {
        _0x41647a = _0x41647a - 0x1ea;
        let _0x57481c = _0x35372d[_0x41647a];
        return _0x57481c;
    }, a0_0x4164(_0x26e6bf, _0x5e9785);
}

function a0_0x3537() {
    const _0x10803a = ['children', '#4b0082', '6032928dbghRR', '1282730JewWQM', '492150bOqpIY', '6MzgCAb', 'rainbowText', '#000000', '#ff7f00', '3458148MbffLx', '#ffff00', 'textContent', '368lZsQtK', 'style', '#ff0000', '743986wqnKce', '805186mWEDXH', '88130gMVBed', '81IhoWsc', 'length'];
    a0_0x3537 = function() {
        return _0x10803a;
    };
    return a0_0x3537();
}

function changeRainbowColor() {
    const _0x1d8caa = a0_0x4164,
        _0x2f224b = [_0x1d8caa(0x1fa), _0x1d8caa(0x1f4), _0x1d8caa(0x1f6), '#00ff00', '#007fff', _0x1d8caa(0x1ed)],
        _0xbeac2 = document['getElementById'](_0x1d8caa(0x1f2));
    if (!rainbowTextClicked) {
        for (let _0xd87bcc = 0x0; _0xd87bcc < _0xbeac2[_0x1d8caa(0x1f7)][_0x1d8caa(0x1eb)]; _0xd87bcc++) {
            _0xbeac2[_0x1d8caa(0x1ec)][_0xd87bcc]['style']['color'] = _0x2f224b[_0xd87bcc];
        }
        rainbowTextClicked = !![];
    } else _0xbeac2[_0x1d8caa(0x1f9)]['color'] = _0x1d8caa(0x1f3), rainbowTextClicked = ![];
}