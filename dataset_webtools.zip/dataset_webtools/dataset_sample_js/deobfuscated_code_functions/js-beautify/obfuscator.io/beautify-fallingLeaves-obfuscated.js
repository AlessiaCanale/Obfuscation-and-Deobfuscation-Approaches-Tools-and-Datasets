const a0_0x20b069 = a0_0x2487;
(function(_0x99d5ca, _0x179ed8) {
    const _0x16f2f7 = a0_0x2487,
        _0xf2babe = _0x99d5ca();
    while (!![]) {
        try {
            const _0xa3c3f3 = parseInt(_0x16f2f7(0x1b9)) / 0x1 * (-parseInt(_0x16f2f7(0x1be)) / 0x2) + parseInt(_0x16f2f7(0x1bf)) / 0x3 * (parseInt(_0x16f2f7(0x1d6)) / 0x4) + -parseInt(_0x16f2f7(0x1bb)) / 0x5 * (-parseInt(_0x16f2f7(0x1de)) / 0x6) + -parseInt(_0x16f2f7(0x1cc)) / 0x7 + -parseInt(_0x16f2f7(0x1b6)) / 0x8 + parseInt(_0x16f2f7(0x1e3)) / 0x9 * (-parseInt(_0x16f2f7(0x1e4)) / 0xa) + parseInt(_0x16f2f7(0x1dc)) / 0xb;
            if (_0xa3c3f3 === _0x179ed8) break;
            else _0xf2babe['push'](_0xf2babe['shift']());
        } catch (_0x21121f) {
            _0xf2babe['push'](_0xf2babe['shift']());
        }
    }
}(a0_0x112c, 0x5184e));
const ns = a0_0x20b069(0x1c4),
    svg = document[a0_0x20b069(0x1e2)](a0_0x20b069(0x1c9))[0x0],
    copyGroup = document['createElementNS'](ns, 'g');
copyGroup[a0_0x20b069(0x1b8)]('id', 'copy'), svg[a0_0x20b069(0x1d9)](copyGroup);
const header = document[a0_0x20b069(0x1db)](a0_0x20b069(0x1b7)),
    header_height = getComputedStyle(header)['height'][a0_0x20b069(0x1d8)]('px')[0x0];
console['log'](header_height);

function changeArrow(_0xcf951f) {
    const _0x162a1a = a0_0x20b069,
        _0x36e3eb = document['querySelector']('.scroll-direction');
    console['log'](_0x36e3eb), _0x36e3eb[_0x162a1a(0x1b8)]('data-direction', _0xcf951f);
}

function changeDirection() {
    const _0x36208b = a0_0x20b069;
    window[_0x36208b(0x1d3)] > header_height && changeArrow('↑'), window[_0x36208b(0x1d3)] < header_height && changeArrow('↓');
}

function a0_0x2487(_0x2d11e7, _0x123eee) {
    const _0x112cb2 = a0_0x112c();
    return a0_0x2487 = function(_0x248755, _0x585915) {
        _0x248755 = _0x248755 - 0x1b4;
        let _0x1ccfb6 = _0x112cb2[_0x248755];
        return _0x1ccfb6;
    }, a0_0x2487(_0x2d11e7, _0x123eee);
}
console[a0_0x20b069(0x1c3)](window[a0_0x20b069(0x1d3)]);
const leafPickers = [{
    'leafs': a0_0x20b069(0x1dd),
    'collection': a0_0x20b069(0x1c2)
}, {
    'leafs': a0_0x20b069(0x1df),
    'collection': 'Purple'
}, {
    'leafs': a0_0x20b069(0x1b5),
    'collection': 'Red'
}, {
    'leafs': a0_0x20b069(0x1d4),
    'collection': a0_0x20b069(0x1c0)
}, {
    'leafs': a0_0x20b069(0x1d1),
    'collection': a0_0x20b069(0x1cb)
}, {
    'leafs': a0_0x20b069(0x1c7),
    'collection': a0_0x20b069(0x1d2)
}];
let leafCopy = [];

function leafPicker(_0x2dd4a3) {
    const _0x39fa14 = a0_0x20b069,
        _0x2a9c55 = document[_0x39fa14(0x1cf)](_0x39fa14(0x1cd) + _0x2dd4a3 + '\x22]');
    for (const _0x4fa9b0 of _0x2a9c55) {
        leafCopy[_0x39fa14(0x1c6)](_0x4fa9b0[_0x39fa14(0x1ce)](!![]));
    }
}
for (const leafs of leafPickers) {
    leafPicker(leafs['collection']);
}
console[a0_0x20b069(0x1c3)](leafCopy);

function makeCopies() {
    const _0x559704 = a0_0x20b069;
    for (const _0x24484f of leafCopy) {
        copyGroup[_0x559704(0x1d9)](_0x24484f);
        const _0x3906b4 = Array['from'](document['getElementById'](_0x559704(0x1e1))[_0x559704(0x1cf)](_0x559704(0x1c1)));
        for (const [_0x661f60, _0x3c18ca] of _0x3906b4[_0x559704(0x1ba)]()) {
            _0x3c18ca['setAttribute']('id', _0x559704(0x1bc) + _0x661f60);
        }
    }
}
makeCopies();

function a0_0x112c() {
    const _0x837fbf = ['querySelectorAll', 'addEventListener', 'blueLeafs', 'green', 'pageYOffset', 'pinkLeafs', 'length', '24XScZii', 'touchmove', 'split', 'appendChild', 'scroll', 'querySelector', '6191372yWXQPS', 'orangeLeafs', '12BeTFXM', 'purpleLeafs', 'from', 'copy', 'getElementsByTagName', '3609NoOJBK', '3830RPXFTQ', 'getElementById', 'redLeafs', '1965880InAwhH', 'header', 'setAttribute', '362898FNCvUX', 'entries', '1558915ypvdxU', 'copy-', 'apply', '2QGROwF', '197646bYOIDE', 'Pink', '[data-name]', 'Orange', 'log', 'http://www.w3.org/2000/svg', 'play', 'push', 'greenLeafs', 'easeInOutQuint', 'svg', 'random', 'blue', '3399144RFebHH', '[data-name=\x22', 'cloneNode'];
    a0_0x112c = function() {
        return _0x837fbf;
    };
    return a0_0x112c();
}
const leafCopies = Array[a0_0x20b069(0x1e0)](document[a0_0x20b069(0x1b4)](a0_0x20b069(0x1e1))[a0_0x20b069(0x1cf)](a0_0x20b069(0x1c1)));
let spring = {},
    summer = {},
    autumn = {};

function shuffle(_0x14e389) {
    const _0x301d6c = a0_0x20b069;
    var _0x3514e9 = _0x14e389[_0x301d6c(0x1d5)],
        _0x3892df, _0x55c4c5;
    while (_0x3514e9--) {
        _0x55c4c5 = Math[_0x301d6c(0x1ca)]() * _0x3514e9 | 0x0, _0x3892df = _0x14e389[_0x3514e9], _0x14e389[_0x3514e9] = _0x14e389[_0x55c4c5], _0x14e389[_0x55c4c5] = _0x3892df;
    }
    return _0x14e389;
}
spring = shuffle(leafCopies), spring['length'] = 0x14, summer = shuffle(leafCopies), summer[a0_0x20b069(0x1d5)] = 0x28;

function debounce(_0x54c25d, _0x2c2280 = 0x14, _0x19911c = !![]) {
    var _0x48fa94;
    return function() {
        const _0x37cad6 = a0_0x2487;
        var _0x1c9f20 = this,
            _0x343571 = arguments,
            _0x5ccde8 = function() {
                _0x48fa94 = null;
                if (!_0x19911c) _0x54c25d['apply'](_0x1c9f20, _0x343571);
            },
            _0x57788c = _0x19911c && !_0x48fa94;
        clearTimeout(_0x48fa94), _0x48fa94 = setTimeout(_0x5ccde8, _0x2c2280);
        if (_0x57788c) _0x54c25d[_0x37cad6(0x1bd)](_0x1c9f20, _0x343571);
    };
}
changeDirection();
const summerFall = anime({
    'targets': summer,
    'easing': a0_0x20b069(0x1c8),
    'opacity': 0x0,
    'translateY': 0xc8,
    'duration': function(_0x3b484c, _0xb1fa0e, _0x1cff8f) {
        return 0x9c4 + _0xb1fa0e * 0x64;
    },
    'autoplay': ![]
});

function playAnimation() {
    const _0x100420 = a0_0x20b069;
    window[_0x100420(0x1d3)] < 0xa && (summerFall[_0x100420(0x1c5)](), summerFall['restart']());;
};
document[a0_0x20b069(0x1d0)](a0_0x20b069(0x1d7), ScrollStart, ![]), document['addEventListener'](a0_0x20b069(0x1da), Scroll, ![]);

function ScrollStart() {
    debounce(playAnimation, 0xa);
}

function Scroll() {
    debounce(playAnimation, 0xa);
}
window[a0_0x20b069(0x1d0)](a0_0x20b069(0x1da), debounce(playAnimation, 0xa));