function a0_0x5cf2(_0x14de94, _0x36bda7) {
    var _0x48d4f4 = a0_0x48d4();
    return a0_0x5cf2 = function(_0x5cf223, _0x4a524a) {
        _0x5cf223 = _0x5cf223 - 0x9d;
        var _0x5b39d7 = _0x48d4f4[_0x5cf223];
        return _0x5b39d7;
    }, a0_0x5cf2(_0x14de94, _0x36bda7);
}(function(_0x598da8, _0x3216bb) {
    var _0x12a1b2 = a0_0x5cf2,
        _0x28e7bd = _0x598da8();
    while (!![]) {
        try {
            var _0x3f97d1 = parseInt(_0x12a1b2(0xad)) / 0x1 + -parseInt(_0x12a1b2(0x9d)) / 0x2 * (parseInt(_0x12a1b2(0xaa)) / 0x3) + -parseInt(_0x12a1b2(0xac)) / 0x4 * (-parseInt(_0x12a1b2(0xa0)) / 0x5) + -parseInt(_0x12a1b2(0xa2)) / 0x6 * (parseInt(_0x12a1b2(0xb0)) / 0x7) + -parseInt(_0x12a1b2(0xab)) / 0x8 + -parseInt(_0x12a1b2(0xa6)) / 0x9 * (-parseInt(_0x12a1b2(0xb1)) / 0xa) + -parseInt(_0x12a1b2(0xa8)) / 0xb * (-parseInt(_0x12a1b2(0xaf)) / 0xc);
            if (_0x3f97d1 === _0x3216bb) break;
            else _0x28e7bd['push'](_0x28e7bd['shift']());
        } catch (_0x3ada2e) {
            _0x28e7bd['push'](_0x28e7bd['shift']());
        }
    }
}(a0_0x48d4, 0x8da3b));
var listtt = [];

function num(_0x323848, _0x67ecd4, _0x57e666) {
    var _0x163a1b = a0_0x5cf2;
    for (i = 0x0; i < _0x323848 / 0x2; i++) {
        var _0x56adaf = Math[_0x163a1b(0xa3)]();
        _0x56adaf > 0.5 ? listtt['push']('1') : listtt[_0x163a1b(0xa7)]('0');
    }
    for (i = 0x0; i < _0x67ecd4; i++) {
        listtt['push']('<font\x20style=\x27opacity:\x200;\x27>#</font>');
    }
    for (i = 0x0; i < _0x323848 / 0x2; i++) {
        var _0x56adaf = Math[_0x163a1b(0xa3)]();
        _0x56adaf > 0.5 ? listtt[_0x163a1b(0xa7)]('1') : listtt[_0x163a1b(0xa7)]('0');
    }
    listtt[_0x163a1b(0xa7)]('<br>');
}

function a0_0x48d4() {
    var _0x5e859b = ['<div\x20class=\x27right\x27>', '9CznTRw', 'push', '33ysKUXB', 'write', '21XTaVyy', '3055536BQCcQk', '779860ZuACNP', '289620Tzbaxr', '<div\x20class=\x27holder\x27>', '3546444eAjKgz', '133vokUHE', '4101490JpQIaU', '284428kRYJpB', '</div>', 'length', '10rGmRoi', '<style>body\x20{\x20text-align:\x20center;\x20background:\x20#000;\x20font-family:\x20monospace;\x20color:\x20#fff;\x20font-size:\x2020px;\x20line-height:\x2012px;\x20margin-top:\x2050px;\x20}\x20.right\x20{\x20width:\x20230px;\x20height:\x20200px;\x20float:\x20left;\x20}\x20.right:nth-child(1){color:\x20blue;}\x20.right:nth-child(2){color:\x20#fff;}\x20.right:nth-child(3){color:\x20red;}\x20.bottom-holder\x20.right:nth-child(1){color:\x20yellow;}\x20.bottom-holder\x20.right:nth-child(2){color:\x20green;}\x20.holder\x20{\x20width:\x20690px;\x20height:\x20200px;\x20margin:\x200\x20auto;\x20}\x20.bottom-holder\x20{\x20width:\x20460px;\x20height:\x20200px;\x20margin:\x200\x20auto;\x20transform:\x20translateY(-95px);\x20}</style>', '5910coACIr', 'random', '<div\x20class=\x27bottom-holder\x27>'];
    a0_0x48d4 = function() {
        return _0x5e859b;
    };
    return a0_0x48d4();
}

function ring(_0x47251c) {
    var _0x353dec = a0_0x5cf2,
        _0x2546e3 = '';
    num(0x6, 0x0, _0x47251c), num(0xa, 0x0, _0x47251c), (num(0x8, 0x6), _0x47251c), num(0x6, 0x8, _0x47251c), num(0x6, 0xb, _0x47251c), num(0x6, 0xb, _0x47251c), num(0x6, 0xe, _0x47251c), num(0x6, 0xe, _0x47251c), num(0x6, 0xe, _0x47251c), num(0x6, 0xe, _0x47251c), num(0x6, 0xb, _0x47251c), num(0x6, 0xb, _0x47251c), num(0x6, 0x8, _0x47251c), num(0x8, 0x6, _0x47251c), num(0xa, 0x0, _0x47251c), num(0x6, 0x0, _0x47251c);
    var _0x2546e3 = '';
    for (i = 0x0; i < _0x47251c[_0x353dec(0x9f)]; i++) {
        _0x2546e3 = _0x2546e3 + _0x47251c[i];
    }
    document['write'](_0x353dec(0xa5)), document[_0x353dec(0xa9)](_0x2546e3), document['write']('</div>'), listtt = [];
}
setInterval(function() {
    var _0x33638d = a0_0x5cf2;
    document['body']['innerHTML'] = '', document[_0x33638d(0xa9)](_0x33638d(0xa1)), document[_0x33638d(0xa9)](_0x33638d(0xae)), ring(listtt), ring(listtt), ring(listtt), document[_0x33638d(0xa9)](_0x33638d(0x9e)), document[_0x33638d(0xa9)](_0x33638d(0xa4)), ring(listtt), ring(listtt), document[_0x33638d(0xa9)](_0x33638d(0x9e));
}, 0x32);