function a0_0x5612(_0x456694, _0x211ab2) {
    var _0x5a1a75 = a0_0x5a1a();
    return a0_0x5612 = function(_0x561209, _0x16475b) {
        _0x561209 = _0x561209 - 0x153;
        var _0x7aafdd = _0x5a1a75[_0x561209];
        return _0x7aafdd;
    }, a0_0x5612(_0x456694, _0x211ab2);
}
var a0_0x35372f = a0_0x5612;
(function(_0x2968bf, _0xbc7f6d) {
    var _0x49a660 = a0_0x5612,
        _0x1a8a4e = _0x2968bf();
    while (!![]) {
        try {
            var _0x2db113 = parseInt(_0x49a660(0x166)) / 0x1 + parseInt(_0x49a660(0x16a)) / 0x2 + parseInt(_0x49a660(0x156)) / 0x3 + -parseInt(_0x49a660(0x15f)) / 0x4 + -parseInt(_0x49a660(0x15b)) / 0x5 * (parseInt(_0x49a660(0x161)) / 0x6) + parseInt(_0x49a660(0x15a)) / 0x7 * (-parseInt(_0x49a660(0x168)) / 0x8) + parseInt(_0x49a660(0x16e)) / 0x9 * (-parseInt(_0x49a660(0x173)) / 0xa);
            if (_0x2db113 === _0xbc7f6d) break;
            else _0x1a8a4e['push'](_0x1a8a4e['shift']());
        } catch (_0x455d5c) {
            _0x1a8a4e['push'](_0x1a8a4e['shift']());
        }
    }
}(a0_0x5a1a, 0xafc46));

function flowerMeaning(_0x18f880) {
    var _0x14543b = a0_0x5612;
    switch (_0x18f880) {
        case _0x14543b(0x16b):
            return _0x14543b(0x16d);
        case _0x14543b(0x163):
            return _0x14543b(0x155);
        case _0x14543b(0x169):
            return _0x14543b(0x157);
        case _0x14543b(0x15e):
            return _0x14543b(0x15d);
        case _0x14543b(0x159):
            return _0x14543b(0x167);
        case _0x14543b(0x16f):
            return _0x14543b(0x174);
        case 'Orchid':
            return _0x14543b(0x160);
        case _0x14543b(0x165):
            return 'Thankfulness,\x20humility';
        case _0x14543b(0x154):
            return _0x14543b(0x172);
        case _0x14543b(0x15c):
            return _0x14543b(0x16c);
        default:
            return _0x14543b(0x171);
    }
}

function a0_0x5a1a() {
    var _0x1b7ec2 = ['5410pRtmTs', 'Prosperity,\x20good\x20fortune', 'Sunflower:\x20', 'Carnation', 'Purity,\x20virtue,\x20symbol\x20of\x20the\x20Virgin\x20Mary', '4286268cubfMf', 'Happiness,\x20adoration', 'log', 'Tulip', '21Fqgjmk', '3132880mHvdhK', 'Lavender', 'Innocence,\x20purity,\x20new\x20beginnings', 'Daisy', '909400MCDvpK', 'Luxury,\x20refinement,\x20beauty', '12YUdhCm', 'Lotus:\x20', 'Lily', 'Lotus', 'Hydrangea', '809712cdNDBo', 'Perfect\x20love,\x20elegance', '2186296nvBNEA', 'Sunflower', '2464980jmZgkf', 'Rose', 'Serenity,\x20calmness,\x20grace', 'Love,\x20passion,\x20beauty', '7497dEsYzL', 'Peony', 'Rose:\x20', 'Even\x20though\x20I\x20don\x27t\x20know\x20the\x20meaning\x20behind\x20this\x20flower,\x20I\x20am\x20sure\x20it\x20is\x20as\x20beautiful\x20as\x20your\x20smile!', 'Love,\x20fascination,\x20admiration'];
    a0_0x5a1a = function() {
        return _0x1b7ec2;
    };
    return a0_0x5a1a();
}
console[a0_0x35372f(0x158)](a0_0x35372f(0x170) + flowerMeaning(a0_0x35372f(0x16b))), console[a0_0x35372f(0x158)](a0_0x35372f(0x153) + flowerMeaning(a0_0x35372f(0x169))), console[a0_0x35372f(0x158)]('Daisy:\x20' + flowerMeaning('Daisy')), console[a0_0x35372f(0x158)]('Tulip:\x20' + flowerMeaning('Tulip')), console[a0_0x35372f(0x158)](a0_0x35372f(0x162) + flowerMeaning(a0_0x35372f(0x164)));