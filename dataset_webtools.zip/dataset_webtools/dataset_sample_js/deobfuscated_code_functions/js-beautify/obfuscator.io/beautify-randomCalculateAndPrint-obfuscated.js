(function(_0x336063, _0x15b75a) {
    const _0xe0af07 = a0_0x4cdc,
        _0x3ae0b6 = _0x336063();
    while (!![]) {
        try {
            const _0x16a529 = parseInt(_0xe0af07(0x1b2)) / 0x1 * (parseInt(_0xe0af07(0x1ab)) / 0x2) + parseInt(_0xe0af07(0x1ae)) / 0x3 + -parseInt(_0xe0af07(0x1a4)) / 0x4 * (-parseInt(_0xe0af07(0x1a9)) / 0x5) + -parseInt(_0xe0af07(0x1aa)) / 0x6 * (parseInt(_0xe0af07(0x1a8)) / 0x7) + parseInt(_0xe0af07(0x1af)) / 0x8 + parseInt(_0xe0af07(0x1a6)) / 0x9 * (-parseInt(_0xe0af07(0x1ac)) / 0xa) + parseInt(_0xe0af07(0x1ad)) / 0xb * (parseInt(_0xe0af07(0x1a5)) / 0xc);
            if (_0x16a529 === _0x15b75a) break;
            else _0x3ae0b6['push'](_0x3ae0b6['shift']());
        } catch (_0x39ce2c) {
            _0x3ae0b6['push'](_0x3ae0b6['shift']());
        }
    }
}(a0_0x5970, 0x4ce38));

function randomCalculateAndPrint(_0x277f48, _0x245e8a) {
    const _0x4e787b = a0_0x4cdc;
    let _0x318662 = ['+', '-', '*', '/'][Math[_0x4e787b(0x1a3)](Math[_0x4e787b(0x1b1)]() * 0x4)],
        _0x21c7ff;
    switch (_0x318662) {
        case '+':
            _0x21c7ff = _0x277f48 + _0x245e8a;
            break;
        case '-':
            _0x21c7ff = _0x277f48 - _0x245e8a;
            break;
        case '*':
            _0x21c7ff = _0x277f48 * _0x245e8a;
            break;
        case '/':
            _0x21c7ff = _0x277f48 / _0x245e8a;
            break;
    }
    console[_0x4e787b(0x1b0)](_0x277f48 + '\x20' + _0x318662 + '\x20' + _0x245e8a + _0x4e787b(0x1a7) + _0x21c7ff);
}

function a0_0x4cdc(_0x3f201f, _0x502f2f) {
    const _0x597041 = a0_0x5970();
    return a0_0x4cdc = function(_0x4cdcbb, _0x8deb43) {
        _0x4cdcbb = _0x4cdcbb - 0x1a3;
        let _0x3b3572 = _0x597041[_0x4cdcbb];
        return _0x3b3572;
    }, a0_0x4cdc(_0x3f201f, _0x502f2f);
}
randomCalculateAndPrint(0xa, 0x5);

function a0_0x5970() {
    const _0x257578 = ['2265376sLvWFL', 'log', 'random', '1uGOzcw', 'floor', '17276nfqYBX', '3840JnGBmT', '2153106lsJmiZ', '\x20=\x20', '3155068SPmgbV', '585ykUjrs', '6ULBsST', '132726WnfFHa', '20Uzxkcj', '7810wXjoVQ', '486210NbTsaI'];
    a0_0x5970 = function() {
        return _0x257578;
    };
    return a0_0x5970();
}