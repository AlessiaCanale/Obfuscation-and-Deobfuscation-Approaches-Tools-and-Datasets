const a0_0x263bb0 = a0_0x4c80;
(function(_0x2cc66e, _0x398d33) {
    const _0x4ac97e = a0_0x4c80,
        _0x1a628b = _0x2cc66e();
    while (!![]) {
        try {
            const _0x459fda = -parseInt(_0x4ac97e(0x173)) / 0x1 + parseInt(_0x4ac97e(0x17a)) / 0x2 + -parseInt(_0x4ac97e(0x178)) / 0x3 + -parseInt(_0x4ac97e(0x177)) / 0x4 + -parseInt(_0x4ac97e(0x176)) / 0x5 + -parseInt(_0x4ac97e(0x171)) / 0x6 + parseInt(_0x4ac97e(0x174)) / 0x7;
            if (_0x459fda === _0x398d33) break;
            else _0x1a628b['push'](_0x1a628b['shift']());
        } catch (_0x47a56a) {
            _0x1a628b['push'](_0x1a628b['shift']());
        }
    }
}(a0_0x4e21, 0x655e0));

function a0_0x4c80(_0x25d548, _0x3f528f) {
    const _0x4e21ed = a0_0x4e21();
    return a0_0x4c80 = function(_0x4c80f0, _0x4d2b16) {
        _0x4c80f0 = _0x4c80f0 - 0x16f;
        let _0x2b967b = _0x4e21ed[_0x4c80f0];
        return _0x2b967b;
    }, a0_0x4c80(_0x25d548, _0x3f528f);
}

function a0_0x4e21() {
    const _0x5c6108 = ['length', '122567PYbTiO', '10163615uqcNKn', 'short', '3249210lcwSiP', '273716pJFott', '1200018zIBjOa', 'imagine\x20all\x20the\x20people\x20living\x20life\x20in\x20peace', '1464054vTLuyB', 'repeat', 'log', '3167568CUNJvj'];
    a0_0x4e21 = function() {
        return _0x5c6108;
    };
    return a0_0x4e21();
}

function aboveAndUnderlineTheSentence(_0x3a1d93) {
    const _0x4f8a7a = a0_0x4c80,
        _0x18f507 = _0x3a1d93[_0x4f8a7a(0x172)],
        _0xc02fef = '_' [_0x4f8a7a(0x16f)](_0x18f507),
        _0x5220a3 = '-' [_0x4f8a7a(0x16f)](_0x18f507);
    console[_0x4f8a7a(0x170)](_0xc02fef), console[_0x4f8a7a(0x170)](_0x3a1d93), console[_0x4f8a7a(0x170)](_0x5220a3);
}
console[a0_0x263bb0(0x170)]('Testing\x20with\x20different\x20sentences:'), aboveAndUnderlineTheSentence(a0_0x263bb0(0x179)), aboveAndUnderlineTheSentence(a0_0x263bb0(0x175)), aboveAndUnderlineTheSentence('This\x20is\x20a\x20longer\x20sentence\x20to\x20test\x20the\x20function.');