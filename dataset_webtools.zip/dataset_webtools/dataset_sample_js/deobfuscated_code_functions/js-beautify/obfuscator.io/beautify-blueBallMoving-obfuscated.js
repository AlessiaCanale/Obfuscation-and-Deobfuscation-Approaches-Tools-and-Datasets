const a0_0x3bbf2a = a0_0x5db9;

function a0_0x3b53() {
    const _0x40ff6e = ['clearRect', '836205fXWVzC', '15235596XOlvgN', 'fill', '3528864AIPZoT', '1694935ESIXxv', 'mouseover', 'beginPath', 'radius', '339828fxpFlp', 'cancelAnimationFrame', 'arc', 'addEventListener', '328JoBeMg', 'getContext', 'mouseout', 'width', '1218444sjdCtL', 'getElementById', 'canvas', '2eSNWTo', 'height', 'color', 'draw', '31955Zdrsin'];
    a0_0x3b53 = function() {
        return _0x40ff6e;
    };
    return a0_0x3b53();
}(function(_0x12b767, _0x38f7eb) {
    const _0x56f7ea = a0_0x5db9,
        _0xf1b418 = _0x12b767();
    while (!![]) {
        try {
            const _0x1d8630 = -parseInt(_0x56f7ea(0x174)) / 0x1 + parseInt(_0x56f7ea(0x16e)) / 0x2 * (-parseInt(_0x56f7ea(0x184)) / 0x3) + -parseInt(_0x56f7ea(0x17c)) / 0x4 + -parseInt(_0x56f7ea(0x178)) / 0x5 + parseInt(_0x56f7ea(0x177)) / 0x6 + -parseInt(_0x56f7ea(0x172)) / 0x7 * (parseInt(_0x56f7ea(0x180)) / 0x8) + parseInt(_0x56f7ea(0x175)) / 0x9;
            if (_0x1d8630 === _0x38f7eb) break;
            else _0xf1b418['push'](_0xf1b418['shift']());
        } catch (_0x54f7bf) {
            _0xf1b418['push'](_0xf1b418['shift']());
        }
    }
}(a0_0x3b53, 0x68606));

function a0_0x5db9(_0x39dea7, _0x1450f0) {
    const _0x3b530c = a0_0x3b53();
    return a0_0x5db9 = function(_0x5db94d, _0x16d5d4) {
        _0x5db94d = _0x5db94d - 0x16d;
        let _0x347baa = _0x3b530c[_0x5db94d];
        return _0x347baa;
    }, a0_0x5db9(_0x39dea7, _0x1450f0);
}
const canvas = document[a0_0x3bbf2a(0x185)](a0_0x3bbf2a(0x16d)),
    ctx = canvas[a0_0x3bbf2a(0x181)]('2d');
let raf;
const ball = {
    'x': 0x64,
    'y': 0x64,
    'vx': 0x5,
    'vy': 0x2,
    'radius': 0x19,
    'color': 'blue',
    'draw'() {
        const _0x358a20 = a0_0x3bbf2a;
        ctx[_0x358a20(0x17a)](), ctx[_0x358a20(0x17e)](this['x'], this['y'], this[_0x358a20(0x17b)], 0x0, Math['PI'] * 0x2, !![]), ctx['closePath'](), ctx['fillStyle'] = this[_0x358a20(0x170)], ctx[_0x358a20(0x176)]();
    }
};

function draw() {
    const _0x4b8daa = a0_0x3bbf2a;
    ctx[_0x4b8daa(0x173)](0x0, 0x0, canvas[_0x4b8daa(0x183)], canvas[_0x4b8daa(0x16f)]), ball[_0x4b8daa(0x171)](), ball['x'] += ball['vx'], ball['y'] += ball['vy'], (ball['y'] + ball['vy'] > canvas[_0x4b8daa(0x16f)] - ball[_0x4b8daa(0x17b)] || ball['y'] + ball['vy'] < ball[_0x4b8daa(0x17b)]) && (ball['vy'] = -ball['vy']), (ball['x'] + ball['vx'] > canvas['width'] - ball[_0x4b8daa(0x17b)] || ball['x'] + ball['vx'] < ball[_0x4b8daa(0x17b)]) && (ball['vx'] = -ball['vx']), raf = window['requestAnimationFrame'](draw);
}
canvas[a0_0x3bbf2a(0x17f)](a0_0x3bbf2a(0x179), _0x184d0f => {
    raf = window['requestAnimationFrame'](draw);
}), canvas[a0_0x3bbf2a(0x17f)](a0_0x3bbf2a(0x182), _0x415a41 => {
    const _0x2dbc51 = a0_0x3bbf2a;
    window[_0x2dbc51(0x17d)](raf);
}), ball[a0_0x3bbf2a(0x171)]();