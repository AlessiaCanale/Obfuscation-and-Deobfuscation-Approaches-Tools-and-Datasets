(function(_0x599d84, _0x1b9787) {
    const _0xd5d95e = a0_0x35cd,
        _0x4b6f37 = _0x599d84();
    while (!![]) {
        try {
            const _0x3f3557 = -parseInt(_0xd5d95e(0x1d8)) / 0x1 + -parseInt(_0xd5d95e(0x1d9)) / 0x2 + -parseInt(_0xd5d95e(0x1e0)) / 0x3 + -parseInt(_0xd5d95e(0x1e1)) / 0x4 + parseInt(_0xd5d95e(0x1d7)) / 0x5 * (parseInt(_0xd5d95e(0x1da)) / 0x6) + parseInt(_0xd5d95e(0x1db)) / 0x7 * (-parseInt(_0xd5d95e(0x1d6)) / 0x8) + parseInt(_0xd5d95e(0x1dd)) / 0x9;
            if (_0x3f3557 === _0x1b9787) break;
            else _0x4b6f37['push'](_0x4b6f37['shift']());
        } catch (_0x4f41df) {
            _0x4b6f37['push'](_0x4b6f37['shift']());
        }
    }
}(a0_0xd526, 0x7cb5e));

function motivationalMessage(_0x2ee685) {
    const _0x255d0e = a0_0x35cd,
        _0x4570a5 = ['Believe\x20you\x20can\x20and\x20you\x27re\x20halfway\x20there.', _0x255d0e(0x1df), 'The\x20only\x20way\x20to\x20do\x20great\x20work\x20is\x20to\x20love\x20what\x20you\x20do.', _0x255d0e(0x1dc), _0x255d0e(0x1d5)];
    if (_0x2ee685 < 0x0) {
        const _0x24c4f3 = Math['floor'](Math['random']() * _0x4570a5[_0x255d0e(0x1de)]);
        return _0x4570a5[_0x24c4f3];
    } else return 'Your\x20smile\x20is\x20great,\x20ask\x20me\x20when\x20you\x20need\x20motivation!';
}
const result1 = motivationalMessage(-0x2),
    result2 = motivationalMessage(0x7);

function a0_0x35cd(_0x2cedf8, _0x505fbd) {
    const _0xd5261b = a0_0xd526();
    return a0_0x35cd = function(_0x35cdb3, _0x2893b0) {
        _0x35cdb3 = _0x35cdb3 - 0x1d5;
        let _0x4c8a62 = _0xd5261b[_0x35cdb3];
        return _0x4c8a62;
    }, a0_0x35cd(_0x2cedf8, _0x505fbd);
}
console['log'](result1), console['log'](result2);

function a0_0xd526() {
    const _0x2a62f9 = ['2037042ozStEj', '2452536rDtdgu', 'The\x20future\x20belongs\x20to\x20those\x20who\x20believe\x20in\x20the\x20beauty\x20of\x20their\x20dreams.', '7081032eFbYCk', '1967785DlnJDn', '850065vuuCBr', '1975030kSRolc', '12mypunV', '7weusZy', 'Don\x27t\x20watch\x20the\x20clock;\x20do\x20what\x20it\x20does.\x20Keep\x20going.', '33647013KMtDHQ', 'length', 'Success\x20is\x20not\x20the\x20key\x20to\x20happiness.\x20Happiness\x20is\x20the\x20key\x20to\x20success.\x20If\x20you\x20love\x20what\x20you\x20are\x20doing,\x20you\x20will\x20be\x20successful.'];
    a0_0xd526 = function() {
        return _0x2a62f9;
    };
    return a0_0xd526();
}