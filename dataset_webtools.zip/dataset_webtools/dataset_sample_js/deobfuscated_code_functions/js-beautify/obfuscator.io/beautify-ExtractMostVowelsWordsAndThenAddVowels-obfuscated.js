const a0_0x6b2377 = a0_0xe2b9;

function a0_0xe2b9(_0x222310, _0x416aba) {
    const _0x167dea = a0_0x167d();
    return a0_0xe2b9 = function(_0xe2b977, _0x4a0cb5) {
        _0xe2b977 = _0xe2b977 - 0x149;
        let _0x305d8a = _0x167dea[_0xe2b977];
        return _0x305d8a;
    }, a0_0xe2b9(_0x222310, _0x416aba);
}

function a0_0x167d() {
    const _0x4b4efa = ['Words\x20with\x20the\x20most\x20vowels:', '300rkThDE', 'Transformed\x20Text:', 'forEach', 'split', 'log', 'Original\x20Text:', '7xXGSoN', '2577WWehho', '2958ohxUxK', '6465410hgwbaH', '8520424iUuVZc', 'push', 'join', '5784ZmYFiK', '8746806ZBMaSU', 'length', '1668810Xjvtwa', '6749046nZxRMk', '331aFOAeq', 'Luscious\x20ferns\x20sway\x20gently\x20under\x20the\x20moonlit\x20sky,\x20whispering\x20secrets\x20of\x20the\x20mystical\x20forest\x20to\x20the\x20vibrant\x20flowers\x20below.'];
    a0_0x167d = function() {
        return _0x4b4efa;
    };
    return a0_0x167d();
}(function(_0x50d4f5, _0x3e83cd) {
    const _0x470bec = a0_0xe2b9,
        _0xd9997e = _0x50d4f5();
    while (!![]) {
        try {
            const _0xac08a6 = -parseInt(_0x470bec(0x158)) / 0x1 * (parseInt(_0x470bec(0x14e)) / 0x2) + -parseInt(_0x470bec(0x14d)) / 0x3 * (-parseInt(_0x470bec(0x153)) / 0x4) + -parseInt(_0x470bec(0x14f)) / 0x5 + parseInt(_0x470bec(0x154)) / 0x6 * (-parseInt(_0x470bec(0x14c)) / 0x7) + -parseInt(_0x470bec(0x150)) / 0x8 + -parseInt(_0x470bec(0x157)) / 0x9 + -parseInt(_0x470bec(0x15b)) / 0xa * (-parseInt(_0x470bec(0x156)) / 0xb);
            if (_0xac08a6 === _0x3e83cd) break;
            else _0xd9997e['push'](_0xd9997e['shift']());
        } catch (_0x46d56e) {
            _0xd9997e['push'](_0xd9997e['shift']());
        }
    }
}(a0_0x167d, 0xb42f3));

function ExtractMostVowelsWordsAndThenAddVowels(_0x971d19) {
    const _0x3a50f2 = a0_0xe2b9,
        _0xb3b420 = _0x971d19[_0x3a50f2(0x149)]('\x20');
    let _0xb04050 = 0x0,
        _0x8d4898 = [];
    _0xb3b420[_0x3a50f2(0x15d)](_0x4f8e17 => {
        const _0x596696 = _0x3a50f2,
            _0x9cb5e7 = _0x4f8e17['match'](/[aeiou]/gi),
            _0x364a59 = _0x9cb5e7 ? _0x9cb5e7[_0x596696(0x155)] : 0x0;
        if (_0x364a59 > _0xb04050) _0xb04050 = _0x364a59, _0x8d4898 = [_0x4f8e17];
        else _0x364a59 === _0xb04050 && _0x8d4898[_0x596696(0x151)](_0x4f8e17);
    });
    const _0x3d9ea2 = _0xb3b420['map'](_0x1ee6d0 => {
        const _0x1c2ebe = _0x3a50f2,
            _0x3a54dd = _0x1ee6d0['match'](/[aeiou]/gi),
            _0x3b4fe8 = _0x3a54dd ? _0xb04050 - _0x3a54dd['length'] : 0x0,
            _0x497b1a = ['a', 'e', 'i', 'o', 'u'];
        let _0x5de8f6 = _0x1ee6d0;
        for (let _0x173116 = 0x0; _0x173116 < _0x3b4fe8; _0x173116++) {
            _0x5de8f6 += _0x497b1a[_0x173116 % _0x497b1a[_0x1c2ebe(0x155)]];
        }
        return _0x5de8f6;
    })[_0x3a50f2(0x152)]('\x20');
    console[_0x3a50f2(0x14a)](_0x3a50f2(0x14b), _0x971d19), console['log'](_0x3a50f2(0x15a), _0x8d4898), console[_0x3a50f2(0x14a)]('Number\x20of\x20vowels:', _0xb04050), console[_0x3a50f2(0x14a)](_0x3a50f2(0x15c), _0x3d9ea2);
}
const text = a0_0x6b2377(0x159);
ExtractMostVowelsWordsAndThenAddVowels(text);