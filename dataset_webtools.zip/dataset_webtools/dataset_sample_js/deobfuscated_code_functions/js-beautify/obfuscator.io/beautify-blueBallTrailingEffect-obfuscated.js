function a0_0xc8f4(_0x3de59f, _0x1364af) {
    const _0x3e1bdc = a0_0x3e1b();
    return a0_0xc8f4 = function(_0xc8f456, _0x14fd60) {
        _0xc8f456 = _0xc8f456 - 0xd8;
        let _0x228c48 = _0x3e1bdc[_0xc8f456];
        return _0x228c48;
    }, a0_0xc8f4(_0x3de59f, _0x1364af);
}

function a0_0x3e1b() {
    const _0x4dc43b = ['8JoIaTy', 'fillRect', '11412400mXOxhh', 'getContext', 'color', 'radius', '403505iTjtnC', '5593796fBUiBr', 'mouseover', 'closePath', 'getElementById', '9VuBmot', '17578668HfxmKZ', 'fillStyle', 'requestAnimationFrame', '1278oauHlg', 'cancelAnimationFrame', 'fill', 'height', 'beginPath', 'draw', 'blue', 'canvas', '161QgsqPT', '18375cJqOBe', 'addEventListener', 'rgb(255\x20255\x20255\x20/\x2030%)', 'mouseout', 'arc', '3vepZvL', '17995065ETOuOX', '384632GoPUfn'];
    a0_0x3e1b = function() {
        return _0x4dc43b;
    };
    return a0_0x3e1b();
}
const a0_0x70b3d7 = a0_0xc8f4;
(function(_0x903aab, _0x2accc0) {
    const _0x1d4baa = a0_0xc8f4,
        _0xc0c31d = _0x903aab();
    while (!![]) {
        try {
            const _0x283548 = parseInt(_0x1d4baa(0xf4)) / 0x1 * (-parseInt(_0x1d4baa(0xee)) / 0x2) + -parseInt(_0x1d4baa(0xeb)) / 0x3 * (parseInt(_0x1d4baa(0xf5)) / 0x4) + -parseInt(_0x1d4baa(0xe6)) / 0x5 * (-parseInt(_0x1d4baa(0xdd)) / 0x6) + parseInt(_0x1d4baa(0xe5)) / 0x7 * (parseInt(_0x1d4baa(0xed)) / 0x8) + parseInt(_0x1d4baa(0xd9)) / 0x9 * (-parseInt(_0x1d4baa(0xf0)) / 0xa) + parseInt(_0x1d4baa(0xec)) / 0xb + parseInt(_0x1d4baa(0xda)) / 0xc;
            if (_0x283548 === _0x2accc0) break;
            else _0xc0c31d['push'](_0xc0c31d['shift']());
        } catch (_0x2cab1a) {
            _0xc0c31d['push'](_0xc0c31d['shift']());
        }
    }
}(a0_0x3e1b, 0xcc067));
const canvas = document[a0_0x70b3d7(0xd8)](a0_0x70b3d7(0xe4)),
    ctx = canvas[a0_0x70b3d7(0xf1)]('2d');
let raf;
const ball = {
    'x': 0x64,
    'y': 0x64,
    'vx': 0x5,
    'vy': 0x2,
    'radius': 0x19,
    'color': a0_0x70b3d7(0xe3),
    'draw'() {
        const _0x4126be = a0_0x70b3d7;
        ctx[_0x4126be(0xe1)](), ctx[_0x4126be(0xea)](this['x'], this['y'], this[_0x4126be(0xf3)], 0x0, Math['PI'] * 0x2, !![]), ctx[_0x4126be(0xf7)](), ctx['fillStyle'] = this[_0x4126be(0xf2)], ctx[_0x4126be(0xdf)]();
    }
};

function draw() {
    const _0x346e8b = a0_0x70b3d7;
    ctx[_0x346e8b(0xdb)] = _0x346e8b(0xe8), ctx[_0x346e8b(0xef)](0x0, 0x0, canvas['width'], canvas[_0x346e8b(0xe0)]), ball['draw'](), ball['x'] += ball['vx'], ball['y'] += ball['vy'], ball['vy'] *= 0.99, ball['vy'] += 0.25, (ball['y'] + ball['vy'] > canvas['height'] - ball['radius'] || ball['y'] + ball['vy'] < ball[_0x346e8b(0xf3)]) && (ball['vy'] = -ball['vy']), (ball['x'] + ball['vx'] > canvas['width'] - ball[_0x346e8b(0xf3)] || ball['x'] + ball['vx'] < ball[_0x346e8b(0xf3)]) && (ball['vx'] = -ball['vx']), raf = window[_0x346e8b(0xdc)](draw);
}
canvas[a0_0x70b3d7(0xe7)](a0_0x70b3d7(0xf6), _0x2009b9 => {
    const _0x22b530 = a0_0x70b3d7;
    raf = window[_0x22b530(0xdc)](draw);
}), canvas[a0_0x70b3d7(0xe7)](a0_0x70b3d7(0xe9), _0x569c08 => {
    const _0x2b3617 = a0_0x70b3d7;
    window[_0x2b3617(0xde)](raf);
}), ball[a0_0x70b3d7(0xe2)]();