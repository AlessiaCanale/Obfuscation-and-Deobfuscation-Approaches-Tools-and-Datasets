(function(_0x119523, _0x50b9b1) {
    const _0x3df3f4 = a0_0x3b11,
        _0x24aff2 = _0x119523();
    while (!![]) {
        try {
            const _0x4e1e7a = parseInt(_0x3df3f4(0x162)) / 0x1 * (-parseInt(_0x3df3f4(0x16a)) / 0x2) + -parseInt(_0x3df3f4(0x16b)) / 0x3 + -parseInt(_0x3df3f4(0x164)) / 0x4 * (-parseInt(_0x3df3f4(0x169)) / 0x5) + -parseInt(_0x3df3f4(0x168)) / 0x6 + -parseInt(_0x3df3f4(0x161)) / 0x7 + -parseInt(_0x3df3f4(0x163)) / 0x8 + parseInt(_0x3df3f4(0x167)) / 0x9;
            if (_0x4e1e7a === _0x50b9b1) break;
            else _0x24aff2['push'](_0x24aff2['shift']());
        } catch (_0x26816c) {
            _0x24aff2['push'](_0x24aff2['shift']());
        }
    }
}(a0_0x2ba0, 0x9ef4d));

function a0_0x3b11(_0x2aeb48, _0x1f01d4) {
    const _0x2ba0ee = a0_0x2ba0();
    return a0_0x3b11 = function(_0x3b110c, _0x5bfe87) {
        _0x3b110c = _0x3b110c - 0x160;
        let _0x45f144 = _0x2ba0ee[_0x3b110c];
        return _0x45f144;
    }, a0_0x3b11(_0x2aeb48, _0x1f01d4);
}

function numberToLetters(_0x152130) {
    const _0x35ac88 = a0_0x3b11,
        _0xf80cc8 = {
            '1': 'a',
            '2': 'b',
            '3': 'c',
            '4': 'd',
            '5': 'e',
            '6': 'f',
            '7': 'g',
            '8': 'h',
            '9': 'i'
        },
        _0x431bc4 = _0x152130['toString']();
    let _0x86b82f = '';
    for (let _0x32df4e = 0x0; _0x32df4e < _0x431bc4[_0x35ac88(0x165)]; _0x32df4e++) {
        const _0x13a245 = _0x431bc4[_0x32df4e];
        _0x86b82f += _0xf80cc8[_0x13a245];
    }
    return console[_0x35ac88(0x166)](_0x35ac88(0x160), _0x152130), console[_0x35ac88(0x166)]('Converted\x20string:\x20', _0x86b82f), _0x86b82f;
}
const number = 0x48e1d44b,
    converted = numberToLetters(number);

function a0_0x2ba0() {
    const _0x41afb7 = ['14516010BSltCY', '1756812ixLgLE', '20IUvOGk', '618764bwZkAe', '1149873mANUad', 'Original\x20number:\x20', '1559607EDyCKB', '2kzUAcA', '4682488yeZlgM', '1141164REmnJM', 'length', 'log'];
    a0_0x2ba0 = function() {
        return _0x41afb7;
    };
    return a0_0x2ba0();
}