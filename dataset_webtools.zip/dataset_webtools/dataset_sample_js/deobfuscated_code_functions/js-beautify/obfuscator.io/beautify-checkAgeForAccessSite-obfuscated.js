(function(_0x4fd784, _0x4d44ea) {
    const _0x4aa63c = a0_0x1cf3,
        _0x41d879 = _0x4fd784();
    while (!![]) {
        try {
            const _0x35c181 = parseInt(_0x4aa63c(0x189)) / 0x1 * (-parseInt(_0x4aa63c(0x18d)) / 0x2) + -parseInt(_0x4aa63c(0x18b)) / 0x3 * (-parseInt(_0x4aa63c(0x186)) / 0x4) + parseInt(_0x4aa63c(0x193)) / 0x5 + -parseInt(_0x4aa63c(0x194)) / 0x6 + -parseInt(_0x4aa63c(0x187)) / 0x7 * (parseInt(_0x4aa63c(0x192)) / 0x8) + parseInt(_0x4aa63c(0x191)) / 0x9 * (-parseInt(_0x4aa63c(0x18c)) / 0xa) + -parseInt(_0x4aa63c(0x188)) / 0xb * (-parseInt(_0x4aa63c(0x18a)) / 0xc);
            if (_0x35c181 === _0x4d44ea) break;
            else _0x41d879['push'](_0x41d879['shift']());
        } catch (_0x37ae8d) {
            _0x41d879['push'](_0x41d879['shift']());
        }
    }
}(a0_0xae7c, 0x98276));

function checkAgeForAccessSite(_0x30d155) {
    const _0x88efcd = a0_0x1cf3;
    _0x30d155 >= 0x12 ? console[_0x88efcd(0x18e)](_0x88efcd(0x195)) : console[_0x88efcd(0x18e)](_0x88efcd(0x190)), console[_0x88efcd(0x18e)](_0x88efcd(0x18f) + _0x30d155);
}

function a0_0xae7c() {
    const _0x3539c7 = ['6BnsAQG', 'log', 'Your\x20age:\x20', 'I\x27m\x20sorry,\x20you\x20are\x20not\x20old\x20enough\x20to\x20access\x20the\x20site\x20safely\x20without\x20adult\x20supervision.\x20Please\x20come\x20back\x20when\x20you\x20are\x20at\x20least\x2018\x20years\x20old,\x20we\x27ll\x20be\x20waiting\x20for\x20you.', '1483857HthNcK', '24uwomge', '4843265zWCMKd', '6934512KhaHTo', 'Welcome!\x20Your\x20age\x20is\x20sufficient\x20to\x20access\x20the\x20site\x20safely.', '2268520hxNbHu', '1277171jzURit', '11dCWzHj', '4853JGvYUF', '15596736UKNdtd', '3TRgUMB', '30ExUROM'];
    a0_0xae7c = function() {
        return _0x3539c7;
    };
    return a0_0xae7c();
}
const userAge = 0x14;
checkAgeForAccessSite(userAge);
const userAge1 = 0x12;
checkAgeForAccessSite(userAge1);

function a0_0x1cf3(_0x336731, _0x5b2e14) {
    const _0xae7c27 = a0_0xae7c();
    return a0_0x1cf3 = function(_0x1cf34e, _0x1bd5d9) {
        _0x1cf34e = _0x1cf34e - 0x186;
        let _0x1e4423 = _0xae7c27[_0x1cf34e];
        return _0x1e4423;
    }, a0_0x1cf3(_0x336731, _0x5b2e14);
}
const userAge2 = 0x7;
checkAgeForAccessSite(userAge2);