(function(_0x1e5cae, _0x314287) {
    const _0x58a4e3 = a0_0x280f,
        _0x48231b = _0x1e5cae();
    while (!![]) {
        try {
            const _0x5ebccc = -parseInt(_0x58a4e3(0x135)) / 0x1 * (-parseInt(_0x58a4e3(0x13b)) / 0x2) + -parseInt(_0x58a4e3(0x131)) / 0x3 * (-parseInt(_0x58a4e3(0x134)) / 0x4) + -parseInt(_0x58a4e3(0x138)) / 0x5 + parseInt(_0x58a4e3(0x130)) / 0x6 * (-parseInt(_0x58a4e3(0x13a)) / 0x7) + parseInt(_0x58a4e3(0x136)) / 0x8 + parseInt(_0x58a4e3(0x13c)) / 0x9 * (-parseInt(_0x58a4e3(0x132)) / 0xa) + -parseInt(_0x58a4e3(0x133)) / 0xb;
            if (_0x5ebccc === _0x314287) break;
            else _0x48231b['push'](_0x48231b['shift']());
        } catch (_0x68ab23) {
            _0x48231b['push'](_0x48231b['shift']());
        }
    }
}(a0_0x2c03, 0xf1095));

function generateRandomBinaryNumber() {
    const _0x2cba0f = a0_0x280f;
    let _0x8ace43 = '';
    for (let _0x1f03b8 = 0x0; _0x1f03b8 < 0xa; _0x1f03b8++) {
        _0x8ace43 += Math['round'](Math['random']());
    }
    let _0x438230 = parseInt(_0x8ace43, 0x2);
    console[_0x2cba0f(0x137)]('Random\x20Binary\x20Number:\x20' + _0x8ace43), console[_0x2cba0f(0x137)](_0x2cba0f(0x139) + _0x438230);
}

function a0_0x2c03() {
    const _0x41bd35 = ['6sfyNtJ', '3Lprvkh', '186460oXOGlf', '14668291AFIlXD', '4627960qBJeCE', '715789AFwNja', '8903504jVDaZG', 'log', '475815JMQdin', 'Decimal\x20Equivalent:\x20', '1037197cBGhES', '4jIPKDY', '549ZELxIV'];
    a0_0x2c03 = function() {
        return _0x41bd35;
    };
    return a0_0x2c03();
}

function a0_0x280f(_0x453fc0, _0x132edb) {
    const _0x2c03cd = a0_0x2c03();
    return a0_0x280f = function(_0x280f91, _0x39136b) {
        _0x280f91 = _0x280f91 - 0x130;
        let _0x1795db = _0x2c03cd[_0x280f91];
        return _0x1795db;
    }, a0_0x280f(_0x453fc0, _0x132edb);
}
generateRandomBinaryNumber();