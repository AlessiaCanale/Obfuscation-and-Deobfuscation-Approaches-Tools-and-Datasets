function a0_0x9a26() {
    var _0x4ae122 = ['easOut', 'mousemove', '9183349gjLRqx', '1764117qmzCOF', '52797Vsupce', '3081600CzlcAY', '4440240cLowTd', 'pageX', '30FdAKep', '4RWUNCU', '163281FtIhGR', 'pageY', 'addClass', 'is-moving', '.cursor', '6936265DnhRZj', '4KbMmBl'];
    a0_0x9a26 = function() {
        return _0x4ae122;
    };
    return a0_0x9a26();
}
var a0_0x1f3ba8 = a0_0xa925;
(function(_0x3a98da, _0x2419fc) {
    var _0x3fbabd = a0_0xa925,
        _0x4f5323 = _0x3a98da();
    while (!![]) {
        try {
            var _0x38649e = -parseInt(_0x3fbabd(0x16c)) / 0x1 + -parseInt(_0x3fbabd(0x167)) / 0x2 * (parseInt(_0x3fbabd(0x161)) / 0x3) + parseInt(_0x3fbabd(0x171)) / 0x4 * (-parseInt(_0x3fbabd(0x166)) / 0x5) + parseInt(_0x3fbabd(0x16e)) / 0x6 + parseInt(_0x3fbabd(0x16a)) / 0x7 + -parseInt(_0x3fbabd(0x16d)) / 0x8 + parseInt(_0x3fbabd(0x16b)) / 0x9 * (parseInt(_0x3fbabd(0x170)) / 0xa);
            if (_0x38649e === _0x2419fc) break;
            else _0x4f5323['push'](_0x4f5323['shift']());
        } catch (_0x15ef26) {
            _0x4f5323['push'](_0x4f5323['shift']());
        }
    }
}(a0_0x9a26, 0xac55a));
var $cursor = $(a0_0x1f3ba8(0x165));

function moveCursor(_0x46219d) {
    var _0x449018 = a0_0x1f3ba8;
    $cursor[_0x449018(0x163)](_0x449018(0x164)), TweenLite['to']($cursor, 0.23, {
        'left': _0x46219d[_0x449018(0x16f)],
        'top': _0x46219d[_0x449018(0x162)],
        'ease': Power4[_0x449018(0x168)]
    }), clearTimeout(_0x175d5d);
    var _0x175d5d = setTimeout(function() {
        $cursor['removeClass']('is-moving');
    }, 0x12c);
}

function a0_0xa925(_0x198b04, _0x82e53f) {
    var _0x9a2640 = a0_0x9a26();
    return a0_0xa925 = function(_0xa92561, _0x30c07c) {
        _0xa92561 = _0xa92561 - 0x161;
        var _0x2f32a3 = _0x9a2640[_0xa92561];
        return _0x2f32a3;
    }, a0_0xa925(_0x198b04, _0x82e53f);
}
$(window)['on'](a0_0x1f3ba8(0x169), moveCursor);