(function(_0x14351, _0x1ec569) {
    const _0x57b781 = a0_0x379b,
        _0x38127a = _0x14351();
    while (!![]) {
        try {
            const _0x189ced = -parseInt(_0x57b781(0xe0)) / 0x1 * (-parseInt(_0x57b781(0xdf)) / 0x2) + -parseInt(_0x57b781(0xe2)) / 0x3 * (-parseInt(_0x57b781(0xe8)) / 0x4) + parseInt(_0x57b781(0xe4)) / 0x5 + parseInt(_0x57b781(0xe7)) / 0x6 + parseInt(_0x57b781(0xe6)) / 0x7 * (-parseInt(_0x57b781(0xde)) / 0x8) + parseInt(_0x57b781(0xe1)) / 0x9 + -parseInt(_0x57b781(0xdb)) / 0xa;
            if (_0x189ced === _0x1ec569) break;
            else _0x38127a['push'](_0x38127a['shift']());
        } catch (_0x196d02) {
            _0x38127a['push'](_0x38127a['shift']());
        }
    }
}(a0_0x407d, 0xd4fd6));

function a0_0x379b(_0x292895, _0x55765a) {
    const _0x407d37 = a0_0x407d();
    return a0_0x379b = function(_0x379bf9, _0x55607f) {
        _0x379bf9 = _0x379bf9 - 0xdb;
        let _0x4a453e = _0x407d37[_0x379bf9];
        return _0x4a453e;
    }, a0_0x379b(_0x292895, _0x55765a);
}

function checkEmailValidity(_0x1d868b) {
    const _0x3235c9 = a0_0x379b,
        _0x24182c = /^[a-zA-Z0-9.]+@email.com$/;
    _0x24182c[_0x3235c9(0xdd)](_0x1d868b) ? console[_0x3235c9(0xe3)](_0x1d868b + _0x3235c9(0xdc)) : console[_0x3235c9(0xe3)](_0x1d868b + _0x3235c9(0xe5));
}
checkEmailValidity('john.doe@email.com'), checkEmailValidity('jane.doe123@email.com'), checkEmailValidity('invalid.email@domain.com'), checkEmailValidity('@email.com');

function a0_0x407d() {
    const _0x3932ce = ['8YTaoyl', '2rHKwEI', '1156279BnPNao', '12131217orFAmu', '6BWaRZj', 'log', '5676810PAOUoy', '\x20is\x20NOT\x20a\x20valid\x20email.', '6003242QrKDSY', '3149310XLgWag', '2979876yCmofA', '39243650lqDQWv', '\x20is\x20a\x20valid\x20email.', 'test'];
    a0_0x407d = function() {
        return _0x3932ce;
    };
    return a0_0x407d();
}