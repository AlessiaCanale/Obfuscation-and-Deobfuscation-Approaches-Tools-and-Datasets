const a0_0x19035a = a0_0x2eec;
(function(_0x4bb567, _0x258d5a) {
    const _0x2be74d = a0_0x2eec,
        _0x14a456 = _0x4bb567();
    while (!![]) {
        try {
            const _0x2b807b = parseInt(_0x2be74d(0x1e0)) / 0x1 * (-parseInt(_0x2be74d(0x1ec)) / 0x2) + parseInt(_0x2be74d(0x1e7)) / 0x3 * (-parseInt(_0x2be74d(0x1f3)) / 0x4) + parseInt(_0x2be74d(0x1e5)) / 0x5 * (-parseInt(_0x2be74d(0x1f0)) / 0x6) + parseInt(_0x2be74d(0x1f4)) / 0x7 + -parseInt(_0x2be74d(0x1e6)) / 0x8 + parseInt(_0x2be74d(0x1e2)) / 0x9 + parseInt(_0x2be74d(0x1e3)) / 0xa;
            if (_0x2b807b === _0x258d5a) break;
            else _0x14a456['push'](_0x14a456['shift']());
        } catch (_0x54e141) {
            _0x14a456['push'](_0x14a456['shift']());
        }
    }
}(a0_0x3046, 0x61338));

function a0_0x3046() {
    const _0x46d7e5 = ['2072727PzzfCu', '13843530rtIjIX', 'forEach', '148145tuzruO', '5704144MloExq', '9qiwNsM', 'Text:', 'Words\x20with\x20the\x20most\x20vowels:', '-\x20Word:\x20', 'filter', '10AFkKZy', 'log', 'length', 'match', '54vrcqbT', 'This\x20is\x20a\x20sample\x20text\x20with\x20lots\x20of\x20vowels', 'push', '512852BVXAUg', '5158811XLZZxd', 'The\x20serene\x20lake\x27s\x20reflection\x20evokes\x20a\x20sense\x20of\x20pure\x20beauty.', '117835twTHhh', ',\x20Vowels:\x20'];
    a0_0x3046 = function() {
        return _0x46d7e5;
    };
    return a0_0x3046();
}

function extractWordsWithMostVowels(_0x53d727) {
    const _0x462bd1 = a0_0x2eec;
    let _0x5d5cfd = _0x53d727['split'](/\s+/)[_0x462bd1(0x1eb)](_0x3be4e6 => _0x3be4e6[_0x462bd1(0x1ef)](/[aeiou]/i)),
        _0x289dee = 0x0,
        _0x2d25df = [];
    _0x5d5cfd[_0x462bd1(0x1e4)](_0x4f69b9 => {
        const _0x627aba = _0x462bd1;
        let _0x22b13e = _0x4f69b9[_0x627aba(0x1ef)](/[aeiou]/gi)[_0x627aba(0x1ee)];
        if (_0x22b13e > _0x289dee) _0x289dee = _0x22b13e, _0x2d25df = [_0x4f69b9];
        else _0x22b13e === _0x289dee && _0x2d25df[_0x627aba(0x1f2)](_0x4f69b9);
    }), console['log'](_0x462bd1(0x1e8), _0x53d727), console['log'](_0x462bd1(0x1e9)), _0x2d25df['forEach'](_0x14041f => {
        const _0x348661 = _0x462bd1;
        console[_0x348661(0x1ed)](_0x348661(0x1ea) + _0x14041f + _0x348661(0x1e1) + _0x289dee);
    });
}

function a0_0x2eec(_0x464c66, _0x573131) {
    const _0x30467f = a0_0x3046();
    return a0_0x2eec = function(_0x2eec21, _0x322b02) {
        _0x2eec21 = _0x2eec21 - 0x1e0;
        let _0x5a6e5e = _0x30467f[_0x2eec21];
        return _0x5a6e5e;
    }, a0_0x2eec(_0x464c66, _0x573131);
}
extractWordsWithMostVowels(a0_0x19035a(0x1f1)), extractWordsWithMostVowels(a0_0x19035a(0x1f5));