function a0_0x4b61(_0x1e6bc6, _0x5f3e2e) {
    const _0x1b79b4 = a0_0x1b79();
    return a0_0x4b61 = function(_0x4b6125, _0xa724c9) {
        _0x4b6125 = _0x4b6125 - 0x142;
        let _0x3ef5f2 = _0x1b79b4[_0x4b6125];
        return _0x3ef5f2;
    }, a0_0x4b61(_0x1e6bc6, _0x5f3e2e);
}

function a0_0x1b79() {
    const _0x2ceeca = ['Nimbostratus', 'Mid-level\x20clouds\x20that\x20appear\x20as\x20white\x20or\x20gray\x20patches.', '3412131zZwLdr', '42861efEoaF', '4604uKrCqr', 'Cumulus', '9066145tyHJpV', '1704wzLjkj', 'random', 'description', 'Low,\x20gray\x20clouds\x20that\x20cover\x20the\x20sky\x20like\x20a\x20blanket.', '11163150dHRHQS', 'Thin,\x20high\x20clouds\x20that\x20often\x20cover\x20the\x20sky\x20in\x20a\x20milky\x20haze.', 'log', 'Stratus', 'Dark,\x20towering\x20clouds\x20associated\x20with\x20thunderstorms.', 'Wispy,\x20feathery\x20clouds\x20found\x20at\x20high\x20altitudes.', '144790JOZdgZ', 'name', 'Altocumulus', '24SrSISD', '11690veiZUY', 'Cirrus', 'floor', '82vyrgqR', '216YHUzHy', '6085BWzGNJ'];
    a0_0x1b79 = function() {
        return _0x2ceeca;
    };
    return a0_0x1b79();
}(function(_0x52d59b, _0x1a60f3) {
    const _0x54e2d2 = a0_0x4b61,
        _0x5be39f = _0x52d59b();
    while (!![]) {
        try {
            const _0x3004e3 = -parseInt(_0x54e2d2(0x147)) / 0x1 * (-parseInt(_0x54e2d2(0x14a)) / 0x2) + parseInt(_0x54e2d2(0x14f)) / 0x3 + parseInt(_0x54e2d2(0x151)) / 0x4 * (-parseInt(_0x54e2d2(0x14c)) / 0x5) + -parseInt(_0x54e2d2(0x158)) / 0x6 + -parseInt(_0x54e2d2(0x150)) / 0x7 * (-parseInt(_0x54e2d2(0x154)) / 0x8) + parseInt(_0x54e2d2(0x14b)) / 0x9 * (-parseInt(_0x54e2d2(0x143)) / 0xa) + parseInt(_0x54e2d2(0x153)) / 0xb * (parseInt(_0x54e2d2(0x146)) / 0xc);
            if (_0x3004e3 === _0x1a60f3) break;
            else _0x5be39f['push'](_0x5be39f['shift']());
        } catch (_0x3ec2e5) {
            _0x5be39f['push'](_0x5be39f['shift']());
        }
    }
}(a0_0x1b79, 0xea7d4));

function printCloudTypes() {
    const _0x161086 = a0_0x4b61,
        _0x422e63 = [{
            'name': _0x161086(0x152),
            'description': 'Fluffy,\x20white\x20clouds\x20often\x20seen\x20on\x20sunny\x20days.'
        }, {
            'name': _0x161086(0x148),
            'description': _0x161086(0x142)
        }, {
            'name': _0x161086(0x15b),
            'description': _0x161086(0x157)
        }, {
            'name': 'Cumulonimbus',
            'description': _0x161086(0x15c)
        }, {
            'name': _0x161086(0x145),
            'description': _0x161086(0x14e)
        }, {
            'name': _0x161086(0x14d),
            'description': 'Thick,\x20dark\x20clouds\x20that\x20bring\x20continuous\x20precipitation.'
        }, {
            'name': 'Cirrostratus',
            'description': _0x161086(0x159)
        }, {
            'name': 'Stratocumulus',
            'description': 'Low,\x20lumpy\x20clouds\x20that\x20can\x20appear\x20in\x20rows\x20or\x20patches.'
        }],
        _0x409425 = Math[_0x161086(0x149)](Math[_0x161086(0x155)]() * _0x422e63['length']),
        _0x595252 = _0x422e63[_0x409425];
    console[_0x161086(0x15a)](_0x595252[_0x161086(0x144)] + ':\x20' + _0x595252[_0x161086(0x156)]);
}
printCloudTypes();