const a0_0x236dca = a0_0x1a08;

function a0_0xacc9() {
    const _0x5b9dc4 = ['1657715ukNEAV', '272560ijHpSN', '7131790sTVxJS', 'match', '1477068CptnGA', '147GwtmZZ', 'log', '234MZYhIc', '66ZHZoEd', '62529hHtExG', 'Lorem\x20Ipsum\x20is\x20simply\x20dummy\x20text\x20of\x20the\x20printing\x20and\x20typesetting\x20industry.\x20It\x20has\x20survived\x20not\x20only\x20five\x20centuries,\x20but\x20also\x20the\x20leap\x20into\x20electronic\x20typesetting,\x20remaining\x20essentially\x20unchanged.\x20It\x20was\x20popularised\x20in\x20the\x201960s\x20with\x20the\x20release\x20of\x20Letraset\x20sheets\x20containing\x20Lorem\x20Ipsum\x20passages,\x20and\x20more\x20recently\x20with\x20desktop\x20publishing\x20software\x20like\x20Aldus\x20PageMaker\x20including\x20versions\x20of\x20Lorem\x20Ipsum.', '121bexisR', '35177swScnP', '396270sVkEjb', '76tQoWSQ'];
    a0_0xacc9 = function() {
        return _0x5b9dc4;
    };
    return a0_0xacc9();
}(function(_0x3b8f74, _0x277764) {
    const _0x401be9 = a0_0x1a08,
        _0x4fd725 = _0x3b8f74();
    while (!![]) {
        try {
            const _0x4d2f0f = parseInt(_0x401be9(0xe4)) / 0x1 * (parseInt(_0x401be9(0xe0)) / 0x2) + -parseInt(_0x401be9(0xe1)) / 0x3 * (parseInt(_0x401be9(0xd7)) / 0x4) + parseInt(_0x401be9(0xd8)) / 0x5 + -parseInt(_0x401be9(0xd6)) / 0x6 * (-parseInt(_0x401be9(0xdd)) / 0x7) + -parseInt(_0x401be9(0xd9)) / 0x8 * (parseInt(_0x401be9(0xdf)) / 0x9) + parseInt(_0x401be9(0xda)) / 0xa + -parseInt(_0x401be9(0xe3)) / 0xb * (parseInt(_0x401be9(0xdc)) / 0xc);
            if (_0x4d2f0f === _0x277764) break;
            else _0x4fd725['push'](_0x4fd725['shift']());
        } catch (_0x143420) {
            _0x4fd725['push'](_0x4fd725['shift']());
        }
    }
}(a0_0xacc9, 0xe9914));

function a0_0x1a08(_0x7aead, _0x8a4c4c) {
    const _0xacc978 = a0_0xacc9();
    return a0_0x1a08 = function(_0x1a0811, _0x2f4463) {
        _0x1a0811 = _0x1a0811 - 0xd6;
        let _0x65520c = _0xacc978[_0x1a0811];
        return _0x65520c;
    }, a0_0x1a08(_0x7aead, _0x8a4c4c);
}

function findCapitalWords(_0x5101cc) {
    const _0x526e01 = a0_0x1a08,
        _0xf82b6f = _0x5101cc[_0x526e01(0xdb)](/\b[A-Z][a-z]*\b/g);
    console[_0x526e01(0xde)]('Text:\x20', _0x5101cc), console['log']('Capital\x20Words:\x20', _0xf82b6f);
}
const text = a0_0x236dca(0xe2);
findCapitalWords(text);