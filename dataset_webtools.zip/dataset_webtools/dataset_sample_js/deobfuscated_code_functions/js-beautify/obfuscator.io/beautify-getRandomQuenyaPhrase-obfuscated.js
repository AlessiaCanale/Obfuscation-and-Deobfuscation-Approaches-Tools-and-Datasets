(function(_0x419749, _0xb836a9) {
    const _0x3eb832 = a0_0x434f,
        _0x467e0e = _0x419749();
    while (!![]) {
        try {
            const _0xf7da2f = parseInt(_0x3eb832(0x1cb)) / 0x1 + -parseInt(_0x3eb832(0x1d4)) / 0x2 + -parseInt(_0x3eb832(0x1dd)) / 0x3 + parseInt(_0x3eb832(0x1cd)) / 0x4 + -parseInt(_0x3eb832(0x1d2)) / 0x5 * (-parseInt(_0x3eb832(0x1d7)) / 0x6) + -parseInt(_0x3eb832(0x1db)) / 0x7 + parseInt(_0x3eb832(0x1cf)) / 0x8;
            if (_0xf7da2f === _0xb836a9) break;
            else _0x467e0e['push'](_0x467e0e['shift']());
        } catch (_0x2542f3) {
            _0x467e0e['push'](_0x467e0e['shift']());
        }
    }
}(a0_0x505a, 0x9a423));

function getRandomQuenyaPhrase() {
    const _0x14b6c6 = a0_0x434f,
        _0xd903dd = [{
            'phrase': _0x14b6c6(0x1d9),
            'translation': _0x14b6c6(0x1d8)
        }, {
            'phrase': _0x14b6c6(0x1e2),
            'translation': _0x14b6c6(0x1e3)
        }, {
            'phrase': 'etta\x20calaciryo\x20míri\x20oialë',
            'translation': _0x14b6c6(0x1ce)
        }, {
            'phrase': _0x14b6c6(0x1cc),
            'translation': _0x14b6c6(0x1d0)
        }, {
            'phrase': _0x14b6c6(0x1d3),
            'translation': _0x14b6c6(0x1d1)
        }, {
            'phrase': _0x14b6c6(0x1dc),
            'translation': 'ring,\x20love,\x20forgiveness'
        }, {
            'phrase': _0x14b6c6(0x1de),
            'translation': _0x14b6c6(0x1df)
        }],
        _0x3a01c3 = Math[_0x14b6c6(0x1ca)](Math[_0x14b6c6(0x1e1)]() * _0xd903dd[_0x14b6c6(0x1da)]),
        _0x4048f4 = _0xd903dd[_0x3a01c3];
    console[_0x14b6c6(0x1e0)]('Random\x20Quenya\x20Phrase:\x20' + _0x4048f4[_0x14b6c6(0x1d5)]), console[_0x14b6c6(0x1e0)]('Translation:\x20' + _0x4048f4[_0x14b6c6(0x1d6)]);
}

function a0_0x505a() {
    const _0xd583cc = ['the\x20path\x20is\x20made\x20by\x20walking', '676296JOjYSc', 'glory\x20is\x20before', 'out\x20of\x20the\x20darkness', '25sfMpYO', 'auta\x20i\x20lóme', '144764zLlCwh', 'phrase', 'translation', '908124ArNBfe', 'be\x20well', 'namárië', 'length', '6047132XQQNXZ', 'nenya,\x20mérë,\x20maitimo', '242271rUiSvv', 'enyalie', 'together', 'log', 'random', 'áre\x20tarna', 'day\x20is\x20ended', 'floor', '660860mubnRM', 'alcar\x20mi\x20tarmen', '586764yySudb'];
    a0_0x505a = function() {
        return _0xd583cc;
    };
    return a0_0x505a();
}

function a0_0x434f(_0x2f0062, _0x10e70f) {
    const _0x505aae = a0_0x505a();
    return a0_0x434f = function(_0x434f57, _0x466cf6) {
        _0x434f57 = _0x434f57 - 0x1ca;
        let _0x26241c = _0x505aae[_0x434f57];
        return _0x26241c;
    }, a0_0x434f(_0x2f0062, _0x10e70f);
}
getRandomQuenyaPhrase();