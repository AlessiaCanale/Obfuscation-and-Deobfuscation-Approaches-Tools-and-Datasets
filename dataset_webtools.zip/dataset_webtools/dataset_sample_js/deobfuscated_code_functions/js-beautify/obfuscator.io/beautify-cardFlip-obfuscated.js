var a0_0x2bbbe5 = a0_0xb09b;
(function(_0xb9158c, _0x144688) {
    var _0x1ee3b5 = a0_0xb09b,
        _0x870209 = _0xb9158c();
    while (!![]) {
        try {
            var _0xa94461 = -parseInt(_0x1ee3b5(0x1d3)) / 0x1 + parseInt(_0x1ee3b5(0x1d7)) / 0x2 + parseInt(_0x1ee3b5(0x1d5)) / 0x3 + parseInt(_0x1ee3b5(0x1d0)) / 0x4 * (parseInt(_0x1ee3b5(0x1d2)) / 0x5) + parseInt(_0x1ee3b5(0x1d8)) / 0x6 + -parseInt(_0x1ee3b5(0x1d1)) / 0x7 + -parseInt(_0x1ee3b5(0x1ce)) / 0x8;
            if (_0xa94461 === _0x144688) break;
            else _0x870209['push'](_0x870209['shift']());
        } catch (_0x55dcb3) {
            _0x870209['push'](_0x870209['shift']());
        }
    }
}(a0_0x49a3, 0xa285f));

function a0_0x49a3() {
    var _0x176685 = ['5888772CzbhKg', 'querySelector', '10782104kLihZe', '.card', '8hmTsea', '2222759TCfoBa', '2355800RYJRmg', '1184308rOFFxi', 'click', '2750232OdUdws', 'addEventListener', '1349554QmMpEi'];
    a0_0x49a3 = function() {
        return _0x176685;
    };
    return a0_0x49a3();
}

function a0_0xb09b(_0x39b289, _0x1d278b) {
    var _0x49a3bf = a0_0x49a3();
    return a0_0xb09b = function(_0xb09bc7, _0x53fce8) {
        _0xb09bc7 = _0xb09bc7 - 0x1ce;
        var _0x547039 = _0x49a3bf[_0xb09bc7];
        return _0x547039;
    }, a0_0xb09b(_0x39b289, _0x1d278b);
}
var card = document[a0_0x2bbbe5(0x1d9)](a0_0x2bbbe5(0x1cf)),
    playing = ![];
card[a0_0x2bbbe5(0x1d6)](a0_0x2bbbe5(0x1d4), function() {
    if (playing) return;
    playing = !![], anime({
        'targets': card,
        'scale': [{
            'value': 0x1
        }, {
            'value': 1.4
        }, {
            'value': 0x1,
            'delay': 0xfa
        }],
        'rotateY': {
            'value': '+=180',
            'delay': 0xc8
        },
        'easing': 'easeInOutSine',
        'duration': 0x190,
        'complete': function(_0x2557ef) {
            playing = ![];
        }
    });
});