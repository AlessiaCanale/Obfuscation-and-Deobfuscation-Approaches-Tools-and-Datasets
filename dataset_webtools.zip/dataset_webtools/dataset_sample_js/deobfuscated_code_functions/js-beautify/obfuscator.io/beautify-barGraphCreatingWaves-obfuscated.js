function a0_0x4ded(_0x281e27, _0x43d7f0) {
    var _0xc61495 = a0_0xc614();
    return a0_0x4ded = function(_0x4ded9, _0x4581fe) {
        _0x4ded9 = _0x4ded9 - 0x114;
        var _0x4e34a4 = _0xc61495[_0x4ded9];
        return _0x4e34a4;
    }, a0_0x4ded(_0x281e27, _0x43d7f0);
}
var a0_0x3ff4d0 = a0_0x4ded;

function a0_0xc614() {
    var _0x172b67 = ['linear', '1523230ymPnpg', '604OTeECV', '195354ukEAYO', ',150)', 'rgb(200,', '49gpKxxW', 'setAttribute', 'stroke-dasharray', 'alternate', '411258WeuZnp', '692991rKhfOz', '12040EqSrDb', 'getTotalLength', '766EDPsUd', '1980368EyiVHe', 'path', '25jPvpqC'];
    a0_0xc614 = function() {
        return _0x172b67;
    };
    return a0_0xc614();
}(function(_0x49a1cb, _0xf5e784) {
    var _0x3cad44 = a0_0x4ded,
        _0x2de87d = _0x49a1cb();
    while (!![]) {
        try {
            var _0x2387cc = parseInt(_0x3cad44(0x11a)) / 0x1 * (parseInt(_0x3cad44(0x114)) / 0x2) + -parseInt(_0x3cad44(0x122)) / 0x3 + -parseInt(_0x3cad44(0x124)) / 0x4 * (parseInt(_0x3cad44(0x117)) / 0x5) + parseInt(_0x3cad44(0x11b)) / 0x6 * (parseInt(_0x3cad44(0x11e)) / 0x7) + -parseInt(_0x3cad44(0x115)) / 0x8 + -parseInt(_0x3cad44(0x123)) / 0x9 + parseInt(_0x3cad44(0x119)) / 0xa;
            if (_0x2387cc === _0xf5e784) break;
            else _0x2de87d['push'](_0x2de87d['shift']());
        } catch (_0x51d9da) {
            _0x2de87d['push'](_0x2de87d['shift']());
        }
    }
}(a0_0xc614, 0x20ee7), anime({
    'targets': a0_0x3ff4d0(0x116),
    'strokeDashoffset': function(_0x1abd25) {
        var _0x27bc9d = a0_0x3ff4d0,
            _0x336fee = _0x1abd25[_0x27bc9d(0x125)]();
        return _0x1abd25[_0x27bc9d(0x11f)](_0x27bc9d(0x120), _0x336fee), [-_0x336fee, 0x0];
    },
    'stroke': {
        'value': function(_0xa01874, _0x6555f9) {
            var _0x4aeeb6 = a0_0x3ff4d0;
            return _0x4aeeb6(0x11d) + _0x6555f9 * 0x8 + _0x4aeeb6(0x11c);
        },
        'easing': 'linear',
        'duration': 0x7d0
    },
    'strokeWidth': {
        'value': 0x6,
        'easing': a0_0x3ff4d0(0x118),
        'delay': function(_0x2ef24c, _0x121a15) {
            return 0x4b0 + _0x121a15 * 0x28;
        },
        'duration': 0x320
    },
    'delay': function(_0x486b7b, _0x4832a9) {
        return _0x4832a9 * 0x3c;
    },
    'duration': 0x4b0,
    'easing': 'easeOutExpo',
    'loop': !![],
    'direction': a0_0x3ff4d0(0x121)
}));