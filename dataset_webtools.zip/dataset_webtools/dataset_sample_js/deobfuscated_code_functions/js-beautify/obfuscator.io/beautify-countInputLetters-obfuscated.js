(function(_0x3c3ba4, _0x2a4fee) {
    const _0x496a9c = a0_0x249e,
        _0x568d81 = _0x3c3ba4();
    while (!![]) {
        try {
            const _0x498cfd = -parseInt(_0x496a9c(0x73)) / 0x1 + -parseInt(_0x496a9c(0x72)) / 0x2 + parseInt(_0x496a9c(0x69)) / 0x3 * (parseInt(_0x496a9c(0x74)) / 0x4) + -parseInt(_0x496a9c(0x6e)) / 0x5 + parseInt(_0x496a9c(0x71)) / 0x6 * (parseInt(_0x496a9c(0x6c)) / 0x7) + parseInt(_0x496a9c(0x6f)) / 0x8 * (parseInt(_0x496a9c(0x68)) / 0x9) + parseInt(_0x496a9c(0x70)) / 0xa * (parseInt(_0x496a9c(0x6d)) / 0xb);
            if (_0x498cfd === _0x2a4fee) break;
            else _0x568d81['push'](_0x568d81['shift']());
        } catch (_0x89b1c4) {
            _0x568d81['push'](_0x568d81['shift']());
        }
    }
}(a0_0x383b, 0xde04d));

function a0_0x249e(_0x517fcc, _0x4dfa24) {
    const _0x383bb7 = a0_0x383b();
    return a0_0x249e = function(_0x249e6b, _0x6e900f) {
        _0x249e6b = _0x249e6b - 0x67;
        let _0x4d07c2 = _0x383bb7[_0x249e6b];
        return _0x4d07c2;
    }, a0_0x249e(_0x517fcc, _0x4dfa24);
}

function countInputLetters() {
    const _0x1ee203 = a0_0x249e;
    let _0x330301 = prompt('Please\x20enter\x20a\x20string:');
    if (_0x330301) {
        let _0x815884 = _0x330301[_0x1ee203(0x75)];
        console['log'](_0x1ee203(0x6a) + _0x815884 + '\x20letters.');
    } else console[_0x1ee203(0x6b)](_0x1ee203(0x67));
}
countInputLetters();

function a0_0x383b() {
    const _0x5eacbd = ['The\x20string\x20you\x20entered\x20contains\x20', 'log', '341138DrpxMG', '9021111PWgRod', '6834800ldtSyu', '16LLacma', '10bKWOXL', '54EGNHdZ', '231190XPGIuZ', '48905dIlmWY', '397012RHXjBT', 'length', 'Invalid\x20input.\x20Please\x20try\x20again.', '4426362DFmtNu', '6YgapFB'];
    a0_0x383b = function() {
        return _0x5eacbd;
    };
    return a0_0x383b();
}