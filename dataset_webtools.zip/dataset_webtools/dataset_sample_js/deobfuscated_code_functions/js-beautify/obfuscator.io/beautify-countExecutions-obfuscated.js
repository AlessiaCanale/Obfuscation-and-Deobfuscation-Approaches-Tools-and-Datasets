(function(_0x231386, _0x5073f3) {
    const _0x5df19d = a0_0x3c30,
        _0x2d3d6d = _0x231386();
    while (!![]) {
        try {
            const _0x3db1f9 = parseInt(_0x5df19d(0x1d1)) / 0x1 * (parseInt(_0x5df19d(0x1d7)) / 0x2) + -parseInt(_0x5df19d(0x1d4)) / 0x3 * (-parseInt(_0x5df19d(0x1d5)) / 0x4) + -parseInt(_0x5df19d(0x1d2)) / 0x5 + -parseInt(_0x5df19d(0x1dd)) / 0x6 * (parseInt(_0x5df19d(0x1d3)) / 0x7) + -parseInt(_0x5df19d(0x1d9)) / 0x8 + -parseInt(_0x5df19d(0x1dc)) / 0x9 + parseInt(_0x5df19d(0x1db)) / 0xa * (parseInt(_0x5df19d(0x1d6)) / 0xb);
            if (_0x3db1f9 === _0x5073f3) break;
            else _0x2d3d6d['push'](_0x2d3d6d['shift']());
        } catch (_0x2a6152) {
            _0x2d3d6d['push'](_0x2d3d6d['shift']());
        }
    }
}(a0_0x2cce, 0xa4736));
let count = 0x0,
    firstExecutionDate = new Date();

function countExecutions() {
    const _0x566018 = a0_0x3c30;
    count++, count === 0x1 && console['log'](_0x566018(0x1d8) + firstExecutionDate), console[_0x566018(0x1da)](_0x566018(0x1de) + count);
}

function a0_0x2cce() {
    const _0x34b28a = ['8008259xGuXzy', '3672222eSkeIq', '4siwufm', '4713379fyIBiQ', '90ePuwJv', 'First\x20execution\x20date:\x20', '4908648uVaaga', 'log', '30dzEOWP', '5945121JPcHbo', '6prkNCC', 'Number\x20of\x20times\x20executed:\x20', '24569UnpdNy', '2616845vUMWWr'];
    a0_0x2cce = function() {
        return _0x34b28a;
    };
    return a0_0x2cce();
}

function a0_0x3c30(_0x1eff3a, _0x590aad) {
    const _0x2cceff = a0_0x2cce();
    return a0_0x3c30 = function(_0x3c3023, _0x345651) {
        _0x3c3023 = _0x3c3023 - 0x1d1;
        let _0x9145cd = _0x2cceff[_0x3c3023];
        return _0x9145cd;
    }, a0_0x3c30(_0x1eff3a, _0x590aad);
}
countExecutions(), countExecutions(), countExecutions();