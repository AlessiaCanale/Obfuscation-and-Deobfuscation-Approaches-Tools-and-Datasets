function a0_0x9737() {
    const _0x4c6703 = ['fill', 'getContext', 'draw', '278096xpKiHY', 'color', 'radius', '1480wJpmgt', '3594fysteO', '29WznwAf', 'canvas', '392139BValoW', '6855930KUhFmA', '27916oHLZaQ', 'beginPath', 'arc', 'getElementById', '13492MoGbJC', '402YvTpVp', 'closePath', '563935JrzBfD'];
    a0_0x9737 = function() {
        return _0x4c6703;
    };
    return a0_0x9737();
}
const a0_0x3d222f = a0_0x3f6f;

function a0_0x3f6f(_0x40168d, _0x5be1de) {
    const _0x973709 = a0_0x9737();
    return a0_0x3f6f = function(_0x3f6f57, _0x243f78) {
        _0x3f6f57 = _0x3f6f57 - 0x18c;
        let _0x4e2b70 = _0x973709[_0x3f6f57];
        return _0x4e2b70;
    }, a0_0x3f6f(_0x40168d, _0x5be1de);
}(function(_0x5510a8, _0x181ef7) {
    const _0x2d4e9a = a0_0x3f6f,
        _0x1ba7a9 = _0x5510a8();
    while (!![]) {
        try {
            const _0x158bbb = parseInt(_0x2d4e9a(0x197)) / 0x1 * (parseInt(_0x2d4e9a(0x19f)) / 0x2) + parseInt(_0x2d4e9a(0x196)) / 0x3 * (-parseInt(_0x2d4e9a(0x195)) / 0x4) + parseInt(_0x2d4e9a(0x18e)) / 0x5 + -parseInt(_0x2d4e9a(0x18c)) / 0x6 * (parseInt(_0x2d4e9a(0x19b)) / 0x7) + -parseInt(_0x2d4e9a(0x192)) / 0x8 + parseInt(_0x2d4e9a(0x199)) / 0x9 + parseInt(_0x2d4e9a(0x19a)) / 0xa;
            if (_0x158bbb === _0x181ef7) break;
            else _0x1ba7a9['push'](_0x1ba7a9['shift']());
        } catch (_0x1733e4) {
            _0x1ba7a9['push'](_0x1ba7a9['shift']());
        }
    }
}(a0_0x9737, 0x4760f));
const canvas = document[a0_0x3d222f(0x19e)](a0_0x3d222f(0x198)),
    ctx = canvas[a0_0x3d222f(0x190)]('2d'),
    ball = {
        'x': 0x64,
        'y': 0x64,
        'radius': 0x19,
        'color': 'blue',
        'draw'() {
            const _0x34c456 = a0_0x3d222f;
            ctx[_0x34c456(0x19c)](), ctx[_0x34c456(0x19d)](this['x'], this['y'], this[_0x34c456(0x194)], 0x0, Math['PI'] * 0x2, !![]), ctx[_0x34c456(0x18d)](), ctx['fillStyle'] = this[_0x34c456(0x193)], ctx[_0x34c456(0x18f)]();
        }
    };
ball[a0_0x3d222f(0x191)]();