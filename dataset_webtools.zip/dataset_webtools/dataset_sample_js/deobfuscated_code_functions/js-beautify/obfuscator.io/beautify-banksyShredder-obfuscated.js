(function(_0x583830, _0x9c3e26) {
    const _0x2abf33 = a0_0x39a5,
        _0x11bc6e = _0x583830();
    while (!![]) {
        try {
            const _0x350f4f = parseInt(_0x2abf33(0xe7)) / 0x1 + parseInt(_0x2abf33(0xe5)) / 0x2 + parseInt(_0x2abf33(0xfc)) / 0x3 + -parseInt(_0x2abf33(0xe4)) / 0x4 + parseInt(_0x2abf33(0xe2)) / 0x5 + -parseInt(_0x2abf33(0xf8)) / 0x6 * (parseInt(_0x2abf33(0xfa)) / 0x7) + -parseInt(_0x2abf33(0xf3)) / 0x8;
            if (_0x350f4f === _0x9c3e26) break;
            else _0x11bc6e['push'](_0x11bc6e['shift']());
        } catch (_0x50ee10) {
            _0x11bc6e['push'](_0x11bc6e['shift']());
        }
    }
}(a0_0xb058, 0x8e93f));

function a0_0xb058() {
    const _0x447b74 = ['transform', '2183644sHzjyk', '1892088CQtKhQ', 'getElementById', '798161URgBDy', 'from', 'files', 'toDataURL', '100%', 'shredding', 'url(', 'height', 'dropping', 'original', '#painting', 'style', '8890240pkmhMC', 'painting', 'target', 'linear', '#original', '21912ErvOPL', 'backgroundImage', '742AqvyBf', 'pause', '276924QWAqlx', '101%', 'shred', '3958945Bbnpgf'];
    a0_0xb058 = function() {
        return _0x447b74;
    };
    return a0_0xb058();
}

function a0_0x39a5(_0xace105, _0x3b0d82) {
    const _0xb058ce = a0_0xb058();
    return a0_0x39a5 = function(_0x39a5de, _0x14be50) {
        _0x39a5de = _0x39a5de - 0xe1;
        let _0x41ab4f = _0xb058ce[_0x39a5de];
        return _0x41ab4f;
    }, a0_0x39a5(_0xace105, _0x3b0d82);
}
const app = new Vue({
    'el': '#banksy',
    'data'() {
        return {
            'shredding': null,
            'dropping': null
        };
    },
    'methods': {
        'shred'() {
            const _0x3ec6a1 = a0_0x39a5;
            this[_0x3ec6a1(0xec)] = anime({
                'targets': _0x3ec6a1(0xf7),
                'height': 0x0,
                'duration': 0x2710,
                'easing': _0x3ec6a1(0xf6)
            }), this[_0x3ec6a1(0xef)] = anime({
                'targets': _0x3ec6a1(0xf1),
                'translateY': _0x3ec6a1(0xfd),
                'duration': 0x2710,
                'easing': _0x3ec6a1(0xf6)
            });
        },
        'artSelected'(_0x230774) {
            const _0x21903d = a0_0x39a5;
            this['shredding'][_0x21903d(0xfb)](), this[_0x21903d(0xef)][_0x21903d(0xfb)](), loadImage(_0x230774[_0x21903d(0xf5)][_0x21903d(0xe9)][0x0], _0x1fb03e => {
                const _0x4e44a6 = _0x21903d;
                let _0x1be865 = _0x1fb03e[_0x4e44a6(0xea)]('image/jpeg');
                document['getElementById'](_0x4e44a6(0xf0))['style'][_0x4e44a6(0xf9)] = 'url(' + _0x1be865 + ')';
                let _0x2645b9 = Array[_0x4e44a6(0xe8)](document['getElementsByClassName'](_0x4e44a6(0xe1)));
                _0x2645b9['forEach'](_0x11b15a => {
                    const _0x2f8927 = _0x4e44a6;
                    _0x11b15a[_0x2f8927(0xf2)][_0x2f8927(0xf9)] = _0x2f8927(0xed) + _0x1be865 + ')';
                }), document['getElementById'](_0x4e44a6(0xf0))[_0x4e44a6(0xf2)][_0x4e44a6(0xee)] = _0x4e44a6(0xeb), document[_0x4e44a6(0xe6)](_0x4e44a6(0xf4))[_0x4e44a6(0xf2)][_0x4e44a6(0xe3)] = 'translateY(0)', this[_0x4e44a6(0xe1)]();
            }, {
                'canvas': !![],
                'crop': !![],
                'maxHeight': 0x236,
                'maxWidth': 0x188,
                'orientation': !![]
            });
        }
    },
    'mounted'() {
        const _0x2d1d4e = a0_0x39a5;
        this[_0x2d1d4e(0xe1)]();
    }
});