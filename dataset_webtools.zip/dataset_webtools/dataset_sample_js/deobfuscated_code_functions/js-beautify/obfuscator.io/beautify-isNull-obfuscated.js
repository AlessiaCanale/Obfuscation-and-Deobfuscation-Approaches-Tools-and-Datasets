const a0_0xba9441 = a0_0x4e47;

function a0_0x4e47(_0x37365c, _0x4f0086) {
    const _0x4563e1 = a0_0x4563();
    return a0_0x4e47 = function(_0x4e4721, _0x45da69) {
        _0x4e4721 = _0x4e4721 - 0xbb;
        let _0x43e15e = _0x4563e1[_0x4e4721];
        return _0x43e15e;
    }, a0_0x4e47(_0x37365c, _0x4f0086);
}

function a0_0x4563() {
    const _0x8c9570 = ['363900XDwYvV', '8886xXxVsV', '8859037DISrxZ', '8926896ordmIm', '31962gHhfgs', 'J\x20is\x20null:\x20', 'log', '10FNpJXg', '277908DiXoGw', '1688ttVfYI', '9syqSXR', '3GAbczc', '3230PTuzKQ', 'null\x20is\x20null:\x20', '2674611vDIoZs'];
    a0_0x4563 = function() {
        return _0x8c9570;
    };
    return a0_0x4563();
}(function(_0x1643a9, _0x179e5e) {
    const _0x53f237 = a0_0x4e47,
        _0x580450 = _0x1643a9();
    while (!![]) {
        try {
            const _0xf75442 = -parseInt(_0x53f237(0xc0)) / 0x1 * (-parseInt(_0x53f237(0xbd)) / 0x2) + parseInt(_0x53f237(0xbf)) / 0x3 * (-parseInt(_0x53f237(0xc4)) / 0x4) + -parseInt(_0x53f237(0xc1)) / 0x5 * (parseInt(_0x53f237(0xc5)) / 0x6) + -parseInt(_0x53f237(0xc8)) / 0x7 * (-parseInt(_0x53f237(0xbe)) / 0x8) + parseInt(_0x53f237(0xc3)) / 0x9 * (parseInt(_0x53f237(0xbc)) / 0xa) + parseInt(_0x53f237(0xc6)) / 0xb + -parseInt(_0x53f237(0xc7)) / 0xc;
            if (_0xf75442 === _0x179e5e) break;
            else _0x580450['push'](_0x580450['shift']());
        } catch (_0xceaf31) {
            _0x580450['push'](_0x580450['shift']());
        }
    }
}(a0_0x4563, 0x7c55b));
const isNull = _0xc08001 => _0xc08001 === null || _0xc08001 === undefined;
console['log'](a0_0xba9441(0xc2) + isNull(null)), console['log']('\x20is\x20null:\x20' + isNull()), console[a0_0xba9441(0xbb)]('123\x20is\x20null:\x20' + isNull(0x7b)), console[a0_0xba9441(0xbb)](a0_0xba9441(0xc9) + isNull('J'));