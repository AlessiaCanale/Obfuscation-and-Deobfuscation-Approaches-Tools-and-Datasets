(function(_0x335379, _0x23b32c) {
    const _0xc20570 = a0_0x4986,
        _0x599cf0 = _0x335379();
    while (!![]) {
        try {
            const _0x37abe5 = -parseInt(_0xc20570(0x6e)) / 0x1 + -parseInt(_0xc20570(0x6b)) / 0x2 + parseInt(_0xc20570(0x75)) / 0x3 + -parseInt(_0xc20570(0x70)) / 0x4 * (-parseInt(_0xc20570(0x6a)) / 0x5) + -parseInt(_0xc20570(0x72)) / 0x6 * (parseInt(_0xc20570(0x6d)) / 0x7) + -parseInt(_0xc20570(0x76)) / 0x8 + parseInt(_0xc20570(0x73)) / 0x9 * (parseInt(_0xc20570(0x6c)) / 0xa);
            if (_0x37abe5 === _0x23b32c) break;
            else _0x599cf0['push'](_0x599cf0['shift']());
        } catch (_0x5e8e64) {
            _0x599cf0['push'](_0x599cf0['shift']());
        }
    }
}(a0_0x4eb6, 0x1dc51));

function a0_0x4eb6() {
    const _0x1d2f07 = ['Matrix\x20created:', '154269LCiDbv', '912616ReiYYq', '15reGsnW', '448986WKKceX', '5794980SgtBEh', '3997rrrgtT', '173932gYjpNb', 'Numbers\x20passed\x20as\x20parameters:\x20', '128788qximpD', 'log', '978vOxbHW', '9SeJCSs'];
    a0_0x4eb6 = function() {
        return _0x1d2f07;
    };
    return a0_0x4eb6();
}

function createMatrixFromParameters(_0x58e50f, _0x18978f) {
    const _0x1b7692 = a0_0x4986;
    let _0x3c6882 = [];
    for (let _0x88c079 = 0x0; _0x88c079 < _0x58e50f; _0x88c079++) {
        _0x3c6882[_0x88c079] = [];
        for (let _0x524e30 = 0x0; _0x524e30 < _0x18978f; _0x524e30++) {
            let _0x3a8fa1 = Math['floor'](Math['random']() * 0x4);
            switch (_0x3a8fa1) {
                case 0x0:
                    _0x3c6882[_0x88c079][_0x524e30] = _0x58e50f;
                    break;
                case 0x1:
                    _0x3c6882[_0x88c079][_0x524e30] = _0x18978f;
                    break;
                case 0x2:
                    _0x3c6882[_0x88c079][_0x524e30] = _0x58e50f + _0x18978f;
                    break;
                case 0x3:
                    _0x3c6882[_0x88c079][_0x524e30] = _0x58e50f - _0x18978f;
                    break;
            }
        }
    }
    console[_0x1b7692(0x71)](_0x1b7692(0x6f) + _0x58e50f + ',\x20' + _0x18978f), console[_0x1b7692(0x71)](_0x1b7692(0x74)), console['log'](_0x3c6882);
}

function a0_0x4986(_0x5d0039, _0x2ff9f9) {
    const _0x4eb6d2 = a0_0x4eb6();
    return a0_0x4986 = function(_0x4986b2, _0x2386b7) {
        _0x4986b2 = _0x4986b2 - 0x6a;
        let _0x1605ef = _0x4eb6d2[_0x4986b2];
        return _0x1605ef;
    }, a0_0x4986(_0x5d0039, _0x2ff9f9);
}
createMatrixFromParameters(0x3, 0x4);