var a0_0x213308 = a0_0x54f7;

function a0_0xb50c() {
    var _0x379dca = ['linear', 'querySelectorAll', 'style', '126234SNqcSo', 'easeInQuart', 'easeInQuad', '.logo-animation\x20path:not(.icon-curve)', '#FFF', '18190POqHgV', '.dot-e', '792KEdabN', 'stroke', '.icon-text\x20path', '521706lPHrxo', '2351750HjfXNl', 'querySelector', '.dot-i', 'easeInBack', 'parentNode', 'stroke-dashoffset', 'length', 'getValue', 'easeInOutQuart', '.icon-text\x20polygon', '.icon', '6023241EScQUZ', 'easeOutBack', '325716AjqmSy', 'add', '55mqOYER', '2118zsYyjC', 'setAttribute', '.fill.in', 'setDashoffset', 'easeOutQuart', 'timeline', '4140204NAKofX', '.logo-animation', '1dezhqN', '9UwsgqK'];
    a0_0xb50c = function() {
        return _0x379dca;
    };
    return a0_0xb50c();
}(function(_0x1a8c35, _0x4db50c) {
    var _0x3d7fb7 = a0_0x54f7,
        _0x1215f8 = _0x1a8c35();
    while (!![]) {
        try {
            var _0x3339d9 = -parseInt(_0x3d7fb7(0x12a)) / 0x1 * (parseInt(_0x3d7fb7(0x111)) / 0x2) + -parseInt(_0x3d7fb7(0x12b)) / 0x3 * (-parseInt(_0x3d7fb7(0x11f)) / 0x4) + -parseInt(_0x3d7fb7(0x10c)) / 0x5 * (parseInt(_0x3d7fb7(0x122)) / 0x6) + -parseInt(_0x3d7fb7(0x11d)) / 0x7 + parseInt(_0x3d7fb7(0x10e)) / 0x8 * (parseInt(_0x3d7fb7(0x107)) / 0x9) + -parseInt(_0x3d7fb7(0x112)) / 0xa + parseInt(_0x3d7fb7(0x121)) / 0xb * (parseInt(_0x3d7fb7(0x128)) / 0xc);
            if (_0x3339d9 === _0x4db50c) break;
            else _0x1215f8['push'](_0x1215f8['shift']());
        } catch (_0x57aec8) {
            _0x1215f8['push'](_0x1215f8['shift']());
        }
    }
}(a0_0xb50c, 0xaf1b9));
var logoEl = document[a0_0x213308(0x113)](a0_0x213308(0x129)),
    pathEls = document[a0_0x213308(0x105)](a0_0x213308(0x10a)),
    innerWidth = window['innerWidth'],
    maxWidth = 0x2e4,
    logoScale = innerWidth <= maxWidth ? innerWidth / maxWidth : 0x1,
    logoTimeline = anime[a0_0x213308(0x127)]();

function a0_0x54f7(_0x17aa5d, _0x272724) {
    var _0xb50cb0 = a0_0xb50c();
    return a0_0x54f7 = function(_0x54f7ac, _0x320bb7) {
        _0x54f7ac = _0x54f7ac - 0x105;
        var _0x416a5c = _0xb50cb0[_0x54f7ac];
        return _0x416a5c;
    }, a0_0x54f7(_0x17aa5d, _0x272724);
}
logoEl[a0_0x213308(0x106)]['transform'] = 'translateY(50px)\x20scale(' + logoScale + ')';
for (var i = 0x0; i < pathEls[a0_0x213308(0x118)]; i++) {
    var el = pathEls[i];
    el[a0_0x213308(0x123)](a0_0x213308(0x117), anime['setDashoffset'](el));
}
logoTimeline[a0_0x213308(0x120)]({
    'targets': a0_0x213308(0x10d),
    'translateX': [{
        'value': -0x258,
        'duration': 0x208,
        'delay': 0xc8,
        'easing': a0_0x213308(0x108)
    }, {
        'value': [-0x64, 0x0],
        'duration': 0x1f4,
        'delay': 0x3e8,
        'easing': 'easeOutQuart'
    }],
    'scale': [{
        'value': [0x0, 0x1],
        'duration': 0xc8,
        'easing': a0_0x213308(0x11e)
    }, {
        'value': 0x0,
        'duration': 0x14,
        'delay': 0x1f4,
        'easing': a0_0x213308(0x108)
    }, {
        'value': 0x1,
        'duration': 0xc8,
        'delay': 0x3e8,
        'easing': a0_0x213308(0x126)
    }, {
        'value': 0x0,
        'duration': 0x190,
        'delay': 0x1f4,
        'easing': a0_0x213308(0x115)
    }],
    'offset': 0x0
})[a0_0x213308(0x120)]({
    'targets': a0_0x213308(0x114),
    'translateY': {
        'value': [-0xc8, 0x0],
        'duration': 0x1f4,
        'elasticity': 0x190
    },
    'scale': [{
        'value': [0x0, 0x1],
        'duration': 0x64,
        'easing': 'easeOutQuart'
    }, {
        'value': 0x0,
        'duration': 0x190,
        'delay': 0x578,
        'easing': 'easeInBack'
    }],
    'delay': 0x4b0,
    'offset': 0x0
})[a0_0x213308(0x120)]({
    'targets': a0_0x213308(0x124),
    'strokeDashoffset': {
        'value': [anime[a0_0x213308(0x125)], 0x0],
        'duration': 0x258,
        'delay': function(_0x1ec2ed, _0xd41d23, _0x56c081) {
            return 0x2bc + _0xd41d23 * 0x64;
        },
        'easing': a0_0x213308(0x126)
    },
    'stroke': {
        'value': [a0_0x213308(0x10b), function(_0xb293c7) {
            var _0x17366d = a0_0x213308;
            return anime[_0x17366d(0x119)](_0xb293c7[_0x17366d(0x116)], _0x17366d(0x10f));
        }],
        'duration': 0x1f4,
        'delay': 0x1f4,
        'easing': a0_0x213308(0x109)
    },
    'opacity': {
        'value': 0x0,
        'duration': 0x1,
        'delay': function(_0x724430, _0x2ecca6, _0x44a339) {
            return 0x76c + _0x2ecca6 * 0x50;
        }
    },
    'offset': 0x0
})[a0_0x213308(0x120)]({
    'targets': '.fill.out',
    'strokeDashoffset': [{
        'value': [anime['setDashoffset'], anime['setDashoffset']],
        'duration': 0x762
    }, {
        'value': [0x0, anime[a0_0x213308(0x125)]],
        'duration': 0x320,
        'delay': function(_0x22f43a, _0xada2f2) {
            return _0xada2f2 * 0x50;
        },
        'easing': a0_0x213308(0x108)
    }],
    'offset': 0x0
})['add']({
    'targets': '.line.out',
    'strokeDashoffset': {
        'value': [0x0, anime[a0_0x213308(0x125)]],
        'duration': 0x4b0,
        'delay': function(_0x36fc98, _0x595e0d, _0x1c5edd) {
            return 0x9c4 + _0x595e0d * 0x64;
        },
        'easing': a0_0x213308(0x108)
    },
    'strokeWidth': {
        'value': [0x0, 0x2],
        'delay': function(_0x3c108f, _0x54e243, _0x500e02) {
            return 0x7d0 + _0x54e243 * 0x64;
        },
        'duration': 0xc8,
        'easing': 'linear'
    },
    'offset': 0x0
})['add']({
    'targets': a0_0x213308(0x11c),
    'opacity': {
        'value': 0x1,
        'duration': 0xa,
        'delay': 0xaf0,
        'easing': a0_0x213308(0x12c)
    },
    'translateY': {
        'value': 0x3c,
        'duration': 0x320
    },
    'delay': 0x1068,
    'offset': 0x0
})[a0_0x213308(0x120)]({
    'targets': '.icon-line',
    'strokeDashoffset': [{
        'value': [anime[a0_0x213308(0x125)], anime[a0_0x213308(0x125)]],
        'duration': 0xbb8
    }, {
        'value': 0x0,
        'duration': 0x4b0,
        'easing': a0_0x213308(0x11a)
    }],
    'strokeWidth': {
        'value': [0x8, 0x2],
        'delay': 0xbb8,
        'duration': 0x320,
        'easing': a0_0x213308(0x109)
    },
    'stroke': {
        'value': [a0_0x213308(0x10b), function(_0x1984e9) {
            var _0x59a076 = a0_0x213308;
            return anime[_0x59a076(0x119)](_0x1984e9, _0x59a076(0x10f));
        }],
        'duration': 0x320,
        'delay': 0xd48,
        'easing': a0_0x213308(0x109)
    },
    'offset': 0x0
})[a0_0x213308(0x120)]({
    'targets': [a0_0x213308(0x110), a0_0x213308(0x11b)],
    'translateY': [0x32, 0x0],
    'opacity': {
        'value': [0x0, 0x1],
        'duration': 0x64,
        'easing': 'linear'
    },
    'delay': function(_0x2c26ae, _0x28eeb3, _0x2108f4) {
        return 0x1068 + _0x28eeb3 * 0x14;
    },
    'offset': 0x0
});