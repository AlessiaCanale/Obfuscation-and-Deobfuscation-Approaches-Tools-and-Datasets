var a0_0x57e853 = a0_0x3569;

function a0_0xb042() {
    var _0xb3e15e = ['174164iWgEpl', '880NJAufA', 'submit', '509334zlDicD', '45amvnRt', '#number-input', '901665TPXTdT', 'setTextVal', 'getTextVal', '51580deeLWn', 'easeOut', '854SnGEpt', 'val', 'input[type=number]', '34934EDwtfz', '11892jIiSCE', '15RvGOSM', '657KDcfQJ', '13488fdAUNB', 'p.number'];
    a0_0xb042 = function() {
        return _0xb3e15e;
    };
    return a0_0xb042();
}(function(_0x255776, _0x399f94) {
    var _0x18d485 = a0_0x3569,
        _0x3096ab = _0x255776();
    while (!![]) {
        try {
            var _0x19b27a = -parseInt(_0x18d485(0xa1)) / 0x1 * (-parseInt(_0x18d485(0x9f)) / 0x2) + parseInt(_0x18d485(0x97)) / 0x3 + parseInt(_0x18d485(0xa5)) / 0x4 * (parseInt(_0x18d485(0xa9)) / 0x5) + -parseInt(_0x18d485(0xa8)) / 0x6 + parseInt(_0x18d485(0x9c)) / 0x7 * (-parseInt(_0x18d485(0xa3)) / 0x8) + -parseInt(_0x18d485(0xa2)) / 0x9 * (parseInt(_0x18d485(0x9a)) / 0xa) + parseInt(_0x18d485(0xa6)) / 0xb * (-parseInt(_0x18d485(0xa0)) / 0xc);
            if (_0x19b27a === _0x399f94) break;
            else _0x3096ab['push'](_0x3096ab['shift']());
        } catch (_0x437481) {
            _0x3096ab['push'](_0x3096ab['shift']());
        }
    }
}(a0_0xb042, 0x32ca2));

function a0_0x3569(_0xcb668f, _0xa75bec) {
    var _0xb04253 = a0_0xb042();
    return a0_0x3569 = function(_0x3569b5, _0x5f4fd7) {
        _0x3569b5 = _0x3569b5 - 0x96;
        var _0x48b11c = _0xb04253[_0x3569b5];
        return _0x48b11c;
    }, a0_0x3569(_0xcb668f, _0xa75bec);
}
var $text = $(a0_0x57e853(0xa4)),
    $input = $(a0_0x57e853(0x9e)),
    endVal = 0x0,
    currVal = 0x0,
    obj = {};
obj[a0_0x57e853(0x99)] = function() {
    return parseInt(currVal, 0xa);
}, obj['setTextVal'] = function(_0x1bbf9) {
    currVal = parseInt(_0x1bbf9, 0xa), $text['text'](currVal);
}, obj[a0_0x57e853(0x98)](0x0);
var animate = function(_0x55156b) {
    var _0x401088 = a0_0x57e853;
    _0x55156b['preventDefault'](), currVal = 0x0, endVal = $input[_0x401088(0x9d)](), TweenLite['to'](obj, 0x7, {
        'setTextVal': endVal,
        'ease': Power1[_0x401088(0x9b)]
    });
};
$(a0_0x57e853(0x96))['on'](a0_0x57e853(0xa7), animate);