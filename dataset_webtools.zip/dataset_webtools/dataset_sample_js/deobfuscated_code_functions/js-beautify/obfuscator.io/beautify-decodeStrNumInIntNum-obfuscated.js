(function(_0x66dc3e, _0x285007) {
    const _0x5b7bf5 = a0_0x33ac,
        _0x3f7e7a = _0x66dc3e();
    while (!![]) {
        try {
            const _0x5a9632 = parseInt(_0x5b7bf5(0x10d)) / 0x1 * (-parseInt(_0x5b7bf5(0x118)) / 0x2) + parseInt(_0x5b7bf5(0x116)) / 0x3 * (parseInt(_0x5b7bf5(0x102)) / 0x4) + -parseInt(_0x5b7bf5(0x119)) / 0x5 + -parseInt(_0x5b7bf5(0x107)) / 0x6 * (parseInt(_0x5b7bf5(0x10a)) / 0x7) + parseInt(_0x5b7bf5(0x10e)) / 0x8 * (parseInt(_0x5b7bf5(0x117)) / 0x9) + -parseInt(_0x5b7bf5(0x10b)) / 0xa + parseInt(_0x5b7bf5(0x110)) / 0xb * (parseInt(_0x5b7bf5(0x113)) / 0xc);
            if (_0x5a9632 === _0x285007) break;
            else _0x3f7e7a['push'](_0x3f7e7a['shift']());
        } catch (_0x38763a) {
            _0x3f7e7a['push'](_0x3f7e7a['shift']());
        }
    }
}(a0_0xdb68, 0xe295e));

function decodeStrNumInIntNum(_0x195e69) {
    const _0x5db75a = a0_0x33ac;
    let _0x576c1c;
    switch (_0x195e69['toLowerCase']()) {
        case 'zero':
            _0x576c1c = 0x0;
            break;
        case _0x5db75a(0x109):
            _0x576c1c = 0x1;
            break;
        case 'two':
            _0x576c1c = 0x2;
            break;
        case _0x5db75a(0x10c):
            _0x576c1c = 0x3;
            break;
        case _0x5db75a(0x111):
            _0x576c1c = 0x4;
            break;
        case _0x5db75a(0x114):
            _0x576c1c = 0x5;
            break;
        case _0x5db75a(0x112):
            _0x576c1c = 0x6;
            break;
        case _0x5db75a(0x106):
            _0x576c1c = 0x7;
            break;
        case _0x5db75a(0x10f):
            _0x576c1c = 0x8;
            break;
        case _0x5db75a(0x115):
            _0x576c1c = 0x9;
            break;
        case _0x5db75a(0x105):
            _0x576c1c = 0xa;
            break;
        default:
            console[_0x5db75a(0x103)](_0x5db75a(0x108));
            return;
    }
    return console[_0x5db75a(0x103)]('Number\x20in\x20words:\x20' + _0x195e69), console['log'](_0x5db75a(0x104) + _0x576c1c), _0x576c1c;
}

function a0_0x33ac(_0x3c8899, _0x34d121) {
    const _0xdb68fe = a0_0xdb68();
    return a0_0x33ac = function(_0x33acb5, _0x75ef7) {
        _0x33acb5 = _0x33acb5 - 0x102;
        let _0x379dbc = _0xdb68fe[_0x33acb5];
        return _0x379dbc;
    }, a0_0x33ac(_0x3c8899, _0x34d121);
}
const numberInWords = 'seven';
decodeStrNumInIntNum(numberInWords);

function a0_0xdb68() {
    const _0x4fdb39 = ['81556HpryAm', 'log', 'Corresponding\x20numerical\x20value:\x20', 'ten', 'seven', '1675536AoyiTN', 'Invalid\x20input.\x20Please\x20enter\x20a\x20number\x20between\x20zero\x20and\x20ten\x20in\x20words.', 'one', '7YYtRIg', '7295790VcXoAW', 'three', '891795hblYNi', '632QTBIMY', 'eight', '11XCaTCE', 'four', 'six', '26827140aJsiVi', 'five', 'nine', '51GQQICx', '156987xcParL', '4VHhKRv', '1198430mNcyok'];
    a0_0xdb68 = function() {
        return _0x4fdb39;
    };
    return a0_0xdb68();
}