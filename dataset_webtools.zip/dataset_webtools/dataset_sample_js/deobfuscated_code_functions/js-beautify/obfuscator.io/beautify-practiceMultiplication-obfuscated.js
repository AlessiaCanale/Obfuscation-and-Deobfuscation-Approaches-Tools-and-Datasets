(function(_0x5c6582, _0x1ec243) {
    const _0x55aa34 = a0_0x2e7d,
        _0x53e705 = _0x5c6582();
    while (!![]) {
        try {
            const _0x5d4ba2 = parseInt(_0x55aa34(0x85)) / 0x1 + -parseInt(_0x55aa34(0x88)) / 0x2 * (parseInt(_0x55aa34(0x90)) / 0x3) + parseInt(_0x55aa34(0x86)) / 0x4 * (parseInt(_0x55aa34(0x87)) / 0x5) + -parseInt(_0x55aa34(0x89)) / 0x6 + -parseInt(_0x55aa34(0x8c)) / 0x7 + parseInt(_0x55aa34(0x92)) / 0x8 + parseInt(_0x55aa34(0x8d)) / 0x9 * (-parseInt(_0x55aa34(0x83)) / 0xa);
            if (_0x5d4ba2 === _0x1ec243) break;
            else _0x53e705['push'](_0x53e705['shift']());
        } catch (_0x4033a4) {
            _0x53e705['push'](_0x53e705['shift']());
        }
    }
}(a0_0x305e, 0xc68af));

function a0_0x2e7d(_0x456b86, _0x31e1d3) {
    const _0x305ee9 = a0_0x305e();
    return a0_0x2e7d = function(_0x2e7dcd, _0x3acb3f) {
        _0x2e7dcd = _0x2e7dcd - 0x82;
        let _0x408f03 = _0x305ee9[_0x2e7dcd];
        return _0x408f03;
    }, a0_0x2e7d(_0x456b86, _0x31e1d3);
}

function a0_0x305e() {
    const _0x2436b1 = ['The\x20correct\x20answer\x20is:\x20', '\x20and\x20', '6EYSdFd', 'Let\x27s\x20practice\x20multiplication!\x20Try\x20to\x20multiply\x20the\x20two\x20numbers\x20above\x20and\x20then\x20check\x20if\x20your\x20answer\x20is\x20correct\x20with\x20the\x20result\x20that\x20will\x20appear\x20after\x205\x20seconds\x20:)', '10330640ipKOqd', 'random', '10lMgrwb', 'log', '1317867EgAINt', '928220OxMYzC', '10KGNWob', '1273158SQJxNu', '727548JxvGAr', 'Random\x20numbers\x20selected:\x20', 'floor', '3642618jGOcuJ', '3107574ijGlOj'];
    a0_0x305e = function() {
        return _0x2436b1;
    };
    return a0_0x305e();
}

function practiceMultiplication() {
    const _0x5c445f = a0_0x2e7d;
    let _0x38001f = Math[_0x5c445f(0x8b)](Math[_0x5c445f(0x82)]() * 0xd),
        _0x3b7468 = Math[_0x5c445f(0x8b)](Math['random']() * 0xd),
        _0x5a8e9e = _0x38001f * _0x3b7468;
    console[_0x5c445f(0x84)](_0x5c445f(0x8a) + _0x38001f + _0x5c445f(0x8f) + _0x3b7468), console[_0x5c445f(0x84)](_0x5c445f(0x91)), setTimeout(() => {
        const _0x41019c = _0x5c445f;
        console['log'](_0x41019c(0x8e) + _0x5a8e9e);
    }, 0x1388);
}
practiceMultiplication();