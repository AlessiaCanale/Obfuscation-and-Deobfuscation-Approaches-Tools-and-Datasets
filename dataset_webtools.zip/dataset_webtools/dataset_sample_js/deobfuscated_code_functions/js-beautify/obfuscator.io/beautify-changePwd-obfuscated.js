const a0_0x58be7d = a0_0x4671;
(function(_0x8691f3, _0x2e3c7b) {
    const _0x3a9261 = a0_0x4671,
        _0x324d42 = _0x8691f3();
    while (!![]) {
        try {
            const _0x3a4049 = -parseInt(_0x3a9261(0x130)) / 0x1 * (-parseInt(_0x3a9261(0x13c)) / 0x2) + -parseInt(_0x3a9261(0x139)) / 0x3 * (parseInt(_0x3a9261(0x138)) / 0x4) + -parseInt(_0x3a9261(0x13d)) / 0x5 + parseInt(_0x3a9261(0x142)) / 0x6 + -parseInt(_0x3a9261(0x131)) / 0x7 * (parseInt(_0x3a9261(0x12f)) / 0x8) + -parseInt(_0x3a9261(0x145)) / 0x9 * (parseInt(_0x3a9261(0x149)) / 0xa) + parseInt(_0x3a9261(0x140)) / 0xb * (parseInt(_0x3a9261(0x14a)) / 0xc);
            if (_0x3a4049 === _0x2e3c7b) break;
            else _0x324d42['push'](_0x324d42['shift']());
        } catch (_0x44aa5e) {
            _0x324d42['push'](_0x324d42['shift']());
        }
    }
}(a0_0x1546, 0x2fa41));
const users = [{
    'nickname': a0_0x58be7d(0x144),
    'password': a0_0x58be7d(0x148)
}, {
    'nickname': a0_0x58be7d(0x147),
    'password': a0_0x58be7d(0x14c)
}, {
    'nickname': a0_0x58be7d(0x13a),
    'password': a0_0x58be7d(0x13e)
}, {
    'nickname': 'user4',
    'password': a0_0x58be7d(0x14b)
}, {
    'nickname': a0_0x58be7d(0x135),
    'password': a0_0x58be7d(0x134)
}];

function a0_0x4671(_0x2aa427, _0x5c68a7) {
    const _0x154674 = a0_0x1546();
    return a0_0x4671 = function(_0x4671ed, _0x459da8) {
        _0x4671ed = _0x4671ed - 0x12f;
        let _0x47e43e = _0x154674[_0x4671ed];
        return _0x47e43e;
    }, a0_0x4671(_0x2aa427, _0x5c68a7);
}

function changePwd(_0x3449f9, _0x2a429e, _0x57017d) {
    const _0xa8ace3 = a0_0x58be7d,
        _0x32a85c = users[_0xa8ace3(0x143)](_0x13a254 => _0x13a254[_0xa8ace3(0x133)] === _0x3449f9 && _0x13a254[_0xa8ace3(0x136)] === _0x2a429e);
    if (_0x32a85c !== -0x1) console[_0xa8ace3(0x13b)](_0x3449f9), console['log'](_0x2a429e), users[_0x32a85c][_0xa8ace3(0x136)] = _0x57017d, console['log'](_0xa8ace3(0x141)), console[_0xa8ace3(0x13b)](users[_0x32a85c][_0xa8ace3(0x136)]);
    else {
        const _0x22a4fa = users[_0xa8ace3(0x13f)](_0x4de7d8 => _0x4de7d8[_0xa8ace3(0x133)] === _0x3449f9);
        !_0x22a4fa ? console[_0xa8ace3(0x13b)]('Nickname\x20not\x20found.') : console['log'](_0xa8ace3(0x146));
    }
}
const nickname = 'user1',
    currentPassword = 'pass1',
    newPassword = 'newPass';
changePwd(nickname, currentPassword, newPassword);
const nickname1 = 'user2',
    currentPassword1 = a0_0x58be7d(0x137),
    newPassword1 = a0_0x58be7d(0x132);

function a0_0x1546() {
    const _0x2bcecb = ['30rUoWwx', '2271660eesQJI', 'pass4', 'pass2', '8nADuvM', '140677vndtTI', '2241974NuqGJI', 'newPass', 'nickname', 'pass5', 'user5', 'password', 'wrongPass', '52VTTdJU', '30399KZEfsE', 'user3', 'log', '2ATQtOE', '1109945KVJNhP', 'pass3', 'some', '44jFAITx', 'Operation\x20successful.\x20Password\x20updated.', '1422078gwCYOr', 'findIndex', 'user1', '797319XzlsEW', 'Incorrect\x20current\x20password.', 'user2', 'pass1'];
    a0_0x1546 = function() {
        return _0x2bcecb;
    };
    return a0_0x1546();
}
changePwd(nickname1, currentPassword1, newPassword1);