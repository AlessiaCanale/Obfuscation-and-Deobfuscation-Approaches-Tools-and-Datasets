function a0_0x1704(_0xbf98ea, _0x30d84c) {
    var _0x444765 = a0_0x4447();
    return a0_0x1704 = function(_0x1704a7, _0x3f14cd) {
        _0x1704a7 = _0x1704a7 - 0x175;
        var _0x3c9575 = _0x444765[_0x1704a7];
        return _0x3c9575;
    }, a0_0x1704(_0xbf98ea, _0x30d84c);
}
var a0_0x34f8cd = a0_0x1704;
(function(_0x337dab, _0x2cc506) {
    var _0x5680f6 = a0_0x1704,
        _0x2bdd4f = _0x337dab();
    while (!![]) {
        try {
            var _0x2f2af1 = parseInt(_0x5680f6(0x179)) / 0x1 * (-parseInt(_0x5680f6(0x180)) / 0x2) + -parseInt(_0x5680f6(0x178)) / 0x3 + -parseInt(_0x5680f6(0x17c)) / 0x4 * (-parseInt(_0x5680f6(0x182)) / 0x5) + parseInt(_0x5680f6(0x17d)) / 0x6 * (parseInt(_0x5680f6(0x17b)) / 0x7) + -parseInt(_0x5680f6(0x17e)) / 0x8 + -parseInt(_0x5680f6(0x177)) / 0x9 * (-parseInt(_0x5680f6(0x17a)) / 0xa) + parseInt(_0x5680f6(0x185)) / 0xb * (-parseInt(_0x5680f6(0x186)) / 0xc);
            if (_0x2f2af1 === _0x2cc506) break;
            else _0x2bdd4f['push'](_0x2bdd4f['shift']());
        } catch (_0x26f74b) {
            _0x2bdd4f['push'](_0x2bdd4f['shift']());
        }
    }
}(a0_0x4447, 0x84e02), today = new Date(), xmas = new Date('December\x2025,\x202024'), msPerDay = 0x18 * 0x3c * 0x3c * 0x3e8, timeLeft = xmas[a0_0x34f8cd(0x183)]() - today[a0_0x34f8cd(0x183)](), console[a0_0x34f8cd(0x176)]('time\x20left\x20till\x20christmas:\x20' + timeLeft), e_daysLeft = timeLeft / msPerDay, daysLeft = Math[a0_0x34f8cd(0x181)](e_daysLeft), e_hrsLeft = (e_daysLeft - daysLeft) * 0x18, hrsLeft = Math[a0_0x34f8cd(0x181)](e_hrsLeft), minsLeft = Math[a0_0x34f8cd(0x181)]((e_hrsLeft - hrsLeft) * 0x3c), console['log'](a0_0x34f8cd(0x17f) + daysLeft + a0_0x34f8cd(0x175) + hrsLeft + a0_0x34f8cd(0x184) + minsLeft + '\x20minutes\x20left\x20Until\x20December\x2025th\x202024'));

function a0_0x4447() {
    var _0x5ea9ef = ['4987080ePSGlj', 'There\x20are\x20only:\x20', '300534qGpIEx', 'floor', '114190hRGXRW', 'getTime', '\x20hours\x20and\x20', '946arTRqV', '720WKtshM', '\x20days\x20', 'log', '16938nOUAIF', '701133UaXPUU', '3kyRUdh', '2960uFeERT', '6064247PWRpqY', '76UBeJtb', '6RiTROc'];
    a0_0x4447 = function() {
        return _0x5ea9ef;
    };
    return a0_0x4447();
}