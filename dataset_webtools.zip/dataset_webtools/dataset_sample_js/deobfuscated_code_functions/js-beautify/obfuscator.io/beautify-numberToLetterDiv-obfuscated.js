const a0_0x45da8a = a0_0x3919;
(function(_0x52d6d5, _0x311531) {
    const _0x26aa34 = a0_0x3919,
        _0x303532 = _0x52d6d5();
    while (!![]) {
        try {
            const _0x5944f9 = -parseInt(_0x26aa34(0xe3)) / 0x1 + parseInt(_0x26aa34(0xd5)) / 0x2 * (parseInt(_0x26aa34(0xdb)) / 0x3) + parseInt(_0x26aa34(0xd7)) / 0x4 * (-parseInt(_0x26aa34(0xe1)) / 0x5) + parseInt(_0x26aa34(0xd3)) / 0x6 + parseInt(_0x26aa34(0xd8)) / 0x7 + -parseInt(_0x26aa34(0xd4)) / 0x8 * (parseInt(_0x26aa34(0xd2)) / 0x9) + -parseInt(_0x26aa34(0xdc)) / 0xa * (-parseInt(_0x26aa34(0xe2)) / 0xb);
            if (_0x5944f9 === _0x311531) break;
            else _0x303532['push'](_0x303532['shift']());
        } catch (_0x5dc657) {
            _0x303532['push'](_0x303532['shift']());
        }
    }
}(a0_0x2819, 0x559ca));

function numberToLetterDiv(_0x9bfed8) {
    const _0x3432f9 = a0_0x3919,
        _0x333f68 = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
    return _0x9bfed8[_0x3432f9(0xd6)]()[_0x3432f9(0xde)]('')[_0x3432f9(0xd9)](_0x221af0 => _0x333f68[parseInt(_0x221af0)])[_0x3432f9(0xda)]('');
}

function divideNumbers(_0x599ac2, _0x160c7f) {
    const _0x3eb2ae = a0_0x3919,
        _0x217dfe = _0x599ac2 / _0x160c7f;
    console['log']('Div\x20result:\x20' + _0x217dfe);
    const _0x5dc229 = _0x217dfe['toString']()['split']('')[_0x3eb2ae(0xd9)](_0x1fe1e2 => numberToLetterDiv(_0x1fe1e2))[_0x3eb2ae(0xda)]('');
    return _0x5dc229;
}

function a0_0x2819() {
    const _0x5b8e68 = ['11NJPKNN', '460834gLKPHp', 'Division\x20Result:\x20', 'log', '27jRHxHq', '2371860rJusDj', '1021672AZtJMQ', '584yBBYSj', 'toString', '52CCxbOf', '2159381AxoRbr', 'map', 'join', '2661sAxjEh', '6808630BPRWUS', 'Number\x202:\x20', 'split', 'Number\x201:\x20', 'Number\x202\x20String:\x20', '172705ujZCzy'];
    a0_0x2819 = function() {
        return _0x5b8e68;
    };
    return a0_0x2819();
}

function a0_0x3919(_0x2486b0, _0x513f0a) {
    const _0x281919 = a0_0x2819();
    return a0_0x3919 = function(_0x391964, _0x4e4652) {
        _0x391964 = _0x391964 - 0xd0;
        let _0x551e69 = _0x281919[_0x391964];
        return _0x551e69;
    }, a0_0x3919(_0x2486b0, _0x513f0a);
}
const num1 = 0x499602d2,
    num2 = 0x24cb016ea,
    num1String = num1['toString']()['split']('')[a0_0x45da8a(0xd9)](_0x217973 => numberToLetterDiv(_0x217973))[a0_0x45da8a(0xda)](''),
    num2String = num2['toString']()[a0_0x45da8a(0xde)]('')[a0_0x45da8a(0xd9)](_0x4cf477 => numberToLetterDiv(_0x4cf477))['join'](''),
    result = divideNumbers(num1, num2);
console[a0_0x45da8a(0xd1)](a0_0x45da8a(0xdf) + num1), console[a0_0x45da8a(0xd1)]('Number\x201\x20String:\x20' + num1String), console[a0_0x45da8a(0xd1)](a0_0x45da8a(0xdd) + num2), console[a0_0x45da8a(0xd1)](a0_0x45da8a(0xe0) + num2String), console[a0_0x45da8a(0xd1)](a0_0x45da8a(0xd0) + result);