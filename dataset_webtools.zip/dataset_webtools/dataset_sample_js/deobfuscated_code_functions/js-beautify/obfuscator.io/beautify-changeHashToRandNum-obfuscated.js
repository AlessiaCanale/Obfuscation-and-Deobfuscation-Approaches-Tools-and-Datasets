function a0_0x5df8() {
    const _0x4ab285 = ['replace', '242bMYuzB', 'log', '1545180uvxNhE', '567968XVHiCd', '876pKYWDh', '612042yPiGTa', '366984DFDoJp', 'random', '8200zaTVTU', '140ZaQDgF', 'This\x20is\x20a\x20#\x20test\x20#\x20with\x20#\x20hash\x20#\x20symbols.', '342005ZbTksc', '966DgMqfT'];
    a0_0x5df8 = function() {
        return _0x4ab285;
    };
    return a0_0x5df8();
}
const a0_0x2e2b8e = a0_0x5001;
(function(_0x186c27, _0x494b1a) {
    const _0x439149 = a0_0x5001,
        _0x5f079e = _0x186c27();
    while (!![]) {
        try {
            const _0x401d5d = -parseInt(_0x439149(0x87)) / 0x1 * (parseInt(_0x439149(0x83)) / 0x2) + parseInt(_0x439149(0x88)) / 0x3 + parseInt(_0x439149(0x86)) / 0x4 + parseInt(_0x439149(0x80)) / 0x5 + parseInt(_0x439149(0x85)) / 0x6 + -parseInt(_0x439149(0x81)) / 0x7 * (-parseInt(_0x439149(0x8b)) / 0x8) + parseInt(_0x439149(0x89)) / 0x9 * (-parseInt(_0x439149(0x7e)) / 0xa);
            if (_0x401d5d === _0x494b1a) break;
            else _0x5f079e['push'](_0x5f079e['shift']());
        } catch (_0xd76f4d) {
            _0x5f079e['push'](_0x5f079e['shift']());
        }
    }
}(a0_0x5df8, 0x2154f));

function changeHashToRandNum(_0x4e288b) {
    const _0x978201 = a0_0x5001,
        _0x22490d = /#/g,
        _0x112697 = _0x4e288b[_0x978201(0x82)](_0x22490d, () => Math['floor'](Math[_0x978201(0x8a)]() * 0x65));
    return _0x112697;
}

function a0_0x5001(_0x10a4ee, _0x52d046) {
    const _0x5df838 = a0_0x5df8();
    return a0_0x5001 = function(_0x5001c5, _0xfb96c3) {
        _0x5001c5 = _0x5001c5 - 0x7e;
        let _0x538cb5 = _0x5df838[_0x5001c5];
        return _0x538cb5;
    }, a0_0x5001(_0x10a4ee, _0x52d046);
}
const originalText = a0_0x2e2b8e(0x7f);
console[a0_0x2e2b8e(0x84)]('Original\x20Text:', originalText), console[a0_0x2e2b8e(0x84)]('Transformed\x20Text:', changeHashToRandNum(originalText));