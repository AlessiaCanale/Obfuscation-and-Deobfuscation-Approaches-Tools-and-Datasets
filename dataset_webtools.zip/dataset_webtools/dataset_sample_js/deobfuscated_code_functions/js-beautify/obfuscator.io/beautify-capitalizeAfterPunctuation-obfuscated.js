const a0_0x54acd8 = a0_0x5b62;
(function(_0x2bbb46, _0x4f98fd) {
    const _0x1f2193 = a0_0x5b62,
        _0x3ebf98 = _0x2bbb46();
    while (!![]) {
        try {
            const _0x4b40ef = parseInt(_0x1f2193(0xa8)) / 0x1 + -parseInt(_0x1f2193(0xa6)) / 0x2 * (parseInt(_0x1f2193(0xab)) / 0x3) + -parseInt(_0x1f2193(0xa7)) / 0x4 * (-parseInt(_0x1f2193(0xa9)) / 0x5) + -parseInt(_0x1f2193(0xa0)) / 0x6 + parseInt(_0x1f2193(0xa1)) / 0x7 + -parseInt(_0x1f2193(0xa3)) / 0x8 + parseInt(_0x1f2193(0x9e)) / 0x9 * (-parseInt(_0x1f2193(0x9d)) / 0xa);
            if (_0x4b40ef === _0x4f98fd) break;
            else _0x3ebf98['push'](_0x3ebf98['shift']());
        } catch (_0x390012) {
            _0x3ebf98['push'](_0x3ebf98['shift']());
        }
    }
}(a0_0x9daa, 0xbd72f));

function capitalizeAfterPunctuation(_0x2df7c1) {
    const _0x15d182 = a0_0x5b62;
    let _0x37d5e5 = _0x2df7c1[_0x15d182(0xaa)]();
    return _0x37d5e5 = _0x37d5e5['replace'](/(?:\.|\?|!)\s*(\w)/g, function(_0x5f1561, _0x4a4d84) {
        const _0x721ea2 = _0x15d182;
        return _0x5f1561[_0x721ea2(0xa2)](_0x4a4d84, _0x4a4d84['toUpperCase']());
    }), _0x37d5e5;
}
const originalText = 'hello.\x20how\x20are\x20you?\x20i\x20am\x20fine!\x20thank\x20you.\x20bye,\x20see\x20you\x20soon',
    correctedText = capitalizeAfterPunctuation(originalText);

function a0_0x9daa() {
    const _0x4b9694 = ['log', 'Original\x20Text:\x20', '541054FhCykd', '4NLPgvV', '1314352YGtJDa', '2005385YwchaJ', 'toLowerCase', '9UyHpdb', '1070iUbnPW', '15480Amxtta', 'Corrected\x20Text:\x20', '1474608vsMINQ', '3210081KpWTZD', 'replace', '1253120WwlOGk'];
    a0_0x9daa = function() {
        return _0x4b9694;
    };
    return a0_0x9daa();
}

function a0_0x5b62(_0x49d891, _0x14dec5) {
    const _0x9daaf5 = a0_0x9daa();
    return a0_0x5b62 = function(_0x5b62db, _0x58f192) {
        _0x5b62db = _0x5b62db - 0x9d;
        let _0x25b4a2 = _0x9daaf5[_0x5b62db];
        return _0x25b4a2;
    }, a0_0x5b62(_0x49d891, _0x14dec5);
}
console['log'](a0_0x54acd8(0xa5) + originalText), console[a0_0x54acd8(0xa4)](a0_0x54acd8(0x9f) + correctedText);