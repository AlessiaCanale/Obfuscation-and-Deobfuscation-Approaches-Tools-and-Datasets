function a0_0x388f() {
    var _0x8c26a5 = ['07/12/2005', '147bnHBaI', 'getTime', '548655EZYKMF', '5016781NUVAGs', '17953040JdMuaD', '1762376OZDUXB', '30854jJNghX', 'Age\x20of\x20the\x20date\x20entered:\x20', '36myOVok', 'getUTCFullYear', '4XoNIvN', '\x20years', '5438118IYjLGs', 'abs', '537931ODPJFB', 'log'];
    a0_0x388f = function() {
        return _0x8c26a5;
    };
    return a0_0x388f();
}

function a0_0x22a1(_0x43c52c, _0x3093dc) {
    var _0x388f35 = a0_0x388f();
    return a0_0x22a1 = function(_0x22a189, _0x28278e) {
        _0x22a189 = _0x22a189 - 0x13e;
        var _0x3e05cd = _0x388f35[_0x22a189];
        return _0x3e05cd;
    }, a0_0x22a1(_0x43c52c, _0x3093dc);
}
var a0_0x21bcb0 = a0_0x22a1;
(function(_0x3d7f94, _0x363341) {
    var _0x428195 = a0_0x22a1,
        _0x55aa40 = _0x3d7f94();
    while (!![]) {
        try {
            var _0x3630da = parseInt(_0x428195(0x14b)) / 0x1 + -parseInt(_0x428195(0x143)) / 0x2 * (-parseInt(_0x428195(0x14e)) / 0x3) + -parseInt(_0x428195(0x147)) / 0x4 * (parseInt(_0x428195(0x13f)) / 0x5) + -parseInt(_0x428195(0x149)) / 0x6 + -parseInt(_0x428195(0x140)) / 0x7 + parseInt(_0x428195(0x142)) / 0x8 * (-parseInt(_0x428195(0x145)) / 0x9) + parseInt(_0x428195(0x141)) / 0xa;
            if (_0x3630da === _0x363341) break;
            else _0x55aa40['push'](_0x55aa40['shift']());
        } catch (_0x219efd) {
            _0x55aa40['push'](_0x55aa40['shift']());
        }
    }
}(a0_0x388f, 0x74043));
var dob = new Date(a0_0x21bcb0(0x14d)),
    month_diff = Date['now']() - dob[a0_0x21bcb0(0x13e)](),
    age_dt = new Date(month_diff),
    year = age_dt[a0_0x21bcb0(0x146)](),
    age = Math[a0_0x21bcb0(0x14a)](year - 0x7b2);
console[a0_0x21bcb0(0x14c)](a0_0x21bcb0(0x144) + age + a0_0x21bcb0(0x148));