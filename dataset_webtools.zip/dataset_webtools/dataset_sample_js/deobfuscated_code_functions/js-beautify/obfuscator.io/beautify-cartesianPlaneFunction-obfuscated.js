var a0_0x354d85 = a0_0x37a5;
(function(_0x3c464d, _0x5f131f) {
    var _0x37e744 = a0_0x37a5,
        _0x51b947 = _0x3c464d();
    while (!![]) {
        try {
            var _0x13f351 = -parseInt(_0x37e744(0x85)) / 0x1 * (-parseInt(_0x37e744(0x8a)) / 0x2) + -parseInt(_0x37e744(0x88)) / 0x3 * (parseInt(_0x37e744(0x8e)) / 0x4) + -parseInt(_0x37e744(0x75)) / 0x5 * (parseInt(_0x37e744(0x8b)) / 0x6) + parseInt(_0x37e744(0x8c)) / 0x7 + parseInt(_0x37e744(0x86)) / 0x8 * (parseInt(_0x37e744(0x78)) / 0x9) + parseInt(_0x37e744(0x89)) / 0xa * (-parseInt(_0x37e744(0x7c)) / 0xb) + -parseInt(_0x37e744(0x8f)) / 0xc * (-parseInt(_0x37e744(0x7a)) / 0xd);
            if (_0x13f351 === _0x5f131f) break;
            else _0x51b947['push'](_0x51b947['shift']());
        } catch (_0xbc4dae) {
            _0x51b947['push'](_0x51b947['shift']());
        }
    }
}(a0_0x56ec, 0x49865));
var pathEl = document['querySelector'](a0_0x354d85(0x80)),
    presetsEls = document[a0_0x354d85(0x94)]('.options\x20button'),
    ratio = window['innerWidth'] >= 0x3d4 ? 0x2 : 0x1,
    timeline = anime[a0_0x354d85(0x7e)]({
        'loop': !![]
    });

function animateProgress(_0x40cb3e) {
    var _0x17d650 = a0_0x354d85;
    timeline[_0x17d650(0x74)](), timeline = anime['timeline']({
        'loop': !![]
    }), timeline[_0x17d650(0x7b)]([{
        'targets': _0x17d650(0x8d),
        'opacity': [{
            'value': [0x0, 0x1],
            'delay': 0x0,
            'duration': 0x1f4
        }, {
            'value': 0x0,
            'delay': 0x5dc,
            'duration': 0x1f4
        }],
        'translateX': {
            'value': [0x0, 0xc8 * ratio],
            'delay': 0x1f4,
            'duration': 0x5dc
        },
        'easing': _0x17d650(0x93),
        'offset': 0x0
    }, {
        'targets': _0x17d650(0x84),
        'opacity': [{
            'value': [0x0, 0x1],
            'delay': 0x0,
            'duration': 0x1f4
        }, {
            'value': 0x0,
            'delay': 0x5dc,
            'duration': 0x1f4
        }],
        'translateY': {
            'value': [0x0, -(0xc8 * ratio)],
            'delay': 0x1f4,
            'duration': 0x5dc,
            'easing': _0x40cb3e
        },
        'easing': _0x17d650(0x93),
        'offset': 0x0
    }, {
        'targets': _0x17d650(0x79),
        'translateY': {
            'value': [0x64, 0x0],
            'delay': 0x1f4,
            'duration': 0x5dc,
            'easing': _0x40cb3e
        },
        'scale': [{
            'value': [0x0, 0x1],
            'delay': 0x0,
            'duration': 0x1f4,
            'easing': _0x17d650(0x7f)
        }, {
            'value': 0x0,
            'delay': 0x5dc,
            'duration': 0x1f4,
            'easing': _0x17d650(0x90)
        }],
        'offset': 0x0
    }]);
}

function a0_0x37a5(_0x4e39f8, _0x39a53e) {
    var _0x56ec17 = a0_0x56ec();
    return a0_0x37a5 = function(_0x37a58f, _0x1d5b5b) {
        _0x37a58f = _0x37a58f - 0x72;
        var _0x12abc9 = _0x56ec17[_0x37a58f];
        return _0x12abc9;
    }, a0_0x37a5(_0x4e39f8, _0x39a53e);
}

function convertCoordinates(_0x43a52d) {
    var _0x551e1f = a0_0x354d85,
        _0x26fb54 = _0x43a52d[0x0] * 0x64,
        _0x26ddf3 = 0x64 - _0x43a52d[0x1] * 0x64,
        _0x4a43af = _0x43a52d[0x2] * 0x64,
        _0x4e1525 = 0x64 - _0x43a52d[0x3] * 0x64;
    return 'M0\x20100C' + _0x26fb54 + '\x20' + _0x26ddf3 + '\x20' + _0x4a43af + '\x20' + _0x4e1525 + _0x551e1f(0x87);
}

function getCoordinates(_0x5da65d) {
    var _0x5bf91a = a0_0x354d85;
    return convertCoordinates(_0x5da65d[_0x5bf91a(0x76)](','));
}

function a0_0x56ec() {
    var _0x313f49 = ['33BwVVRy', 'classList', 'timeline', 'easeOutBack', '.curve', 'length', 'name', 'onclick', '.axis.y', '2KmRdZy', '4173968rVgPSt', '\x20100\x200', '504723MLVHxB', '394620iwbYBf', '323124QFEWef', '6GRghJq', '394387fRRdoI', '.axis.x', '8eLZzMO', '132cFtGRa', 'easeInBack', 'active', 'target', 'linear', 'querySelectorAll', 'click', 'value', 'pause', '1668025FHHNxx', 'split', 'remove', '9OKgBMQ', '.ball', '222677KnqDpF', 'add'];
    a0_0x56ec = function() {
        return _0x313f49;
    };
    return a0_0x56ec();
}

function changeEase(_0x57de32) {
    var _0x2234ef = a0_0x354d85;
    for (var _0x8082d9 = 0x0; _0x8082d9 < presetsEls[_0x2234ef(0x81)]; _0x8082d9++) {
        presetsEls[_0x8082d9]['classList'][_0x2234ef(0x77)](_0x2234ef(0x91));
    }
    var _0xc40d4e = _0x57de32[_0x2234ef(0x92)],
        _0x4b1158 = _0xc40d4e[_0x2234ef(0x73)],
        _0x120d4c = _0xc40d4e[_0x2234ef(0x82)];
    _0xc40d4e[_0x2234ef(0x7d)]['add'](_0x2234ef(0x91));
    var _0x3d5848 = getCoordinates(_0x4b1158);
    animateProgress(_0x120d4c), anime['remove'](pathEl), anime({
        'targets': pathEl,
        'd': _0x3d5848
    });
}
for (var i = 0x0; i < presetsEls['length']; i++) {
    presetsEls[i][a0_0x354d85(0x83)] = changeEase;
}
presetsEls[0x0][a0_0x354d85(0x72)](), pathEl['setAttribute']('d', getCoordinates(presetsEls[0x0]['value']));