const a0_0x1ae6c4 = a0_0x4a36;

function a0_0x4a36(_0x1d9dcf, _0x592126) {
    const _0x564955 = a0_0x5649();
    return a0_0x4a36 = function(_0x4a3694, _0x4163e6) {
        _0x4a3694 = _0x4a3694 - 0x106;
        let _0x5adb60 = _0x564955[_0x4a3694];
        return _0x5adb60;
    }, a0_0x4a36(_0x1d9dcf, _0x592126);
}(function(_0x1a190d, _0x330f5c) {
    const _0x445eeb = a0_0x4a36,
        _0x591aa1 = _0x1a190d();
    while (!![]) {
        try {
            const _0x2b3f3a = parseInt(_0x445eeb(0x10c)) / 0x1 + -parseInt(_0x445eeb(0x110)) / 0x2 * (-parseInt(_0x445eeb(0x10e)) / 0x3) + -parseInt(_0x445eeb(0x111)) / 0x4 + parseInt(_0x445eeb(0x112)) / 0x5 + parseInt(_0x445eeb(0x106)) / 0x6 + parseInt(_0x445eeb(0x10a)) / 0x7 * (parseInt(_0x445eeb(0x107)) / 0x8) + -parseInt(_0x445eeb(0x109)) / 0x9;
            if (_0x2b3f3a === _0x330f5c) break;
            else _0x591aa1['push'](_0x591aa1['shift']());
        } catch (_0x476136) {
            _0x591aa1['push'](_0x591aa1['shift']());
        }
    }
}(a0_0x5649, 0xdf694));

function countSpacesText(_0x35528b) {
    const _0x87407d = a0_0x4a36;
    let _0x4a111f = 0x0;
    for (let _0x480d14 = 0x0; _0x480d14 < _0x35528b['length']; _0x480d14++) {
        _0x35528b[_0x480d14] === '\x20' && _0x4a111f++;
    }
    console[_0x87407d(0x10b)](_0x87407d(0x10f) + _0x35528b), console[_0x87407d(0x10b)](_0x87407d(0x10d) + _0x4a111f);
}
countSpacesText(a0_0x1ae6c4(0x108));

function a0_0x5649() {
    const _0x44be1b = ['8333898bbYUyT', '16dPpyUs', 'Hello,\x20how\x20is\x20your\x20day?\x20I\x20hope\x20that\x20is\x20a\x20really\x20good\x20day\x20and\x20that\x20you\x20are\x20enjoying\x20it!', '32377509HYrSsh', '457240NIUScS', 'log', '1685471xHJKjj', 'Number\x20of\x20spaces:\x20', '211935vIoNDs', 'Text:\x20', '34TLjNuX', '2676072YZgTrQ', '3877760jfyyYA'];
    a0_0x5649 = function() {
        return _0x44be1b;
    };
    return a0_0x5649();
}