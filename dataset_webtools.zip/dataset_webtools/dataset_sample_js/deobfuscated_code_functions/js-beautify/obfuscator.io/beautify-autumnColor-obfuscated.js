function a0_0x5ab9(_0x28ac33, _0x2bcf90) {
    const _0x35e2ed = a0_0x35e2();
    return a0_0x5ab9 = function(_0x5ab9c3, _0x16fa90) {
        _0x5ab9c3 = _0x5ab9c3 - 0x11e;
        let _0x24d00d = _0x35e2ed[_0x5ab9c3];
        return _0x24d00d;
    }, a0_0x5ab9(_0x28ac33, _0x2bcf90);
}
const a0_0x2d64d6 = a0_0x5ab9;
(function(_0x88095d, _0x458c6a) {
    const _0x22519e = a0_0x5ab9,
        _0x13b59e = _0x88095d();
    while (!![]) {
        try {
            const _0x14b0f7 = parseInt(_0x22519e(0x126)) / 0x1 * (-parseInt(_0x22519e(0x128)) / 0x2) + parseInt(_0x22519e(0x121)) / 0x3 + parseInt(_0x22519e(0x120)) / 0x4 + -parseInt(_0x22519e(0x11e)) / 0x5 + -parseInt(_0x22519e(0x12b)) / 0x6 * (parseInt(_0x22519e(0x127)) / 0x7) + -parseInt(_0x22519e(0x123)) / 0x8 + -parseInt(_0x22519e(0x129)) / 0x9 * (-parseInt(_0x22519e(0x12c)) / 0xa);
            if (_0x14b0f7 === _0x458c6a) break;
            else _0x13b59e['push'](_0x13b59e['shift']());
        } catch (_0x3fb0b9) {
            _0x13b59e['push'](_0x13b59e['shift']());
        }
    }
}(a0_0x35e2, 0x4761f));
let currentColorIndex = 0x0;

function a0_0x35e2() {
    const _0x568211 = ['313990uijeIQ', 'length', '57280vToOML', '652041UAYGqQ', 'add', '2525288ERTnXD', 'red', 'green', '145447ZyJmXD', '273GEgTom', '8zQXwZA', '990954amRBMV', 'brown', '29262LqLCAe', '110PpamjM', 'classList', 'yellow'];
    a0_0x35e2 = function() {
        return _0x568211;
    };
    return a0_0x35e2();
}
const leafColors = [a0_0x2d64d6(0x125), a0_0x2d64d6(0x12e), a0_0x2d64d6(0x124), a0_0x2d64d6(0x12a)];

function autumnColor() {
    const _0x3803b9 = a0_0x2d64d6,
        _0x13f0db = document['querySelector']('.leaf-icon');
    _0x13f0db[_0x3803b9(0x12d)]['remove'](leafColors[currentColorIndex]), currentColorIndex = (currentColorIndex + 0x1) % leafColors[_0x3803b9(0x11f)], _0x13f0db[_0x3803b9(0x12d)][_0x3803b9(0x122)](leafColors[currentColorIndex]);
}