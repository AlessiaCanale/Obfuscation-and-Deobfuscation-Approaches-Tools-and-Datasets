const a0_0x32a761 = a0_0x2f36;

function a0_0x2f36(_0x5e5a57, _0x76ca52) {
    const _0xe1655b = a0_0xe165();
    return a0_0x2f36 = function(_0x2f3675, _0x361763) {
        _0x2f3675 = _0x2f3675 - 0x189;
        let _0x571abc = _0xe1655b[_0x2f3675];
        return _0x571abc;
    }, a0_0x2f36(_0x5e5a57, _0x76ca52);
}(function(_0x47819a, _0x5ec94f) {
    const _0xcc48e6 = a0_0x2f36,
        _0x188d17 = _0x47819a();
    while (!![]) {
        try {
            const _0x218a99 = parseInt(_0xcc48e6(0x19c)) / 0x1 * (-parseInt(_0xcc48e6(0x18b)) / 0x2) + -parseInt(_0xcc48e6(0x198)) / 0x3 + -parseInt(_0xcc48e6(0x197)) / 0x4 + parseInt(_0xcc48e6(0x19a)) / 0x5 * (parseInt(_0xcc48e6(0x19e)) / 0x6) + -parseInt(_0xcc48e6(0x18d)) / 0x7 * (parseInt(_0xcc48e6(0x194)) / 0x8) + -parseInt(_0xcc48e6(0x190)) / 0x9 * (-parseInt(_0xcc48e6(0x191)) / 0xa) + parseInt(_0xcc48e6(0x193)) / 0xb;
            if (_0x218a99 === _0x5ec94f) break;
            else _0x188d17['push'](_0x188d17['shift']());
        } catch (_0x3afd33) {
            _0x188d17['push'](_0x188d17['shift']());
        }
    }
}(a0_0xe165, 0xcbdae));

function checkWordPresence(_0x180776, _0x1b005b) {
    const _0x238ec9 = a0_0x2f36;
    console[_0x238ec9(0x19b)](_0x180776);
    const _0x556fd3 = _0x180776[_0x238ec9(0x18f)](/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, ''),
        _0x599778 = _0x556fd3[_0x238ec9(0x196)]()[_0x238ec9(0x18a)]('\x20'),
        _0x262ff3 = _0x599778[_0x238ec9(0x192)]((_0x4c3703, _0x437852) => {
            const _0x49fcd8 = _0x238ec9;
            if (_0x437852 === _0x1b005b[_0x49fcd8(0x196)]()) return _0x4c3703 + 0x1;
            return _0x4c3703;
        }, 0x0);
    _0x262ff3 > 0x0 ? (console[_0x238ec9(0x19b)](_0x238ec9(0x19d) + _0x1b005b + '\x22\x20is\x20present\x20in\x20the\x20text.'), console[_0x238ec9(0x19b)](_0x238ec9(0x189) + _0x262ff3 + _0x238ec9(0x195))) : console[_0x238ec9(0x19b)](_0x238ec9(0x19d) + _0x1b005b + _0x238ec9(0x199));
}
const text = a0_0x32a761(0x18c),
    word = a0_0x32a761(0x18e),
    word1 = a0_0x32a761(0x19f);

function a0_0xe165() {
    const _0x3b9e8c = ['2598892pOfQYa', '3391428lpSpKG', '\x22\x20is\x20not\x20present\x20in\x20the\x20text.', '6322815gwCsvS', 'log', '1yQcKbG', 'The\x20word\x20\x22', '6sLAlGm', 'hello', 'It\x20appears\x20', 'split', '2263292ScqdVo', 'Hello,\x20world!\x20This\x20is\x20a\x20hello\x20test\x20text\x20to\x20check\x20the\x20word\x20presence.', '268219aBIKXW', 'test', 'replace', '27936bHOkEI', '5260bYtAUI', 'reduce', '10188222gFAoga', '16dfXYQr', '\x20time(s)\x20in\x20the\x20text.', 'toLowerCase'];
    a0_0xe165 = function() {
        return _0x3b9e8c;
    };
    return a0_0xe165();
}
checkWordPresence(text, word), checkWordPresence(text, word1);