const a0_0x2036bd = a0_0x2e7c;

function a0_0x2e7c(_0x5b84ec, _0x3d5c89) {
    const _0x384527 = a0_0x3845();
    return a0_0x2e7c = function(_0x2e7c84, _0x54a148) {
        _0x2e7c84 = _0x2e7c84 - 0x185;
        let _0xd87e1d = _0x384527[_0x2e7c84];
        return _0xd87e1d;
    }, a0_0x2e7c(_0x5b84ec, _0x3d5c89);
}

function a0_0x3845() {
    const _0x1de3c1 = ['17968HePVGg', '99HfaPaN', '9YdSyYK', 'log', '5695504tVPGYm', '5321604KmKmkO', 'match', '515585iILxAH', 'This\x20Is\x20A\x20Text\x20With\x20A\x20Lot\x20of\x20Capital\x20Letters', '10391090GtbhAG', 'Initial\x20Text:', '180plvGNK', '963750JAJmDi', '1180386uJCwPi', '64kWexuw', '5mraQPH'];
    a0_0x3845 = function() {
        return _0x1de3c1;
    };
    return a0_0x3845();
}(function(_0x12037e, _0x3eded8) {
    const _0x2e161b = a0_0x2e7c,
        _0x55e880 = _0x12037e();
    while (!![]) {
        try {
            const _0x44ddb1 = -parseInt(_0x2e161b(0x190)) / 0x1 + parseInt(_0x2e161b(0x194)) / 0x2 * (-parseInt(_0x2e161b(0x18f)) / 0x3) + -parseInt(_0x2e161b(0x188)) / 0x4 * (parseInt(_0x2e161b(0x193)) / 0x5) + parseInt(_0x2e161b(0x191)) / 0x6 + -parseInt(_0x2e161b(0x18b)) / 0x7 * (-parseInt(_0x2e161b(0x192)) / 0x8) + parseInt(_0x2e161b(0x186)) / 0x9 * (-parseInt(_0x2e161b(0x18d)) / 0xa) + parseInt(_0x2e161b(0x185)) / 0xb * (parseInt(_0x2e161b(0x189)) / 0xc);
            if (_0x44ddb1 === _0x3eded8) break;
            else _0x55e880['push'](_0x55e880['shift']());
        } catch (_0x368ae7) {
            _0x55e880['push'](_0x55e880['shift']());
        }
    }
}(a0_0x3845, 0xc6187));

function extractCapitalLetters(_0x5d84a) {
    const _0x219d9a = a0_0x2e7c;
    let _0x3a414d = _0x5d84a[_0x219d9a(0x18a)](/[A-Z]/g)['join']('');
    return _0x3a414d;
}
let initialText = a0_0x2036bd(0x18c),
    result = extractCapitalLetters(initialText);
console[a0_0x2036bd(0x187)](a0_0x2036bd(0x18e), initialText), console[a0_0x2036bd(0x187)]('Result:', result);