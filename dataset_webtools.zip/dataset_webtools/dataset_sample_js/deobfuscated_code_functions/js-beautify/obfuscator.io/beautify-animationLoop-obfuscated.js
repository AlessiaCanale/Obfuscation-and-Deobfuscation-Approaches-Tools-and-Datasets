const a0_0xe3ad55 = a0_0x420e;
(function(_0x404986, _0x2ac223) {
    const _0x29035e = a0_0x420e,
        _0x5d91ac = _0x404986();
    while (!![]) {
        try {
            const _0x1bad1f = parseInt(_0x29035e(0x79)) / 0x1 + parseInt(_0x29035e(0x7d)) / 0x2 * (-parseInt(_0x29035e(0x70)) / 0x3) + -parseInt(_0x29035e(0x7a)) / 0x4 * (-parseInt(_0x29035e(0x6b)) / 0x5) + -parseInt(_0x29035e(0x76)) / 0x6 * (parseInt(_0x29035e(0x7f)) / 0x7) + parseInt(_0x29035e(0x77)) / 0x8 + -parseInt(_0x29035e(0x78)) / 0x9 + -parseInt(_0x29035e(0x73)) / 0xa;
            if (_0x1bad1f === _0x2ac223) break;
            else _0x5d91ac['push'](_0x5d91ac['shift']());
        } catch (_0x554712) {
            _0x5d91ac['push'](_0x5d91ac['shift']());
        }
    }
}(a0_0x5e20, 0x64891));
const FRAME_DURATION = 0x3e8 / 0x3c,
    getTime = typeof performance === 'function' ? performance[a0_0xe3ad55(0x6a)] : Date[a0_0xe3ad55(0x6a)],
    MAX_POSITION = 0x96,
    boxRaf = document[a0_0xe3ad55(0x7e)](a0_0xe3ad55(0x6e)),
    positionElementRaf = document[a0_0xe3ad55(0x7e)](a0_0xe3ad55(0x75));
let positionRaf = 0x0;

function animateRaf() {
    const _0x60378e = a0_0xe3ad55;
    positionRaf += 0x1, positionRaf > MAX_POSITION && (positionRaf = 0x0), boxRaf[_0x60378e(0x80)]['transform'] = _0x60378e(0x6d) + positionRaf + 'px)', positionElementRaf['innerHTML'] = positionRaf[_0x60378e(0x7c)](0x2) + 'px', requestAnimationFrame(animateRaf);
}
animateRaf();
const boxTimeout = document[a0_0xe3ad55(0x7e)]('.Example--timeout\x20.Box'),
    positionElementTimeout = document[a0_0xe3ad55(0x7e)](a0_0xe3ad55(0x6f));
let positionTimeout = 0x0;

function a0_0x420e(_0x2bcbc8, _0x55363b) {
    const _0x5e2061 = a0_0x5e20();
    return a0_0x420e = function(_0x420ecd, _0x162bad) {
        _0x420ecd = _0x420ecd - 0x6a;
        let _0xd4c572 = _0x5e2061[_0x420ecd];
        return _0xd4c572;
    }, a0_0x420e(_0x2bcbc8, _0x55363b);
}

function animateTimeout() {
    const _0x5b2d8c = a0_0xe3ad55;
    positionTimeout += 0x1, positionTimeout > MAX_POSITION && (positionTimeout -= MAX_POSITION), boxTimeout[_0x5b2d8c(0x80)]['transform'] = _0x5b2d8c(0x6d) + positionTimeout + 'px)', positionElementTimeout[_0x5b2d8c(0x74)] = positionTimeout[_0x5b2d8c(0x7c)](0x2) + 'px', setTimeout(animateTimeout, 0x64);
}
animateTimeout();
const boxTimeoutDelta = document['querySelector']('.Example--timeoutDelta\x20.Box'),
    positionElementTimeoutDelta = document['querySelector'](a0_0xe3ad55(0x71));
let positionTimeoutDelta = 0x0,
    lastTimeoutUpdate = getTime();

function animateTimeoutDelta() {
    const _0x63dd2a = a0_0xe3ad55,
        _0x2e531d = getTime(),
        _0x3660da = (_0x2e531d - lastTimeoutUpdate) / FRAME_DURATION;
    positionTimeoutDelta += 0x1 * _0x3660da, positionTimeoutDelta > MAX_POSITION && (positionTimeoutDelta -= MAX_POSITION), boxTimeoutDelta[_0x63dd2a(0x80)]['transform'] = 'translateX(' + positionTimeoutDelta + _0x63dd2a(0x6c), positionElementTimeoutDelta['innerHTML'] = positionTimeoutDelta[_0x63dd2a(0x7c)](0x2) + 'px', lastTimeoutUpdate = _0x2e531d, setTimeout(animateTimeoutDelta, 0x64);
}
animateTimeoutDelta();
const boxRafDelta = document[a0_0xe3ad55(0x7e)](a0_0xe3ad55(0x72)),
    positionElementRafDelta = document[a0_0xe3ad55(0x7e)](a0_0xe3ad55(0x7b));

function a0_0x5e20() {
    const _0x310233 = ['toFixed', '23060stDiJe', 'querySelector', '13118SvTVAy', 'style', 'now', '815CVkHHM', 'px)', 'translateX(', '.Example--raf\x20.Box', '.Example--timeout\x20.Example-position', '123ubyQiX', '.Example--timeoutDelta\x20.Example-position', '.Example--rafDelta\x20.Box', '2798400dIOFCl', 'innerHTML', '.Example--raf\x20.Example-position', '462TZZeoq', '2203656AtZxhn', '724806KzqrAw', '750085WBEuno', '8924rAMKNe', '.Example--rafDelta\x20.Example-position'];
    a0_0x5e20 = function() {
        return _0x310233;
    };
    return a0_0x5e20();
}
let positionRafDelta = 0x0,
    lastRafUpdate = getTime();

function animateRafDelta() {
    const _0x3d7d54 = a0_0xe3ad55,
        _0x4563de = getTime(),
        _0x4d7e6c = (_0x4563de - lastRafUpdate) / FRAME_DURATION;
    positionRafDelta += 0x1 * _0x4d7e6c, positionRafDelta > MAX_POSITION && (positionRafDelta -= MAX_POSITION), boxRafDelta['style']['transform'] = _0x3d7d54(0x6d) + positionRafDelta + _0x3d7d54(0x6c), positionElementRafDelta[_0x3d7d54(0x74)] = positionRafDelta[_0x3d7d54(0x7c)](0x2) + 'px', lastRafUpdate = _0x4563de, requestAnimationFrame(animateRafDelta);
}
animateRafDelta();