const a0_0x3ecaa7 = a0_0x3563;
(function(_0x1bcb04, _0x14a7c1) {
    const _0x3b8168 = a0_0x3563,
        _0x3732f4 = _0x1bcb04();
    while (!![]) {
        try {
            const _0x274941 = parseInt(_0x3b8168(0xc9)) / 0x1 * (-parseInt(_0x3b8168(0xc5)) / 0x2) + parseInt(_0x3b8168(0xd9)) / 0x3 + -parseInt(_0x3b8168(0xcb)) / 0x4 * (parseInt(_0x3b8168(0xc7)) / 0x5) + parseInt(_0x3b8168(0xd6)) / 0x6 + parseInt(_0x3b8168(0xd3)) / 0x7 * (parseInt(_0x3b8168(0xc6)) / 0x8) + parseInt(_0x3b8168(0xca)) / 0x9 * (-parseInt(_0x3b8168(0xd5)) / 0xa) + parseInt(_0x3b8168(0xd8)) / 0xb;
            if (_0x274941 === _0x14a7c1) break;
            else _0x3732f4['push'](_0x3732f4['shift']());
        } catch (_0x5a878d) {
            _0x3732f4['push'](_0x3732f4['shift']());
        }
    }
}(a0_0x2be1, 0xcb94b));

function a0_0x3563(_0x5eaf85, _0x355d41) {
    const _0x2be184 = a0_0x2be1();
    return a0_0x3563 = function(_0x356374, _0x3a7c3a) {
        _0x356374 = _0x356374 - 0xc5;
        let _0x4e7a25 = _0x2be184[_0x356374];
        return _0x4e7a25;
    }, a0_0x3563(_0x5eaf85, _0x355d41);
}

function findWordWithStringInside(_0x97b67b, _0x4e2464) {
    const _0x166df8 = a0_0x3563,
        _0x4debda = _0x97b67b['split'](/\s+/),
        _0x41b285 = _0x4debda[_0x166df8(0xce)](_0xb86496 => _0xb86496['toLowerCase']()[_0x166df8(0xd7)](_0x4e2464['toLowerCase']()));
    console[_0x166df8(0xda)](_0x166df8(0xd0) + _0x97b67b), console['log'](_0x166df8(0xcd) + _0x4e2464 + '\x27'), _0x41b285[_0x166df8(0xd4)] > 0x0 ? console['log'](_0x166df8(0xcc), _0x41b285[_0x166df8(0xd2)](',\x20')) : console['log'](_0x166df8(0xcf));
}
const text = a0_0x3ecaa7(0xc8),
    searchString = a0_0x3ecaa7(0xd1);

function a0_0x2be1() {
    const _0x157e01 = ['10693611MwlBGJ', '1664588qCxpGv', 'Matching\x20Words:', 'Search\x20String:\x20\x27', 'filter', 'No\x20words\x20found\x20with\x20the\x20given\x20search\x20string\x20inside.', 'Text:\x20', 'app', 'join', '20797HfNWOU', 'length', '10tVNOch', '8913792gQxTGe', 'includes', '12200463uebDqF', '2527440DeDTSg', 'log', '2586362qPnEoe', '792lotkCN', '5NhwqxV', 'The\x20quick\x20brown\x20fox\x20jumps\x20over\x20the\x20lazy\x20dog.\x20Apples\x20are\x20delicious,\x20thank\x20you', '1gOjefu'];
    a0_0x2be1 = function() {
        return _0x157e01;
    };
    return a0_0x2be1();
}
findWordWithStringInside(text, searchString);
const searchString1 = 'th';
findWordWithStringInside(text, searchString1);
const searchString2 = 'ou';
findWordWithStringInside(text, searchString2);