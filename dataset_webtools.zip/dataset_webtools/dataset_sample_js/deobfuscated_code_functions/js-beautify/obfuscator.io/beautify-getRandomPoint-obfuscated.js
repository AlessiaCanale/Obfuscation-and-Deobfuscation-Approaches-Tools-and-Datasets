const a0_0x768de4 = a0_0x2955;

function a0_0x1cb4() {
    const _0x228d86 = ['2160543rptQwx', '29576240THMETx', '349765sYsegU', '769046zNTSFf', 'log', '60JvJvkO', '2djpdZs', '2572367lCvVJl', 'floor', 'random', '1367120GtqSlM', '6281010QnTtyX', '16dGmRHj'];
    a0_0x1cb4 = function() {
        return _0x228d86;
    };
    return a0_0x1cb4();
}

function a0_0x2955(_0x3977b8, _0x14ea00) {
    const _0x1cb4e4 = a0_0x1cb4();
    return a0_0x2955 = function(_0x2955dc, _0x26917e) {
        _0x2955dc = _0x2955dc - 0x104;
        let _0x1d8a9e = _0x1cb4e4[_0x2955dc];
        return _0x1d8a9e;
    }, a0_0x2955(_0x3977b8, _0x14ea00);
}(function(_0x3e90b0, _0x38ee55) {
    const _0xf10de4 = a0_0x2955,
        _0x1b2fab = _0x3e90b0();
    while (!![]) {
        try {
            const _0x1bcfbb = -parseInt(_0xf10de4(0x10a)) / 0x1 + -parseInt(_0xf10de4(0x10d)) / 0x2 * (parseInt(_0xf10de4(0x107)) / 0x3) + -parseInt(_0xf10de4(0x104)) / 0x4 + parseInt(_0xf10de4(0x109)) / 0x5 * (parseInt(_0xf10de4(0x10c)) / 0x6) + parseInt(_0xf10de4(0x10e)) / 0x7 * (-parseInt(_0xf10de4(0x106)) / 0x8) + -parseInt(_0xf10de4(0x105)) / 0x9 + parseInt(_0xf10de4(0x108)) / 0xa;
            if (_0x1bcfbb === _0x38ee55) break;
            else _0x1b2fab['push'](_0x1b2fab['shift']());
        } catch (_0x303939) {
            _0x1b2fab['push'](_0x1b2fab['shift']());
        }
    }
}(a0_0x1cb4, 0x6004f));

function getRandomPoint() {
    const _0x21a6e9 = a0_0x2955,
        _0x1fc9c0 = Math['floor'](Math[_0x21a6e9(0x110)]() * 0x65),
        _0xecac54 = Math[_0x21a6e9(0x10f)](Math[_0x21a6e9(0x110)]() * 0x65);
    return {
        'x': _0x1fc9c0,
        'y': _0xecac54
    };
}
const randomPoint = getRandomPoint();
console[a0_0x768de4(0x10b)]('Random\x20Point:\x20(' + randomPoint['x'] + ',\x20' + randomPoint['y'] + ')');