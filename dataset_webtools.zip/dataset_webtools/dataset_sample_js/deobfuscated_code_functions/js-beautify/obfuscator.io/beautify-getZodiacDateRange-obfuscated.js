var a0_0x2715eb = a0_0x2071;
(function(_0x75d301, _0x5ee421) {
    var _0x566f0f = a0_0x2071,
        _0x4c54a8 = _0x75d301();
    while (!![]) {
        try {
            var _0x33b814 = parseInt(_0x566f0f(0x84)) / 0x1 + -parseInt(_0x566f0f(0x8d)) / 0x2 + -parseInt(_0x566f0f(0x78)) / 0x3 + -parseInt(_0x566f0f(0x81)) / 0x4 * (parseInt(_0x566f0f(0x7b)) / 0x5) + -parseInt(_0x566f0f(0x87)) / 0x6 + -parseInt(_0x566f0f(0x7a)) / 0x7 * (parseInt(_0x566f0f(0x79)) / 0x8) + -parseInt(_0x566f0f(0x85)) / 0x9 * (-parseInt(_0x566f0f(0x80)) / 0xa);
            if (_0x33b814 === _0x5ee421) break;
            else _0x4c54a8['push'](_0x4c54a8['shift']());
        } catch (_0x2c6727) {
            _0x4c54a8['push'](_0x4c54a8['shift']());
        }
    }
}(a0_0x1408, 0xf3683));

function a0_0x2071(_0x201a2b, _0x2fa2e9) {
    var _0x140839 = a0_0x1408();
    return a0_0x2071 = function(_0x2071fa, _0x37404c) {
        _0x2071fa = _0x2071fa - 0x73;
        var _0x3f507d = _0x140839[_0x2071fa];
        return _0x3f507d;
    }, a0_0x2071(_0x201a2b, _0x2fa2e9);
}

function a0_0x1408() {
    var _0x2b30ec = ['467754zUEOBI', '9235WuHntq', 'Pisces\x20(February\x2019\x20-\x20March\x2020)', 'Leo\x20(July\x2023\x20-\x20August\x2022)', 'capricorn', 'Scorpio\x20(October\x2023\x20-\x20November\x2021)', '968070QdTBBy', '3508UlNrsg', 'scorpio', 'libra', '1715308JQOhei', '360fiPhuB', 'Aries\x20(March\x2021\x20-\x20April\x2019)', '4854456eYtZvh', 'pisces', 'sagittarius', 'Capricorn\x20(December\x2022\x20-\x20January\x2019)', 'Taurus\x20(April\x2020\x20-\x20May\x2020)', 'leo', '736880GOQkkn', 'gemini', 'Aquarius\x20(January\x2020\x20-\x20February\x2018)', 'Virgo\x20(August\x2023\x20-\x20September\x2022)', 'cancer', 'log', 'taurus', 'virgo', 'aquarius', 'Libra\x20(September\x2023\x20-\x20October\x2022)', '2773716SBqmgq', '104mnfQNg'];
    a0_0x1408 = function() {
        return _0x2b30ec;
    };
    return a0_0x1408();
}

function getZodiacDateRange(_0x592774) {
    var _0x5cceb4 = a0_0x2071;
    switch (_0x592774['toLowerCase']()) {
        case 'aries':
            return _0x5cceb4(0x86);
        case _0x5cceb4(0x74):
            return _0x5cceb4(0x8b);
        case _0x5cceb4(0x8e):
            return 'Gemini\x20(May\x2021\x20-\x20June\x2020)';
        case _0x5cceb4(0x91):
            return 'Cancer\x20(June\x2021\x20-\x20July\x2022)';
        case _0x5cceb4(0x8c):
            return _0x5cceb4(0x7d);
        case _0x5cceb4(0x75):
            return _0x5cceb4(0x90);
        case _0x5cceb4(0x83):
            return _0x5cceb4(0x77);
        case _0x5cceb4(0x82):
            return _0x5cceb4(0x7f);
        case _0x5cceb4(0x89):
            return 'Sagittarius\x20(November\x2022\x20-\x20December\x2021)';
        case _0x5cceb4(0x7e):
            return _0x5cceb4(0x8a);
        case 'aquarius':
            return _0x5cceb4(0x8f);
        case 'pisces':
            return _0x5cceb4(0x7c);
        default:
            return 'Invalid\x20zodiac\x20sign\x20provided';
    }
}
console[a0_0x2715eb(0x73)](getZodiacDateRange('aries')), console[a0_0x2715eb(0x73)](getZodiacDateRange(a0_0x2715eb(0x83))), console['log'](getZodiacDateRange(a0_0x2715eb(0x76))), console['log'](getZodiacDateRange(a0_0x2715eb(0x82))), console[a0_0x2715eb(0x73)](getZodiacDateRange(a0_0x2715eb(0x88)));