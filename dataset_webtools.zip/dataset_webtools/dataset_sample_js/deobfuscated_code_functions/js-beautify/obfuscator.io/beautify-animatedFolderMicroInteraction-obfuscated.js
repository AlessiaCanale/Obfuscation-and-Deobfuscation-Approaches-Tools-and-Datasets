const a0_0x1b5847 = a0_0x2ae4;

function a0_0x2ae4(_0x4d33b7, _0x509afd) {
    const _0x8ce6d4 = a0_0x8ce6();
    return a0_0x2ae4 = function(_0x2ae427, _0x373e80) {
        _0x2ae427 = _0x2ae427 - 0x6e;
        let _0x5e289e = _0x8ce6d4[_0x2ae427];
        return _0x5e289e;
    }, a0_0x2ae4(_0x4d33b7, _0x509afd);
}(function(_0x2e35ec, _0x5685a4) {
    const _0xd6a499 = a0_0x2ae4,
        _0x5f0b4c = _0x2e35ec();
    while (!![]) {
        try {
            const _0xd3d271 = -parseInt(_0xd6a499(0x6e)) / 0x1 + parseInt(_0xd6a499(0x70)) / 0x2 * (-parseInt(_0xd6a499(0x82)) / 0x3) + parseInt(_0xd6a499(0x84)) / 0x4 * (-parseInt(_0xd6a499(0x6f)) / 0x5) + parseInt(_0xd6a499(0x72)) / 0x6 + parseInt(_0xd6a499(0x76)) / 0x7 + -parseInt(_0xd6a499(0x7f)) / 0x8 * (parseInt(_0xd6a499(0x7a)) / 0x9) + parseInt(_0xd6a499(0x88)) / 0xa;
            if (_0xd3d271 === _0x5685a4) break;
            else _0x5f0b4c['push'](_0x5f0b4c['shift']());
        } catch (_0x5ab2fd) {
            _0x5f0b4c['push'](_0x5f0b4c['shift']());
        }
    }
}(a0_0x8ce6, 0xe2a06));
const toggleFolder = document[a0_0x1b5847(0x7e)](a0_0x1b5847(0x77)),
    showFolderContentAnimation = anime['timeline']({
        'easing': a0_0x1b5847(0x7d),
        'autoplay': ![]
    });
showFolderContentAnimation[a0_0x1b5847(0x7c)]({
    'targets': a0_0x1b5847(0x86),
    'height': [0x0, 0xf0],
    'duration': 0x15e
})[a0_0x1b5847(0x7c)]({
    'targets': '#js_folder-summary-amount',
    'opacity': [0x1, 0x0],
    'duration': 0x190
}, a0_0x1b5847(0x83))['add']({
    'targets': a0_0x1b5847(0x78),
    'opacity': [0x0, 0x1],
    'duration': 0x190
}, a0_0x1b5847(0x74))['add']({
    'targets': '#js_folder-collapse-button-icon',
    'duration': 0x12c,
    'translateX': [a0_0x1b5847(0x85), a0_0x1b5847(0x85)],
    'translateY': [a0_0x1b5847(0x85), a0_0x1b5847(0x85)],
    'rotate': [a0_0x1b5847(0x89), a0_0x1b5847(0x7b)]
}, a0_0x1b5847(0x87))[a0_0x1b5847(0x7c)]({
    'targets': a0_0x1b5847(0x8a),
    'translateY': [0x14, 0x0],
    'opacity': [0x0, 0x1],
    'duration': 0x12c,
    'delay': (_0x326e16, _0x20dc18, _0x16d735) => _0x20dc18 * 0x78
}, '-=275'), toggleFolder['addEventListener'](a0_0x1b5847(0x73), () => {
    const _0xba0338 = a0_0x1b5847;
    showFolderContentAnimation[_0xba0338(0x71)] && (showFolderContentAnimation['reverse'](), showFolderContentAnimation[_0xba0338(0x8b)] === 0x64 && showFolderContentAnimation[_0xba0338(0x75)] === _0xba0338(0x81) && (showFolderContentAnimation[_0xba0338(0x80)] = ![])), showFolderContentAnimation['paused'] && showFolderContentAnimation[_0xba0338(0x79)]();
});

function a0_0x8ce6() {
    const _0xba3d55 = ['began', '10795692xAHCXJ', 'click', '-=300', 'direction', '12808124AevDCq', 'js_toggle-folder', '#js_folder-collapse-button', 'play', '909CoUbFO', '180deg', 'add', 'easeOutCubic', 'getElementById', '116432EAVoaw', 'completed', 'reverse', '6OJCgWr', '-=350', '87332cVFHmV', '-50%', '#js_folder-content', '-=400', '22319170dhSSEV', '0deg', '.js_folder-item', 'progress', '1655246Kcpxng', '5rGdYpO', '1785636lgmNgo'];
    a0_0x8ce6 = function() {
        return _0xba3d55;
    };
    return a0_0x8ce6();
}