const a0_0x56b764 = a0_0x58cf;
(function(_0x1c3512, _0xef2c8c) {
    const _0x105960 = a0_0x58cf,
        _0x30d5b2 = _0x1c3512();
    while (!![]) {
        try {
            const _0xa2b5df = -parseInt(_0x105960(0x1d4)) / 0x1 + -parseInt(_0x105960(0x1cd)) / 0x2 + parseInt(_0x105960(0x1d0)) / 0x3 * (parseInt(_0x105960(0x1c9)) / 0x4) + -parseInt(_0x105960(0x1d3)) / 0x5 * (parseInt(_0x105960(0x1cc)) / 0x6) + -parseInt(_0x105960(0x1cb)) / 0x7 + -parseInt(_0x105960(0x1c5)) / 0x8 + parseInt(_0x105960(0x1d1)) / 0x9 * (parseInt(_0x105960(0x1c8)) / 0xa);
            if (_0xa2b5df === _0xef2c8c) break;
            else _0x30d5b2['push'](_0x30d5b2['shift']());
        } catch (_0x4b7bb7) {
            _0x30d5b2['push'](_0x30d5b2['shift']());
        }
    }
}(a0_0xd76a, 0x93abe));

function findQuestionText(_0x38e1b8) {
    const _0x52767d = a0_0x58cf,
        _0x35ba44 = /[A-Z][A-Za-z\s]+\?/g,
        _0x2d0909 = _0x38e1b8[_0x52767d(0x1c7)](_0x35ba44);
    _0x2d0909 ? _0x2d0909[_0x52767d(0x1c6)](_0x4fbb92 => {
        const _0x370471 = _0x52767d;
        console[_0x370471(0x1cf)](_0x4fbb92);
    }) : console[_0x52767d(0x1cf)](_0x52767d(0x1ca));
}
const text = a0_0x56b764(0x1ce);

function a0_0xd76a() {
    const _0x5a38db = ['match', '10ovNanx', '610860WERzlo', 'No\x20matching\x20strings\x20found.', '3023538XuDaxz', '6JESOZF', '2344546kgPYfR', 'Hello,\x20World!\x20How\x20are\x20you?\x20Is\x20everything\x20alright?\x20I\x20hope\x20so.\x20What\x20is\x20the\x20weather\x20like\x20today?', 'log', '18kwnVas', '23955048JUuIQp', 'Matched\x20strings:', '3182380QeVNhq', '677018zNbfQG', '443192EQmchS', 'forEach'];
    a0_0xd76a = function() {
        return _0x5a38db;
    };
    return a0_0xd76a();
}

function a0_0x58cf(_0x2ba6b4, _0x104efe) {
    const _0xd76a02 = a0_0xd76a();
    return a0_0x58cf = function(_0x58cff7, _0x57cf40) {
        _0x58cff7 = _0x58cff7 - 0x1c5;
        let _0x894246 = _0xd76a02[_0x58cff7];
        return _0x894246;
    }, a0_0x58cf(_0x2ba6b4, _0x104efe);
}
console['log']('Original\x20text:\x0a' + text + '\x0a'), console[a0_0x56b764(0x1cf)](a0_0x56b764(0x1d2)), findQuestionText(text);