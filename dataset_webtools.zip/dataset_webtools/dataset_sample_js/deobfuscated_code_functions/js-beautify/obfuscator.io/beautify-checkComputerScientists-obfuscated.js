const a0_0x4049a4 = a0_0x3b52;
(function(_0x3a904e, _0x245903) {
    const _0x6d8a25 = a0_0x3b52,
        _0x3ec10b = _0x3a904e();
    while (!![]) {
        try {
            const _0x554a7f = parseInt(_0x6d8a25(0x1bd)) / 0x1 * (-parseInt(_0x6d8a25(0x1b2)) / 0x2) + -parseInt(_0x6d8a25(0x1c3)) / 0x3 + -parseInt(_0x6d8a25(0x1c2)) / 0x4 * (-parseInt(_0x6d8a25(0x1c4)) / 0x5) + -parseInt(_0x6d8a25(0x1bb)) / 0x6 * (-parseInt(_0x6d8a25(0x1b1)) / 0x7) + -parseInt(_0x6d8a25(0x1be)) / 0x8 * (-parseInt(_0x6d8a25(0x1b6)) / 0x9) + parseInt(_0x6d8a25(0x1af)) / 0xa * (-parseInt(_0x6d8a25(0x1c6)) / 0xb) + parseInt(_0x6d8a25(0x1bc)) / 0xc * (-parseInt(_0x6d8a25(0x1c5)) / 0xd);
            if (_0x554a7f === _0x245903) break;
            else _0x3ec10b['push'](_0x3ec10b['shift']());
        } catch (_0x1400c1) {
            _0x3ec10b['push'](_0x3ec10b['shift']());
        }
    }
}(a0_0x120f, 0xe7d82));

function a0_0x3b52(_0x4a25cb, _0x50d571) {
    const _0x120f7a = a0_0x120f();
    return a0_0x3b52 = function(_0x3b52f0, _0x31178e) {
        _0x3b52f0 = _0x3b52f0 - 0x1ac;
        let _0x19b599 = _0x120f7a[_0x3b52f0];
        return _0x19b599;
    }, a0_0x3b52(_0x4a25cb, _0x50d571);
}

function checkComputerScientists(_0x16e670, _0xc439ee) {
    const _0x3a8504 = a0_0x3b52;
    for (let _0x235615 = 0x0; _0x235615 < _0xc439ee[_0x3a8504(0x1ba)]; _0x235615++) {
        _0x16e670[_0x3a8504(0x1c8)](_0xc439ee[_0x235615]) ? console[_0x3a8504(0x1bf)](_0xc439ee[_0x235615] + _0x3a8504(0x1b4)) : console['log'](_0xc439ee[_0x235615] + _0x3a8504(0x1ad));
    }
}
const computerScientists = [a0_0x4049a4(0x1ae), 'Ada\x20Lovelace', a0_0x4049a4(0x1b3), a0_0x4049a4(0x1ac), 'Tim\x20Berners-Lee', a0_0x4049a4(0x1c1), a0_0x4049a4(0x1b8), a0_0x4049a4(0x1b0), a0_0x4049a4(0x1b7), a0_0x4049a4(0x1c7)],
    names = [a0_0x4049a4(0x1b5), 'Paul\x20Jobs', a0_0x4049a4(0x1ac), a0_0x4049a4(0x1c0), a0_0x4049a4(0x1b9)];
checkComputerScientists(computerScientists, names);

function a0_0x120f() {
    const _0x3cac61 = ['170532FHxxds', '1Gzxtug', '256KQQhQD', 'log', 'Bill\x20Fates', 'Katherine\x20Johnson', '1912jdKfLg', '5521482ekMKGp', '16160apKItH', '195nGEljK', '11fGyyIX', 'Sheryl\x20Sandberg', 'includes', 'Grace\x20Hopper', '\x20is\x20not\x20a\x20computer\x20scientist.', 'Alan\x20Turing', '273730QNkTbs', 'Margaret\x20Hamilton', '7zUvTKa', '2035838aSqyaY', 'Linus\x20Torvalds', '\x20is\x20a\x20computer\x20scientist.', 'Ada\x20Lovelace', '472239GZvXrH', 'Mark\x20Zuckerberg', 'Steve\x20Wozniak', 'Tim\x20Cooker', 'length', '4947702chwtoY'];
    a0_0x120f = function() {
        return _0x3cac61;
    };
    return a0_0x120f();
}