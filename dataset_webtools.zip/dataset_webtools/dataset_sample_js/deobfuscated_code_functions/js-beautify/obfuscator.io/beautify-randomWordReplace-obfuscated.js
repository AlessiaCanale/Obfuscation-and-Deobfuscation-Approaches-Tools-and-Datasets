function a0_0x43f1() {
    const _0x53b5d6 = ['403186vDhvzt', 'log', 'floor', 'repeat', 'filter', '331620lhZxqf', '1048740QyWkps', '414054RtyWYx', 'length', '508624Ijwlkj', '846dhZDRL', 'split', '85818ooBalN', '16EdYAmZ', 'Try\x20to\x20guess\x20the\x20word\x20from\x20the\x20context\x20of\x20the\x20text\x20and\x20the\x20clues\x20I\x20provided.', '2dOlOic', 'random', '55rVDqMP', '24FSInQV', 'Did\x20you\x20guess\x20it?', 'replace'];
    a0_0x43f1 = function() {
        return _0x53b5d6;
    };
    return a0_0x43f1();
}(function(_0x48f9f2, _0x4977f5) {
    const _0x540038 = a0_0x6683,
        _0x569dba = _0x48f9f2();
    while (!![]) {
        try {
            const _0x497443 = -parseInt(_0x540038(0x8e)) / 0x1 * (-parseInt(_0x540038(0x91)) / 0x2) + parseInt(_0x540038(0x8c)) / 0x3 + -parseInt(_0x540038(0x8b)) / 0x4 + -parseInt(_0x540038(0x87)) / 0x5 * (parseInt(_0x540038(0x94)) / 0x6) + parseInt(_0x540038(0x97)) / 0x7 * (-parseInt(_0x540038(0x8f)) / 0x8) + parseInt(_0x540038(0x89)) / 0x9 + -parseInt(_0x540038(0x88)) / 0xa * (-parseInt(_0x540038(0x93)) / 0xb);
            if (_0x497443 === _0x4977f5) break;
            else _0x569dba['push'](_0x569dba['shift']());
        } catch (_0x19d9ed) {
            _0x569dba['push'](_0x569dba['shift']());
        }
    }
}(a0_0x43f1, 0x2455c));

function a0_0x6683(_0x10cb12, _0x2a965f) {
    const _0x43f1d8 = a0_0x43f1();
    return a0_0x6683 = function(_0x66836e, _0x4a1ca2) {
        _0x66836e = _0x66836e - 0x83;
        let _0x11e7a9 = _0x43f1d8[_0x66836e];
        return _0x11e7a9;
    }, a0_0x6683(_0x10cb12, _0x2a965f);
}

function randomWordReplace(_0x48222f) {
    const _0x4d69e5 = a0_0x6683,
        _0x34ff66 = _0x48222f[_0x4d69e5(0x8d)]('\x20'),
        _0x3d3364 = _0x34ff66[_0x4d69e5(0x86)](_0x99505f => _0x99505f[_0x4d69e5(0x8a)] >= 0x3),
        _0x5e8929 = Math[_0x4d69e5(0x84)](Math[_0x4d69e5(0x92)]() * _0x3d3364['length']),
        _0x1248d6 = _0x3d3364[_0x5e8929],
        _0x56dc1f = '?' [_0x4d69e5(0x85)](_0x1248d6['length']),
        _0x391205 = _0x48222f[_0x4d69e5(0x96)](_0x1248d6, _0x56dc1f),
        _0x400676 = _0x1248d6[0x0],
        _0x4dc8e4 = _0x1248d6[_0x1248d6[_0x4d69e5(0x8a)] - 0x1];
    console[_0x4d69e5(0x83)](_0x391205), console[_0x4d69e5(0x83)](_0x4d69e5(0x90)), console['log']('Clue:\x20The\x20word\x20starts\x20with\x20\x22' + _0x400676 + '\x22\x20and\x20ends\x20with\x20\x22' + _0x4dc8e4 + '\x22.'), setTimeout(() => {
        const _0xc1dda8 = _0x4d69e5;
        console[_0xc1dda8(0x83)](_0x1248d6), console['log'](_0xc1dda8(0x95));
    }, 0x1b58);
}
const text = 'This\x20is\x20a\x20random\x20text\x20where\x20we\x20will\x20pick\x20a\x20word\x20to\x20mask\x20and\x20challenge\x20you\x20to\x20guess\x20it.';
randomWordReplace(text);