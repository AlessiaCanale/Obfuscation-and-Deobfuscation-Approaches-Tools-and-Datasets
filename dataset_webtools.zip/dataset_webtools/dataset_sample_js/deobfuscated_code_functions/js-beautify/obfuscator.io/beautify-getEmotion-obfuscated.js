var a0_0x50c7da = a0_0x2e46;
(function(_0x2dbad5, _0x928956) {
    var _0x3b157d = a0_0x2e46,
        _0x1bc646 = _0x2dbad5();
    while (!![]) {
        try {
            var _0x963751 = parseInt(_0x3b157d(0x1e4)) / 0x1 + -parseInt(_0x3b157d(0x1d5)) / 0x2 * (-parseInt(_0x3b157d(0x1d8)) / 0x3) + parseInt(_0x3b157d(0x1df)) / 0x4 + -parseInt(_0x3b157d(0x1d6)) / 0x5 + -parseInt(_0x3b157d(0x1d7)) / 0x6 * (-parseInt(_0x3b157d(0x1d9)) / 0x7) + parseInt(_0x3b157d(0x1e0)) / 0x8 + -parseInt(_0x3b157d(0x1d3)) / 0x9;
            if (_0x963751 === _0x928956) break;
            else _0x1bc646['push'](_0x1bc646['shift']());
        } catch (_0x49401b) {
            _0x1bc646['push'](_0x1bc646['shift']());
        }
    }
}(a0_0x13b7, 0x955a5));

function a0_0x2e46(_0x2815e6, _0x288fd) {
    var _0x13b7a6 = a0_0x13b7();
    return a0_0x2e46 = function(_0x2e46cc, _0x2b9241) {
        _0x2e46cc = _0x2e46cc - 0x1d0;
        var _0x1573d5 = _0x13b7a6[_0x2e46cc];
        return _0x1573d5;
    }, a0_0x2e46(_0x2815e6, _0x288fd);
}

function getEmotion(_0x2876c2) {
    var _0xfb53e9 = a0_0x2e46;
    switch (_0x2876c2) {
        case ':)':
            return 'smile';
        case ':(':
            return _0xfb53e9(0x1db);
        case ':D':
            return _0xfb53e9(0x1dd);
        case ':\x27(':
            return _0xfb53e9(0x1d0);
        case ':*':
            return _0xfb53e9(0x1e1);
        default:
            return _0xfb53e9(0x1e3);
    }
}

function a0_0x13b7() {
    var _0x4b6a91 = ['4800528FhCNoi', 'kiss', ':)\x20=>\x20', 'unknown\x20emotion', '636518bJReSt', 'cry', ':*\x20=>\x20', ':D\x20=>\x20', '13034691Uxdbrd', ':\x27(', '4UvMWuk', '4340175teeIEX', '2051898GntXsY', '521979OgOJII', '7EaoxzM', ':\x27(\x20=>\x20', 'sad', 'log', 'laugh', ':(\x20=>\x20', '4006120tJOEHp'];
    a0_0x13b7 = function() {
        return _0x4b6a91;
    };
    return a0_0x13b7();
}
console[a0_0x50c7da(0x1dc)](a0_0x50c7da(0x1e2) + getEmotion(':)')), console[a0_0x50c7da(0x1dc)](a0_0x50c7da(0x1de) + getEmotion(':(')), console[a0_0x50c7da(0x1dc)](a0_0x50c7da(0x1d2) + getEmotion(':D')), console[a0_0x50c7da(0x1dc)](a0_0x50c7da(0x1da) + getEmotion(a0_0x50c7da(0x1d4))), console[a0_0x50c7da(0x1dc)](a0_0x50c7da(0x1d1) + getEmotion(':*'));