const a0_0x8f1eb0 = a0_0x315d;

function a0_0x315d(_0x5e6e38, _0xdfbb76) {
    const _0x2956a6 = a0_0x2956();
    return a0_0x315d = function(_0x315dcf, _0x4096a9) {
        _0x315dcf = _0x315dcf - 0x175;
        let _0x21fc0b = _0x2956a6[_0x315dcf];
        return _0x21fc0b;
    }, a0_0x315d(_0x5e6e38, _0xdfbb76);
}

function a0_0x2956() {
    const _0x4f3dee = ['(:\x20', '1179SrqrZh', '42659727kVyWJp', '\x20:]', '10678112hvNfcp', 'I\x20like\x20(JavaScript)\x20and\x20[programming].', 'join', '915094BipYSB', '33690DZSNsi', '<This>\x20is\x20(a)\x20{test}\x20[sentence].', '2321823tVuWQv', '{:\x20', '10vbbGdS', '3aBatwW', 'hasOwnProperty', '4221832attBPO', 'log', '2iKbJIi', '\x20:>', '1943382BWXEZw', 'push', 'Modified\x20sentence:\x20', '\x20:)', '12VFlbIG'];
    a0_0x2956 = function() {
        return _0x4f3dee;
    };
    return a0_0x2956();
}(function(_0x448939, _0x293fb3) {
    const _0x14d553 = a0_0x315d,
        _0x526147 = _0x448939();
    while (!![]) {
        try {
            const _0x3688c0 = -parseInt(_0x14d553(0x181)) / 0x1 * (parseInt(_0x14d553(0x177)) / 0x2) + parseInt(_0x14d553(0x17d)) / 0x3 * (-parseInt(_0x14d553(0x17f)) / 0x4) + parseInt(_0x14d553(0x17c)) / 0x5 * (-parseInt(_0x14d553(0x183)) / 0x6) + parseInt(_0x14d553(0x17a)) / 0x7 + -parseInt(_0x14d553(0x18c)) / 0x8 + -parseInt(_0x14d553(0x189)) / 0x9 * (-parseInt(_0x14d553(0x178)) / 0xa) + -parseInt(_0x14d553(0x18a)) / 0xb * (-parseInt(_0x14d553(0x187)) / 0xc);
            if (_0x3688c0 === _0x293fb3) break;
            else _0x526147['push'](_0x526147['shift']());
        } catch (_0x53117d) {
            _0x526147['push'](_0x526147['shift']());
        }
    }
}(a0_0x2956, 0xaa6db));

function changeBracketWithEmoji(_0x25272e) {
    const _0x1149c4 = a0_0x315d,
        _0x5e2ef6 = {
            ')': _0x1149c4(0x186),
            '(': _0x1149c4(0x188),
            '[': '[:\x20',
            ']': _0x1149c4(0x18b),
            '{': _0x1149c4(0x17b),
            '}': '\x20:}',
            '<': '<:\x20',
            '>': _0x1149c4(0x182)
        };
    let _0x447bbc = [];
    for (let _0x532b43 of _0x25272e) {
        _0x5e2ef6[_0x1149c4(0x17e)](_0x532b43) ? _0x447bbc[_0x1149c4(0x184)](_0x5e2ef6[_0x532b43]) : _0x447bbc['push'](_0x532b43);
    }
    _0x447bbc = _0x447bbc[_0x1149c4(0x176)](''), console['log']('Original\x20sentence:\x20' + _0x25272e), console[_0x1149c4(0x180)](_0x1149c4(0x185) + _0x447bbc);
}
changeBracketWithEmoji('Hello\x20(world)!\x20[How]\x20{are}\x20<you>\x20?'), changeBracketWithEmoji(a0_0x8f1eb0(0x175)), changeBracketWithEmoji(a0_0x8f1eb0(0x179));