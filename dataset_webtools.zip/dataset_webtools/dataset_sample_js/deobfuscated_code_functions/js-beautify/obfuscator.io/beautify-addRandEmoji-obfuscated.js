const a0_0x57d943 = a0_0x5a8b;
(function(_0x56f40b, _0x341db2) {
    const _0x297662 = a0_0x5a8b,
        _0x49d461 = _0x56f40b();
    while (!![]) {
        try {
            const _0x175c7b = -parseInt(_0x297662(0x104)) / 0x1 * (parseInt(_0x297662(0xfe)) / 0x2) + -parseInt(_0x297662(0xfd)) / 0x3 * (parseInt(_0x297662(0x107)) / 0x4) + parseInt(_0x297662(0x10c)) / 0x5 * (parseInt(_0x297662(0x102)) / 0x6) + parseInt(_0x297662(0x108)) / 0x7 * (-parseInt(_0x297662(0x10b)) / 0x8) + -parseInt(_0x297662(0x10a)) / 0x9 + -parseInt(_0x297662(0x101)) / 0xa + parseInt(_0x297662(0x106)) / 0xb;
            if (_0x175c7b === _0x341db2) break;
            else _0x49d461['push'](_0x49d461['shift']());
        } catch (_0x3bfd1d) {
            _0x49d461['push'](_0x49d461['shift']());
        }
    }
}(a0_0x1d23, 0x65752));
const emojis = [':)', ':(', ':o', ':*', ':D', ':P', a0_0x57d943(0x105)];

function addRandEmoji(_0x2ecad5) {
    const _0x290d49 = a0_0x57d943,
        _0x4617b6 = /\[\?\]/g,
        _0x212649 = _0x2ecad5[_0x290d49(0x103)](_0x4617b6, () => {
            const _0x4234ba = Math['floor'](Math['random']() * emojis['length']);
            return emojis[_0x4234ba];
        });
    console[_0x290d49(0x100)](_0x290d49(0xff), _0x2ecad5), console[_0x290d49(0x100)]('Modified\x20Text:', _0x212649);
}

function a0_0x1d23() {
    const _0x1c0b5b = ['29032UOwAQc', '95ZqhwJa', '237738vVzFGu', '280RaqjgY', 'Original\x20Text:', 'log', '5018040zYJgUz', '151644UoMzhO', 'replace', '5020GbQhiZ', ':\x27)', '21178762DbNRKy', '8gSPQZK', '791vepnHJ', 'I\x27m\x20feeling\x20[?]\x20today.\x20How\x20about\x20you?', '1951245sZevcY'];
    a0_0x1d23 = function() {
        return _0x1c0b5b;
    };
    return a0_0x1d23();
}
const text = a0_0x57d943(0x109);

function a0_0x5a8b(_0xde1c37, _0x1eb9f6) {
    const _0x1d2383 = a0_0x1d23();
    return a0_0x5a8b = function(_0x5a8b7b, _0x160a4d) {
        _0x5a8b7b = _0x5a8b7b - 0xfd;
        let _0x52bede = _0x1d2383[_0x5a8b7b];
        return _0x52bede;
    }, a0_0x5a8b(_0xde1c37, _0x1eb9f6);
}
addRandEmoji(text);