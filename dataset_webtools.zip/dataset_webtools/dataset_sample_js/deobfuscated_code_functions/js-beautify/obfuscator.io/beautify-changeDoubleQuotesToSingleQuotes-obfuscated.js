const a0_0x392f6c = a0_0x1366;
(function(_0x1a62d5, _0xce67de) {
    const _0x501d65 = a0_0x1366,
        _0x33af42 = _0x1a62d5();
    while (!![]) {
        try {
            const _0x160293 = -parseInt(_0x501d65(0x1da)) / 0x1 * (-parseInt(_0x501d65(0x1e4)) / 0x2) + -parseInt(_0x501d65(0x1dd)) / 0x3 * (-parseInt(_0x501d65(0x1db)) / 0x4) + -parseInt(_0x501d65(0x1e1)) / 0x5 * (-parseInt(_0x501d65(0x1e3)) / 0x6) + parseInt(_0x501d65(0x1de)) / 0x7 * (parseInt(_0x501d65(0x1df)) / 0x8) + parseInt(_0x501d65(0x1e2)) / 0x9 + parseInt(_0x501d65(0x1e6)) / 0xa * (parseInt(_0x501d65(0x1d9)) / 0xb) + parseInt(_0x501d65(0x1e0)) / 0xc * (-parseInt(_0x501d65(0x1e8)) / 0xd);
            if (_0x160293 === _0xce67de) break;
            else _0x33af42['push'](_0x33af42['shift']());
        } catch (_0x44758c) {
            _0x33af42['push'](_0x33af42['shift']());
        }
    }
}(a0_0x8f59, 0xe158f));

function changeDoubleQuotesToSingleQuotes(_0x532ada) {
    const _0x1f6557 = a0_0x1366;
    let _0x18df38 = _0x532ada[_0x1f6557(0x1e5)](/"/g, '\x27');
    console[_0x1f6557(0x1dc)]('Original\x20text:\x20\x22' + _0x532ada + '\x22'), console['log']('Modified\x20text:\x20\x22' + _0x18df38 + '\x22');
}

function a0_0x1366(_0x364036, _0x2c437c) {
    const _0x8f59ea = a0_0x8f59();
    return a0_0x1366 = function(_0x1366c0, _0x35fda2) {
        _0x1366c0 = _0x1366c0 - 0x1d9;
        let _0x3119e6 = _0x8f59ea[_0x1366c0];
        return _0x3119e6;
    }, a0_0x1366(_0x364036, _0x2c437c);
}

function a0_0x8f59() {
    const _0x5ccf7d = ['761096bZwwBI', '80qHRZQe', '276WUCTnC', '1185ZWnoYO', '13331367JqynAh', '33246imHYqk', '4JhZDSt', 'replace', '2396700YzwrXZ', 'This\x20is\x20a\x20\x22sample\x22\x20text.', '2968589FGQfhz', '44ujhPAY', '227249dBiaYy', '67708wtugeC', 'log', '156IRjTFs'];
    a0_0x8f59 = function() {
        return _0x5ccf7d;
    };
    return a0_0x8f59();
}
changeDoubleQuotesToSingleQuotes(a0_0x392f6c(0x1e7)), changeDoubleQuotesToSingleQuotes('\x22Double\x20quotes\x22\x20everywhere!');