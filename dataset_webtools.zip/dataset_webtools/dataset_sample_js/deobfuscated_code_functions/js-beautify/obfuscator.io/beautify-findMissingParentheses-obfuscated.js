const a0_0x4cf5fc = a0_0x41b5;

function a0_0x2a2f() {
    const _0x2f195e = ['120VSFPOa', 'push', 'pop', '2350792CnyWpB', '45ZEvwDe', '1155638iDXAnr', '14CFmlDR', '991985QdoSXC', 'length', 'missing\x20matching\x20parenthesis', '47052FilHnV', 'char', '6tbTREz', '106490jejuQe', 'missing\x20closing\x20parenthesis', '929181xBjcew', '54ezcLrn', '1699324rOuwKd', 'missing\x20opening\x20parenthesis', 'log'];
    a0_0x2a2f = function() {
        return _0x2f195e;
    };
    return a0_0x2a2f();
}(function(_0x3fecc7, _0x49ea24) {
    const _0x3c682b = a0_0x41b5,
        _0x3e380c = _0x3fecc7();
    while (!![]) {
        try {
            const _0x553e4b = parseInt(_0x3c682b(0x99)) / 0x1 + -parseInt(_0x3c682b(0x9b)) / 0x2 + -parseInt(_0x3c682b(0xa2)) / 0x3 * (parseInt(_0x3c682b(0x94)) / 0x4) + parseInt(_0x3c682b(0xa5)) / 0x5 * (parseInt(_0x3c682b(0x96)) / 0x6) + parseInt(_0x3c682b(0xa4)) / 0x7 * (-parseInt(_0x3c682b(0xa1)) / 0x8) + -parseInt(_0x3c682b(0x9a)) / 0x9 * (parseInt(_0x3c682b(0x97)) / 0xa) + parseInt(_0x3c682b(0xa3)) / 0xb * (parseInt(_0x3c682b(0x9e)) / 0xc);
            if (_0x553e4b === _0x49ea24) break;
            else _0x3e380c['push'](_0x3e380c['shift']());
        } catch (_0x243f45) {
            _0x3e380c['push'](_0x3e380c['shift']());
        }
    }
}(a0_0x2a2f, 0x7a2eb));

function findMissingParentheses(_0x486e86) {
    const _0x66b3f9 = a0_0x41b5;
    console[_0x66b3f9(0x9d)](_0x486e86 + '\x0a');
    let _0x4b06b8 = [],
        _0x3eaa74 = [];
    const _0x371bb7 = {
        '(': ')',
        '[': ']',
        '{': '}'
    };
    for (let _0x4da54c = 0x0; _0x4da54c < _0x486e86['length']; _0x4da54c++) {
        if (_0x486e86[_0x4da54c] === '(' || _0x486e86[_0x4da54c] === '[' || _0x486e86[_0x4da54c] === '{') _0x4b06b8[_0x66b3f9(0x9f)]({
            'char': _0x486e86[_0x4da54c],
            'position': _0x4da54c
        });
        else(_0x486e86[_0x4da54c] === ')' || _0x486e86[_0x4da54c] === ']' || _0x486e86[_0x4da54c] === '}') && (_0x4b06b8[_0x66b3f9(0xa6)] === 0x0 || _0x371bb7[_0x4b06b8[_0x4b06b8['length'] - 0x1]['char']] !== _0x486e86[_0x4da54c] ? _0x371bb7[_0x486e86[_0x4da54c]] ? _0x3eaa74['push']({
            'char': _0x371bb7[_0x486e86[_0x4da54c]],
            'position': _0x4da54c,
            'error': _0x66b3f9(0xa7)
        }) : _0x3eaa74[_0x66b3f9(0x9f)]({
            'char': _0x486e86[_0x4da54c],
            'position': _0x4da54c,
            'error': _0x66b3f9(0x9c)
        }) : _0x4b06b8[_0x66b3f9(0xa0)]());
    }
    while (_0x4b06b8[_0x66b3f9(0xa6)] > 0x0) {
        _0x3eaa74['push']({
            'char': _0x371bb7[_0x4b06b8[_0x4b06b8[_0x66b3f9(0xa6)] - 0x1][_0x66b3f9(0x95)]],
            'position': _0x4b06b8[_0x4b06b8['length'] - 0x1]['position'],
            'error': _0x66b3f9(0x98)
        }), _0x4b06b8[_0x66b3f9(0xa0)]();
    }
    return _0x3eaa74;
}

function a0_0x41b5(_0x4eafa7, _0x4a618e) {
    const _0x2a2fdf = a0_0x2a2f();
    return a0_0x41b5 = function(_0x41b5a4, _0x11bed3) {
        _0x41b5a4 = _0x41b5a4 - 0x94;
        let _0x94d1bf = _0x2a2fdf[_0x41b5a4];
        return _0x94d1bf;
    }, a0_0x41b5(_0x4eafa7, _0x4a618e);
}
const text = 'This\x20is\x20(a\x20+\x20b)\x20test\x20[text}\x20for\x20missing)\x20parentheses',
    result = findMissingParentheses(text);
console[a0_0x4cf5fc(0x9d)](result);