const a0_0x4ec8b4 = a0_0x58bc;

function a0_0x3845() {
    const _0x153bd = ['random', 'world', 'soul', 'mother', 'living', 'log', '7773294BYDSCu', 'word', '498745JJMIvx', '207iceESZ', 'temperance', 'love', '39972oDNFOS', '418430WZIbxJ', 'brother', 'length', '147600ZEGFuL', 'φιλία', '38FGfqWa', 'grace', 'The\x20word\x20in\x20Ancient\x20Greek\x20is:\x20', 'power', 'good', 'keys', '56VrIFqi', 'The\x20word\x20passed\x20as\x20a\x20parameter\x20is:\x20', '2971698RjlkBY', 'life', 'freedom', 'friendship', 'strength', '\x20-\x20The\x20translation\x20is:\x20', 'lessons', '5363505ZEEhHM'];
    a0_0x3845 = function() {
        return _0x153bd;
    };
    return a0_0x3845();
}(function(_0x5088f4, _0x2a9e79) {
    const _0x131e5a = a0_0x58bc,
        _0x353f6b = _0x5088f4();
    while (!![]) {
        try {
            const _0xbf7e1e = parseInt(_0x131e5a(0xf4)) / 0x1 * (parseInt(_0x131e5a(0xfa)) / 0x2) + -parseInt(_0x131e5a(0x102)) / 0x3 + -parseInt(_0x131e5a(0x100)) / 0x4 * (-parseInt(_0x131e5a(0x112)) / 0x5) + parseInt(_0x131e5a(0x110)) / 0x6 + -parseInt(_0x131e5a(0x109)) / 0x7 + -parseInt(_0x131e5a(0xf8)) / 0x8 + -parseInt(_0x131e5a(0x113)) / 0x9 * (parseInt(_0x131e5a(0xf5)) / 0xa);
            if (_0xbf7e1e === _0x2a9e79) break;
            else _0x353f6b['push'](_0x353f6b['shift']());
        } catch (_0x1bf4a5) {
            _0x353f6b['push'](_0x353f6b['shift']());
        }
    }
}(a0_0x3845, 0xae49b));

function displayRandomGreekWord(_0x57a3d4) {
    const _0x127884 = a0_0x58bc,
        _0x17b4c5 = {
            'ἀγάπη': _0x127884(0xf3),
            'ἀλήθεια': 'truth',
            'ἀρετή': 'excellence',
            'βίος': _0x127884(0x103),
            'γνῶσις': 'knowledge',
            'δύναμις': _0x127884(0xfd),
            'ἐλευθερία': _0x127884(0x104),
            'ζωή': _0x127884(0x10e),
            'καλός': _0x127884(0xfe),
            'λόγος': _0x127884(0x111),
            'μαθήματα': _0x127884(0x108),
            'νόσος': 'disease',
            'πόλεμος': 'war',
            'σωφροσύνη': _0x127884(0x114),
            'τεχνή': 'art',
            'φιλία': _0x127884(0x105),
            'χάρις': _0x127884(0xfb),
            'ψυχή': _0x127884(0x10c),
            'ἰσχύς': _0x127884(0x106),
            'δόξα': 'glory',
            'κόσμος': _0x127884(0x10b),
            'πίστις': 'faith',
            'πατήρ': 'father',
            'μήτηρ': _0x127884(0x10d),
            'ἀδελφός': _0x127884(0xf6)
        },
        _0x5c708d = Math['floor'](Math[_0x127884(0x10a)]() * Object['keys'](_0x17b4c5)[_0x127884(0xf7)]),
        _0xf13269 = Object[_0x127884(0xff)](_0x17b4c5)[_0x5c708d];
    console[_0x127884(0x10f)](_0x127884(0xfc) + _0xf13269 + _0x127884(0x107) + _0x17b4c5[_0xf13269]), console['log'](_0x127884(0x101) + _0x57a3d4 + _0x127884(0x107) + _0x17b4c5[_0x57a3d4]);
}

function a0_0x58bc(_0x5a99b5, _0x169c8f) {
    const _0x3845df = a0_0x3845();
    return a0_0x58bc = function(_0x58bc88, _0x5f18e6) {
        _0x58bc88 = _0x58bc88 - 0xf3;
        let _0x54c760 = _0x3845df[_0x58bc88];
        return _0x54c760;
    }, a0_0x58bc(_0x5a99b5, _0x169c8f);
}
displayRandomGreekWord(a0_0x4ec8b4(0xf9));