function a0_0xdb78(_0x4ad094, _0x2199e2) {
    const _0x3a0371 = a0_0x3a03();
    return a0_0xdb78 = function(_0xdb7831, _0x50b2c2) {
        _0xdb7831 = _0xdb7831 - 0xd3;
        let _0x2cfd0c = _0x3a0371[_0xdb7831];
        return _0x2cfd0c;
    }, a0_0xdb78(_0x4ad094, _0x2199e2);
}

function a0_0x3a03() {
    const _0x291113 = ['join', 'Invalid\x20season\x20input.\x20Please\x20enter\x20one\x20of\x20the\x20following\x20seasons:\x20spring,\x20summer,\x20autumn,\x20winter.', 'September\x2023', 'September\x2022', 'December\x2022', 'autumn', '52726OKeJXZ', '\x20in\x20Europe\x20are:\x20', 'summer', 'hasOwnProperty', '4697wpozGu', '404150AcAvcK', 'March\x2021', 'December\x2023', '561775jTDqhT', '3UlFEGj', 'June\x2022', '30311NkfWlr', 'log', '1816VgTpTp', '45cCvARv', 'March\x2022', '842444KpkDsE', '1494lPSdHI', 'September\x2024', 'June\x2021'];
    a0_0x3a03 = function() {
        return _0x291113;
    };
    return a0_0x3a03();
}
const a0_0x465ab5 = a0_0xdb78;
(function(_0x485517, _0x2ee88b) {
    const _0x35d41d = a0_0xdb78,
        _0xe6e870 = _0x485517();
    while (!![]) {
        try {
            const _0x19dd3e = parseInt(_0x35d41d(0xdd)) / 0x1 + parseInt(_0x35d41d(0xec)) / 0x2 * (-parseInt(_0x35d41d(0xdb)) / 0x3) + -parseInt(_0x35d41d(0xe2)) / 0x4 + parseInt(_0x35d41d(0xda)) / 0x5 + -parseInt(_0x35d41d(0xe3)) / 0x6 * (-parseInt(_0x35d41d(0xd6)) / 0x7) + -parseInt(_0x35d41d(0xdf)) / 0x8 * (parseInt(_0x35d41d(0xe0)) / 0x9) + parseInt(_0x35d41d(0xd7)) / 0xa;
            if (_0x19dd3e === _0x2ee88b) break;
            else _0xe6e870['push'](_0xe6e870['shift']());
        } catch (_0xe7026) {
            _0xe6e870['push'](_0xe6e870['shift']());
        }
    }
}(a0_0x3a03, 0x1b5b3));

function getStartSeasonDates(_0x55de58) {
    const _0x1b7902 = a0_0xdb78;
    let _0x47130c = {
        'spring': ['March\x2020', _0x1b7902(0xd8), _0x1b7902(0xe1)],
        'summer': [_0x1b7902(0xe5), _0x1b7902(0xdc), 'June\x2023'],
        'autumn': [_0x1b7902(0xe9), _0x1b7902(0xe8), _0x1b7902(0xe4)],
        'winter': ['December\x2021', _0x1b7902(0xea), _0x1b7902(0xd9)]
    };
    _0x47130c[_0x1b7902(0xd5)](_0x55de58) ? console[_0x1b7902(0xde)]('Possible\x20start\x20dates\x20for\x20' + _0x55de58 + _0x1b7902(0xd3) + _0x47130c[_0x55de58][_0x1b7902(0xe6)](',\x20')) : console['log'](_0x1b7902(0xe7));
}
getStartSeasonDates('spring'), getStartSeasonDates(a0_0x465ab5(0xd4)), getStartSeasonDates(a0_0x465ab5(0xeb)), getStartSeasonDates('winter');