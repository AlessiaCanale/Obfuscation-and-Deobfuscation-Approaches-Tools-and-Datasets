function a0_0x5dad() {
    var _0x4065a4 = ['6BpqsJM', '.ball', '1412034uGaKad', 'easeInCubic', '1444626DdxNeG', '1481263UGeodh', '60vh', '669652ByFmaP', '519458xbJcjm', '8tNzHdr', '156808kwiJAd', '178710SSHdZn'];
    a0_0x5dad = function() {
        return _0x4065a4;
    };
    return a0_0x5dad();
}
var a0_0x31640d = a0_0x5086;

function a0_0x5086(_0x1caa80, _0x2ab096) {
    var _0x5dad63 = a0_0x5dad();
    return a0_0x5086 = function(_0x50866f, _0x5e0ae3) {
        _0x50866f = _0x50866f - 0x1ed;
        var _0x44f2a2 = _0x5dad63[_0x50866f];
        return _0x44f2a2;
    }, a0_0x5086(_0x1caa80, _0x2ab096);
}(function(_0x3b5784, _0x2dc426) {
    var _0x4744a2 = a0_0x5086,
        _0x37768c = _0x3b5784();
    while (!![]) {
        try {
            var _0x4ab52b = parseInt(_0x4744a2(0x1ef)) / 0x1 + -parseInt(_0x4744a2(0x1ed)) / 0x2 + parseInt(_0x4744a2(0x1f1)) / 0x3 * (-parseInt(_0x4744a2(0x1f8)) / 0x4) + parseInt(_0x4744a2(0x1f0)) / 0x5 + parseInt(_0x4744a2(0x1f3)) / 0x6 + -parseInt(_0x4744a2(0x1f6)) / 0x7 * (-parseInt(_0x4744a2(0x1ee)) / 0x8) + parseInt(_0x4744a2(0x1f5)) / 0x9;
            if (_0x4ab52b === _0x2dc426) break;
            else _0x37768c['push'](_0x37768c['shift']());
        } catch (_0x37b3ae) {
            _0x37768c['push'](_0x37768c['shift']());
        }
    }
}(a0_0x5dad, 0x32291));
var bouncingBall = anime({
    'targets': a0_0x31640d(0x1f2),
    'translateY': a0_0x31640d(0x1f7),
    'duration': 0x12c,
    'loop': !![],
    'direction': 'alternate',
    'easing': a0_0x31640d(0x1f4),
    'scaleX': {
        'value': 1.05,
        'duration': 0x96,
        'delay': 0x10c
    }
});