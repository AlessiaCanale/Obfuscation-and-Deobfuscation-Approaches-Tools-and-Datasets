var a0_0xae0996 = a0_0x1675;
(function(_0x1c8360, _0x5146d6) {
    var _0x1ef7aa = a0_0x1675,
        _0x4d7860 = _0x1c8360();
    while (!![]) {
        try {
            var _0x446276 = parseInt(_0x1ef7aa(0x104)) / 0x1 + parseInt(_0x1ef7aa(0xdf)) / 0x2 + -parseInt(_0x1ef7aa(0xd8)) / 0x3 * (-parseInt(_0x1ef7aa(0xfa)) / 0x4) + parseInt(_0x1ef7aa(0xdc)) / 0x5 * (parseInt(_0x1ef7aa(0xe2)) / 0x6) + parseInt(_0x1ef7aa(0x108)) / 0x7 * (parseInt(_0x1ef7aa(0xed)) / 0x8) + -parseInt(_0x1ef7aa(0xe7)) / 0x9 * (-parseInt(_0x1ef7aa(0xd5)) / 0xa) + -parseInt(_0x1ef7aa(0xf3)) / 0xb;
            if (_0x446276 === _0x5146d6) break;
            else _0x4d7860['push'](_0x4d7860['shift']());
        } catch (_0x239f7a) {
            _0x4d7860['push'](_0x4d7860['shift']());
        }
    }
}(a0_0x2826, 0x2ee44));
var c = document[a0_0xae0996(0x10b)]('c'),
    ctx = c[a0_0xae0996(0xdb)]('2d'),
    cH, cW, bgColor = a0_0xae0996(0xd9),
    animations = [],
    circles = [],
    colorPicker = (function() {
        var _0x3b925f = a0_0xae0996,
            _0x5ad6c5 = ['#FF6138', _0x3b925f(0xfc), '#2980B9', _0x3b925f(0xe0)],
            _0x352581 = 0x0;

        function _0x38dac9() {
            return _0x352581 = _0x352581++ < _0x5ad6c5['length'] - 0x1 ? _0x352581 : 0x0, _0x5ad6c5[_0x352581];
        }

        function _0x3f1970() {
            return _0x5ad6c5[_0x352581];
        }
        return {
            'next': _0x38dac9,
            'current': _0x3f1970
        };
    }());

function removeAnimation(_0xe9990a) {
    var _0x3310c1 = a0_0xae0996,
        _0x2e8031 = animations[_0x3310c1(0x105)](_0xe9990a);
    if (_0x2e8031 > -0x1) animations[_0x3310c1(0xe9)](_0x2e8031, 0x1);
}

function calcPageFillRadius(_0x4a4176, _0x5d4287) {
    var _0xeea537 = a0_0xae0996,
        _0x4ac424 = Math[_0xeea537(0xf2)](_0x4a4176 - 0x0, cW - _0x4a4176),
        _0x135a64 = Math[_0xeea537(0xf2)](_0x5d4287 - 0x0, cH - _0x5d4287);
    return Math['sqrt'](Math[_0xeea537(0x101)](_0x4ac424, 0x2) + Math[_0xeea537(0x101)](_0x135a64, 0x2));
}

function addClickListeners() {
    var _0x20564c = a0_0xae0996;
    document['addEventListener'](_0x20564c(0xf0), handleEvent), document[_0x20564c(0xdd)]('mousedown', handleEvent);
};

function handleEvent(_0x37a1f1) {
    var _0x4b92ae = a0_0xae0996;
    _0x37a1f1[_0x4b92ae(0xfd)] && (_0x37a1f1[_0x4b92ae(0xf7)](), _0x37a1f1 = _0x37a1f1[_0x4b92ae(0xfd)][0x0]);
    var _0x4df123 = colorPicker[_0x4b92ae(0xf8)](),
        _0x2b492f = colorPicker['next'](),
        _0xeba63c = calcPageFillRadius(_0x37a1f1[_0x4b92ae(0xd6)], _0x37a1f1[_0x4b92ae(0xef)]),
        _0x3201c5 = Math[_0x4b92ae(0x10a)](0xc8, cW * 0.4),
        _0x35b92a = 0x2ee,
        _0x43f3b0 = new Circle({
            'x': _0x37a1f1['pageX'],
            'y': _0x37a1f1[_0x4b92ae(0xef)],
            'r': 0x0,
            'fill': _0x2b492f
        }),
        _0x3881b2 = anime({
            'targets': _0x43f3b0,
            'r': _0xeba63c,
            'duration': Math['max'](_0xeba63c / 0x2, _0x35b92a),
            'easing': _0x4b92ae(0x10c),
            'complete': function() {
                bgColor = _0x43f3b0['fill'], removeAnimation(_0x3881b2);
            }
        }),
        _0x5df8e3 = new Circle({
            'x': _0x37a1f1['pageX'],
            'y': _0x37a1f1[_0x4b92ae(0xef)],
            'r': 0x0,
            'fill': _0x4df123,
            'stroke': {
                'width': 0x3,
                'color': _0x4df123
            },
            'opacity': 0x1
        }),
        _0x17362a = anime({
            'targets': _0x5df8e3,
            'r': _0x3201c5,
            'opacity': 0x0,
            'easing': _0x4b92ae(0xd7),
            'duration': 0x384,
            'complete': removeAnimation
        }),
        _0x2098a4 = [];
    for (var _0x48712f = 0x0; _0x48712f < 0x20; _0x48712f++) {
        var _0xe939d5 = new Circle({
            'x': _0x37a1f1[_0x4b92ae(0xd6)],
            'y': _0x37a1f1[_0x4b92ae(0xef)],
            'fill': _0x4df123,
            'r': anime[_0x4b92ae(0x102)](0x18, 0x30)
        });
        _0x2098a4[_0x4b92ae(0xe3)](_0xe939d5);
    }
    var _0x174b44 = anime({
        'targets': _0x2098a4,
        'x': function(_0x4281fd) {
            var _0x17fb44 = _0x4b92ae;
            return _0x4281fd['x'] + anime[_0x17fb44(0x102)](_0x3201c5, -_0x3201c5);
        },
        'y': function(_0x37d2e3) {
            var _0x317c12 = _0x4b92ae;
            return _0x37d2e3['y'] + anime[_0x317c12(0x102)](_0x3201c5 * 1.15, -_0x3201c5 * 1.15);
        },
        'r': 0x0,
        'easing': _0x4b92ae(0xd7),
        'duration': anime[_0x4b92ae(0x102)](0x3e8, 0x514),
        'complete': removeAnimation
    });
    animations[_0x4b92ae(0xe3)](_0x3881b2, _0x17362a, _0x174b44);
}

function a0_0x2826() {
    var _0x1c01ef = ['9AQTVNG', 'lineWidth', 'splice', 'fill', 'innerWidth', 'PenTimer', '1441144nKnIFe', 'beginPath', 'pageY', 'touchstart', 'MAX_TIME_IN_LOOP_WO_EXIT', 'max', '9344412xYkvBc', 'hasOwnProperty', 'pathname', 'globalAlpha', 'preventDefault', 'current', 'target', '916yVBkMl', 'mousedown', '#FFBE53', 'touches', 'location', 'width', 'height', 'pow', 'random', 'prototype', '260742KgEPox', 'indexOf', 'forEach', 'fillStyle', '14ksblnk', 'fillRect', 'min', 'getElementById', 'easeOutQuart', 'innerHeight', 'resize', '269900vavJvF', 'pageX', 'easeOutExpo', '3177loqqPa', '#FF6138', 'color', 'getContext', '4545zvtTYa', 'addEventListener', 'scale', '216616BznAen', '#282741', 'removeEventListener', '282ELEgvX', 'push', 'strokeStyle', 'stroke', 'draw'];
    a0_0x2826 = function() {
        return _0x1c01ef;
    };
    return a0_0x2826();
}

function extend(_0x540b6c, _0x5ca5b9) {
    var _0x5aca0c = a0_0xae0996;
    for (var _0x47ed6f in _0x5ca5b9) {
        _0x5ca5b9[_0x5aca0c(0xf4)](_0x47ed6f) && (_0x540b6c[_0x47ed6f] = _0x5ca5b9[_0x47ed6f]);
    }
    return _0x540b6c;
}
var Circle = function(_0x5debdb) {
    extend(this, _0x5debdb);
};
Circle[a0_0xae0996(0x103)][a0_0xae0996(0xe6)] = function() {
    var _0x2e3e62 = a0_0xae0996;
    ctx[_0x2e3e62(0xf6)] = this['opacity'] || 0x1, ctx[_0x2e3e62(0xee)](), ctx['arc'](this['x'], this['y'], this['r'], 0x0, 0x2 * Math['PI'], ![]), this['stroke'] && (ctx[_0x2e3e62(0xe4)] = this['stroke'][_0x2e3e62(0xda)], ctx[_0x2e3e62(0xe8)] = this['stroke'][_0x2e3e62(0xff)], ctx[_0x2e3e62(0xe5)]()), this[_0x2e3e62(0xea)] && (ctx['fillStyle'] = this[_0x2e3e62(0xea)], ctx[_0x2e3e62(0xea)]()), ctx['closePath'](), ctx[_0x2e3e62(0xf6)] = 0x1;
};
var animate = anime({
        'duration': Infinity,
        'update': function() {
            var _0x439ff4 = a0_0xae0996;
            ctx[_0x439ff4(0x107)] = bgColor, ctx[_0x439ff4(0x109)](0x0, 0x0, cW, cH), animations['forEach'](function(_0x2c6ac9) {
                var _0x4d7763 = _0x439ff4;
                _0x2c6ac9['animatables'][_0x4d7763(0x106)](function(_0x430988) {
                    var _0x56a27b = _0x4d7763;
                    _0x430988[_0x56a27b(0xf9)]['draw']();
                });
            });
        }
    }),
    resizeCanvas = function() {
        var _0x3b68ce = a0_0xae0996;
        cW = window[_0x3b68ce(0xeb)], cH = window[_0x3b68ce(0x10d)], c['width'] = cW * devicePixelRatio, c[_0x3b68ce(0x100)] = cH * devicePixelRatio, ctx[_0x3b68ce(0xde)](devicePixelRatio, devicePixelRatio);
    };

function a0_0x1675(_0x7f060, _0x433e72) {
    var _0x2826f5 = a0_0x2826();
    return a0_0x1675 = function(_0x1675be, _0x2ba6ae) {
        _0x1675be = _0x1675be - 0xd4;
        var _0xdc2f08 = _0x2826f5[_0x1675be];
        return _0xdc2f08;
    }, a0_0x1675(_0x7f060, _0x433e72);
}(function init() {
    var _0x56a45c = a0_0xae0996;
    resizeCanvas(), window['CP'] && (window['CP'][_0x56a45c(0xec)][_0x56a45c(0xf1)] = 0x1770), window[_0x56a45c(0xdd)](_0x56a45c(0xd4), resizeCanvas), addClickListeners(), !!window[_0x56a45c(0xfe)][_0x56a45c(0xf5)]['match'](/fullcpgrid/) && startFauxClicking(), handleInactiveUser();
}());

function handleInactiveUser() {
    var _0x5dbf03 = a0_0xae0996,
        _0x4e679c = setTimeout(function() {
            fauxClick(cW / 0x2, cH / 0x2);
        }, 0x7d0);

    function _0x2f4e70() {
        var _0x514716 = a0_0x1675;
        clearTimeout(_0x4e679c), document[_0x514716(0xe1)](_0x514716(0xfb), _0x2f4e70), document['removeEventListener']('touchstart', _0x2f4e70);
    }
    document[_0x5dbf03(0xdd)](_0x5dbf03(0xfb), _0x2f4e70), document[_0x5dbf03(0xdd)](_0x5dbf03(0xf0), _0x2f4e70);
}

function startFauxClicking() {
    var _0x1913c3 = a0_0xae0996;
    setTimeout(function() {
        var _0x435f74 = a0_0x1675;
        fauxClick(anime[_0x435f74(0x102)](cW * 0.2, cW * 0.8), anime[_0x435f74(0x102)](cH * 0.2, cH * 0.8)), startFauxClicking();
    }, anime[_0x1913c3(0x102)](0xc8, 0x384));
}

function fauxClick(_0x5c811c, _0x1d9328) {
    var _0x9ebe8b = a0_0xae0996,
        _0x3d64ac = new Event(_0x9ebe8b(0xfb));
    _0x3d64ac[_0x9ebe8b(0xd6)] = _0x5c811c, _0x3d64ac[_0x9ebe8b(0xef)] = _0x1d9328, document['dispatchEvent'](_0x3d64ac);
}