function a0_0x476e() {
    const _0x2e1469 = ['1481712eDzFUR', '272724NGIjTO', '13424LIaRBY', '739116dVMteY', 'Mar\x20Tirreno', '561316snoclC', 'Mar\x20Ligure', '2tfWyxm', 'Mar\x20Baltico', '160277ibiXGB', 'Mar\x20Ionio', '\x20does\x20not\x20touch\x20the\x20Italian\x20coast.', 'log', '\x20touches\x20the\x20Italian\x20coast.', 'Mar\x20Adriatico', 'Mar\x20Mediterraneo', '1800325ogdZqz', '3033opqYHi'];
    a0_0x476e = function() {
        return _0x2e1469;
    };
    return a0_0x476e();
}

function a0_0x5cb2(_0x449eec, _0x593594) {
    const _0x476e46 = a0_0x476e();
    return a0_0x5cb2 = function(_0x5cb2cb, _0x5d918d) {
        _0x5cb2cb = _0x5cb2cb - 0x126;
        let _0x2522a8 = _0x476e46[_0x5cb2cb];
        return _0x2522a8;
    }, a0_0x5cb2(_0x449eec, _0x593594);
}
const a0_0x14a8aa = a0_0x5cb2;
(function(_0x39de51, _0x39c6a8) {
    const _0xedf157 = a0_0x5cb2,
        _0x1aae33 = _0x39de51();
    while (!![]) {
        try {
            const _0x43e963 = parseInt(_0xedf157(0x127)) / 0x1 * (-parseInt(_0xedf157(0x137)) / 0x2) + -parseInt(_0xedf157(0x133)) / 0x3 + parseInt(_0xedf157(0x131)) / 0x4 + -parseInt(_0xedf157(0x12e)) / 0x5 + parseInt(_0xedf157(0x130)) / 0x6 + parseInt(_0xedf157(0x135)) / 0x7 + -parseInt(_0xedf157(0x132)) / 0x8 * (-parseInt(_0xedf157(0x12f)) / 0x9);
            if (_0x43e963 === _0x39c6a8) break;
            else _0x1aae33['push'](_0x1aae33['shift']());
        } catch (_0x523038) {
            _0x1aae33['push'](_0x1aae33['shift']());
        }
    }
}(a0_0x476e, 0x2f62d));

function checkIfItalianCoast(_0x268b37) {
    const _0x3d902c = a0_0x5cb2,
        _0x4cdf60 = [_0x3d902c(0x134), _0x3d902c(0x136), _0x3d902c(0x12d), _0x3d902c(0x128), _0x3d902c(0x12c)];
    _0x4cdf60['includes'](_0x268b37) ? console[_0x3d902c(0x12a)](_0x268b37 + _0x3d902c(0x12b)) : console[_0x3d902c(0x12a)](_0x268b37 + _0x3d902c(0x129));
}
checkIfItalianCoast('Mar\x20Mediterraneo'), checkIfItalianCoast(a0_0x14a8aa(0x126));