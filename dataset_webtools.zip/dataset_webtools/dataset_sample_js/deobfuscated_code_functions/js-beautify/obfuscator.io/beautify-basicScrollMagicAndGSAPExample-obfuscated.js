var a0_0xf907ca = a0_0x1314;

function a0_0x207b() {
    var _0x50a6f2 = ['282348WcUkPv', '11655012nhfRJH', '210350huQAPQ', '445tpjInZ', '11543584eqWqxP', '3zHGARL', '4761840INiVkf', 'setTween', '495RHUYaf', '.box', 'Scene', '4688ozbgSj', '2715370bYXisL', '24TmvRDW', 'Controller', 'rotate(90deg)', '11FItqji'];
    a0_0x207b = function() {
        return _0x50a6f2;
    };
    return a0_0x207b();
}(function(_0x2c1cba, _0xc5fd42) {
    var _0x1ba285 = a0_0x1314,
        _0x3903f2 = _0x2c1cba();
    while (!![]) {
        try {
            var _0x492e48 = parseInt(_0x1ba285(0x109)) / 0x1 * (parseInt(_0x1ba285(0x100)) / 0x2) + parseInt(_0x1ba285(0x10b)) / 0x3 * (-parseInt(_0x1ba285(0x106)) / 0x4) + -parseInt(_0x1ba285(0x10c)) / 0x5 + -parseInt(_0x1ba285(0x102)) / 0x6 * (-parseInt(_0x1ba285(0x101)) / 0x7) + parseInt(_0x1ba285(0x10a)) / 0x8 + -parseInt(_0x1ba285(0x10e)) / 0x9 * (parseInt(_0x1ba285(0x108)) / 0xa) + parseInt(_0x1ba285(0x105)) / 0xb * (-parseInt(_0x1ba285(0x107)) / 0xc);
            if (_0x492e48 === _0xc5fd42) break;
            else _0x3903f2['push'](_0x3903f2['shift']());
        } catch (_0x368ee1) {
            _0x3903f2['push'](_0x3903f2['shift']());
        }
    }
}(a0_0x207b, 0xd8709));

function a0_0x1314(_0x18fe76, _0x803091) {
    var _0x207bb2 = a0_0x207b();
    return a0_0x1314 = function(_0x131486, _0xa03ff) {
        _0x131486 = _0x131486 - 0xff;
        var _0x238592 = _0x207bb2[_0x131486];
        return _0x238592;
    }, a0_0x1314(_0x18fe76, _0x803091);
}
var controller = new ScrollMagic[(a0_0xf907ca(0x103))](),
    scene = new ScrollMagic[(a0_0xf907ca(0xff))]({
        'duration': 0x3e8
    })[a0_0xf907ca(0x10d)](a0_0xf907ca(0x10f), {
        'backgroundColor': 'red',
        'transform': a0_0xf907ca(0x104)
    })['addTo'](controller);