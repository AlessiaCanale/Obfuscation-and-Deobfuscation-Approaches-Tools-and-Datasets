function a0_0x3dab() {
    const _0x54dac4 = ['10fCXuGc', 'Napoli', '136076vyuDWL', 'Palermo', 'No\x20region\x20found\x20for\x20the\x20capital\x20city\x20', '23446860jSjXBK', 'Milano', 'The\x20capital\x20city\x20', 'Torino', 'Catanzaro', 'Campobasso', '35JZQffk', 'Capital\x20city:\x20', 'Bologna', 'Potenza', 'Venezia', '12624227UhEjEG', '268sxyFQX', 'Perugia', '33TZUuOe', 'Trieste', 'L\x27Aquila', 'log', '\x20is\x20in\x20the\x20region\x20of\x20', 'Genova', 'Aosta', '776ZXKMTn', 'Cagliari', '556212zomLsR', '7773318YAAfyv', 'Ancona', 'Roma', '9679dPwlFe', '102781CYZwwX'];
    a0_0x3dab = function() {
        return _0x54dac4;
    };
    return a0_0x3dab();
}
const a0_0x4f25a0 = a0_0x4738;

function a0_0x4738(_0x26260d, _0x396b4d) {
    const _0x3dab08 = a0_0x3dab();
    return a0_0x4738 = function(_0x473810, _0x2aed8a) {
        _0x473810 = _0x473810 - 0x1ca;
        let _0x594a14 = _0x3dab08[_0x473810];
        return _0x594a14;
    }, a0_0x4738(_0x26260d, _0x396b4d);
}(function(_0x27787d, _0x535af7) {
    const _0x32431b = a0_0x4738,
        _0x52f8ee = _0x27787d();
    while (!![]) {
        try {
            const _0x194801 = parseInt(_0x32431b(0x1df)) / 0x1 * (parseInt(_0x32431b(0x1d0)) / 0x2) + parseInt(_0x32431b(0x1d2)) / 0x3 * (-parseInt(_0x32431b(0x1e3)) / 0x4) + -parseInt(_0x32431b(0x1ca)) / 0x5 * (-parseInt(_0x32431b(0x1db)) / 0x6) + parseInt(_0x32431b(0x1e0)) / 0x7 * (parseInt(_0x32431b(0x1d9)) / 0x8) + parseInt(_0x32431b(0x1dc)) / 0x9 + parseInt(_0x32431b(0x1e1)) / 0xa * (-parseInt(_0x32431b(0x1cf)) / 0xb) + -parseInt(_0x32431b(0x1e6)) / 0xc;
            if (_0x194801 === _0x535af7) break;
            else _0x52f8ee['push'](_0x52f8ee['shift']());
        } catch (_0x57e3c5) {
            _0x52f8ee['push'](_0x52f8ee['shift']());
        }
    }
}(a0_0x3dab, 0xb9142));

function getRegion(_0x1dc090) {
    const _0x2bd3af = a0_0x4738,
        _0x848f27 = {
            'Abruzzo': _0x2bd3af(0x1d4),
            'Basilicata': _0x2bd3af(0x1cd),
            'Calabria': _0x2bd3af(0x1ea),
            'Campania': _0x2bd3af(0x1e2),
            'Emilia-Romagna': _0x2bd3af(0x1cc),
            'Friuli-Venezia\x20Giulia': _0x2bd3af(0x1d3),
            'Lazio': 'Roma',
            'Liguria': _0x2bd3af(0x1d7),
            'Lombardia': _0x2bd3af(0x1e7),
            'Marche': _0x2bd3af(0x1dd),
            'Molise': _0x2bd3af(0x1eb),
            'Piemonte': _0x2bd3af(0x1e9),
            'Puglia': 'Bari',
            'Sardegna': _0x2bd3af(0x1da),
            'Sicilia': _0x2bd3af(0x1e4),
            'Toscana': 'Firenze',
            'Trentino-Alto\x20Adige': 'Trento',
            'Umbria': _0x2bd3af(0x1d1),
            'Valle\x20d\x27Aosta': _0x2bd3af(0x1d8),
            'Veneto': _0x2bd3af(0x1ce)
        };
    for (const _0x1e7292 in _0x848f27) {
        if (_0x848f27[_0x1e7292] === _0x1dc090) {
            console[_0x2bd3af(0x1d5)](_0x2bd3af(0x1e8) + _0x1dc090 + _0x2bd3af(0x1d6) + _0x1e7292 + '.'), console['log'](_0x2bd3af(0x1cb) + _0x1dc090), console[_0x2bd3af(0x1d5)]('Region:\x20' + _0x1e7292);
            return;
        }
    }
    console[_0x2bd3af(0x1d5)](_0x2bd3af(0x1e5) + _0x1dc090 + '.');
}
getRegion(a0_0x4f25a0(0x1de)), getRegion(a0_0x4f25a0(0x1e9)), getRegion(a0_0x4f25a0(0x1e7)), getRegion('Genova'), getRegion(a0_0x4f25a0(0x1d8));