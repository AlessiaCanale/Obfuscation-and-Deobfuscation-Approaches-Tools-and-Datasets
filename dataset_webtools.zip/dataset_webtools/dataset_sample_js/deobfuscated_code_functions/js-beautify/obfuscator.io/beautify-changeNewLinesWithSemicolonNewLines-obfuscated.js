function a0_0x5eff(_0x35e35c, _0x19adb1) {
    const _0x46f054 = a0_0x46f0();
    return a0_0x5eff = function(_0x5eff40, _0x56eb2b) {
        _0x5eff40 = _0x5eff40 - 0x1b8;
        let _0x2c799c = _0x46f054[_0x5eff40];
        return _0x2c799c;
    }, a0_0x5eff(_0x35e35c, _0x19adb1);
}(function(_0x2c8251, _0x244849) {
    const _0x2fb93a = a0_0x5eff,
        _0x54ac99 = _0x2c8251();
    while (!![]) {
        try {
            const _0x51526b = -parseInt(_0x2fb93a(0x1c0)) / 0x1 * (-parseInt(_0x2fb93a(0x1ba)) / 0x2) + parseInt(_0x2fb93a(0x1c1)) / 0x3 + parseInt(_0x2fb93a(0x1b9)) / 0x4 + parseInt(_0x2fb93a(0x1be)) / 0x5 * (parseInt(_0x2fb93a(0x1b8)) / 0x6) + parseInt(_0x2fb93a(0x1c2)) / 0x7 * (parseInt(_0x2fb93a(0x1bc)) / 0x8) + parseInt(_0x2fb93a(0x1bd)) / 0x9 + -parseInt(_0x2fb93a(0x1c3)) / 0xa;
            if (_0x51526b === _0x244849) break;
            else _0x54ac99['push'](_0x54ac99['shift']());
        } catch (_0x3d55bd) {
            _0x54ac99['push'](_0x54ac99['shift']());
        }
    }
}(a0_0x46f0, 0xa7d42));

function changeNewLinesWithSemicolonNewLines(_0x433242) {
    const _0xb9b6c2 = a0_0x5eff,
        _0x36fc19 = _0x433242['replace'](/\n/g, ';\x0a');
    console['log'](_0xb9b6c2(0x1bb) + _0x433242), console[_0xb9b6c2(0x1c4)](_0xb9b6c2(0x1bf) + _0x36fc19);
}
const code = 'let\x20x\x20=\x2010\x0ax\x20+=\x205\x0aif\x20(x\x20>\x2010)\x20{\x0a\x20\x20\x20\x20console.log(\x22x\x20is\x20greater\x20than\x2010\x22)\x0a}\x0ax\x20=\x20x\x20*\x202';

function a0_0x46f0() {
    const _0x42edbb = ['30808dBhKeW', '5947074WARRed', '565WvgaeP', '\x0aModified\x20Code:\x0a', '32510BnCJrF', '3970686hSuDkH', '581YOUoTE', '36144930zRWnSQ', 'log', '15486vpHVrF', '4224340BKrhIX', '40GGfsOY', 'Original\x20Code:\x0a'];
    a0_0x46f0 = function() {
        return _0x42edbb;
    };
    return a0_0x46f0();
}
changeNewLinesWithSemicolonNewLines(code);