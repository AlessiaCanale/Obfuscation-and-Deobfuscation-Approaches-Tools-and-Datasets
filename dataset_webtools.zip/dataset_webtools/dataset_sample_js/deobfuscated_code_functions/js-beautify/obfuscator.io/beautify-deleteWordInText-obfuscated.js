function a0_0x38f2() {
    const _0x187313 = ['This\x20is\x20an\x20example\x20sentence\x20with\x20the\x20word\x20apple\x20appearing\x20multiple\x20times.\x20Apple', '1204945dzBCcl', '292640ffBLkF', '1136nwlose', 'apple', '10600Hpzfpz', '17436mKgVtZ', 'replace', '3186IIzKhU', '676665XyYEkY', '1075736WUkhFS', 'Word\x20to\x20delete:\x20', 'log', '60XpinQn', 'lemon'];
    a0_0x38f2 = function() {
        return _0x187313;
    };
    return a0_0x38f2();
}
const a0_0x1235df = a0_0x41c7;
(function(_0x31eb58, _0x4f8168) {
    const _0x1e2508 = a0_0x41c7,
        _0x167111 = _0x31eb58();
    while (!![]) {
        try {
            const _0x268547 = parseInt(_0x1e2508(0xd4)) / 0x1 + parseInt(_0x1e2508(0xd7)) / 0x2 + parseInt(_0x1e2508(0xcc)) / 0x3 + -parseInt(_0x1e2508(0xcd)) / 0x4 + -parseInt(_0x1e2508(0xd0)) / 0x5 * (-parseInt(_0x1e2508(0xd8)) / 0x6) + -parseInt(_0x1e2508(0xd3)) / 0x7 + -parseInt(_0x1e2508(0xd5)) / 0x8 * (-parseInt(_0x1e2508(0xcb)) / 0x9);
            if (_0x268547 === _0x4f8168) break;
            else _0x167111['push'](_0x167111['shift']());
        } catch (_0x324982) {
            _0x167111['push'](_0x167111['shift']());
        }
    }
}(a0_0x38f2, 0x28e8e));

function deleteWordInText(_0x55ec95, _0x3b6e2a) {
    const _0xa30720 = a0_0x41c7;
    let _0x2dbfd8 = new RegExp('\x5cb' + _0x3b6e2a + '\x5cb', 'gi'),
        _0x1f66e9 = _0x55ec95[_0xa30720(0xd9)](_0x2dbfd8, '');
    _0x55ec95 === _0x1f66e9 ? console[_0xa30720(0xcf)](_0x3b6e2a + '\x20is\x20not\x20present\x20in\x20the\x20text.') : (console[_0xa30720(0xcf)]('Original\x20text:\x20' + _0x55ec95), console[_0xa30720(0xcf)](_0xa30720(0xce) + _0x3b6e2a), console['log']('Text\x20without\x20occurrences\x20of\x20the\x20word:\x20' + _0x1f66e9));
}

function a0_0x41c7(_0x2c25bc, _0x257538) {
    const _0x38f246 = a0_0x38f2();
    return a0_0x41c7 = function(_0x41c77b, _0x5c3b36) {
        _0x41c77b = _0x41c77b - 0xcb;
        let _0x1ec7cb = _0x38f246[_0x41c77b];
        return _0x1ec7cb;
    }, a0_0x41c7(_0x2c25bc, _0x257538);
}
deleteWordInText(a0_0x1235df(0xd2), a0_0x1235df(0xd6)), deleteWordInText(a0_0x1235df(0xd2), a0_0x1235df(0xd1));