(function(_0x47eb89, _0x532cde) {
    const _0x50fe1d = a0_0x4ca3,
        _0x560fb9 = _0x47eb89();
    while (!![]) {
        try {
            const _0x2ea1ae = parseInt(_0x50fe1d(0x179)) / 0x1 * (parseInt(_0x50fe1d(0x17c)) / 0x2) + parseInt(_0x50fe1d(0x176)) / 0x3 + -parseInt(_0x50fe1d(0x172)) / 0x4 + parseInt(_0x50fe1d(0x171)) / 0x5 + parseInt(_0x50fe1d(0x177)) / 0x6 + -parseInt(_0x50fe1d(0x17b)) / 0x7 + -parseInt(_0x50fe1d(0x174)) / 0x8;
            if (_0x2ea1ae === _0x532cde) break;
            else _0x560fb9['push'](_0x560fb9['shift']());
        } catch (_0x2cdd03) {
            _0x560fb9['push'](_0x560fb9['shift']());
        }
    }
}(a0_0x1578, 0x911e5));

function a0_0x4ca3(_0x19d1ff, _0x3bb08e) {
    const _0x157895 = a0_0x1578();
    return a0_0x4ca3 = function(_0x4ca38a, _0x436d08) {
        _0x4ca38a = _0x4ca38a - 0x171;
        let _0xa81b17 = _0x157895[_0x4ca38a];
        return _0xa81b17;
    }, a0_0x4ca3(_0x19d1ff, _0x3bb08e);
}

function rectanglePerimeter(_0x2fc201, _0x2447c5) {
    const _0x5ceaae = a0_0x4ca3,
        _0x4b9ea6 = 0x2 * (_0x2fc201 + _0x2447c5);
    return console[_0x5ceaae(0x173)](_0x5ceaae(0x17a) + _0x2fc201), console[_0x5ceaae(0x173)](_0x5ceaae(0x178) + _0x2447c5), console[_0x5ceaae(0x173)](_0x5ceaae(0x175) + _0x4b9ea6), _0x4b9ea6;
}
const smallerSide = 0x4,
    largerSide = 0x6;
rectanglePerimeter(smallerSide, largerSide);

function a0_0x1578() {
    const _0x4b0d5 = ['6460842pVVtGe', 'Length\x20of\x20the\x20larger\x20side:\x20', '58165dPZAWj', 'Length\x20of\x20the\x20smaller\x20side:\x20', '6705440XfJcPq', '18xscNom', '289895SeWvEO', '2619724hfdrwR', 'log', '4050464nCgkZc', 'Perimeter\x20of\x20the\x20rectangle:\x20', '3165879lyIgrs'];
    a0_0x1578 = function() {
        return _0x4b0d5;
    };
    return a0_0x1578();
}