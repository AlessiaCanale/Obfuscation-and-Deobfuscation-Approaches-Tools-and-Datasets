var a0_0x8bde2 = a0_0x1af0;
(function(_0x5ec3c5, _0x13def6) {
    var _0x4741ec = a0_0x1af0,
        _0x3a4407 = _0x5ec3c5();
    while (!![]) {
        try {
            var _0x3c380e = -parseInt(_0x4741ec(0x199)) / 0x1 + -parseInt(_0x4741ec(0x19f)) / 0x2 * (parseInt(_0x4741ec(0x19b)) / 0x3) + -parseInt(_0x4741ec(0x193)) / 0x4 * (-parseInt(_0x4741ec(0x195)) / 0x5) + parseInt(_0x4741ec(0x197)) / 0x6 * (parseInt(_0x4741ec(0x1a0)) / 0x7) + -parseInt(_0x4741ec(0x19a)) / 0x8 + -parseInt(_0x4741ec(0x196)) / 0x9 + parseInt(_0x4741ec(0x19e)) / 0xa;
            if (_0x3c380e === _0x13def6) break;
            else _0x3a4407['push'](_0x3a4407['shift']());
        } catch (_0x2728be) {
            _0x3a4407['push'](_0x3a4407['shift']());
        }
    }
}(a0_0x32f5, 0x67594));

function a0_0x32f5() {
    var _0x6f7576 = ['1653624ORftwq', 'Modified\x20sentence:\x20', '10MFwUbL', '3746079xrnIkU', '198966snfCVg', 'Original\x20sentence:\x20', '777230gPeQtG', '5832016cETMfX', '3dXtDtL', 'log', 'replace', '17843450bDVgso', '1658230pMvgAb', '119JTSVWW', 'This\x20is\x20a\x20sentence.\x20It\x20has\x20some\x20dots.\x20Here\x27s\x20another\x20one.'];
    a0_0x32f5 = function() {
        return _0x6f7576;
    };
    return a0_0x32f5();
}

function changeDotWithCommas(_0x3ea285) {
    var _0x164071 = a0_0x1af0,
        _0x5cf21f = _0x3ea285[_0x164071(0x19d)](/\./g, ',');
    console[_0x164071(0x19c)](_0x164071(0x198) + _0x3ea285), console['log'](_0x164071(0x194) + _0x5cf21f);
}

function a0_0x1af0(_0x2b056a, _0x19752a) {
    var _0x32f58b = a0_0x32f5();
    return a0_0x1af0 = function(_0x1af0f0, _0x5d9b07) {
        _0x1af0f0 = _0x1af0f0 - 0x192;
        var _0x2c4137 = _0x32f58b[_0x1af0f0];
        return _0x2c4137;
    }, a0_0x1af0(_0x2b056a, _0x19752a);
}
var inputSentence = a0_0x8bde2(0x192);
changeDotWithCommas(inputSentence);