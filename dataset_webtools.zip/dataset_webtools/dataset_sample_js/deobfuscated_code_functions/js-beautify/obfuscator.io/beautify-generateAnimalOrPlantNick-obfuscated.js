function a0_0x46bb(_0x1caedc, _0x1d3f68) {
    const _0xc99b26 = a0_0xc99b();
    return a0_0x46bb = function(_0x46bbc0, _0xdcaa5) {
        _0x46bbc0 = _0x46bbc0 - 0x1cd;
        let _0x1723a1 = _0xc99b26[_0x46bbc0];
        return _0x1723a1;
    }, a0_0x46bb(_0x1caedc, _0x1d3f68);
}(function(_0x44883e, _0x39d596) {
    const _0x1670d1 = a0_0x46bb,
        _0x407de3 = _0x44883e();
    while (!![]) {
        try {
            const _0x20098b = -parseInt(_0x1670d1(0x1f6)) / 0x1 + parseInt(_0x1670d1(0x1ea)) / 0x2 + parseInt(_0x1670d1(0x1d8)) / 0x3 * (parseInt(_0x1670d1(0x1d3)) / 0x4) + parseInt(_0x1670d1(0x1e1)) / 0x5 + -parseInt(_0x1670d1(0x1eb)) / 0x6 + parseInt(_0x1670d1(0x1e5)) / 0x7 + parseInt(_0x1670d1(0x1f1)) / 0x8;
            if (_0x20098b === _0x39d596) break;
            else _0x407de3['push'](_0x407de3['shift']());
        } catch (_0x2d6e62) {
            _0x407de3['push'](_0x407de3['shift']());
        }
    }
}(a0_0xc99b, 0x39cbb));

function generateAnimalOrPlantNick(_0x3f1dea, _0x42eea6) {
    const _0x55cbc6 = a0_0x46bb,
        _0x7187c9 = {
            'a': ['antelope', 'apple'],
            'b': [_0x55cbc6(0x1f3), _0x55cbc6(0x1dc)],
            'c': [_0x55cbc6(0x1fb), 'cherry'],
            'd': [_0x55cbc6(0x1e6), _0x55cbc6(0x1ce)],
            'e': [_0x55cbc6(0x1da), 'eggplant'],
            'f': [_0x55cbc6(0x1fc), _0x55cbc6(0x1e3)],
            'g': [_0x55cbc6(0x1f5), _0x55cbc6(0x1d7)],
            'h': [_0x55cbc6(0x1e4), _0x55cbc6(0x1f0)],
            'i': [_0x55cbc6(0x1d0), 'iris'],
            'j': [_0x55cbc6(0x1f8), _0x55cbc6(0x1cf)],
            'k': [_0x55cbc6(0x200), _0x55cbc6(0x1fe)],
            'l': ['lion', _0x55cbc6(0x1ef)],
            'm': [_0x55cbc6(0x1ff), 'melon'],
            'n': ['newt', _0x55cbc6(0x1f2)],
            'o': [_0x55cbc6(0x1d9), _0x55cbc6(0x1df)],
            'p': [_0x55cbc6(0x1f9), _0x55cbc6(0x1ed)],
            'q': [_0x55cbc6(0x1e7), 'quince'],
            'r': ['rabbit', _0x55cbc6(0x1de)],
            's': [_0x55cbc6(0x1d5), _0x55cbc6(0x1f7)],
            't': [_0x55cbc6(0x1cd), _0x55cbc6(0x1dd)],
            'u': [_0x55cbc6(0x1d6), _0x55cbc6(0x1e2)],
            'v': ['vulture', _0x55cbc6(0x1e8)],
            'w': ['whale', _0x55cbc6(0x1e9)],
            'x': [_0x55cbc6(0x1d4), _0x55cbc6(0x1d1)],
            'y': [_0x55cbc6(0x1fa), _0x55cbc6(0x1e0)],
            'z': [_0x55cbc6(0x1fd), _0x55cbc6(0x1ee)]
        },
        _0x495a2b = Math[_0x55cbc6(0x1f4)](Math[_0x55cbc6(0x1d2)]() * 0x2),
        _0x3e5a7e = _0x7187c9[_0x3f1dea['toLowerCase']()][_0x495a2b],
        _0x5956b6 = ['#', '@', '£', '%', '&', '°', '!'],
        _0x382624 = _0x5956b6[Math[_0x55cbc6(0x1f4)](Math['random']() * _0x5956b6[_0x55cbc6(0x1ec)])],
        _0x1ee3f7 = _0x3e5a7e + _0x42eea6 + _0x382624;
    console[_0x55cbc6(0x1db)](_0x1ee3f7);
}

function a0_0xc99b() {
    const _0x150393 = ['2803032Vqhiry', 'length', 'pear', 'zucchini', 'lavender', 'hazelnut', '2061744WYoRGW', 'nettle', 'bear', 'floor', 'goat', '450695gyAsaG', 'strawberry', 'jackal', 'penguin', 'yak', 'cat', 'fox', 'zebra', 'kiwi', 'monkey', 'kangaroo', 'tiger', 'daisy', 'juniper', 'iguana', 'ximenia', 'random', '4zIPgCn', 'xerus', 'squirrel', 'unicorn', 'grape', '511284fmxEdl', 'owl', 'elephant', 'log', 'bluebell', 'tomato', 'rose', 'orange', 'yam', '2005945aOlLae', 'umeboshi', 'fennel', 'hamster', '1906415gqrIGm', 'dog', 'quokka', 'violet', 'watermelon', '105836DllgDR'];
    a0_0xc99b = function() {
        return _0x150393;
    };
    return a0_0xc99b();
}
generateAnimalOrPlantNick('a', 'z');