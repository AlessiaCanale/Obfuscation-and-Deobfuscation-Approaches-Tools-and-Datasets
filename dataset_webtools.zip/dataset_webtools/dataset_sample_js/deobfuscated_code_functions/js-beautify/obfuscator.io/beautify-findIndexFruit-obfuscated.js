const a0_0x3c3809 = a0_0x58f6;

function a0_0x2d3e() {
    const _0x3998e5 = ['findIndex', '1152150rPSNdX', '36ZZLvCx', 'banana', '8188496BETplA', 'apple', 'mango', '8205885UgMKRP', 'name', 'mango\x20is\x20at\x20index:\x20', '4859463AucnCA', '200jDkaJc', '2AERGYb', '150312ZNqtvD', '222977FLuayJ', '76701YPNZSp'];
    a0_0x2d3e = function() {
        return _0x3998e5;
    };
    return a0_0x2d3e();
}(function(_0x514944, _0x2b94e5) {
    const _0x29f675 = a0_0x58f6,
        _0x3d9ec7 = _0x514944();
    while (!![]) {
        try {
            const _0x1e029b = -parseInt(_0x29f675(0x145)) / 0x1 * (-parseInt(_0x29f675(0x143)) / 0x2) + -parseInt(_0x29f675(0x146)) / 0x3 * (parseInt(_0x29f675(0x149)) / 0x4) + -parseInt(_0x29f675(0x142)) / 0x5 * (-parseInt(_0x29f675(0x144)) / 0x6) + -parseInt(_0x29f675(0x141)) / 0x7 + parseInt(_0x29f675(0x14b)) / 0x8 + -parseInt(_0x29f675(0x14e)) / 0x9 + parseInt(_0x29f675(0x148)) / 0xa;
            if (_0x1e029b === _0x2b94e5) break;
            else _0x3d9ec7['push'](_0x3d9ec7['shift']());
        } catch (_0x44b807) {
            _0x3d9ec7['push'](_0x3d9ec7['shift']());
        }
    }
}(a0_0x2d3e, 0x80d8d));
const fruits = [{
        'name': a0_0x3c3809(0x14c),
        'count': 0xa
    }, {
        'name': a0_0x3c3809(0x14a),
        'count': 0x12
    }, {
        'name': a0_0x3c3809(0x14d),
        'count': 0x3
    }],
    findMango = fruits[a0_0x3c3809(0x147)](_0x2de7d4 => _0x2de7d4[a0_0x3c3809(0x14f)] === a0_0x3c3809(0x14d));

function a0_0x58f6(_0xa10c78, _0x255021) {
    const _0x2d3e2e = a0_0x2d3e();
    return a0_0x58f6 = function(_0x58f6ac, _0x2083ff) {
        _0x58f6ac = _0x58f6ac - 0x140;
        let _0x1d7621 = _0x2d3e2e[_0x58f6ac];
        return _0x1d7621;
    }, a0_0x58f6(_0xa10c78, _0x255021);
}
console['log'](a0_0x3c3809(0x140) + findMango);