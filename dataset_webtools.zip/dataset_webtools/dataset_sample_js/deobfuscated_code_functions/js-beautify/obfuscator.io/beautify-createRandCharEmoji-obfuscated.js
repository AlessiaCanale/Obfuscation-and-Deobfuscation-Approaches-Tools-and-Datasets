(function(_0x226777, _0x4686e8) {
    const _0x34d662 = a0_0x3035,
        _0x3e5254 = _0x226777();
    while (!![]) {
        try {
            const _0x13022c = -parseInt(_0x34d662(0xda)) / 0x1 + -parseInt(_0x34d662(0xdf)) / 0x2 + -parseInt(_0x34d662(0xdc)) / 0x3 + parseInt(_0x34d662(0xd6)) / 0x4 + -parseInt(_0x34d662(0xde)) / 0x5 + -parseInt(_0x34d662(0xdb)) / 0x6 * (parseInt(_0x34d662(0xd4)) / 0x7) + parseInt(_0x34d662(0xd8)) / 0x8 * (parseInt(_0x34d662(0xd5)) / 0x9);
            if (_0x13022c === _0x4686e8) break;
            else _0x3e5254['push'](_0x3e5254['shift']());
        } catch (_0x403789) {
            _0x3e5254['push'](_0x3e5254['shift']());
        }
    }
}(a0_0x42c8, 0x7c5eb));

function createRandCharEmoji() {
    const _0xefbee7 = a0_0x3035,
        _0x18f01d = [':', ';', 'X', 'B', '8'],
        _0x28c054 = [')', '(', 'D', 'P', 'I', '*', ']'],
        _0x27ac27 = _0x18f01d[Math[_0xefbee7(0xd7)](Math['random']() * _0x18f01d['length'])],
        _0x26a0a6 = _0x28c054[Math['floor'](Math[_0xefbee7(0xdd)]() * _0x28c054[_0xefbee7(0xd9)])],
        _0x363f21 = _0x27ac27 + _0x26a0a6;
    console['log']('Generated\x20Emoji:', _0x363f21);
}

function a0_0x3035(_0x41bfe0, _0x575829) {
    const _0x42c819 = a0_0x42c8();
    return a0_0x3035 = function(_0x303548, _0x3c92fc) {
        _0x303548 = _0x303548 - 0xd4;
        let _0xcc21d1 = _0x42c819[_0x303548];
        return _0xcc21d1;
    }, a0_0x3035(_0x41bfe0, _0x575829);
}
createRandCharEmoji();

function a0_0x42c8() {
    const _0x523a89 = ['40zTUmMv', 'length', '328005qVtwpJ', '330nXIjvm', '1257762IlVYaR', 'random', '4991710xsiFlE', '1684640zYWSkl', '8029oZxafN', '4308651vMEYAp', '3066920yLcHbh', 'floor'];
    a0_0x42c8 = function() {
        return _0x523a89;
    };
    return a0_0x42c8();
}