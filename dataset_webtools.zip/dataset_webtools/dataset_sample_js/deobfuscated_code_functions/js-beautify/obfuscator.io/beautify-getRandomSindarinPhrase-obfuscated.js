(function(_0x47de6c, _0x391ba7) {
    const _0x2a0247 = a0_0x274e,
        _0x2fac58 = _0x47de6c();
    while (!![]) {
        try {
            const _0x4a4916 = -parseInt(_0x2a0247(0x14e)) / 0x1 * (-parseInt(_0x2a0247(0x14c)) / 0x2) + parseInt(_0x2a0247(0x149)) / 0x3 + parseInt(_0x2a0247(0x143)) / 0x4 * (parseInt(_0x2a0247(0x13b)) / 0x5) + -parseInt(_0x2a0247(0x13f)) / 0x6 * (-parseInt(_0x2a0247(0x145)) / 0x7) + parseInt(_0x2a0247(0x146)) / 0x8 * (parseInt(_0x2a0247(0x14f)) / 0x9) + -parseInt(_0x2a0247(0x142)) / 0xa * (parseInt(_0x2a0247(0x14b)) / 0xb) + -parseInt(_0x2a0247(0x147)) / 0xc * (parseInt(_0x2a0247(0x148)) / 0xd);
            if (_0x4a4916 === _0x391ba7) break;
            else _0x2fac58['push'](_0x2fac58['shift']());
        } catch (_0x194484) {
            _0x2fac58['push'](_0x2fac58['shift']());
        }
    }
}(a0_0x1fc0, 0x71caf));

function a0_0x274e(_0x27f8ff, _0x290fd3) {
    const _0x1fc03d = a0_0x1fc0();
    return a0_0x274e = function(_0x274e50, _0x1b82d5) {
        _0x274e50 = _0x274e50 - 0x13a;
        let _0x3f7f7f = _0x1fc03d[_0x274e50];
        return _0x3f7f7f;
    }, a0_0x274e(_0x27f8ff, _0x290fd3);
}

function getRandomSindarinPhrase() {
    const _0x5503fc = a0_0x274e,
        _0x8e56a4 = {
            'Aenon\x20neled\x20herain': 'I\x20would\x20rather\x20spend\x20my\x20days\x20with\x20you',
            'Guren\x20bein\x20thia': 'I\x20have\x20a\x20broken\x20heart',
            'Lach\x20en\x20Annûn': _0x5503fc(0x14d),
            'Elen\x20síla\x20lúmenn\x27\x20omentielvo': _0x5503fc(0x13c),
            'Le\x20hannon': _0x5503fc(0x140),
            'Hûl\x20eithel': _0x5503fc(0x150),
            'Gi\x20melin': _0x5503fc(0x13a)
        },
        _0x3baae4 = Object[_0x5503fc(0x14a)](_0x8e56a4),
        _0x30580a = _0x3baae4[Math[_0x5503fc(0x141)](Math[_0x5503fc(0x144)]() * _0x3baae4['length'])],
        _0x3c71b8 = _0x8e56a4[_0x30580a];
    console[_0x5503fc(0x13e)](_0x30580a + _0x5503fc(0x13d) + _0x3c71b8);
}
getRandomSindarinPhrase();

function a0_0x1fc0() {
    const _0x32a520 = ['724412yFYWoo', '639318IvuGCx', 'keys', '9076298mKcoaD', '226938udnEiF', 'Flame\x20of\x20the\x20West', '1gTFlzq', '153dvtEae', 'Secret\x20fire', 'I\x20love\x20you', '80065qeplfI', 'A\x20star\x20shines\x20on\x20the\x20hour\x20of\x20our\x20meeting', '\x20-\x20', 'log', '5442DtnFre', 'Thank\x20you', 'floor', '10RjnaBc', '176ClMpKK', 'random', '2569IzezUE', '70632zjWbsL', '48wHFVrU'];
    a0_0x1fc0 = function() {
        return _0x32a520;
    };
    return a0_0x1fc0();
}