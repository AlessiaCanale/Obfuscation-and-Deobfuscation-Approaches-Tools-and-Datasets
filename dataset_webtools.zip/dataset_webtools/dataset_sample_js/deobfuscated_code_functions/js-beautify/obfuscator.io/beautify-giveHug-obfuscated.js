(function(_0xc7f5a4, _0x1d9d96) {
    var _0x7666aa = a0_0x5283,
        _0x2c45a4 = _0xc7f5a4();
    while (!![]) {
        try {
            var _0xc94855 = parseInt(_0x7666aa(0x154)) / 0x1 + -parseInt(_0x7666aa(0x14d)) / 0x2 * (-parseInt(_0x7666aa(0x152)) / 0x3) + parseInt(_0x7666aa(0x14f)) / 0x4 + -parseInt(_0x7666aa(0x14b)) / 0x5 + parseInt(_0x7666aa(0x14a)) / 0x6 * (parseInt(_0x7666aa(0x14c)) / 0x7) + parseInt(_0x7666aa(0x14e)) / 0x8 * (-parseInt(_0x7666aa(0x153)) / 0x9) + -parseInt(_0x7666aa(0x150)) / 0xa * (parseInt(_0x7666aa(0x151)) / 0xb);
            if (_0xc94855 === _0x1d9d96) break;
            else _0x2c45a4['push'](_0x2c45a4['shift']());
        } catch (_0x3a2009) {
            _0x2c45a4['push'](_0x2c45a4['shift']());
        }
    }
}(a0_0x5128, 0x90468));

function giveHug() {
    var _0x58615e = a0_0x5283;
    console[_0x58615e(0x149)](_0x58615e(0x148)), setTimeout(function() {
        var _0x23ca1e = _0x58615e;
        console[_0x23ca1e(0x149)]('a\x20huge\x20hug\x20for\x20you\x20is\x20here!\x20<3');
    }, 0x1388);
}

function a0_0x5128() {
    var _0x4dbb20 = ['log', '24ZoUIgC', '321090lmvKOw', '1159571PiRAlS', '38EdzyZU', '360vEqzoZ', '1719212ewnfqA', '12616460BqXSvH', '11BvcThk', '183555QkzmgB', '216603OZyyAq', '744901lmyDxk', 'hug\x20coming...'];
    a0_0x5128 = function() {
        return _0x4dbb20;
    };
    return a0_0x5128();
}

function a0_0x5283(_0x337bec, _0x298eac) {
    var _0x512841 = a0_0x5128();
    return a0_0x5283 = function(_0x52831f, _0xe78455) {
        _0x52831f = _0x52831f - 0x148;
        var _0x5606b8 = _0x512841[_0x52831f];
        return _0x5606b8;
    }, a0_0x5283(_0x337bec, _0x298eac);
}
giveHug();