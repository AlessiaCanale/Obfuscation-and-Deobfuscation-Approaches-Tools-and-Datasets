const a0_0x456ad5 = a0_0x4a2a;
(function(_0x533228, _0x4cee42) {
    const _0x6b89a9 = a0_0x4a2a,
        _0x379498 = _0x533228();
    while (!![]) {
        try {
            const _0x6417ef = parseInt(_0x6b89a9(0x118)) / 0x1 * (parseInt(_0x6b89a9(0x11b)) / 0x2) + parseInt(_0x6b89a9(0x11c)) / 0x3 + -parseInt(_0x6b89a9(0x115)) / 0x4 * (-parseInt(_0x6b89a9(0x114)) / 0x5) + parseInt(_0x6b89a9(0x116)) / 0x6 + parseInt(_0x6b89a9(0x120)) / 0x7 * (-parseInt(_0x6b89a9(0x11f)) / 0x8) + parseInt(_0x6b89a9(0x113)) / 0x9 * (-parseInt(_0x6b89a9(0x11a)) / 0xa) + parseInt(_0x6b89a9(0x119)) / 0xb;
            if (_0x6417ef === _0x4cee42) break;
            else _0x379498['push'](_0x379498['shift']());
        } catch (_0x18ed07) {
            _0x379498['push'](_0x379498['shift']());
        }
    }
}(a0_0x4130, 0x89308));

function calculateSphereVolume(_0x24b997) {
    const _0xb5c020 = Math['PI'],
        _0x26dd29 = 0x4 / 0x3 * _0xb5c020 * Math['pow'](_0x24b997, 0x3);
    return _0x26dd29;
}

function a0_0x4a2a(_0x47754f, _0x466d96) {
    const _0x4130c5 = a0_0x4130();
    return a0_0x4a2a = function(_0x4a2a49, _0x2cdf17) {
        _0x4a2a49 = _0x4a2a49 - 0x113;
        let _0x2273ff = _0x4130c5[_0x4a2a49];
        return _0x2273ff;
    }, a0_0x4a2a(_0x47754f, _0x466d96);
}
const radius1 = 0x2,
    volume1 = calculateSphereVolume(radius1);

function a0_0x4130() {
    const _0x4cd5df = ['496397uYjyJT', '5740FPlvyl', '298uApwvr', '111519FFXMyb', ',\x20the\x20volume\x20is\x20', 'For\x20a\x20sphere\x20with\x20radius\x20', '2528PbHfGS', '5509gtAGwE', '3933PKRTiQ', '1115AsKaya', '5668bNjyqH', '3953076RSCScZ', 'log', '29TlAhmS'];
    a0_0x4130 = function() {
        return _0x4cd5df;
    };
    return a0_0x4130();
}
console[a0_0x456ad5(0x117)]('For\x20a\x20sphere\x20with\x20radius\x20' + radius1 + a0_0x456ad5(0x11d) + volume1);
const radius2 = 0x3,
    volume2 = calculateSphereVolume(radius2);
console[a0_0x456ad5(0x117)](a0_0x456ad5(0x11e) + radius2 + a0_0x456ad5(0x11d) + volume2);
const radius3 = 0x5,
    volume3 = calculateSphereVolume(radius3);
console[a0_0x456ad5(0x117)](a0_0x456ad5(0x11e) + radius3 + a0_0x456ad5(0x11d) + volume3);