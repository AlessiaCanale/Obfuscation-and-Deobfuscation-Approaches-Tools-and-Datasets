function a0_0x31ef(_0x4aadac, _0x2e1cbd) {
    const _0x577fb9 = a0_0x577f();
    return a0_0x31ef = function(_0x31ef4b, _0x77635c) {
        _0x31ef4b = _0x31ef4b - 0x17c;
        let _0xe2d360 = _0x577fb9[_0x31ef4b];
        return _0xe2d360;
    }, a0_0x31ef(_0x4aadac, _0x2e1cbd);
}

function a0_0x577f() {
    const _0x28f9f3 = ['8hlKjMc', 'translation', '31064341GWVycG', '4138830wXNnGE', 'Carpe\x20diem', 'random', '14HCuZih', 'Veritas\x20vos\x20liberabit', 'length', '939490FaRYyS', 'Random\x20Latin\x20Phrase:\x20\x22', '2688186kcNZhZ', '1584153ujDuEb', '1472LboHDU', '12897200NJZcfm', 'Sic\x20parvis\x20magna', 'Alea\x20iacta\x20est', 'Remember\x20that\x20you\x20will\x20die', 'floor', 'I\x20came,\x20I\x20saw,\x20I\x20conquered', '\x22\x20-\x20Translation:\x20\x22', '1fCzHtF', 'The\x20truth\x20will\x20set\x20you\x20free', '12265EjWYZV', 'Greatness\x20from\x20small\x20beginnings'];
    a0_0x577f = function() {
        return _0x28f9f3;
    };
    return a0_0x577f();
}(function(_0x2a1505, _0x261d8e) {
    const _0x4087ae = a0_0x31ef,
        _0x31e953 = _0x2a1505();
    while (!![]) {
        try {
            const _0xc0afa3 = parseInt(_0x4087ae(0x186)) / 0x1 * (parseInt(_0x4087ae(0x193)) / 0x2) + -parseInt(_0x4087ae(0x17d)) / 0x3 + parseInt(_0x4087ae(0x17e)) / 0x4 * (parseInt(_0x4087ae(0x188)) / 0x5) + -parseInt(_0x4087ae(0x17c)) / 0x6 * (-parseInt(_0x4087ae(0x190)) / 0x7) + parseInt(_0x4087ae(0x18a)) / 0x8 * (parseInt(_0x4087ae(0x18d)) / 0x9) + parseInt(_0x4087ae(0x17f)) / 0xa + -parseInt(_0x4087ae(0x18c)) / 0xb;
            if (_0xc0afa3 === _0x261d8e) break;
            else _0x31e953['push'](_0x31e953['shift']());
        } catch (_0x26b78b) {
            _0x31e953['push'](_0x31e953['shift']());
        }
    }
}(a0_0x577f, 0xa29a3));

function randomLatinPhrase() {
    const _0x427ecb = a0_0x31ef,
        _0x2ae3e4 = [{
            'latin': _0x427ecb(0x18e),
            'translation': 'Seize\x20the\x20day'
        }, {
            'latin': 'Veni,\x20vidi,\x20vici',
            'translation': _0x427ecb(0x184)
        }, {
            'latin': _0x427ecb(0x181),
            'translation': 'The\x20die\x20is\x20cast'
        }, {
            'latin': 'Memento\x20mori',
            'translation': _0x427ecb(0x182)
        }, {
            'latin': 'Acta\x20non\x20verba',
            'translation': 'Deeds\x20not\x20words'
        }, {
            'latin': _0x427ecb(0x191),
            'translation': _0x427ecb(0x187)
        }, {
            'latin': _0x427ecb(0x180),
            'translation': _0x427ecb(0x189)
        }],
        _0x26905c = Math[_0x427ecb(0x183)](Math[_0x427ecb(0x18f)]() * _0x2ae3e4[_0x427ecb(0x192)]),
        _0x4c51d8 = _0x2ae3e4[_0x26905c];
    console['log'](_0x427ecb(0x194) + _0x4c51d8['latin'] + _0x427ecb(0x185) + _0x4c51d8[_0x427ecb(0x18b)] + '\x22');
}
randomLatinPhrase();