function a0_0x42f3(_0x15a743, _0x1bec18) {
    var _0x1d3cd5 = a0_0x1d3c();
    return a0_0x42f3 = function(_0x42f321, _0x4aabb2) {
        _0x42f321 = _0x42f321 - 0xe6;
        var _0x1daa1f = _0x1d3cd5[_0x42f321];
        return _0x1daa1f;
    }, a0_0x42f3(_0x15a743, _0x1bec18);
}
var a0_0x3448c5 = a0_0x42f3;
(function(_0x385d2d, _0x4b9c71) {
    var _0x445451 = a0_0x42f3,
        _0x5e60a4 = _0x385d2d();
    while (!![]) {
        try {
            var _0x4d7cfa = parseInt(_0x445451(0xea)) / 0x1 * (parseInt(_0x445451(0xe6)) / 0x2) + parseInt(_0x445451(0xf6)) / 0x3 * (parseInt(_0x445451(0xf0)) / 0x4) + -parseInt(_0x445451(0xee)) / 0x5 * (-parseInt(_0x445451(0xe7)) / 0x6) + -parseInt(_0x445451(0xe8)) / 0x7 * (parseInt(_0x445451(0xf2)) / 0x8) + -parseInt(_0x445451(0xf4)) / 0x9 * (-parseInt(_0x445451(0xf1)) / 0xa) + -parseInt(_0x445451(0xec)) / 0xb * (parseInt(_0x445451(0xeb)) / 0xc) + -parseInt(_0x445451(0xed)) / 0xd * (parseInt(_0x445451(0xef)) / 0xe);
            if (_0x4d7cfa === _0x4b9c71) break;
            else _0x5e60a4['push'](_0x5e60a4['shift']());
        } catch (_0x3d42a7) {
            _0x5e60a4['push'](_0x5e60a4['shift']());
        }
    }
}(a0_0x1d3c, 0x73734));

function a0_0x1d3c() {
    var _0x45da38 = ['224854NvIKYO', '6lVmFtT', '238aTxovo', 'height', '5Sorzia', '72EZnZGG', '353551uKALcV', '3518879iQJqMw', '91815dBlEoS', '14DweSXf', '184YRwzOA', '631310WpMqHU', '11384ZwMOsU', 'width', '45nEGjdA', 'radius', '5781tZVtLP'];
    a0_0x1d3c = function() {
        return _0x45da38;
    };
    return a0_0x1d3c();
}(ball['y'] + ball['vy'] > canvas[a0_0x3448c5(0xe9)] - ball[a0_0x3448c5(0xf5)] || ball['y'] + ball['vy'] < ball['radius']) && (ball['vy'] = -ball['vy']);
(ball['x'] + ball['vx'] > canvas[a0_0x3448c5(0xf3)] - ball[a0_0x3448c5(0xf5)] || ball['x'] + ball['vx'] < ball['radius']) && (ball['vx'] = -ball['vx']);