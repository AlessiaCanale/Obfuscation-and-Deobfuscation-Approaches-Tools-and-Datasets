(function(_0x41839d, _0x23ad4a) {
    const _0x14e31c = a0_0xf8a2,
        _0x18613c = _0x41839d();
    while (!![]) {
        try {
            const _0x49aaae = -parseInt(_0x14e31c(0x1b9)) / 0x1 + parseInt(_0x14e31c(0x1c3)) / 0x2 + -parseInt(_0x14e31c(0x1bf)) / 0x3 * (parseInt(_0x14e31c(0x1c0)) / 0x4) + parseInt(_0x14e31c(0x1c6)) / 0x5 + parseInt(_0x14e31c(0x1ba)) / 0x6 + parseInt(_0x14e31c(0x1bc)) / 0x7 * (-parseInt(_0x14e31c(0x1c2)) / 0x8) + parseInt(_0x14e31c(0x1c4)) / 0x9 * (-parseInt(_0x14e31c(0x1b7)) / 0xa);
            if (_0x49aaae === _0x23ad4a) break;
            else _0x18613c['push'](_0x18613c['shift']());
        } catch (_0x4bff39) {
            _0x18613c['push'](_0x18613c['shift']());
        }
    }
}(a0_0x32fc, 0x5e495));

function a0_0x32fc() {
    const _0x5ca7de = ['log', '324362ZkrsAq', '3698856qfnQIW', 'random', '1576442qvywYr', 'toString', 'Try\x20to\x20convert\x20the\x20decimal\x20number\x20shown\x20into\x20binary,\x20the\x20solution\x20will\x20appear\x20after\x2010\x20seconds.', '3yDOKIj', '2189576BruibB', 'Decimal\x20number:\x20', '8txVNNU', '1069332ZWQaDj', '9nGBqBd', 'floor', '1756450DcNcVE', 'Binary\x20number:\x20', '192730omcnoW'];
    a0_0x32fc = function() {
        return _0x5ca7de;
    };
    return a0_0x32fc();
}

function a0_0xf8a2(_0xff5991, _0x4f83fd) {
    const _0x32fcb1 = a0_0x32fc();
    return a0_0xf8a2 = function(_0xf8a2e3, _0x5b4eca) {
        _0xf8a2e3 = _0xf8a2e3 - 0x1b7;
        let _0x1c8feb = _0x32fcb1[_0xf8a2e3];
        return _0x1c8feb;
    }, a0_0xf8a2(_0xff5991, _0x4f83fd);
}

function practiceDecimalToBinary() {
    const _0x481aac = a0_0xf8a2,
        _0x3e9a4b = Math[_0x481aac(0x1c5)](Math[_0x481aac(0x1bb)]() * 0x65),
        _0x30aa29 = _0x3e9a4b[_0x481aac(0x1bd)](0x2);
    console[_0x481aac(0x1b8)](_0x481aac(0x1c1) + _0x3e9a4b), console[_0x481aac(0x1b8)](_0x481aac(0x1be)), setTimeout(() => {
        const _0x268ca3 = _0x481aac;
        console['log'](_0x268ca3(0x1c7) + _0x30aa29);
    }, 0x2710);
}
practiceDecimalToBinary();