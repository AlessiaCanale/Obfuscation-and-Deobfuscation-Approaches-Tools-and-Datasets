(function(_0xbf2ce3, _0x1f5753) {
    const _0x46a52b = a0_0x1d02,
        _0x1b7b34 = _0xbf2ce3();
    while (!![]) {
        try {
            const _0x2a568c = -parseInt(_0x46a52b(0x133)) / 0x1 * (parseInt(_0x46a52b(0x12f)) / 0x2) + parseInt(_0x46a52b(0x141)) / 0x3 * (parseInt(_0x46a52b(0x13a)) / 0x4) + parseInt(_0x46a52b(0x13c)) / 0x5 * (parseInt(_0x46a52b(0x131)) / 0x6) + parseInt(_0x46a52b(0x13b)) / 0x7 + parseInt(_0x46a52b(0x13d)) / 0x8 + parseInt(_0x46a52b(0x134)) / 0x9 + -parseInt(_0x46a52b(0x136)) / 0xa * (parseInt(_0x46a52b(0x130)) / 0xb);
            if (_0x2a568c === _0x1f5753) break;
            else _0x1b7b34['push'](_0x1b7b34['shift']());
        } catch (_0x344e9e) {
            _0x1b7b34['push'](_0x1b7b34['shift']());
        }
    }
}(a0_0x4c21, 0x9c424));

function getRandomGreekLetter() {
    const _0x5e3d95 = a0_0x1d02,
        _0x42c1cc = [{
            'letter': 'Α',
            'name': _0x5e3d95(0x145)
        }, {
            'letter': 'Β',
            'name': _0x5e3d95(0x146)
        }, {
            'letter': 'Γ',
            'name': 'Gamma'
        }, {
            'letter': 'Δ',
            'name': 'Delta'
        }, {
            'letter': 'Ε',
            'name': 'Epsilon'
        }, {
            'letter': 'Ζ',
            'name': 'Zeta'
        }, {
            'letter': 'Η',
            'name': 'Eta'
        }, {
            'letter': 'Θ',
            'name': 'Theta'
        }, {
            'letter': 'Ι',
            'name': _0x5e3d95(0x13e)
        }, {
            'letter': 'Κ',
            'name': _0x5e3d95(0x137)
        }],
        _0x575f7c = Math[_0x5e3d95(0x143)](Math[_0x5e3d95(0x144)]() * _0x42c1cc[_0x5e3d95(0x140)]),
        _0x3aace7 = _0x42c1cc[_0x575f7c],
        _0x4c98a5 = _0x3aace7['letter'][_0x5e3d95(0x142)](),
        _0x33db76 = _0x3aace7[_0x5e3d95(0x138)]['toLowerCase']();
    console['log'](_0x5e3d95(0x139) + _0x3aace7[_0x5e3d95(0x132)] + '\x20-\x20Name:\x20' + _0x3aace7[_0x5e3d95(0x138)]), console[_0x5e3d95(0x13f)]('Random\x20Lowercase\x20Letter:\x20' + _0x4c98a5 + _0x5e3d95(0x135) + _0x33db76);
}

function a0_0x4c21() {
    const _0x3da833 = ['870YCITmb', 'letter', '2dcxmNC', '3101760vHKbIW', '\x20-\x20Name:\x20', '23082180khJcQm', 'Kappa', 'name', 'Random\x20Uppercase\x20Letter:\x20', '2940676JkiIdo', '4191586BMiaio', '37405qHFqdG', '1813552fdtVjx', 'Iota', 'log', 'length', '3PkfGNJ', 'toLowerCase', 'floor', 'random', 'Alpha', 'Beta', '41792ceeCya', '11xZCkMt'];
    a0_0x4c21 = function() {
        return _0x3da833;
    };
    return a0_0x4c21();
}

function a0_0x1d02(_0x49a915, _0x583cc0) {
    const _0x4c216e = a0_0x4c21();
    return a0_0x1d02 = function(_0x1d025c, _0x5ce4ba) {
        _0x1d025c = _0x1d025c - 0x12f;
        let _0x47641f = _0x4c216e[_0x1d025c];
        return _0x47641f;
    }, a0_0x1d02(_0x49a915, _0x583cc0);
}
getRandomGreekLetter();