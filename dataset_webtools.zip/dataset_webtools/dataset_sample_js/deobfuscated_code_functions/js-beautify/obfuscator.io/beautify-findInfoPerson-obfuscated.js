function a0_0x5163() {
    const _0x317b27 = ['log', 'Hermione', '9jFzSwk', 'filter', 'Fred', '36pIFQei', 'Ron', '7474428UueEtk', '360763KWwLve', 'Weasley', 'forEach', 'There\x20are\x20no\x20people\x20matching\x20the\x20data\x20entered.', '1558140BvTPdT', '11WmZffC', 'Granger', '128265SNHWFu', '25ubBHgb', 'Harry', '2188880sobUhT', '14bZtvmj', 'Ginny', '14394SdGlKP', '1151322cVSVeS', 'People\x20matching\x20the\x20data:\x20', 'nome', 'Potter'];
    a0_0x5163 = function() {
        return _0x317b27;
    };
    return a0_0x5163();
}
const a0_0x5a54a1 = a0_0x30b7;
(function(_0x7fe8c1, _0x53b8f6) {
    const _0x329a02 = a0_0x30b7,
        _0x1f0f2c = _0x7fe8c1();
    while (!![]) {
        try {
            const _0x3b2222 = parseInt(_0x329a02(0xe3)) / 0x1 + parseInt(_0x329a02(0xd7)) / 0x2 + parseInt(_0x329a02(0xd0)) / 0x3 * (-parseInt(_0x329a02(0xe0)) / 0x4) + -parseInt(_0x329a02(0xd1)) / 0x5 * (parseInt(_0x329a02(0xd6)) / 0x6) + -parseInt(_0x329a02(0xd4)) / 0x7 * (-parseInt(_0x329a02(0xd3)) / 0x8) + -parseInt(_0x329a02(0xdd)) / 0x9 * (parseInt(_0x329a02(0xcd)) / 0xa) + parseInt(_0x329a02(0xce)) / 0xb * (-parseInt(_0x329a02(0xe2)) / 0xc);
            if (_0x3b2222 === _0x53b8f6) break;
            else _0x1f0f2c['push'](_0x1f0f2c['shift']());
        } catch (_0x3be49b) {
            _0x1f0f2c['push'](_0x1f0f2c['shift']());
        }
    }
}(a0_0x5163, 0x4b3cb));

function a0_0x30b7(_0x3b3ff1, _0x41481a) {
    const _0x5163d9 = a0_0x5163();
    return a0_0x30b7 = function(_0x30b77e, _0x5af8f5) {
        _0x30b77e = _0x30b77e - 0xcb;
        let _0x4ae3c7 = _0x5163d9[_0x30b77e];
        return _0x4ae3c7;
    }, a0_0x30b7(_0x3b3ff1, _0x41481a);
}
const people = [{
    'nome': a0_0x5a54a1(0xd2),
    'cognome': a0_0x5a54a1(0xda)
}, {
    'nome': a0_0x5a54a1(0xdc),
    'cognome': a0_0x5a54a1(0xcf)
}, {
    'nome': a0_0x5a54a1(0xe1),
    'cognome': a0_0x5a54a1(0xe4)
}, {
    'nome': a0_0x5a54a1(0xd5),
    'cognome': 'Weasley'
}, {
    'nome': a0_0x5a54a1(0xdf),
    'cognome': a0_0x5a54a1(0xe4)
}];

function findInfoPerson(_0x5aedab) {
    const _0x5472de = a0_0x5a54a1;
    console[_0x5472de(0xdb)](_0x5aedab);
    const _0x4d4d77 = people[_0x5472de(0xde)](_0x408130 => _0x408130[_0x5472de(0xd9)] === _0x5aedab || _0x408130['cognome'] === _0x5aedab);
    _0x4d4d77['length'] > 0x0 ? (console['log'](_0x5472de(0xd8)), _0x4d4d77[_0x5472de(0xcb)](_0xca12dc => console[_0x5472de(0xdb)](_0xca12dc))) : console[_0x5472de(0xdb)](_0x5472de(0xcc));
}
findInfoPerson('Weasley'), findInfoPerson(a0_0x5a54a1(0xd2)), findInfoPerson('Granger'), findInfoPerson('Reepicheep');