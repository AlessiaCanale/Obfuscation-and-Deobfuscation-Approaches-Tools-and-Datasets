function a0_0x1f03() {
    const _0x1a112a = ['1410PstsgH', 'name', 'sky', 'Word\x20Passed:\x20', '2143295oPCxzz', '3266694CSASoo', 'Translation:\x20', 'art', '410yMjNUP', 'forest', 'earth', 'love', 'matter', 'to\x20conquer', 'eternity', 'random', '8iUcsSW', 'death', 'faith', 'truth', 'soul', 'life', 'log', '485hJoaoD', 'light', 'wise', 'wind', 'war', '577445ieHrZo', '2733246jYGUEL', '1858DhawIH', 'shadow', '8648susOAN', 'keys', '3806955TbrkoE'];
    a0_0x1f03 = function() {
        return _0x1a112a;
    };
    return a0_0x1f03();
}
const a0_0x48c681 = a0_0xe6c8;
(function(_0x28822b, _0x14e760) {
    const _0x58b0d9 = a0_0xe6c8,
        _0x4802dd = _0x28822b();
    while (!![]) {
        try {
            const _0x1188b0 = -parseInt(_0x58b0d9(0x11f)) / 0x1 * (parseInt(_0x58b0d9(0x126)) / 0x2) + -parseInt(_0x58b0d9(0x130)) / 0x3 + parseInt(_0x58b0d9(0x128)) / 0x4 * (parseInt(_0x58b0d9(0x12b)) / 0x5) + -parseInt(_0x58b0d9(0x125)) / 0x6 + parseInt(_0x58b0d9(0x12f)) / 0x7 + -parseInt(_0x58b0d9(0x13b)) / 0x8 * (parseInt(_0x58b0d9(0x12a)) / 0x9) + parseInt(_0x58b0d9(0x133)) / 0xa * (parseInt(_0x58b0d9(0x124)) / 0xb);
            if (_0x1188b0 === _0x14e760) break;
            else _0x4802dd['push'](_0x4802dd['shift']());
        } catch (_0x109ad0) {
            _0x4802dd['push'](_0x4802dd['shift']());
        }
    }
}(a0_0x1f03, 0x9ebb5));

function a0_0xe6c8(_0x5890b0, _0x9ea189) {
    const _0x1f0345 = a0_0x1f03();
    return a0_0xe6c8 = function(_0xe6c838, _0x23c577) {
        _0xe6c838 = _0xe6c838 - 0x119;
        let _0x10de0c = _0x1f0345[_0xe6c838];
        return _0x10de0c;
    }, a0_0xe6c8(_0x5890b0, _0x9ea189);
}

function displayRandomLatinWord(_0x15b7ee, _0x403473) {
    const _0x59c3f5 = a0_0xe6c8,
        _0x15b3dd = {
            'amor': 'love',
            'veritas': _0x59c3f5(0x11b),
            'lux': _0x59c3f5(0x120),
            'tempus': 'time',
            'ventus': _0x59c3f5(0x122),
            'aeternitas': _0x59c3f5(0x139),
            'vincere': _0x59c3f5(0x138),
            'scio': 'to\x20know',
            'bellum': _0x59c3f5(0x123),
            'mors': _0x59c3f5(0x119),
            'vita': _0x59c3f5(0x11d),
            'terra': _0x59c3f5(0x135),
            'sapiens': _0x59c3f5(0x121),
            'fortuna': 'fortune',
            'animus': _0x59c3f5(0x11c),
            'silva': _0x59c3f5(0x134),
            'umbra': _0x59c3f5(0x127),
            'caelum': _0x59c3f5(0x12d),
            'ars': _0x59c3f5(0x132),
            'fides': _0x59c3f5(0x11a),
            'magister': 'teacher',
            'materia': _0x59c3f5(0x137),
            'lumen': 'light',
            'senex': 'old\x20man',
            'nomen': _0x59c3f5(0x12c)
        },
        _0x40d6db = Object[_0x59c3f5(0x129)](_0x15b3dd),
        _0x17d126 = _0x40d6db[Math['floor'](Math[_0x59c3f5(0x13a)]() * _0x40d6db['length'])];
    console[_0x59c3f5(0x11e)]('Latin\x20Word:\x20' + _0x17d126), console[_0x59c3f5(0x11e)](_0x59c3f5(0x131) + _0x15b3dd[_0x17d126]), console[_0x59c3f5(0x11e)](_0x59c3f5(0x12e) + _0x15b7ee), console[_0x59c3f5(0x11e)]('Translation\x20Passed:\x20' + _0x403473);
}
displayRandomLatinWord('amor', a0_0x48c681(0x136));