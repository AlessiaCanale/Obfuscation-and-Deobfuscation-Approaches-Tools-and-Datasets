const a0_0x332557 = a0_0x27c2;

function a0_0x27c2(_0x23c84d, _0x3c86cd) {
    const _0x4a9900 = a0_0x4a99();
    return a0_0x27c2 = function(_0x27c220, _0x1c8bfd) {
        _0x27c220 = _0x27c220 - 0xaa;
        let _0x178635 = _0x4a9900[_0x27c220];
        return _0x178635;
    }, a0_0x27c2(_0x23c84d, _0x3c86cd);
}(function(_0x4c55e3, _0x57fc39) {
    const _0x1cb1f7 = a0_0x27c2,
        _0x369a25 = _0x4c55e3();
    while (!![]) {
        try {
            const _0xf87d37 = parseInt(_0x1cb1f7(0xb5)) / 0x1 + parseInt(_0x1cb1f7(0xae)) / 0x2 + -parseInt(_0x1cb1f7(0xb2)) / 0x3 * (-parseInt(_0x1cb1f7(0xaa)) / 0x4) + -parseInt(_0x1cb1f7(0xad)) / 0x5 + parseInt(_0x1cb1f7(0xb4)) / 0x6 + parseInt(_0x1cb1f7(0xb0)) / 0x7 + -parseInt(_0x1cb1f7(0xab)) / 0x8 * (parseInt(_0x1cb1f7(0xb6)) / 0x9);
            if (_0xf87d37 === _0x57fc39) break;
            else _0x369a25['push'](_0x369a25['shift']());
        } catch (_0x23ba0e) {
            _0x369a25['push'](_0x369a25['shift']());
        }
    }
}(a0_0x4a99, 0x7469d));
const alphabet = a0_0x332557(0xac),
    randomLetter = alphabet[Math[a0_0x332557(0xb1)](Math['random']() * alphabet[a0_0x332557(0xaf)])];

function a0_0x4a99() {
    const _0x1255ba = ['832930uMrgTf', '9176229wREQCo', '100NQAxLD', '24zpeeJa', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', '25195jUgiGQ', '1784558IOgzFo', 'length', '4380159rViXxF', 'floor', '51243FfotNc', 'log', '4575840OOJUAv'];
    a0_0x4a99 = function() {
        return _0x1255ba;
    };
    return a0_0x4a99();
}
console[a0_0x332557(0xb3)](randomLetter);