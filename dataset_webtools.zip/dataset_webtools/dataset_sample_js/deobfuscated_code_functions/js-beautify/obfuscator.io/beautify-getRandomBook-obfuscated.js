function a0_0x13b0() {
    const _0x3be50d = ['Follows\x20the\x20journey\x20of\x20a\x20young\x20wizard\x20named\x20Harry\x20Potter\x20as\x20he\x20attends\x20Hogwarts\x20School\x20of\x20Witchcraft\x20and\x20Wizardry\x20and\x20battles\x20the\x20dark\x20wizard\x20Lord\x20Voldemort.', '160tkbiIM', 'Licia\x20Troisi', 'length', 'log', '4086838JIOigH', 'A\x20young\x20hobbit\x20named\x20Frodo\x20Baggins\x20inherits\x20a\x20magical\x20ring\x20and\x20must\x20journey\x20across\x20Middle-earth\x20to\x20destroy\x20it\x20before\x20it\x20falls\x20into\x20the\x20hands\x20of\x20the\x20dark\x20lord\x20Sauron.', 'Plot:\x20', 'author', 'J.R.R.\x20Tolkien', '5265kOQjLd', '7456JpBTQm', 'Title:\x20', 'A\x20complex\x20tale\x20of\x20power\x20struggles\x20among\x20noble\x20families\x20in\x20the\x20fictional\x20continents\x20of\x20Westeros\x20and\x20Essos,\x20while\x20an\x20ancient\x20threat\x20awakens\x20beyond\x20the\x20Wall.', 'C.S.\x20Lewis', 'An\x20epic\x20fantasy\x20trilogy\x20following\x20the\x20adventures\x20of\x20a\x20young\x20girl\x20named\x20Nihal\x20in\x20a\x20world\x20where\x20magic\x20and\x20war\x20collide.', '138870eUzmyg', '27qkFkCi', 'A\x20series\x20of\x20fantasy\x20novels\x20that\x20take\x20place\x20in\x20the\x20magical\x20land\x20of\x20Narnia,\x20where\x20children\x20embark\x20on\x20adventures\x20and\x20encounters\x20with\x20mythical\x20creatures.', '247930lRMqXS', '6gJUfvZ', '1989024kowiUx', '2150830NVvpqP', '589195pscMYO', 'random'];
    a0_0x13b0 = function() {
        return _0x3be50d;
    };
    return a0_0x13b0();
}(function(_0x4b335e, _0x4512b3) {
    const _0x5f4a89 = a0_0xbc45,
        _0x2b940e = _0x4b335e();
    while (!![]) {
        try {
            const _0x475ca6 = -parseInt(_0x5f4a89(0x118)) / 0x1 + parseInt(_0x5f4a89(0x12a)) / 0x2 * (-parseInt(_0x5f4a89(0x12b)) / 0x3) + -parseInt(_0x5f4a89(0x12f)) / 0x4 + -parseInt(_0x5f4a89(0x12d)) / 0x5 * (-parseInt(_0x5f4a89(0x12e)) / 0x6) + -parseInt(_0x5f4a89(0x11f)) / 0x7 + parseInt(_0x5f4a89(0x125)) / 0x8 * (-parseInt(_0x5f4a89(0x124)) / 0x9) + parseInt(_0x5f4a89(0x11b)) / 0xa * (parseInt(_0x5f4a89(0x130)) / 0xb);
            if (_0x475ca6 === _0x4512b3) break;
            else _0x2b940e['push'](_0x2b940e['shift']());
        } catch (_0x11b9ec) {
            _0x2b940e['push'](_0x2b940e['shift']());
        }
    }
}(a0_0x13b0, 0x526ee));

function getRandomBook() {
    const _0x493e09 = a0_0xbc45,
        _0x20749a = [{
            'title': 'The\x20Lord\x20of\x20the\x20Rings',
            'author': _0x493e09(0x123),
            'plot': _0x493e09(0x120)
        }, {
            'title': 'The\x20Chronicles\x20of\x20Ice\x20and\x20Fire',
            'author': 'George\x20R.R.\x20Martin',
            'plot': _0x493e09(0x127)
        }, {
            'title': 'Harry\x20Potter',
            'author': 'J.K.\x20Rowling',
            'plot': _0x493e09(0x11a)
        }, {
            'title': 'The\x20Chronicles\x20of\x20Narnia',
            'author': _0x493e09(0x128),
            'plot': _0x493e09(0x12c)
        }, {
            'title': 'The\x20Chronicles\x20of\x20the\x20Emerged\x20World',
            'author': _0x493e09(0x11c),
            'plot': _0x493e09(0x129)
        }],
        _0x15affb = Math['floor'](Math[_0x493e09(0x119)]() * _0x20749a[_0x493e09(0x11d)]),
        _0x4b2fb7 = _0x20749a[_0x15affb];
    console[_0x493e09(0x11e)](_0x493e09(0x126) + _0x4b2fb7['title']), console['log']('Author:\x20' + _0x4b2fb7[_0x493e09(0x122)]), console[_0x493e09(0x11e)](_0x493e09(0x121) + _0x4b2fb7['plot']);
}

function a0_0xbc45(_0x2be2e6, _0x1ca473) {
    const _0x13b028 = a0_0x13b0();
    return a0_0xbc45 = function(_0xbc45c0, _0x151742) {
        _0xbc45c0 = _0xbc45c0 - 0x118;
        let _0x43bb09 = _0x13b028[_0xbc45c0];
        return _0x43bb09;
    }, a0_0xbc45(_0x2be2e6, _0x1ca473);
}
getRandomBook();