var a0_0x2cb09c = a0_0x52f0;

function a0_0x52f0(_0x4a4f13, _0x52e4c0) {
    var _0x2a9fa8 = a0_0x2a9f();
    return a0_0x52f0 = function(_0x52f0b9, _0x2f4e1a) {
        _0x52f0b9 = _0x52f0b9 - 0x1a5;
        var _0x4e88c4 = _0x2a9fa8[_0x52f0b9];
        return _0x4e88c4;
    }, a0_0x52f0(_0x4a4f13, _0x52e4c0);
}(function(_0x55376b, _0x480af9) {
    var _0x36574a = a0_0x52f0,
        _0x4d6095 = _0x55376b();
    while (!![]) {
        try {
            var _0x5e87d1 = -parseInt(_0x36574a(0x1a6)) / 0x1 * (parseInt(_0x36574a(0x1aa)) / 0x2) + -parseInt(_0x36574a(0x1a7)) / 0x3 + parseInt(_0x36574a(0x1ae)) / 0x4 + parseInt(_0x36574a(0x1ab)) / 0x5 + parseInt(_0x36574a(0x1ad)) / 0x6 + parseInt(_0x36574a(0x1b8)) / 0x7 + parseInt(_0x36574a(0x1ac)) / 0x8 * (-parseInt(_0x36574a(0x1a8)) / 0x9);
            if (_0x5e87d1 === _0x480af9) break;
            else _0x4d6095['push'](_0x4d6095['shift']());
        } catch (_0xddfabd) {
            _0x4d6095['push'](_0x4d6095['shift']());
        }
    }
}(a0_0x2a9f, 0xadb47), Vue[a0_0x2cb09c(0x1b5)](a0_0x2cb09c(0x1b0), {
    'template': a0_0x2cb09c(0x1ba),
    'data': function() {
        var _0x4b0506 = a0_0x2cb09c;
        return {
            'ActiveNewsItem': null,
            'News': [{
                'Title': _0x4b0506(0x1b9),
                'Id': 0x1,
                'Url': 'https://www.sb-websolutions.de/index.php?action=ViewBlogPost&postID=34&title=css-nummerierte-liste-mit-unterpunkten'
            }, {
                'Title': 'Preview:\x20Neues\x20ACP\x20Design',
                'Id': 0x2,
                'Url': _0x4b0506(0x1bc)
            }, {
                'Title': 'SBW\x20goes\x20social',
                'Id': 0x3,
                'Url': _0x4b0506(0x1b6)
            }]
        };
    },
    'mounted': function() {
        var _0x309645 = a0_0x2cb09c;
        this[_0x309645(0x1b1)] = this[_0x309645(0x1b2)][0x0], $(_0x309645(0x1a9))[_0x309645(0x1b3)]('animationend', this[_0x309645(0x1bb)]);
    },
    'methods': {
        'onTickerEnd': function() {
            var _0x55a8d2 = a0_0x2cb09c,
                _0x2d94cc = this[_0x55a8d2(0x1c0)];
            this[_0x55a8d2(0x1b1)] = _0x2d94cc, this['resetProgressbar']();
        },
        'resetProgressbar': function() {
            var _0x37b155 = a0_0x2cb09c,
                _0x14b85e = $(_0x37b155(0x1a9)),
                _0x5cb6ab = $(_0x14b85e)[_0x37b155(0x1be)](!![]);
            $(_0x14b85e)[_0x37b155(0x1af)](_0x5cb6ab), $(_0x14b85e)[_0x37b155(0x1bf)]();
        },
        'onTickerStatusIconClick': function(_0x3441da) {
            var _0x22acf6 = a0_0x2cb09c;
            this[_0x22acf6(0x1b1)] = _0x3441da, this[_0x22acf6(0x1b4)]();
        }
    },
    'computed': {
        'NextNews': function() {
            var _0x35ab70 = a0_0x2cb09c,
                _0x46e7ca = this[_0x35ab70(0x1b7)] + 0x1,
                _0x30aa10 = this['News'][_0x35ab70(0x1bd)];
            return _0x46e7ca >= _0x30aa10 && (_0x46e7ca = 0x0), this[_0x35ab70(0x1b2)][_0x46e7ca];
        },
        'CurrentActiveNewsIndex': function() {
            var _0x1bcb00 = a0_0x2cb09c;
            for (var _0x2e5900 = 0x0; _0x2e5900 < this['News']['length']; _0x2e5900 += 0x1) {
                if (this[_0x1bcb00(0x1b2)][_0x2e5900]['Id'] === this[_0x1bcb00(0x1b1)]['Id']) return _0x2e5900;
            }
        }
    }
}), new Vue({
    'el': a0_0x2cb09c(0x1a5)
}));

function a0_0x2a9f() {
    var _0x598f84 = ['2727205cbddIO', '1863584EewiYQ', '4814640QUXvpK', '3993736CdKLVQ', 'before', 'sbticker', 'ActiveNewsItem', 'News', 'bind', 'resetProgressbar', 'component', 'https://www.sb-websolutions.de/index.php?action=ViewBlogPost&postID=32&title=sbw-goes-social', 'CurrentActiveNewsIndex', '5927733SzFQKw', 'CSS:\x20Nummerierte\x20Liste\x20mit\x20unterpunkten', '#tickerTpl', 'onTickerEnd', 'https://www.sb-websolutions.de/index.php?action=ViewBlogPost&postID=33&title=preview-neues-acp-design', 'length', 'clone', 'remove', 'NextNews', '#ticker', '1kuauMh', '4026636ZxYDpU', '18ZmFtea', '.progress', '1347062JdgkLf'];
    a0_0x2a9f = function() {
        return _0x598f84;
    };
    return a0_0x2a9f();
}