const a0_0x223ef1 = a0_0x5401;
(function(_0x1695a9, _0x53d192) {
    const _0x58f089 = a0_0x5401,
        _0x1175af = _0x1695a9();
    while (!![]) {
        try {
            const _0x3e6277 = parseInt(_0x58f089(0x109)) / 0x1 * (-parseInt(_0x58f089(0x108)) / 0x2) + -parseInt(_0x58f089(0x10e)) / 0x3 * (parseInt(_0x58f089(0x104)) / 0x4) + -parseInt(_0x58f089(0x103)) / 0x5 * (-parseInt(_0x58f089(0x10c)) / 0x6) + parseInt(_0x58f089(0x10a)) / 0x7 + parseInt(_0x58f089(0x10f)) / 0x8 * (parseInt(_0x58f089(0x106)) / 0x9) + -parseInt(_0x58f089(0x10b)) / 0xa * (-parseInt(_0x58f089(0x10d)) / 0xb) + parseInt(_0x58f089(0x105)) / 0xc;
            if (_0x3e6277 === _0x53d192) break;
            else _0x1175af['push'](_0x1175af['shift']());
        } catch (_0xfadee6) {
            _0x1175af['push'](_0x1175af['shift']());
        }
    }
}(a0_0x3c7a, 0x3a937));
let pi = 3.141592653589793;

function a0_0x5401(_0x304c18, _0xc3523a) {
    const _0x3c7a3b = a0_0x3c7a();
    return a0_0x5401 = function(_0x5401da, _0x3f4e22) {
        _0x5401da = _0x5401da - 0x102;
        let _0x2fc216 = _0x3c7a3b[_0x5401da];
        return _0x2fc216;
    }, a0_0x5401(_0x304c18, _0xc3523a);
}

function findArea(_0x7acd4f) {
    return pi * _0x7acd4f * _0x7acd4f;
}

function a0_0x3c7a() {
    const _0x50943c = ['15020iVEjEy', '2GUBZTN', '475447WXebsq', '35850ymTjWM', '616332AmQdlN', '759cEyWwQ', '3qWsAXF', '88QwnQdX', '\x20is:\x20', '5bFZPQv', '1903632VjOObX', '426972iEuEaZ', '226854isbATj', 'Area\x20of\x20Circle\x20with\x20r\x20'];
    a0_0x3c7a = function() {
        return _0x50943c;
    };
    return a0_0x3c7a();
}
let r, Area;
r = 0x5, Area = findArea(r), console['log'](a0_0x223ef1(0x107) + r + a0_0x223ef1(0x102) + Area);