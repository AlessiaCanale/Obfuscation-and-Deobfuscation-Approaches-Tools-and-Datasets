function a0_0x34e9() {
    const _0x3b9d82 = ['309484oTKsnJ', '654488XtQvjm', 'log', '1027496hVhbCb', '10JNzjQV', '7NXJECr', '3970374XUldSm', 'Area\x20of\x20the\x20circumscribed\x20circle:\x20', 'pow', '12087889fbOhPq', 'Side\x20length\x20of\x20the\x20square:\x20', 'The\x20area\x20of\x20the\x20circle\x20circumscribed\x20around\x20a\x20square\x20with\x20side\x20length\x20', '\x20is:\x20', '1oXZBsx', '1525698VvCwDp', '3688596wLCuhZ', 'Diameter\x20of\x20the\x20circumscribed\x20circle:\x20', '5VqDIbD'];
    a0_0x34e9 = function() {
        return _0x3b9d82;
    };
    return a0_0x34e9();
}

function a0_0x3a8e(_0x4e64b1, _0x54f228) {
    const _0x34e984 = a0_0x34e9();
    return a0_0x3a8e = function(_0x3a8ea5, _0x5071dd) {
        _0x3a8ea5 = _0x3a8ea5 - 0xd6;
        let _0x52bfa8 = _0x34e984[_0x3a8ea5];
        return _0x52bfa8;
    }, a0_0x3a8e(_0x4e64b1, _0x54f228);
}
const a0_0x57dbe0 = a0_0x3a8e;
(function(_0x2980b7, _0x2182f7) {
    const _0x37b830 = a0_0x3a8e,
        _0x50227f = _0x2980b7();
    while (!![]) {
        try {
            const _0x5c2425 = -parseInt(_0x37b830(0xd9)) / 0x1 * (parseInt(_0x37b830(0xde)) / 0x2) + -parseInt(_0x37b830(0xda)) / 0x3 + -parseInt(_0x37b830(0xdf)) / 0x4 + parseInt(_0x37b830(0xdd)) / 0x5 * (parseInt(_0x37b830(0xe4)) / 0x6) + parseInt(_0x37b830(0xe3)) / 0x7 * (-parseInt(_0x37b830(0xe1)) / 0x8) + -parseInt(_0x37b830(0xdb)) / 0x9 + parseInt(_0x37b830(0xe2)) / 0xa * (parseInt(_0x37b830(0xe7)) / 0xb);
            if (_0x5c2425 === _0x2182f7) break;
            else _0x50227f['push'](_0x50227f['shift']());
        } catch (_0x28b9ff) {
            _0x50227f['push'](_0x50227f['shift']());
        }
    }
}(a0_0x34e9, 0x60899));

function areaCircleCircumscribedBySquare(_0x5b1e17) {
    const _0x355a65 = a0_0x3a8e;
    console['log'](_0x355a65(0xd6) + _0x5b1e17);
    const _0x3531e2 = Math['sqrt'](0x2) * _0x5b1e17;
    console[_0x355a65(0xe0)](_0x355a65(0xdc) + _0x3531e2);
    const _0x324040 = _0x3531e2 / 0x2;
    console[_0x355a65(0xe0)]('Radius\x20of\x20the\x20circumscribed\x20circle:\x20' + _0x324040);
    const _0x24e955 = Math['PI'] * Math[_0x355a65(0xe6)](_0x324040, 0x2);
    return console['log'](_0x355a65(0xe5) + _0x24e955), _0x24e955;
}
const sideLength = 0x5,
    area = areaCircleCircumscribedBySquare(sideLength);
console[a0_0x57dbe0(0xe0)](a0_0x57dbe0(0xd7) + sideLength + a0_0x57dbe0(0xd8) + area);