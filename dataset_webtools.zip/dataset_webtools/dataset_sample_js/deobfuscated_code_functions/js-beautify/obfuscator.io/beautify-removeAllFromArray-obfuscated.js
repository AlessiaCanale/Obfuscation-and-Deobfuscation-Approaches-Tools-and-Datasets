function a0_0x4802(_0x5930db, _0x2a99b9) {
    const _0x3d1448 = a0_0x3d14();
    return a0_0x4802 = function(_0x480279, _0x5ea38e) {
        _0x480279 = _0x480279 - 0x18f;
        let _0x437960 = _0x3d1448[_0x480279];
        return _0x437960;
    }, a0_0x4802(_0x5930db, _0x2a99b9);
}
const a0_0x2c3eed = a0_0x4802;
(function(_0x2d02cb, _0x392d4a) {
    const _0x3d3ec8 = a0_0x4802,
        _0x40ae84 = _0x2d02cb();
    while (!![]) {
        try {
            const _0x438f71 = -parseInt(_0x3d3ec8(0x19b)) / 0x1 + -parseInt(_0x3d3ec8(0x197)) / 0x2 + parseInt(_0x3d3ec8(0x193)) / 0x3 + -parseInt(_0x3d3ec8(0x18f)) / 0x4 + parseInt(_0x3d3ec8(0x195)) / 0x5 * (-parseInt(_0x3d3ec8(0x19e)) / 0x6) + parseInt(_0x3d3ec8(0x190)) / 0x7 * (-parseInt(_0x3d3ec8(0x199)) / 0x8) + -parseInt(_0x3d3ec8(0x19f)) / 0x9 * (-parseInt(_0x3d3ec8(0x192)) / 0xa);
            if (_0x438f71 === _0x392d4a) break;
            else _0x40ae84['push'](_0x40ae84['shift']());
        } catch (_0x423466) {
            _0x40ae84['push'](_0x40ae84['shift']());
        }
    }
}(a0_0x3d14, 0xdd6af));

function a0_0x3d14() {
    const _0x350faa = ['6eQpUrI', '5661LykhXu', '2763504lxGUZe', '23037RRuSiq', 'splice', '60310TDJHel', '3987003gsudgx', 'length', '7353415udPzoH', 'pop', '702762qJIxGE', 'Original\x20array:\x20', '3384FrFSQg', 'shift', '310540fKQPqh', 'log', '\x0aarray\x20length:\x20'];
    a0_0x3d14 = function() {
        return _0x350faa;
    };
    return a0_0x3d14();
}
let array = [a0_0x2c3eed(0x196), a0_0x2c3eed(0x191), 'filter', a0_0x2c3eed(0x19a)];
console[a0_0x2c3eed(0x19c)](a0_0x2c3eed(0x198) + array + a0_0x2c3eed(0x19d) + array['length']);
while (array[a0_0x2c3eed(0x194)]) {
    array[a0_0x2c3eed(0x196)]();
}
console[a0_0x2c3eed(0x19c)]('Array\x20Length\x20after\x20remove\x20all\x20elements:\x20' + array[a0_0x2c3eed(0x194)]);