function a0_0x5899() {
    const _0x3e1265 = ['Resulting\x20string\x20with\x20odd\x20words\x20only:\x20', '1335335aDvqcJ', '187520KyyXEb', 'Initial\x20string:\x20', 'filter', '3141228rGXjfc', 'split', '2783904EXvhRA', '77xxhJuL', '1802265dgZMlc', 'log', '2355008qvLGSo', '1274235iXkNGG', 'length'];
    a0_0x5899 = function() {
        return _0x3e1265;
    };
    return a0_0x5899();
}(function(_0x2d26aa, _0x1290cc) {
    const _0x41f594 = a0_0x18ab,
        _0x4ae112 = _0x2d26aa();
    while (!![]) {
        try {
            const _0x2addb1 = -parseInt(_0x41f594(0x157)) / 0x1 + parseInt(_0x41f594(0x156)) / 0x2 + parseInt(_0x41f594(0x154)) / 0x3 + parseInt(_0x41f594(0x152)) / 0x4 + parseInt(_0x41f594(0x15a)) / 0x5 + -parseInt(_0x41f594(0x150)) / 0x6 + parseInt(_0x41f594(0x153)) / 0x7 * (-parseInt(_0x41f594(0x15b)) / 0x8);
            if (_0x2addb1 === _0x1290cc) break;
            else _0x4ae112['push'](_0x4ae112['shift']());
        } catch (_0x3b3cf3) {
            _0x4ae112['push'](_0x4ae112['shift']());
        }
    }
}(a0_0x5899, 0xa7679));

function a0_0x18ab(_0x1da8db, _0x170b1d) {
    const _0x589948 = a0_0x5899();
    return a0_0x18ab = function(_0x18ab8f, _0x52f5b5) {
        _0x18ab8f = _0x18ab8f - 0x14f;
        let _0x507822 = _0x589948[_0x18ab8f];
        return _0x507822;
    }, a0_0x18ab(_0x1da8db, _0x170b1d);
}

function filterOddLengthWords(_0x5b72f2) {
    const _0x5b804d = a0_0x18ab,
        _0x3425ab = _0x5b72f2[_0x5b804d(0x151)]('\x20'),
        _0x30f655 = _0x3425ab[_0x5b804d(0x14f)](_0x196975 => _0x196975[_0x5b804d(0x158)] % 0x2 !== 0x0),
        _0x39631d = _0x3425ab[_0x5b804d(0x14f)](_0x1a5428 => _0x1a5428['length'] % 0x2 === 0x0);
    console[_0x5b804d(0x155)](_0x5b804d(0x15c) + _0x5b72f2), console[_0x5b804d(0x155)]('Even\x20words\x20removed:\x20' + _0x39631d['join']('\x20')), console[_0x5b804d(0x155)](_0x5b804d(0x159) + _0x30f655['join']('\x20'));
}
const inputString = 'apple\x20banana\x20cherry\x20orange\x20pineapple\x20strawberry\x20blueberry\x20kiwi\x20mango';
filterOddLengthWords(inputString);