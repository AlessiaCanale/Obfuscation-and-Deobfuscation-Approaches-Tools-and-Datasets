const a0_0x57365b = a0_0x255a;

function a0_0x255a(_0x47445e, _0x42a1d0) {
    const _0x437a2d = a0_0x437a();
    return a0_0x255a = function(_0x255a79, _0x1ad5d8) {
        _0x255a79 = _0x255a79 - 0x190;
        let _0x24c11a = _0x437a2d[_0x255a79];
        return _0x24c11a;
    }, a0_0x255a(_0x47445e, _0x42a1d0);
}(function(_0x1d9d9d, _0x2fa130) {
    const _0x1b2528 = a0_0x255a,
        _0x2fe677 = _0x1d9d9d();
    while (!![]) {
        try {
            const _0xbd68b3 = -parseInt(_0x1b2528(0x194)) / 0x1 + -parseInt(_0x1b2528(0x197)) / 0x2 + -parseInt(_0x1b2528(0x195)) / 0x3 * (-parseInt(_0x1b2528(0x191)) / 0x4) + parseInt(_0x1b2528(0x198)) / 0x5 + -parseInt(_0x1b2528(0x19f)) / 0x6 * (parseInt(_0x1b2528(0x193)) / 0x7) + parseInt(_0x1b2528(0x19c)) / 0x8 * (parseInt(_0x1b2528(0x19b)) / 0x9) + parseInt(_0x1b2528(0x1a1)) / 0xa * (parseInt(_0x1b2528(0x199)) / 0xb);
            if (_0xbd68b3 === _0x2fa130) break;
            else _0x2fe677['push'](_0x2fe677['shift']());
        } catch (_0x12546b) {
            _0x2fe677['push'](_0x2fe677['shift']());
        }
    }
}(a0_0x437a, 0xa2272));
const box = document[a0_0x57365b(0x19e)](a0_0x57365b(0x190));
let isAnimating = ![];

function a0_0x437a() {
    const _0xb06f6e = ['getElementById', '186tNFhho', 'transform', '5499730IKSEmF', 'animated-box', '8weRupm', 'translateX(0)', '63091CpHhZw', '372325tlDNxT', '1803792WpogQS', 'addEventListener', '2465768xlBfNd', '560165mGPkdC', '22QGvjSF', 'click', '153ppfJAe', '63192fLYfUa', 'style'];
    a0_0x437a = function() {
        return _0xb06f6e;
    };
    return a0_0x437a();
}
box[a0_0x57365b(0x196)](a0_0x57365b(0x19a), () => {
    const _0x467273 = a0_0x57365b;
    !isAnimating && (isAnimating = !![], box[_0x467273(0x19d)]['transform'] = 'translateX(200px)', setTimeout(() => {
        const _0x3e13c2 = _0x467273;
        isAnimating = ![], box['style'][_0x3e13c2(0x1a0)] = _0x3e13c2(0x192);
    }, 0x3e8));
});