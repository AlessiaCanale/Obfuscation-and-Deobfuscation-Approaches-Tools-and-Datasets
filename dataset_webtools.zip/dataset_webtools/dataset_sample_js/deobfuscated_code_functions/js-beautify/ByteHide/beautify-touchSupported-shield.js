/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x13d674 = _0x5b97;
(function(_0x3212e6, _0x4f6f6c) {
    const _0x375ce2 = _0x5b97,
        _0x1a1cd5 = _0x3212e6();
    while (!![]) {
        try {
            const _0x46c18f = parseInt(_0x375ce2(0x1b0)) / 0x1 + -parseInt(_0x375ce2(0x1aa)) / 0x2 * (-parseInt(_0x375ce2(0x1b3)) / 0x3) + -parseInt(_0x375ce2(0x1b1)) / 0x4 + -parseInt(_0x375ce2(0x1b5)) / 0x5 + parseInt(_0x375ce2(0x1af)) / 0x6 * (-parseInt(_0x375ce2(0x1ad)) / 0x7) + -parseInt(_0x375ce2(0x1ae)) / 0x8 * (-parseInt(_0x375ce2(0x1ab)) / 0x9) + -parseInt(_0x375ce2(0x1b2)) / 0xa * (parseInt(_0x375ce2(0x1b6)) / 0xb);
            if (_0x46c18f === _0x4f6f6c) break;
            else _0x1a1cd5['push'](_0x1a1cd5['shift']());
        } catch (_0x19532d) {
            _0x1a1cd5['push'](_0x1a1cd5['shift']());
        }
    }
}(_0x13de, 0xc84ce));
const touchSupported = () => {
    const _0x313f42 = _0x5b97;
    _0x313f42(0x1b4) in window || window[_0x313f42(0x1a9)] && document instanceof window[_0x313f42(0x1a9)];
};

function _0x5b97(_0x588193, _0x509a07) {
    const _0x13de44 = _0x13de();
    return _0x5b97 = function(_0x5b97f6, _0x3cad08) {
        _0x5b97f6 = _0x5b97f6 - 0x1a9;
        let _0x42789a = _0x13de44[_0x5b97f6];
        return _0x42789a;
    }, _0x5b97(_0x588193, _0x509a07);
}

function _0x13de() {
    const _0x458479 = ['2324872CdZxKY', '9369590PPGOVZ', '3NToKgv', 'ontouchstart', '3742860ozYSbQ', '11nhLqaZ', 'DocumentTouch', '2864476fxXFNM', '99YtyjOv', 'log', '161tcepVm', '1170248vQNfQm', '383322ZnKEzm', '1515251dfolTH'];
    _0x13de = function() {
        return _0x458479;
    };
    return _0x13de();
}
console[_0x13d674(0x1ac)](touchSupported());