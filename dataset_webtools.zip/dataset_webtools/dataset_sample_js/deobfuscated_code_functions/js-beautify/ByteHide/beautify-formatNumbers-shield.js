/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x96af() {
    const _0x18519f = ['214538UMKBpF', '19369HkFJoZ', 'forEach', '204124XcQNPQ', '999favYiP', 'de-DE', 'Number\x20', '203240eHIXem', 'en-US', 'format', '801840oZvglX', '3258KKmToL', '5ernFkJ', 'fr-FR', '126530rlVgiE', 'Locale:\x20', 'NumberFormat', 'ja-JP', '12fWYRWf', 'map', '3vAMDVj', '49467847HTFMsR'];
    _0x96af = function() {
        return _0x18519f;
    };
    return _0x96af();
}
const _0x5c1477 = _0x3183;
(function(_0x299bd7, _0x488698) {
    const _0x377524 = _0x3183,
        _0x468912 = _0x299bd7();
    while (!![]) {
        try {
            const _0x4ca518 = -parseInt(_0x377524(0x90)) / 0x1 + parseInt(_0x377524(0x86)) / 0x2 * (parseInt(_0x377524(0x84)) / 0x3) + -parseInt(_0x377524(0x89)) / 0x4 * (-parseInt(_0x377524(0x92)) / 0x5) + -parseInt(_0x377524(0x91)) / 0x6 * (parseInt(_0x377524(0x87)) / 0x7) + -parseInt(_0x377524(0x8d)) / 0x8 + -parseInt(_0x377524(0x8a)) / 0x9 * (parseInt(_0x377524(0x94)) / 0xa) + -parseInt(_0x377524(0x85)) / 0xb * (-parseInt(_0x377524(0x98)) / 0xc);
            if (_0x4ca518 === _0x488698) break;
            else _0x468912['push'](_0x468912['shift']());
        } catch (_0x4428d7) {
            _0x468912['push'](_0x468912['shift']());
        }
    }
}(_0x96af, 0xe0e50));

function _0x3183(_0x6f4396, _0x1e89dc) {
    const _0x96af91 = _0x96af();
    return _0x3183 = function(_0x318382, _0x233905) {
        _0x318382 = _0x318382 - 0x83;
        let _0x3b4430 = _0x96af91[_0x318382];
        return _0x3b4430;
    }, _0x3183(_0x6f4396, _0x1e89dc);
}
const numbersToFormat = [1234567.89, 98765.4321, 1234.5678],
    locales = [_0x5c1477(0x8e), _0x5c1477(0x93), _0x5c1477(0x8b), 'es-ES', _0x5c1477(0x97)];
locales[_0x5c1477(0x88)](_0x114023 => {
    const _0x5e128d = _0x5c1477,
        _0x4bf4b5 = new Intl[(_0x5e128d(0x96))](_0x114023),
        _0x5d87fd = numbersToFormat[_0x5e128d(0x83)](_0x15979a => _0x4bf4b5[_0x5e128d(0x8f)](_0x15979a));
    console['log'](_0x5e128d(0x95) + _0x114023), _0x5d87fd[_0x5e128d(0x88)]((_0x620a4c, _0x568c85) => {
        const _0x473aa4 = _0x5e128d;
        console['log'](_0x473aa4(0x8c) + (_0x568c85 + 0x1) + ':\x20' + _0x620a4c);
    }), console['log']('\x0a');
});