/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x401749 = _0x2090;

function _0x2090(_0xab6538, _0x5099cb) {
    const _0x540fb3 = _0x540f();
    return _0x2090 = function(_0x2090a8, _0x128398) {
        _0x2090a8 = _0x2090a8 - 0x1f4;
        let _0x4f2bd7 = _0x540fb3[_0x2090a8];
        return _0x4f2bd7;
    }, _0x2090(_0xab6538, _0x5099cb);
}

function _0x540f() {
    const _0x5c3d04 = ['1172297gPaexR', '4977WfdCZX', '1083553rgjujq', 'banana', '126WqInTy', 'find', 'mango', '3784fxewAC', '6YiQOnf', '199096SxuBwe', '692540EKuRDZ', 'count', '2651956EUVqvb', 'find\x20mango:\x20', '696udUgpr', '20360hnBmQo'];
    _0x540f = function() {
        return _0x5c3d04;
    };
    return _0x540f();
}(function(_0x59cc7c, _0x3750bd) {
    const _0x483abd = _0x2090,
        _0x5e35c9 = _0x59cc7c();
    while (!![]) {
        try {
            const _0x590e9f = parseInt(_0x483abd(0x203)) / 0x1 + parseInt(_0x483abd(0x1ff)) / 0x2 * (parseInt(_0x483abd(0x202)) / 0x3) + parseInt(_0x483abd(0x1fd)) / 0x4 + -parseInt(_0x483abd(0x1fb)) / 0x5 + parseInt(_0x483abd(0x1f9)) / 0x6 * (-parseInt(_0x483abd(0x201)) / 0x7) + parseInt(_0x483abd(0x1fa)) / 0x8 * (-parseInt(_0x483abd(0x1f5)) / 0x9) + parseInt(_0x483abd(0x200)) / 0xa * (-parseInt(_0x483abd(0x1f8)) / 0xb);
            if (_0x590e9f === _0x3750bd) break;
            else _0x5e35c9['push'](_0x5e35c9['shift']());
        } catch (_0x87a9f8) {
            _0x5e35c9['push'](_0x5e35c9['shift']());
        }
    }
}(_0x540f, 0xec985));
const fruits = [{
        'name': 'apple',
        'count': 0xa
    }, {
        'name': _0x401749(0x1f4),
        'count': 0x12
    }, {
        'name': _0x401749(0x1f7),
        'count': 0x3
    }],
    findMango = fruits[_0x401749(0x1f6)](_0x49e73d => _0x49e73d['name'] === _0x401749(0x1f7));
console['log'](_0x401749(0x1fe) + findMango['name'] + '\x20' + findMango[_0x401749(0x1fc)]);