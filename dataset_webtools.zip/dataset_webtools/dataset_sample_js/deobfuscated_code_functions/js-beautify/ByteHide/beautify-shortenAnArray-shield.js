/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x30360d = _0x5ae4;

function _0x5ed2() {
    const _0x38741d = ['Six', '18530ULzLaT', '5036tjDyCR', '2154CZWeZa', '145180qHRTIo', 'log', 'One', '5311824NfUikg', '410092PdQkhb', '85BUqsRB', '4378TOfJOG', '1366TiwRPB', '24AjWouH', 'length', 'Five', 'Three', 'Two', '3438837fwgznf'];
    _0x5ed2 = function() {
        return _0x38741d;
    };
    return _0x5ed2();
}(function(_0x3ad1ad, _0x5c3e43) {
    const _0x547c19 = _0x5ae4,
        _0x215e7e = _0x3ad1ad();
    while (!![]) {
        try {
            const _0x248306 = parseInt(_0x547c19(0x1b3)) / 0x1 + parseInt(_0x547c19(0x1b6)) / 0x2 * (-parseInt(_0x547c19(0x1ae)) / 0x3) + parseInt(_0x547c19(0x1ad)) / 0x4 * (parseInt(_0x547c19(0x1b4)) / 0x5) + -parseInt(_0x547c19(0x1b7)) / 0x6 * (-parseInt(_0x547c19(0x1af)) / 0x7) + parseInt(_0x547c19(0x1b2)) / 0x8 + parseInt(_0x547c19(0x1aa)) / 0x9 + parseInt(_0x547c19(0x1ac)) / 0xa * (-parseInt(_0x547c19(0x1b5)) / 0xb);
            if (_0x248306 === _0x5c3e43) break;
            else _0x215e7e['push'](_0x215e7e['shift']());
        } catch (_0x4be05e) {
            _0x215e7e['push'](_0x215e7e['shift']());
        }
    }
}(_0x5ed2, 0x5135e));

function _0x5ae4(_0xfecbac, _0x2bcb40) {
    const _0x5ed264 = _0x5ed2();
    return _0x5ae4 = function(_0x5ae43b, _0x399977) {
        _0x5ae43b = _0x5ae43b - 0x1a6;
        let _0x372107 = _0x5ed264[_0x5ae43b];
        return _0x372107;
    }, _0x5ae4(_0xfecbac, _0x2bcb40);
}
const big_array = [_0x30360d(0x1b1), _0x30360d(0x1a9), _0x30360d(0x1a8), 'Four', _0x30360d(0x1a7), _0x30360d(0x1ab)];
big_array[_0x30360d(0x1a6)] = 0x3, console[_0x30360d(0x1b0)](big_array);