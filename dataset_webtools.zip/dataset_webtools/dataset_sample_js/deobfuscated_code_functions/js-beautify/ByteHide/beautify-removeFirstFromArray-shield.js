/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x1e542e = _0x5f4d;

function _0x5f4d(_0x3adfac, _0x425221) {
    const _0x348af7 = _0x348a();
    return _0x5f4d = function(_0x5f4d08, _0x172e10) {
        _0x5f4d08 = _0x5f4d08 - 0x12c;
        let _0x7d2f45 = _0x348af7[_0x5f4d08];
        return _0x7d2f45;
    }, _0x5f4d(_0x3adfac, _0x425221);
}(function(_0x534cdc, _0x5f1792) {
    const _0x4b6a84 = _0x5f4d,
        _0x2f0d5a = _0x534cdc();
    while (!![]) {
        try {
            const _0x44ad43 = parseInt(_0x4b6a84(0x12d)) / 0x1 * (parseInt(_0x4b6a84(0x12f)) / 0x2) + -parseInt(_0x4b6a84(0x136)) / 0x3 + parseInt(_0x4b6a84(0x135)) / 0x4 + parseInt(_0x4b6a84(0x13a)) / 0x5 + -parseInt(_0x4b6a84(0x131)) / 0x6 * (parseInt(_0x4b6a84(0x12c)) / 0x7) + -parseInt(_0x4b6a84(0x133)) / 0x8 + parseInt(_0x4b6a84(0x13b)) / 0x9;
            if (_0x44ad43 === _0x5f1792) break;
            else _0x2f0d5a['push'](_0x2f0d5a['shift']());
        } catch (_0x140d13) {
            _0x2f0d5a['push'](_0x2f0d5a['shift']());
        }
    }
}(_0x348a, 0xdcee7));
let arr = [_0x1e542e(0x138), _0x1e542e(0x130), _0x1e542e(0x134), _0x1e542e(0x137)];

function _0x348a() {
    const _0x48181e = ['18095580ZQjAPZ', '8767304gFfvlP', '188109YImhYo', 'original\x20array:\x20', '6fAaRPv', 'splice', '6aApymM', 'Remaining\x20elements:\x20', '6769904xIHtzF', 'filter', '1669008TcPqyf', '1051824ciHceN', 'pop', 'shift', 'log', '1810270dAPhme'];
    _0x348a = function() {
        return _0x48181e;
    };
    return _0x348a();
}
console['log'](_0x1e542e(0x12e) + arr);
let shifted = arr[_0x1e542e(0x138)]();
console[_0x1e542e(0x139)]('Removed\x20element:\x20' + shifted), console[_0x1e542e(0x139)](_0x1e542e(0x132) + arr);