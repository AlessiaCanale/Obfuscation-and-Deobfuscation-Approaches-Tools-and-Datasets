/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x1a9709 = _0x63c8;

function _0x126d() {
    const _0x2bb509 = ['log', 'getTime', '110244CtKiuF', '130572LiYnfI', '49NGMbKO', '\x20days', '5518MszYqX', '989435SdSmit', '656100UeYlcC', 'toDateString', '\x20and\x20', '\x20is:\x20', '01/20/2024', 'Total\x20number\x20of\x20days\x20between\x20dates:\x0a', '920059gUELtk', '01/27/2024', '486104UUpGce'];
    _0x126d = function() {
        return _0x2bb509;
    };
    return _0x126d();
}(function(_0x35a3c4, _0x1c9888) {
    const _0x376833 = _0x63c8,
        _0x3e47f = _0x35a3c4();
    while (!![]) {
        try {
            const _0x1b0a86 = -parseInt(_0x376833(0x1cf)) / 0x1 * (-parseInt(_0x376833(0x1d1)) / 0x2) + parseInt(_0x376833(0x1de)) / 0x3 + parseInt(_0x376833(0x1df)) / 0x4 + parseInt(_0x376833(0x1d2)) / 0x5 + -parseInt(_0x376833(0x1d3)) / 0x6 + -parseInt(_0x376833(0x1d9)) / 0x7 + -parseInt(_0x376833(0x1db)) / 0x8;
            if (_0x1b0a86 === _0x1c9888) break;
            else _0x3e47f['push'](_0x3e47f['shift']());
        } catch (_0xc714de) {
            _0x3e47f['push'](_0x3e47f['shift']());
        }
    }
}(_0x126d, 0x18a37));

function _0x63c8(_0x1edfff, _0x55d9ff) {
    const _0x126dcc = _0x126d();
    return _0x63c8 = function(_0x63c860, _0x5aba61) {
        _0x63c860 = _0x63c860 - 0x1cf;
        let _0x558a1c = _0x126dcc[_0x63c860];
        return _0x558a1c;
    }, _0x63c8(_0x1edfff, _0x55d9ff);
}
let date1 = new Date(_0x1a9709(0x1d7)),
    date2 = new Date(_0x1a9709(0x1da)),
    Difference_In_Time = date2[_0x1a9709(0x1dd)]() - date1[_0x1a9709(0x1dd)](),
    Difference_In_Days = Math['round'](Difference_In_Time / (0x3e8 * 0xe10 * 0x18));
console[_0x1a9709(0x1dc)](_0x1a9709(0x1d8) + date1[_0x1a9709(0x1d4)]() + _0x1a9709(0x1d5) + date2[_0x1a9709(0x1d4)]() + _0x1a9709(0x1d6) + Difference_In_Days + _0x1a9709(0x1d0));