/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x40b52f = _0x1e9e;
(function(_0x4d27a6, _0x29e1e9) {
    const _0x2e45ea = _0x1e9e,
        _0x216367 = _0x4d27a6();
    while (!![]) {
        try {
            const _0x140478 = -parseInt(_0x2e45ea(0x1db)) / 0x1 * (parseInt(_0x2e45ea(0x1d2)) / 0x2) + -parseInt(_0x2e45ea(0x1d8)) / 0x3 * (parseInt(_0x2e45ea(0x1d7)) / 0x4) + -parseInt(_0x2e45ea(0x1da)) / 0x5 + parseInt(_0x2e45ea(0x1d4)) / 0x6 + -parseInt(_0x2e45ea(0x1cf)) / 0x7 * (-parseInt(_0x2e45ea(0x1d0)) / 0x8) + parseInt(_0x2e45ea(0x1ce)) / 0x9 * (parseInt(_0x2e45ea(0x1d5)) / 0xa) + parseInt(_0x2e45ea(0x1d6)) / 0xb;
            if (_0x140478 === _0x29e1e9) break;
            else _0x216367['push'](_0x216367['shift']());
        } catch (_0x489749) {
            _0x216367['push'](_0x216367['shift']());
        }
    }
}(_0x24b8, 0x544d2));

function _0x1e9e(_0x533a7c, _0x911328) {
    const _0x24b83f = _0x24b8();
    return _0x1e9e = function(_0x1e9e44, _0x314fec) {
        _0x1e9e44 = _0x1e9e44 - 0x1ce;
        let _0x4f330f = _0x24b83f[_0x1e9e44];
        return _0x4f330f;
    }, _0x1e9e(_0x533a7c, _0x911328);
}

function _0x24b8() {
    const _0xea673d = ['12513314NVChkp', '424lsKTRc', '14739bVrRjM', 'matches', '2681470AhwHgX', '53239CnDDjD', '45brMzji', '29372HuCsIj', '520qsmNbL', 'matchMedia', '12VqeozU', '(prefers-color-scheme:\x20dark)', '1246170QOZkVw', '207590XDEIpl'];
    _0x24b8 = function() {
        return _0xea673d;
    };
    return _0x24b8();
}
const isDarkMode = window[_0x40b52f(0x1d1)] && window['matchMedia'](_0x40b52f(0x1d3))[_0x40b52f(0x1d9)];
console['log'](isDarkMode);