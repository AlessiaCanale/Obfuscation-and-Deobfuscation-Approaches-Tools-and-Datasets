/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x1e4682 = _0x2c06;
(function(_0x4bc8de, _0x25eff9) {
    const _0x13bd50 = _0x2c06,
        _0x49eda1 = _0x4bc8de();
    while (!![]) {
        try {
            const _0x57c367 = -parseInt(_0x13bd50(0x14d)) / 0x1 * (parseInt(_0x13bd50(0x146)) / 0x2) + parseInt(_0x13bd50(0x14f)) / 0x3 + parseInt(_0x13bd50(0x14c)) / 0x4 + -parseInt(_0x13bd50(0x154)) / 0x5 + -parseInt(_0x13bd50(0x150)) / 0x6 * (-parseInt(_0x13bd50(0x149)) / 0x7) + parseInt(_0x13bd50(0x14b)) / 0x8 + parseInt(_0x13bd50(0x153)) / 0x9 * (parseInt(_0x13bd50(0x145)) / 0xa);
            if (_0x57c367 === _0x25eff9) break;
            else _0x49eda1['push'](_0x49eda1['shift']());
        } catch (_0x16544e) {
            _0x49eda1['push'](_0x49eda1['shift']());
        }
    }
}(_0x2031, 0x412bc));

function _0x2031() {
    const _0x3b8dce = ['text/html', '516376xxlXgz', 'parseFromString', '3316160ttTUVe', '158664cuasJg', '249911QOmGcp', '<h1>Hello\x20<strong>World</strong>!!!</h1>', '225060jTHBml', '12NKdYcD', 'log', 'body', '9FoSShX', '2205375OWXAMQ', '5310950RkYAkm', '4uBZFrp', 'textContent'];
    _0x2031 = function() {
        return _0x3b8dce;
    };
    return _0x2031();
}

function _0x2c06(_0x3d2fcf, _0x495489) {
    const _0x203149 = _0x2031();
    return _0x2c06 = function(_0x2c0660, _0x38b006) {
        _0x2c0660 = _0x2c0660 - 0x145;
        let _0x7ac1c4 = _0x203149[_0x2c0660];
        return _0x7ac1c4;
    }, _0x2c06(_0x3d2fcf, _0x495489);
}
const stripHtml = _0x33239e => new DOMParser()[_0x1e4682(0x14a)](_0x33239e, _0x1e4682(0x148))[_0x1e4682(0x152)][_0x1e4682(0x147)] || '';
console[_0x1e4682(0x151)](stripHtml(_0x1e4682(0x14e)));