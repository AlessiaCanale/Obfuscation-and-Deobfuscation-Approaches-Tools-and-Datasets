/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x4a4a() {
    const _0x34a6bd = ['9872135bIcvNs', '564268uIsfyd', '6fErNof', 'none', '27305844BTlSfK', '16vYVdTr', 'display', '14pTJTvV', '3307527oylWXP', '76241vssGob', 'style', 'block', '193329HOwUsW', '60gToVfa', '649434RCwKtO', '10dobVlV'];
    _0x4a4a = function() {
        return _0x34a6bd;
    };
    return _0x4a4a();
}
const _0x32356e = _0x45af;
(function(_0x5d6a94, _0x1e2b5a) {
    const _0x5e6fb8 = _0x45af,
        _0x5b19c7 = _0x5d6a94();
    while (!![]) {
        try {
            const _0x19bfe6 = -parseInt(_0x5e6fb8(0x199)) / 0x1 + -parseInt(_0x5e6fb8(0x192)) / 0x2 * (parseInt(_0x5e6fb8(0x197)) / 0x3) + -parseInt(_0x5e6fb8(0x19c)) / 0x4 * (-parseInt(_0x5e6fb8(0x19a)) / 0x5) + parseInt(_0x5e6fb8(0x18d)) / 0x6 * (-parseInt(_0x5e6fb8(0x19b)) / 0x7) + -parseInt(_0x5e6fb8(0x190)) / 0x8 * (-parseInt(_0x5e6fb8(0x193)) / 0x9) + parseInt(_0x5e6fb8(0x198)) / 0xa * (-parseInt(_0x5e6fb8(0x194)) / 0xb) + parseInt(_0x5e6fb8(0x18f)) / 0xc;
            if (_0x19bfe6 === _0x1e2b5a) break;
            else _0x5b19c7['push'](_0x5b19c7['shift']());
        } catch (_0x6ad884) {
            _0x5b19c7['push'](_0x5b19c7['shift']());
        }
    }
}(_0x4a4a, 0xb4b69));
const toggleElementDisplay = _0x41b45d => _0x41b45d[_0x32356e(0x195)][_0x32356e(0x191)] = _0x41b45d[_0x32356e(0x195)]['display'] === _0x32356e(0x18e) ? _0x32356e(0x196) : _0x32356e(0x18e);

function _0x45af(_0x3aead2, _0x592bf0) {
    const _0x4a4a5c = _0x4a4a();
    return _0x45af = function(_0x45aff2, _0x405db6) {
        _0x45aff2 = _0x45aff2 - 0x18d;
        let _0x597931 = _0x4a4a5c[_0x45aff2];
        return _0x597931;
    }, _0x45af(_0x3aead2, _0x592bf0);
}
toggleElementDisplay(document['body']);