/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x1e9905 = _0xae15;
(function(_0xf3aa46, _0x55b3d0) {
    const _0x3dd1fb = _0xae15,
        _0x48ef7d = _0xf3aa46();
    while (!![]) {
        try {
            const _0x1f8e03 = -parseInt(_0x3dd1fb(0xe0)) / 0x1 + -parseInt(_0x3dd1fb(0xe7)) / 0x2 * (-parseInt(_0x3dd1fb(0xe3)) / 0x3) + parseInt(_0x3dd1fb(0xe1)) / 0x4 * (parseInt(_0x3dd1fb(0xdd)) / 0x5) + parseInt(_0x3dd1fb(0xe6)) / 0x6 + parseInt(_0x3dd1fb(0xde)) / 0x7 * (-parseInt(_0x3dd1fb(0xe9)) / 0x8) + parseInt(_0x3dd1fb(0xe4)) / 0x9 + -parseInt(_0x3dd1fb(0xe5)) / 0xa * (parseInt(_0x3dd1fb(0xe2)) / 0xb);
            if (_0x1f8e03 === _0x55b3d0) break;
            else _0x48ef7d['push'](_0x48ef7d['shift']());
        } catch (_0x3ab845) {
            _0x48ef7d['push'](_0x48ef7d['shift']());
        }
    }
}(_0x2fc1, 0xec02a));
let word = _0x1e9905(0xdc);

function TransformWordInArray(_0x35f7c7) {
    const _0x18155f = _0x1e9905,
        _0xfd0ccb = _0x35f7c7[_0x18155f(0xe8)]('');
    return _0xfd0ccb;
}

function _0x2fc1() {
    const _0x4c0d9e = ['3659796csSWlu', '24ABnRFP', 'split', '42536wzysiO', '\x0aresult\x20array:\x20', 'Hello\x20World!', '625IXZXQi', '952mOUwZm', 'log', '1370051MTQZZG', '54128XnzJGd', '7117rySZaW', '344643SCjtie', '6757344FoIwNL', '21190xnLUCk'];
    _0x2fc1 = function() {
        return _0x4c0d9e;
    };
    return _0x2fc1();
}

function _0xae15(_0x7f0296, _0x4717d4) {
    const _0x2fc15b = _0x2fc1();
    return _0xae15 = function(_0xae159b, _0x20f08c) {
        _0xae159b = _0xae159b - 0xdb;
        let _0x332d8b = _0x2fc15b[_0xae159b];
        return _0x332d8b;
    }, _0xae15(_0x7f0296, _0x4717d4);
}
console[_0x1e9905(0xdf)]('word:\x20' + word + _0x1e9905(0xdb) + TransformWordInArray(word));