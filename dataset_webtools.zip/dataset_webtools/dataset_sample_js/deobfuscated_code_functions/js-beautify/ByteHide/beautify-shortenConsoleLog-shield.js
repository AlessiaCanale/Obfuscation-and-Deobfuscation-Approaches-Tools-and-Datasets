/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x24aa(_0x5d8711, _0x5a37f9) {
    const _0x298016 = _0x2980();
    return _0x24aa = function(_0x24aaca, _0x4b967d) {
        _0x24aaca = _0x24aaca - 0x9b;
        let _0x14d791 = _0x298016[_0x24aaca];
        return _0x14d791;
    }, _0x24aa(_0x5d8711, _0x5a37f9);
}

function _0x2980() {
    const _0x51e396 = ['1379756FBpmzW', '704117qYTasb', '65IoSAuv', '18iuBOCB', '132ZKDyCP', '2086308YjAGRD', '1409180EDFdus', 'yes', '16CElAOT', '684972oTMaLc', 'bind', '281810exRulH', '117372lfVqeb'];
    _0x2980 = function() {
        return _0x51e396;
    };
    return _0x2980();
}
const _0x1e097e = _0x24aa;
(function(_0x4d0bbc, _0x297af9) {
    const _0x1cff7c = _0x24aa,
        _0x55d6d7 = _0x4d0bbc();
    while (!![]) {
        try {
            const _0x3f768b = parseInt(_0x1cff7c(0xa6)) / 0x1 + -parseInt(_0x1cff7c(0x9e)) / 0x2 + -parseInt(_0x1cff7c(0xa1)) / 0x3 + -parseInt(_0x1cff7c(0xa4)) / 0x4 * (-parseInt(_0x1cff7c(0xa7)) / 0x5) + -parseInt(_0x1cff7c(0x9b)) / 0x6 * (parseInt(_0x1cff7c(0xa5)) / 0x7) + parseInt(_0x1cff7c(0xa0)) / 0x8 * (parseInt(_0x1cff7c(0x9d)) / 0x9) + -parseInt(_0x1cff7c(0xa3)) / 0xa * (-parseInt(_0x1cff7c(0x9c)) / 0xb);
            if (_0x3f768b === _0x297af9) break;
            else _0x55d6d7['push'](_0x55d6d7['shift']());
        } catch (_0x21eb28) {
            _0x55d6d7['push'](_0x55d6d7['shift']());
        }
    }
}(_0x2980, 0x58a7e));
const log = console['log'][_0x1e097e(0xa2)]();
log('does\x20it\x20work?'), log(_0x1e097e(0x9f)), log(0x5);