/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x5ba2(_0x3a4282, _0x544113) {
    const _0x4499ac = _0x4499();
    return _0x5ba2 = function(_0x5ba211, _0x2998ed) {
        _0x5ba211 = _0x5ba211 - 0x106;
        let _0x271efa = _0x4499ac[_0x5ba211];
        return _0x271efa;
    }, _0x5ba2(_0x3a4282, _0x544113);
}

function _0x4499() {
    const _0x44cfa3 = ['65oqCCul', 'All\x20the\x20entries\x20have\x20a\x20valid\x20id', '4178421hKWXpz', '3850616HsFuQU', '1424rVZPEF', '44408CaiIyE', 'no\x20all\x20entries\x20have\x20a\x20valid\x20id', '3HZQOhh', 'every', '6910tGEizG', '1430934KYgBCp', '174710BOnUyH', '319qlYAdc', '576MJrYGt', '1eZiKcF', 'log', '3813588TXDafl', 'isInteger'];
    _0x4499 = function() {
        return _0x44cfa3;
    };
    return _0x4499();
}
const _0x10fa28 = _0x5ba2;
(function(_0x115794, _0x19e26d) {
    const _0x4a2b00 = _0x5ba2,
        _0x4f79d1 = _0x115794();
    while (!![]) {
        try {
            const _0x2d6431 = -parseInt(_0x4a2b00(0x10a)) / 0x1 * (parseInt(_0x4a2b00(0x106)) / 0x2) + -parseInt(_0x4a2b00(0x115)) / 0x3 * (-parseInt(_0x4a2b00(0x111)) / 0x4) + parseInt(_0x4a2b00(0x117)) / 0x5 * (-parseInt(_0x4a2b00(0x109)) / 0x6) + -parseInt(_0x4a2b00(0x113)) / 0x7 * (parseInt(_0x4a2b00(0x112)) / 0x8) + -parseInt(_0x4a2b00(0x110)) / 0x9 + -parseInt(_0x4a2b00(0x107)) / 0xa * (-parseInt(_0x4a2b00(0x108)) / 0xb) + -parseInt(_0x4a2b00(0x10c)) / 0xc * (-parseInt(_0x4a2b00(0x10e)) / 0xd);
            if (_0x2d6431 === _0x19e26d) break;
            else _0x4f79d1['push'](_0x4f79d1['shift']());
        } catch (_0x3280b7) {
            _0x4f79d1['push'](_0x4f79d1['shift']());
        }
    }
}(_0x4499, 0x968dc));
const entries = [{
    'id': 0x1
}, {
    'id': 0x2
}, {
    'id': 0x3
}];
entries[_0x10fa28(0x116)](_0x7a18f3 => {
    const _0x58f2ea = _0x10fa28;
    return Number[_0x58f2ea(0x10d)](_0x7a18f3['id']) && _0x7a18f3['id'] > 0x0;
}) ? console[_0x10fa28(0x10b)](_0x10fa28(0x10f)) : console['log'](_0x10fa28(0x114));