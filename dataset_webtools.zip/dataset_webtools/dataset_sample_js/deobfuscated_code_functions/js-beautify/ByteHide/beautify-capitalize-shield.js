/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x1e0358 = _0x57bc;

function _0x57bc(_0x1da46e, _0x5374e0) {
    const _0x575129 = _0x5751();
    return _0x57bc = function(_0x57bc35, _0x32a712) {
        _0x57bc35 = _0x57bc35 - 0x107;
        let _0x6c9b93 = _0x575129[_0x57bc35];
        return _0x6c9b93;
    }, _0x57bc(_0x1da46e, _0x5374e0);
}

function _0x5751() {
    const _0x5eb952 = ['i\x20hope\x20you\x20like\x20my\x20article.', 'toUpperCase', 'slice', '8120405eLTjOX', '9907638NcmwIQ', '620984nxlSdu', 'log', '686106SeXhGV', '90btcPgL', '4NahzxD', '6310168OMUCcY', '2324egoNpf', '129htHGVA', '674928ddoKsw', 'charAt'];
    _0x5751 = function() {
        return _0x5eb952;
    };
    return _0x5751();
}(function(_0x127d0e, _0x36e415) {
    const _0x3edc20 = _0x57bc,
        _0x1c073d = _0x127d0e();
    while (!![]) {
        try {
            const _0x356762 = parseInt(_0x3edc20(0x10e)) / 0x1 + -parseInt(_0x3edc20(0x10c)) / 0x2 * (-parseInt(_0x3edc20(0x10d)) / 0x3) + parseInt(_0x3edc20(0x10a)) / 0x4 * (parseInt(_0x3edc20(0x113)) / 0x5) + -parseInt(_0x3edc20(0x114)) / 0x6 + parseInt(_0x3edc20(0x115)) / 0x7 + parseInt(_0x3edc20(0x10b)) / 0x8 + -parseInt(_0x3edc20(0x108)) / 0x9 * (parseInt(_0x3edc20(0x109)) / 0xa);
            if (_0x356762 === _0x36e415) break;
            else _0x1c073d['push'](_0x1c073d['shift']());
        } catch (_0x4ffafb) {
            _0x1c073d['push'](_0x1c073d['shift']());
        }
    }
}(_0x5751, 0xd90f7));
const capitalize = _0x29429f => _0x29429f[_0x1e0358(0x10f)](0x0)[_0x1e0358(0x111)]() + _0x29429f[_0x1e0358(0x112)](0x1);
console[_0x1e0358(0x107)](capitalize(_0x1e0358(0x110)));