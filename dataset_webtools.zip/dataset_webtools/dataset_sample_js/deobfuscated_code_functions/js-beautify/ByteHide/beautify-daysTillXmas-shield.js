/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x30cf(_0x3f9b85, _0x2441f5) {
    var _0x4d53df = _0x4d53();
    return _0x30cf = function(_0x30cfc5, _0x5f13d9) {
        _0x30cfc5 = _0x30cfc5 - 0x9f;
        var _0x1b3c16 = _0x4d53df[_0x30cfc5];
        return _0x1b3c16;
    }, _0x30cf(_0x3f9b85, _0x2441f5);
}
var _0x4f746b = _0x30cf;
(function(_0x497908, _0x59806d) {
    var _0x221b9a = _0x30cf,
        _0x73dbee = _0x497908();
    while (!![]) {
        try {
            var _0x531357 = -parseInt(_0x221b9a(0xa5)) / 0x1 * (-parseInt(_0x221b9a(0xae)) / 0x2) + -parseInt(_0x221b9a(0xa8)) / 0x3 * (parseInt(_0x221b9a(0xa1)) / 0x4) + -parseInt(_0x221b9a(0xac)) / 0x5 * (parseInt(_0x221b9a(0xa6)) / 0x6) + parseInt(_0x221b9a(0xad)) / 0x7 * (parseInt(_0x221b9a(0xa7)) / 0x8) + -parseInt(_0x221b9a(0xb0)) / 0x9 * (-parseInt(_0x221b9a(0xa2)) / 0xa) + -parseInt(_0x221b9a(0xa0)) / 0xb + parseInt(_0x221b9a(0xa9)) / 0xc * (parseInt(_0x221b9a(0xa3)) / 0xd);
            if (_0x531357 === _0x59806d) break;
            else _0x73dbee['push'](_0x73dbee['shift']());
        } catch (_0x58d37e) {
            _0x73dbee['push'](_0x73dbee['shift']());
        }
    }
}(_0x4d53, 0x678aa), today = new Date(), xmas = new Date('December\x2025,\x202024'), msPerDay = 0x18 * 0x3c * 0x3c * 0x3e8, timeLeft = xmas['getTime']() - today[_0x4f746b(0x9f)](), console[_0x4f746b(0xaf)]('time\x20left\x20till\x20christmas:\x20' + timeLeft), e_daysLeft = timeLeft / msPerDay, daysLeft = Math[_0x4f746b(0xaa)](e_daysLeft), e_hrsLeft = (e_daysLeft - daysLeft) * 0x18, hrsLeft = Math[_0x4f746b(0xaa)](e_hrsLeft), minsLeft = Math[_0x4f746b(0xaa)]((e_hrsLeft - hrsLeft) * 0x3c), console['log'](_0x4f746b(0xab) + daysLeft + _0x4f746b(0xa4) + hrsLeft + '\x20hours\x20and\x20' + minsLeft + '\x20minutes\x20left\x20Until\x20December\x2025th\x202024'));

function _0x4d53() {
    var _0x17e07c = ['307fCjjJf', '42NGDsgj', '8YGmHTe', '2401671bMjjPd', '56556wcHgLv', 'floor', 'There\x20are\x20only:\x20', '295595plCosS', '5489477kOhMFa', '5086safFeV', 'log', '2412IOlesM', 'getTime', '3002813leswLJ', '4WOhyiD', '7480CezEuR', '403WElBSd', '\x20days\x20'];
    _0x4d53 = function() {
        return _0x17e07c;
    };
    return _0x4d53();
}