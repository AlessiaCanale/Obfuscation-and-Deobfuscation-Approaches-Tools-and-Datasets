/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x5312(_0x2a476e, _0x2c1a2d) {
    const _0x2c2241 = _0x2c22();
    return _0x5312 = function(_0x5312cc, _0x4c69b6) {
        _0x5312cc = _0x5312cc - 0x6e;
        let _0x1e8529 = _0x2c2241[_0x5312cc];
        return _0x1e8529;
    }, _0x5312(_0x2a476e, _0x2c1a2d);
}

function _0x2c22() {
    const _0x498734 = ['2570384ojbxNa', 'cheese', 'log', '2vJHXIA', 'bread', '1127010HdfjlD', 'spliced\x20at\x20index\x202:\x20', 'original:\x20', '664330qTUMIx', 'splice', '153937NPjlSJ', 'milk', '16395759ANZiaj', '464YuJEQJ', 'butter', '466956kUNhzI', '2060859AgPShq'];
    _0x2c22 = function() {
        return _0x498734;
    };
    return _0x2c22();
}
const _0x45a3b5 = _0x5312;
(function(_0x150435, _0x473b50) {
    const _0x44e471 = _0x5312,
        _0x4ed670 = _0x150435();
    while (!![]) {
        try {
            const _0x20a32c = parseInt(_0x44e471(0x72)) / 0x1 + parseInt(_0x44e471(0x70)) / 0x2 * (-parseInt(_0x44e471(0x7d)) / 0x3) + parseInt(_0x44e471(0x7e)) / 0x4 + parseInt(_0x44e471(0x75)) / 0x5 + parseInt(_0x44e471(0x7c)) / 0x6 + -parseInt(_0x44e471(0x77)) / 0x7 * (-parseInt(_0x44e471(0x7a)) / 0x8) + -parseInt(_0x44e471(0x79)) / 0x9;
            if (_0x20a32c === _0x473b50) break;
            else _0x4ed670['push'](_0x4ed670['shift']());
        } catch (_0x143fa7) {
            _0x4ed670['push'](_0x4ed670['shift']());
        }
    }
}(_0x2c22, 0xb6640));
const items = ['eggs', _0x45a3b5(0x78), _0x45a3b5(0x6e), _0x45a3b5(0x71), _0x45a3b5(0x7b)];
console['log'](_0x45a3b5(0x74) + items), items[_0x45a3b5(0x76)](0x2, 0x1), console[_0x45a3b5(0x6f)](_0x45a3b5(0x73) + items);