/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x55d823 = _0xabb0;
(function(_0x4e17e3, _0x1afec4) {
    const _0x11ebf5 = _0xabb0,
        _0x1992d2 = _0x4e17e3();
    while (!![]) {
        try {
            const _0x267334 = parseInt(_0x11ebf5(0xdc)) / 0x1 + parseInt(_0x11ebf5(0xda)) / 0x2 + -parseInt(_0x11ebf5(0xdd)) / 0x3 * (-parseInt(_0x11ebf5(0xe3)) / 0x4) + -parseInt(_0x11ebf5(0xe5)) / 0x5 + parseInt(_0x11ebf5(0xe4)) / 0x6 * (-parseInt(_0x11ebf5(0xdf)) / 0x7) + -parseInt(_0x11ebf5(0xe2)) / 0x8 * (-parseInt(_0x11ebf5(0xde)) / 0x9) + parseInt(_0x11ebf5(0xe1)) / 0xa;
            if (_0x267334 === _0x1afec4) break;
            else _0x1992d2['push'](_0x1992d2['shift']());
        } catch (_0x31559d) {
            _0x1992d2['push'](_0x1992d2['shift']());
        }
    }
}(_0x2937, 0x1f1d2));
const dayOfYear = _0x46e0e6 => Math[_0x55d823(0xe0)]((_0x46e0e6 - new Date(_0x46e0e6[_0x55d823(0xdb)](), 0x0, 0x0)) / 0x3e8 / 0x3c / 0x3c / 0x18);

function _0xabb0(_0xe6afa6, _0x2314d3) {
    const _0x2937a4 = _0x2937();
    return _0xabb0 = function(_0xabb0a6, _0x9b1522) {
        _0xabb0a6 = _0xabb0a6 - 0xda;
        let _0x3dc00a = _0x2937a4[_0xabb0a6];
        return _0x3dc00a;
    }, _0xabb0(_0xe6afa6, _0x2314d3);
}

function _0x2937() {
    const _0x3fcdb7 = ['186490YcAnOB', '20912wLQpxp', '692gqyBXF', '999978cCUrQM', '787565kvCZZM', 'log', '101506MsJavZ', 'getFullYear', '223518ZbNVUH', '2616zjVsrS', '27epHfPF', '7WtviVO', 'floor'];
    _0x2937 = function() {
        return _0x3fcdb7;
    };
    return _0x2937();
}
console[_0x55d823(0xe6)](dayOfYear(new Date()));