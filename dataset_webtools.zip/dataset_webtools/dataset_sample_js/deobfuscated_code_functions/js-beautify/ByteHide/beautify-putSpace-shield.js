/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x5e4885 = _0x345a;
(function(_0x447baa, _0xa64760) {
    const _0x1eae13 = _0x345a,
        _0x31ff4a = _0x447baa();
    while (!![]) {
        try {
            const _0x1b5f39 = -parseInt(_0x1eae13(0x97)) / 0x1 * (-parseInt(_0x1eae13(0x8e)) / 0x2) + -parseInt(_0x1eae13(0x9d)) / 0x3 * (parseInt(_0x1eae13(0x98)) / 0x4) + -parseInt(_0x1eae13(0x94)) / 0x5 * (parseInt(_0x1eae13(0x90)) / 0x6) + -parseInt(_0x1eae13(0x92)) / 0x7 * (parseInt(_0x1eae13(0x9a)) / 0x8) + parseInt(_0x1eae13(0x9b)) / 0x9 + -parseInt(_0x1eae13(0x9f)) / 0xa + parseInt(_0x1eae13(0x8f)) / 0xb * (-parseInt(_0x1eae13(0x96)) / 0xc);
            if (_0x1b5f39 === _0xa64760) break;
            else _0x31ff4a['push'](_0x31ff4a['shift']());
        } catch (_0x43435a) {
            _0x31ff4a['push'](_0x31ff4a['shift']());
        }
    }
}(_0x5015, 0xe1bd1));

function _0x345a(_0x1d0d8a, _0x2ed59c) {
    const _0x50156d = _0x5015();
    return _0x345a = function(_0x345a6d, _0x39a1dd) {
        _0x345a6d = _0x345a6d - 0x8e;
        let _0x3ef3f9 = _0x50156d[_0x345a6d];
        return _0x3ef3f9;
    }, _0x345a(_0x1d0d8a, _0x2ed59c);
}

function PutSpace(_0x2ea6a7) {
    const _0x20240a = _0x345a;
    let _0x48a712 = _0x2ea6a7[_0x20240a(0x9e)](/([A-Z])/g, _0x20240a(0x93));
    _0x48a712 = _0x48a712[_0x20240a(0x95)](), console[_0x20240a(0x91)](_0x20240a(0x99) + _0x2ea6a7), console[_0x20240a(0x91)]('\x0a\x20result:\x20' + _0x48a712);
}
let str1 = _0x5e4885(0x9c);

function _0x5015() {
    const _0x1396dc = ['toLowerCase', '2821476VnDPJb', '4786WviBhH', '8mSbjek', 'original:\x20', '760296vwNLSE', '13530915rUZqaW', 'GEEKS@#$786$^geeksTreeOfLife', '898113Amrash', 'replace', '7083930KiXBIZ', '764sopRfs', '11PZmxRy', '1539534ocNfRl', 'log', '7LLLKpK', '\x20$&', '15NzPDrb'];
    _0x5015 = function() {
        return _0x1396dc;
    };
    return _0x5015();
}
PutSpace(str1);