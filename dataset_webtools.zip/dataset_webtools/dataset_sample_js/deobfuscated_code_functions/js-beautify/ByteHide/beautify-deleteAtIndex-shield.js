/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x101d1b = _0x4de0;

function _0x4de0(_0x3c70a0, _0x2e02c8) {
    const _0x4f59d9 = _0x4f59();
    return _0x4de0 = function(_0x4de076, _0x245a56) {
        _0x4de076 = _0x4de076 - 0x179;
        let _0x40c1c3 = _0x4f59d9[_0x4de076];
        return _0x40c1c3;
    }, _0x4de0(_0x3c70a0, _0x2e02c8);
}(function(_0x4c847a, _0x233c31) {
    const _0x469fc7 = _0x4de0,
        _0x218b87 = _0x4c847a();
    while (!![]) {
        try {
            const _0x4275de = parseInt(_0x469fc7(0x182)) / 0x1 * (-parseInt(_0x469fc7(0x188)) / 0x2) + -parseInt(_0x469fc7(0x186)) / 0x3 * (parseInt(_0x469fc7(0x184)) / 0x4) + -parseInt(_0x469fc7(0x17c)) / 0x5 + -parseInt(_0x469fc7(0x179)) / 0x6 * (-parseInt(_0x469fc7(0x187)) / 0x7) + parseInt(_0x469fc7(0x17f)) / 0x8 + -parseInt(_0x469fc7(0x17e)) / 0x9 + parseInt(_0x469fc7(0x185)) / 0xa;
            if (_0x4275de === _0x233c31) break;
            else _0x218b87['push'](_0x218b87['shift']());
        } catch (_0x49a05b) {
            _0x218b87['push'](_0x218b87['shift']());
        }
    }
}(_0x4f59, 0xc34c2));
let array = [_0x101d1b(0x183), _0x101d1b(0x17d), _0x101d1b(0x17a), 'reset'];

function _0x4f59() {
    const _0x3efb30 = ['3238880bijJis', 'remove', '12661659hugvpa', '10512280dKMaKe', 'Remaining\x20elements:\x20', 'original:\x20', '6DKOHaY', 'lowdash', '8932OazTnh', '27989670yEBfCC', '1395siSnql', '450982WQaKMb', '395494LbiHHO', '90NcRuVo', 'delete', 'log'];
    _0x4f59 = function() {
        return _0x3efb30;
    };
    return _0x4f59();
}
console[_0x101d1b(0x17b)](_0x101d1b(0x181), array);
let deleted = delete array[0x2];
console[_0x101d1b(0x17b)]('Removed:\x20' + deleted), console[_0x101d1b(0x17b)](_0x101d1b(0x180) + array);