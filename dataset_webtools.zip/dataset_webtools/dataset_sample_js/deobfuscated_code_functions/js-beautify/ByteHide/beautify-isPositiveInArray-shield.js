/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x46bc5d = _0x101f;
(function(_0x3e6588, _0x2b6f46) {
    const _0x42c040 = _0x101f,
        _0x4101e5 = _0x3e6588();
    while (!![]) {
        try {
            const _0x1b531c = -parseInt(_0x42c040(0x168)) / 0x1 + -parseInt(_0x42c040(0x15d)) / 0x2 * (parseInt(_0x42c040(0x15f)) / 0x3) + parseInt(_0x42c040(0x161)) / 0x4 * (parseInt(_0x42c040(0x162)) / 0x5) + parseInt(_0x42c040(0x15e)) / 0x6 * (parseInt(_0x42c040(0x166)) / 0x7) + -parseInt(_0x42c040(0x164)) / 0x8 + parseInt(_0x42c040(0x165)) / 0x9 + -parseInt(_0x42c040(0x160)) / 0xa;
            if (_0x1b531c === _0x2b6f46) break;
            else _0x4101e5['push'](_0x4101e5['shift']());
        } catch (_0x20e1cc) {
            _0x4101e5['push'](_0x4101e5['shift']());
        }
    }
}(_0x34e3, 0xc7cca));

function _0x34e3() {
    const _0x13a0d8 = ['Positive\x20elements\x20in\x20array:\x20', '2cyqizh', '414822owJvsJ', '1481439eiWfLs', '6364130fWghJs', '482268mSGHfN', '55poyDsL', 'filter', '8642224PpZrhP', '5841675BAinrY', '133CNhSbK', 'log', '260033BWWmEr'];
    _0x34e3 = function() {
        return _0x13a0d8;
    };
    return _0x34e3();
}

function _0x101f(_0x1ea4ed, _0x44f7fb) {
    const _0x34e397 = _0x34e3();
    return _0x101f = function(_0x101f5d, _0x1d9d6e) {
        _0x101f5d = _0x101f5d - 0x15d;
        let _0x4e9874 = _0x34e397[_0x101f5d];
        return _0x4e9874;
    }, _0x101f(_0x1ea4ed, _0x44f7fb);
}

function isPositive(_0x380b05) {
    return _0x380b05 > 0x0;
}

function func() {
    const _0x1aa4b5 = _0x101f;
    let _0x4645e9 = [0x65, 0x62, 0xc, -0x1, 0x350][_0x1aa4b5(0x163)](isPositive);
    console[_0x1aa4b5(0x167)](_0x1aa4b5(0x169) + _0x4645e9);
}
console[_0x46bc5d(0x167)]('[101,\x2098,\x2012,\x20-1,\x20848]'), func();