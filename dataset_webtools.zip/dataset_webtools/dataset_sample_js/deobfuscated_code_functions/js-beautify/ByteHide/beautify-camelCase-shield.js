/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

(function(_0x366042, _0x362e07) {
    const _0x4b6bfd = _0x5f33,
        _0x200546 = _0x366042();
    while (!![]) {
        try {
            const _0x568ab2 = parseInt(_0x4b6bfd(0x100)) / 0x1 + parseInt(_0x4b6bfd(0xf1)) / 0x2 * (parseInt(_0x4b6bfd(0xf6)) / 0x3) + -parseInt(_0x4b6bfd(0xfa)) / 0x4 + parseInt(_0x4b6bfd(0xff)) / 0x5 * (-parseInt(_0x4b6bfd(0xf7)) / 0x6) + -parseInt(_0x4b6bfd(0xfe)) / 0x7 * (-parseInt(_0x4b6bfd(0xf5)) / 0x8) + -parseInt(_0x4b6bfd(0xfb)) / 0x9 + parseInt(_0x4b6bfd(0xf4)) / 0xa;
            if (_0x568ab2 === _0x362e07) break;
            else _0x200546['push'](_0x200546['shift']());
        } catch (_0x5d719a) {
            _0x200546['push'](_0x200546['shift']());
        }
    }
}(_0x5d2c, 0xb1c34));
let str = 'Click\x20the\x20button\x20to\x20convert\x20to\x20camelCase';

function camelCase(_0x4f405e) {
    const _0x1a8180 = _0x5f33;
    return _0x4f405e['replace'](/(?:^\w|[A-Z]|\b\w)/g, function(_0x512a5e, _0x19ecea) {
        const _0x2c0bf1 = _0x5f33;
        return _0x19ecea == 0x0 ? _0x512a5e[_0x2c0bf1(0xf9)]() : _0x512a5e[_0x2c0bf1(0xfc)]();
    })[_0x1a8180(0xf3)](/\s+/g, '');
}

function gfg_Run() {
    const _0x38d35b = _0x5f33;
    console[_0x38d35b(0xf8)](_0x38d35b(0xfd) + str + _0x38d35b(0xf2) + camelCase(str));
}

function _0x5f33(_0x458abb, _0x467e7e) {
    const _0x5d2c52 = _0x5d2c();
    return _0x5f33 = function(_0x5f33b7, _0x6c6d5c) {
        _0x5f33b7 = _0x5f33b7 - 0xf1;
        let _0x254959 = _0x5d2c52[_0x5f33b7];
        return _0x254959;
    }, _0x5f33(_0x458abb, _0x467e7e);
}

function _0x5d2c() {
    const _0x2f95bc = ['14vvasPH', '1154355HBLDXz', '825750hgaikq', '213148Wjhucf', '\x0aresult:\x20', 'replace', '8857790JPadcg', '3405856EwnyNN', '3SCtKoO', '30rkRDnR', 'log', 'toLowerCase', '2134400lckhjw', '2281464GDvqFr', 'toUpperCase', 'original:\x20'];
    _0x5d2c = function() {
        return _0x2f95bc;
    };
    return _0x5d2c();
}
gfg_Run();