/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x3f3c() {
    const _0xda4988 = ['10524mFVpUP', 'function\x20hi()\x20takes:\x20', '6716493saSXaQ', '15805fbEExA', 'performance', '9juUxpD', '\x20milisecond', '2617080RLDJqX', '3581904saQNYV', '201Tkuzyb', 'now', 'log', '3149040ovJbBP', '6oeFrLV', 'perf_hooks', '15681870ARpUnu'];
    _0x3f3c = function() {
        return _0xda4988;
    };
    return _0x3f3c();
}
const _0x22508a = _0x2555;
(function(_0x1d6199, _0x30cf24) {
    const _0x336365 = _0x2555,
        _0x27410d = _0x1d6199();
    while (!![]) {
        try {
            const _0xa2ba97 = parseInt(_0x336365(0x76)) / 0x1 + parseInt(_0x336365(0x7a)) / 0x2 + -parseInt(_0x336365(0x7c)) / 0x3 * (parseInt(_0x336365(0x73)) / 0x4) + -parseInt(_0x336365(0x6f)) / 0x5 + -parseInt(_0x336365(0x70)) / 0x6 * (parseInt(_0x336365(0x75)) / 0x7) + -parseInt(_0x336365(0x7b)) / 0x8 * (parseInt(_0x336365(0x78)) / 0x9) + parseInt(_0x336365(0x72)) / 0xa;
            if (_0xa2ba97 === _0x30cf24) break;
            else _0x27410d['push'](_0x27410d['shift']());
        } catch (_0x392326) {
            _0x27410d['push'](_0x27410d['shift']());
        }
    }
}(_0x3f3c, 0xa5d2a));

function _0x2555(_0x3cb798, _0x44cd8e) {
    const _0x3f3c7 = _0x3f3c();
    return _0x2555 = function(_0x25555b, _0x42b9f2) {
        _0x25555b = _0x25555b - 0x6d;
        let _0x1949eb = _0x3f3c7[_0x25555b];
        return _0x1949eb;
    }, _0x2555(_0x3cb798, _0x44cd8e);
}
const performance = require(_0x22508a(0x71))[_0x22508a(0x77)],
    start = performance[_0x22508a(0x6d)]();

function hi() {
    const _0x609f1b = _0x22508a;
    console[_0x609f1b(0x6e)]('Hello\x20World!');
}
hi();
const end = performance[_0x22508a(0x6d)](),
    total = start - end;
console[_0x22508a(0x6e)](_0x22508a(0x74) + total + _0x22508a(0x79));