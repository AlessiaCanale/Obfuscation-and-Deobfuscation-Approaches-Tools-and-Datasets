/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

(function(_0x2412b4, _0x35a524) {
    var _0x21cc1 = _0xb33e,
        _0x4ea20f = _0x2412b4();
    while (!![]) {
        try {
            var _0x51dbbc = -parseInt(_0x21cc1(0x1ab)) / 0x1 * (parseInt(_0x21cc1(0x1a9)) / 0x2) + -parseInt(_0x21cc1(0x1ad)) / 0x3 * (parseInt(_0x21cc1(0x1ac)) / 0x4) + -parseInt(_0x21cc1(0x1af)) / 0x5 * (parseInt(_0x21cc1(0x1a8)) / 0x6) + parseInt(_0x21cc1(0x1a5)) / 0x7 * (parseInt(_0x21cc1(0x1ae)) / 0x8) + -parseInt(_0x21cc1(0x1a4)) / 0x9 + -parseInt(_0x21cc1(0x1aa)) / 0xa * (parseInt(_0x21cc1(0x1a7)) / 0xb) + parseInt(_0x21cc1(0x1a6)) / 0xc;
            if (_0x51dbbc === _0x35a524) break;
            else _0x4ea20f['push'](_0x4ea20f['shift']());
        } catch (_0x5b01c8) {
            _0x4ea20f['push'](_0x4ea20f['shift']());
        }
    }
}(_0x4a31, 0x66392));

function _0xb33e(_0x2d82c5, _0x11e29f) {
    var _0x4a3119 = _0x4a31();
    return _0xb33e = function(_0xb33e22, _0x423e3d) {
        _0xb33e22 = _0xb33e22 - 0x1a4;
        var _0x215b41 = _0x4a3119[_0xb33e22];
        return _0x215b41;
    }, _0xb33e(_0x2d82c5, _0x11e29f);
}

function hi() {
    var _0x109530 = _0xb33e;
    console[_0x109530(0x1b0)]('Hello\x20World!');
}
hi();

function _0x4a31() {
    var _0x42eec7 = ['log', '2053224tGdHqR', '3094TdyvJv', '13307712niEPzw', '11aSOIUk', '24ccUFST', '2qXZYld', '1076870hGAfqJ', '38557NesdWf', '1385312ZcsDJE', '3OwYOTi', '14696wLutco', '976895QuIwBB'];
    _0x4a31 = function() {
        return _0x42eec7;
    };
    return _0x4a31();
}