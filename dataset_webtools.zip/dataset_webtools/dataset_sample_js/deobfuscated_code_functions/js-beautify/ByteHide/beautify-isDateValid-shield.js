/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x112228 = _0x1a88;
(function(_0x199e39, _0x1eb2c4) {
    const _0x355e3a = _0x1a88,
        _0x43909f = _0x199e39();
    while (!![]) {
        try {
            const _0xde9f00 = -parseInt(_0x355e3a(0x135)) / 0x1 * (parseInt(_0x355e3a(0x139)) / 0x2) + -parseInt(_0x355e3a(0x13d)) / 0x3 + parseInt(_0x355e3a(0x136)) / 0x4 + parseInt(_0x355e3a(0x137)) / 0x5 + parseInt(_0x355e3a(0x13b)) / 0x6 * (parseInt(_0x355e3a(0x138)) / 0x7) + parseInt(_0x355e3a(0x13e)) / 0x8 * (parseInt(_0x355e3a(0x13c)) / 0x9) + parseInt(_0x355e3a(0x141)) / 0xa;
            if (_0xde9f00 === _0x1eb2c4) break;
            else _0x43909f['push'](_0x43909f['shift']());
        } catch (_0x20043a) {
            _0x43909f['push'](_0x43909f['shift']());
        }
    }
}(_0x4388, 0x688e7));
const isDateValid = (..._0x3797fd) => !Number[_0x112228(0x13f)](new Date(..._0x3797fd)[_0x112228(0x140)]());
console[_0x112228(0x142)](isDateValid(_0x112228(0x13a)));

function _0x1a88(_0x38ac3b, _0x4cee55) {
    const _0x43882e = _0x4388();
    return _0x1a88 = function(_0x1a88f0, _0x16b269) {
        _0x1a88f0 = _0x1a88f0 - 0x135;
        let _0x2fddc5 = _0x43882e[_0x1a88f0];
        return _0x2fddc5;
    }, _0x1a88(_0x38ac3b, _0x4cee55);
}

function _0x4388() {
    const _0x8c3c2a = ['6433870SBvoyW', 'log', '39451FEaxLo', '1930452CLsMoR', '1215320CzNjjQ', '2191sOhYgG', '34eSrUdW', 'December\x2017,\x201995\x2003:24:00', '2166eHFsqT', '4224672uHyvgT', '2557605RStzyl', '8iDnZLU', 'isNaN', 'valueOf'];
    _0x4388 = function() {
        return _0x8c3c2a;
    };
    return _0x4388();
}