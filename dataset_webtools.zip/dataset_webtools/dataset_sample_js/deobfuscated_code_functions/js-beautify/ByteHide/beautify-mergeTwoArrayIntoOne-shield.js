/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x3b5cb5 = _0xf89d;

function _0x256b() {
    const _0x289eb9 = ['1255694qZeTis', 'Two', 'One', '1208697qPLuTo', '4oAYNal', '6JzEJqi', '24MrAHJb', 'Five', 'log', '6823725ScUbmy', '18357416SCgjoa', '14589690XArlBx', '3102218lGFeKs', '5353584tayjpd', 'Six', 'Three', 'Four', '2qcqpee', '9EFbkyB', 'concat'];
    _0x256b = function() {
        return _0x289eb9;
    };
    return _0x256b();
}(function(_0x1c3011, _0x4a5d72) {
    const _0x12c767 = _0xf89d,
        _0xa6c97a = _0x1c3011();
    while (!![]) {
        try {
            const _0x3d855d = -parseInt(_0x12c767(0xc6)) / 0x1 * (parseInt(_0x12c767(0xc3)) / 0x2) + parseInt(_0x12c767(0xc9)) / 0x3 + parseInt(_0x12c767(0xca)) / 0x4 * (-parseInt(_0x12c767(0xcf)) / 0x5) + -parseInt(_0x12c767(0xcb)) / 0x6 * (-parseInt(_0x12c767(0xd2)) / 0x7) + parseInt(_0x12c767(0xd3)) / 0x8 + -parseInt(_0x12c767(0xc4)) / 0x9 * (parseInt(_0x12c767(0xd1)) / 0xa) + parseInt(_0x12c767(0xd0)) / 0xb * (parseInt(_0x12c767(0xcc)) / 0xc);
            if (_0x3d855d === _0x4a5d72) break;
            else _0xa6c97a['push'](_0xa6c97a['shift']());
        } catch (_0x58899f) {
            _0xa6c97a['push'](_0xa6c97a['shift']());
        }
    }
}(_0x256b, 0xbcdc7));
const array1 = [_0x3b5cb5(0xc8), _0x3b5cb5(0xc7), _0x3b5cb5(0xd5)],
    array2 = [_0x3b5cb5(0xd6), _0x3b5cb5(0xcd), _0x3b5cb5(0xd4)],
    merged = array1[_0x3b5cb5(0xc5)](array2);

function _0xf89d(_0x15738f, _0x4ddcbd) {
    const _0x256b0c = _0x256b();
    return _0xf89d = function(_0xf89dcf, _0x146eda) {
        _0xf89dcf = _0xf89dcf - 0xc3;
        let _0x143fbc = _0x256b0c[_0xf89dcf];
        return _0x143fbc;
    }, _0xf89d(_0x15738f, _0x4ddcbd);
}
console[_0x3b5cb5(0xce)](merged);