/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

var _0x3de555 = _0xa4c0;
(function(_0x213742, _0x2c4093) {
    var _0x2f7f9f = _0xa4c0,
        _0x592c48 = _0x213742();
    while (!![]) {
        try {
            var _0x395b12 = -parseInt(_0x2f7f9f(0x17b)) / 0x1 + parseInt(_0x2f7f9f(0x177)) / 0x2 * (-parseInt(_0x2f7f9f(0x17f)) / 0x3) + -parseInt(_0x2f7f9f(0x175)) / 0x4 * (parseInt(_0x2f7f9f(0x17d)) / 0x5) + parseInt(_0x2f7f9f(0x172)) / 0x6 + -parseInt(_0x2f7f9f(0x171)) / 0x7 * (-parseInt(_0x2f7f9f(0x173)) / 0x8) + -parseInt(_0x2f7f9f(0x17e)) / 0x9 + parseInt(_0x2f7f9f(0x181)) / 0xa;
            if (_0x395b12 === _0x2c4093) break;
            else _0x592c48['push'](_0x592c48['shift']());
        } catch (_0x1e38fd) {
            _0x592c48['push'](_0x592c48['shift']());
        }
    }
}(_0x22a6, 0x6a977));
var arr = [_0x3de555(0x174), _0x3de555(0x176), _0x3de555(0x17c), _0x3de555(0x17a), _0x3de555(0x178)],
    sumOddWords = 0x0,
    i = 0x0;

function _0x22a6() {
    var _0x218ae0 = ['length', '632874Odeszj', 'sumOddWords', '179405hhkePI', '2257425wVsyaF', '9wvhpyW', 'log', '14764300aWtDRF', ',\x20length:\x20', '1507961gQuSed', '2978226XHpNvU', '24yFXnlM', 'word', '84VxwhDt', 'array', '363514hfHyay', 'programming', 'sum\x20odd\x20words:\x20'];
    _0x22a6 = function() {
        return _0x218ae0;
    };
    return _0x22a6();
}

function _0xa4c0(_0x47dc48, _0x1c2a71) {
    var _0x22a6cc = _0x22a6();
    return _0xa4c0 = function(_0xa4c01, _0x2c68d6) {
        _0xa4c01 = _0xa4c01 - 0x171;
        var _0x1e1eb4 = _0x22a6cc[_0xa4c01];
        return _0x1e1eb4;
    }, _0xa4c0(_0x47dc48, _0x1c2a71);
}
for (i = 0x0; i < arr['length']; i++) {
    arr[i][_0x3de555(0x17a)] % 0x2 != 0x0 && (console[_0x3de555(0x180)](arr[i] + _0x3de555(0x182) + arr[i][_0x3de555(0x17a)]), sumOddWords = sumOddWords + arr[i][_0x3de555(0x17a)]);
}
console['log'](_0x3de555(0x179) + sumOddWords);