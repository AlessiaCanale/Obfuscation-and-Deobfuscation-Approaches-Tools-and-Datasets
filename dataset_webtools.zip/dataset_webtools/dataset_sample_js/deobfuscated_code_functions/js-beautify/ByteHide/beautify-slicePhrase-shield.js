/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x5d3b2f = _0xe7c6;
(function(_0x642a00, _0x1de0d1) {
    const _0x1b747f = _0xe7c6,
        _0x202eb8 = _0x642a00();
    while (!![]) {
        try {
            const _0x147487 = parseInt(_0x1b747f(0xa0)) / 0x1 * (parseInt(_0x1b747f(0x9f)) / 0x2) + -parseInt(_0x1b747f(0xa5)) / 0x3 * (parseInt(_0x1b747f(0xa6)) / 0x4) + -parseInt(_0x1b747f(0xa7)) / 0x5 + -parseInt(_0x1b747f(0xa1)) / 0x6 + -parseInt(_0x1b747f(0x9a)) / 0x7 * (-parseInt(_0x1b747f(0x9e)) / 0x8) + -parseInt(_0x1b747f(0x9c)) / 0x9 * (-parseInt(_0x1b747f(0xab)) / 0xa) + parseInt(_0x1b747f(0xa3)) / 0xb * (-parseInt(_0x1b747f(0xa8)) / 0xc);
            if (_0x147487 === _0x1de0d1) break;
            else _0x202eb8['push'](_0x202eb8['shift']());
        } catch (_0x29d7f8) {
            _0x202eb8['push'](_0x202eb8['shift']());
        }
    }
}(_0x4bb6, 0x32206));
const headline = _0x5d3b2f(0xa2);

function _0xe7c6(_0x1799a4, _0x17f845) {
    const _0x4bb623 = _0x4bb6();
    return _0xe7c6 = function(_0xe7c65d, _0x13b977) {
        _0xe7c65d = _0xe7c65d - 0x9a;
        let _0xb71cd = _0x4bb623[_0xe7c65d];
        return _0xb71cd;
    }, _0xe7c6(_0x1799a4, _0x17f845);
}
console[_0x5d3b2f(0xa9)](_0x5d3b2f(0x9d) + headline);

function _0x4bb6() {
    const _0x12f9f2 = ['39444dujWjk', 'log', 'waiting', '1693520iLqAzP', '70WfcWyg', 'indexOf', '18TzfAyk', 'original:\x20', '300824SyzMwe', '3854JTipqc', '6cwovCU', '792810GGgQnT', 'And\x20in\x20tonight\x27s\x20special,\x20the\x20guest\x20we\x27ve\x20all\x20been\x20waiting\x20for!', '1166YhqZdH', 'slice', '54bNhBiV', '6632jWQOVs', '52885siRizr'];
    _0x4bb6 = function() {
        return _0x12f9f2;
    };
    return _0x4bb6();
}
const startIndex = headline['indexOf']('guest'),
    endIndex = headline[_0x5d3b2f(0x9b)](_0x5d3b2f(0xaa)),
    newHeadline = headline[_0x5d3b2f(0xa4)](startIndex, endIndex);
console[_0x5d3b2f(0xa9)]('sliced:\x20' + newHeadline);