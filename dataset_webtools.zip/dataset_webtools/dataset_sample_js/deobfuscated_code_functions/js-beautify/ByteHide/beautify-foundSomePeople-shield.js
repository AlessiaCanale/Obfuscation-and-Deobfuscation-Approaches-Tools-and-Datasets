/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0xed369c = _0x4f73;

function _0x4f73(_0x53ac14, _0x389478) {
    const _0x2fbdaa = _0x2fbd();
    return _0x4f73 = function(_0x4f732f, _0x4c7402) {
        _0x4f732f = _0x4f732f - 0x150;
        let _0x507898 = _0x2fbdaa[_0x4f732f];
        return _0x507898;
    }, _0x4f73(_0x53ac14, _0x389478);
}

function _0x2fbd() {
    const _0xe18d3e = ['3239632TQVcoD', '615154wJStKc', '67908smElLD', '5131gReium', 'Person\x201', 'log', '15bqDZBA', '232HxQkZr', '365661xwSwmj', '310379fDLzZv', 'Person\x202', '14970UYAaby', '1208AhMFzJ', 'Found\x20some\x20people\x20older\x20then\x2035!', '40oUmTvD'];
    _0x2fbd = function() {
        return _0xe18d3e;
    };
    return _0x2fbd();
}(function(_0x219da5, _0x3b40be) {
    const _0x10e72b = _0x4f73,
        _0x2aee80 = _0x219da5();
    while (!![]) {
        try {
            const _0x35dadc = -parseInt(_0x10e72b(0x150)) / 0x1 + -parseInt(_0x10e72b(0x157)) / 0x2 + -parseInt(_0x10e72b(0x152)) / 0x3 * (parseInt(_0x10e72b(0x15d)) / 0x4) + parseInt(_0x10e72b(0x15c)) / 0x5 * (-parseInt(_0x10e72b(0x158)) / 0x6) + parseInt(_0x10e72b(0x159)) / 0x7 * (-parseInt(_0x10e72b(0x153)) / 0x8) + parseInt(_0x10e72b(0x15e)) / 0x9 + parseInt(_0x10e72b(0x155)) / 0xa * (parseInt(_0x10e72b(0x156)) / 0xb);
            if (_0x35dadc === _0x3b40be) break;
            else _0x2aee80['push'](_0x2aee80['shift']());
        } catch (_0x205a5b) {
            _0x2aee80['push'](_0x2aee80['shift']());
        }
    }
}(_0x2fbd, 0x28b08));
const persons = [{
    'name': _0xed369c(0x15a),
    'age': 0x20
}, {
    'name': _0xed369c(0x151),
    'age': 0x28
}];
persons['some'](_0x371526 => {
    return _0x371526['age'] > 0x23;
}) ? console[_0xed369c(0x15b)](_0xed369c(0x154)) : console[_0xed369c(0x15b)]('No\x20people\x20older\x20then\x2035!');