/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x97be(_0x5224c5, _0x181e57) {
    const _0x450d0c = _0x450d();
    return _0x97be = function(_0x97be32, _0x550beb) {
        _0x97be32 = _0x97be32 - 0xb6;
        let _0x270f42 = _0x450d0c[_0x97be32];
        return _0x270f42;
    }, _0x97be(_0x5224c5, _0x181e57);
}
const _0x25a82a = _0x97be;
(function(_0x1c2ccd, _0x22e448) {
    const _0xab26 = _0x97be,
        _0xc23bd1 = _0x1c2ccd();
    while (!![]) {
        try {
            const _0x3d1e00 = parseInt(_0xab26(0xbf)) / 0x1 * (parseInt(_0xab26(0xb8)) / 0x2) + parseInt(_0xab26(0xb6)) / 0x3 * (-parseInt(_0xab26(0xba)) / 0x4) + -parseInt(_0xab26(0xbd)) / 0x5 + -parseInt(_0xab26(0xc5)) / 0x6 + parseInt(_0xab26(0xbb)) / 0x7 * (parseInt(_0xab26(0xbe)) / 0x8) + parseInt(_0xab26(0xb7)) / 0x9 * (-parseInt(_0xab26(0xc0)) / 0xa) + parseInt(_0xab26(0xbc)) / 0xb;
            if (_0x3d1e00 === _0x22e448) break;
            else _0xc23bd1['push'](_0xc23bd1['shift']());
        } catch (_0x661234) {
            _0xc23bd1['push'](_0xc23bd1['shift']());
        }
    }
}(_0x450d, 0xd89b9));
const randomHex = () => '#' + Math[_0x25a82a(0xc1)](Math[_0x25a82a(0xb9)]() * 0xffffff)[_0x25a82a(0xc4)](0x10)[_0x25a82a(0xc3)](0x6, '0');

function _0x450d() {
    const _0x51ca27 = ['5538313sqrHWV', '600190snWjFJ', '8ZvlrXR', '2xjMTCn', '340YBIIsE', 'floor', 'log', 'padEnd', 'toString', '1397142ThgovF', '2879433MFtCgu', '351171jTUDnF', '1264388ddrnXG', 'random', '4DfKsjH', '12310942DqUkrg'];
    _0x450d = function() {
        return _0x51ca27;
    };
    return _0x450d();
}
console[_0x25a82a(0xc2)](randomHex());