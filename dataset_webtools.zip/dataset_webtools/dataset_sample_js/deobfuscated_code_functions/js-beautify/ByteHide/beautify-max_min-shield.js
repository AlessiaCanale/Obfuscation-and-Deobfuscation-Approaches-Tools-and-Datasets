/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x43a0(_0x3d7bca, _0x3be57e) {
    var _0x1c2103 = _0x1c21();
    return _0x43a0 = function(_0x43a0c4, _0x2dd427) {
        _0x43a0c4 = _0x43a0c4 - 0x1b7;
        var _0x536030 = _0x1c2103[_0x43a0c4];
        return _0x536030;
    }, _0x43a0(_0x3d7bca, _0x3be57e);
}
var _0x5c0622 = _0x43a0;
(function(_0x554726, _0x3afc07) {
    var _0xcdd0e7 = _0x43a0,
        _0x112c61 = _0x554726();
    while (!![]) {
        try {
            var _0x3c8580 = parseInt(_0xcdd0e7(0x1b7)) / 0x1 * (parseInt(_0xcdd0e7(0x1c1)) / 0x2) + -parseInt(_0xcdd0e7(0x1c3)) / 0x3 * (-parseInt(_0xcdd0e7(0x1c5)) / 0x4) + -parseInt(_0xcdd0e7(0x1be)) / 0x5 + -parseInt(_0xcdd0e7(0x1b9)) / 0x6 + -parseInt(_0xcdd0e7(0x1bc)) / 0x7 * (-parseInt(_0xcdd0e7(0x1bf)) / 0x8) + -parseInt(_0xcdd0e7(0x1c0)) / 0x9 * (-parseInt(_0xcdd0e7(0x1c4)) / 0xa) + -parseInt(_0xcdd0e7(0x1bb)) / 0xb * (parseInt(_0xcdd0e7(0x1ba)) / 0xc);
            if (_0x3c8580 === _0x3afc07) break;
            else _0x112c61['push'](_0x112c61['shift']());
        } catch (_0x5093c2) {
            _0x112c61['push'](_0x112c61['shift']());
        }
    }
}(_0x1c21, 0x3d0bf));
var my_array = new Array(0x5c, 0x6, 0x2d, 0x8, 0x3f, 0x2, 0xf, 0x8, 0x12);

function maxNum(_0x278a65) {
    var _0x5a64ac = Math['max']['apply'](null, _0x278a65);
    return _0x5a64ac;
}

function minNum(_0xa01573) {
    var _0xb3c7cf = _0x43a0,
        _0x2f0986 = Math[_0xb3c7cf(0x1c2)][_0xb3c7cf(0x1bd)](null, _0xa01573);
    return _0x2f0986;
}

function _0x1c21() {
    var _0x1b2c9a = ['47634uiekcE', '12mrVcNp', '2997742ZVoOIJ', '225323QJqPWU', 'apply', '1300330yvGJSZ', '56hgGtnG', '9paShjp', '794336CluOlQ', 'min', '90630pJbGRn', '1378730TavnZN', '4UcXlIX', '1UujRzv', 'log'];
    _0x1c21 = function() {
        return _0x1b2c9a;
    };
    return _0x1c21();
}
console[_0x5c0622(0x1b8)]('Il\x20valore\x20massimo\x20dell\x27array\x20è:\x20' + maxNum(my_array)), console[_0x5c0622(0x1b8)]('\x0a'), console[_0x5c0622(0x1b8)]('Il\x20valore\x20minimo\x20dell\x27array\x20è:\x20' + minNum(my_array));