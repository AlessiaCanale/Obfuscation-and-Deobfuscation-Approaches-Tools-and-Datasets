/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x308e06 = _0x295e;

function _0x295e(_0x585849, _0x23e052) {
    const _0xe7866 = _0xe786();
    return _0x295e = function(_0x295ed8, _0x309fbf) {
        _0x295ed8 = _0x295ed8 - 0x1f2;
        let _0x3c831c = _0xe7866[_0x295ed8];
        return _0x3c831c;
    }, _0x295e(_0x585849, _0x23e052);
}

function _0xe786() {
    const _0x4b2058 = ['1352vftWGb', '7010UsYVDO', 'toUpperCase', '1257876KVPhFk', '6291ICRgRJ', '3619MDNqYb', '14DfBuUh', '162711kAAAOP', '9655lwKcJF', 'log', '338502veBQue', 'toString', '16RaviFd', 'floor', '570089Tqafta', '398UErCvY'];
    _0xe786 = function() {
        return _0x4b2058;
    };
    return _0xe786();
}(function(_0x504f3d, _0x3da454) {
    const _0x47ddb4 = _0x295e,
        _0x1a6802 = _0x504f3d();
    while (!![]) {
        try {
            const _0x53293f = parseInt(_0x47ddb4(0x1f7)) / 0x1 + parseInt(_0x47ddb4(0x1f8)) / 0x2 * (parseInt(_0x47ddb4(0x1fd)) / 0x3) + parseInt(_0x47ddb4(0x1f9)) / 0x4 * (-parseInt(_0x47ddb4(0x201)) / 0x5) + -parseInt(_0x47ddb4(0x1f3)) / 0x6 * (parseInt(_0x47ddb4(0x1ff)) / 0x7) + parseInt(_0x47ddb4(0x1f5)) / 0x8 * (-parseInt(_0x47ddb4(0x200)) / 0x9) + parseInt(_0x47ddb4(0x1fa)) / 0xa * (parseInt(_0x47ddb4(0x1fe)) / 0xb) + parseInt(_0x47ddb4(0x1fc)) / 0xc;
            if (_0x53293f === _0x3da454) break;
            else _0x1a6802['push'](_0x1a6802['shift']());
        } catch (_0x35087d) {
            _0x1a6802['push'](_0x1a6802['shift']());
        }
    }
}(_0xe786, 0x7f3d6));

function generateRandomColor() {
    const _0x738e78 = _0x295e;
    let _0x15bf5e = 0xffffff,
        _0xced607 = Math['random']() * _0x15bf5e;
    _0xced607 = Math[_0x738e78(0x1f6)](_0xced607), _0xced607 = _0xced607[_0x738e78(0x1f4)](0x10);
    let _0x3a9464 = _0xced607['padStart'](0x6, 0x0);
    return '#' + _0x3a9464[_0x738e78(0x1fb)]();
}
console[_0x308e06(0x1f2)](generateRandomColor());