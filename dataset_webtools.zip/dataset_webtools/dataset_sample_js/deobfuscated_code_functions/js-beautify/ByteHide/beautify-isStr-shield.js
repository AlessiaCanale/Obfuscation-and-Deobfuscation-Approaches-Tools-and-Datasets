/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x12df6d = _0x3439;

function _0x2c81() {
    const _0xc45af3 = ['log', '4ELyfYo', '702bJXlwE', '78yEXYdM', '1343817yFPZhk', '286TNnrfs', '961270ATEYqZ', '936EyNtOX', '27380EuZcNG', '10507iAeOSW', '44336KRsgqz', '345\x20is\x20string:\x20', 'JavaScript\x20is\x20string:\x20', '1704448JeKbTc', 'JavaScript', 'true\x20is\x20string:\x20'];
    _0x2c81 = function() {
        return _0xc45af3;
    };
    return _0x2c81();
}

function _0x3439(_0x2bdac9, _0x36bb45) {
    const _0x2c813c = _0x2c81();
    return _0x3439 = function(_0x343986, _0x462a1c) {
        _0x343986 = _0x343986 - 0xd3;
        let _0x25289f = _0x2c813c[_0x343986];
        return _0x25289f;
    }, _0x3439(_0x2bdac9, _0x36bb45);
}(function(_0x5b87aa, _0x74257a) {
    const _0x5f2f40 = _0x3439,
        _0x58a62f = _0x5b87aa();
    while (!![]) {
        try {
            const _0x3ffa06 = parseInt(_0x5f2f40(0xe2)) / 0x1 + -parseInt(_0x5f2f40(0xda)) / 0x2 * (-parseInt(_0x5f2f40(0xdf)) / 0x3) + parseInt(_0x5f2f40(0xd9)) / 0x4 * (parseInt(_0x5f2f40(0xde)) / 0x5) + -parseInt(_0x5f2f40(0xdb)) / 0x6 * (parseInt(_0x5f2f40(0xe1)) / 0x7) + -parseInt(_0x5f2f40(0xd5)) / 0x8 + parseInt(_0x5f2f40(0xdc)) / 0x9 + parseInt(_0x5f2f40(0xe0)) / 0xa * (-parseInt(_0x5f2f40(0xdd)) / 0xb);
            if (_0x3ffa06 === _0x74257a) break;
            else _0x58a62f['push'](_0x58a62f['shift']());
        } catch (_0x3e9f20) {
            _0x58a62f['push'](_0x58a62f['shift']());
        }
    }
}(_0x2c81, 0x2ecaa));
const isStr = _0x36d32b => typeof _0x36d32b === 'string';
console['log'](_0x12df6d(0xd4) + isStr(_0x12df6d(0xd6))), console[_0x12df6d(0xd8)](_0x12df6d(0xd3) + isStr(0x159)), console['log'](_0x12df6d(0xd7) + isStr(!![]));