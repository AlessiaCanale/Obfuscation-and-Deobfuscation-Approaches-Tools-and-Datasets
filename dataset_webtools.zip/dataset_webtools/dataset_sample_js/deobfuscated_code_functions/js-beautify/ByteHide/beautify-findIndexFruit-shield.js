/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x155ef6 = _0x10ef;

function _0x1a1e() {
    const _0x211c7e = ['1867395FPBNyG', '792431tUZRjy', 'log', 'apple', 'mango', '482586nztnQm', '1243245yLWxQR', '2344470IIdBLB', '1867590ebTXEh', '6310430SIxGZu', '4IkxNWl', '8CktDWb', 'findIndex', 'name', 'mango\x20is\x20at\x20index:\x20'];
    _0x1a1e = function() {
        return _0x211c7e;
    };
    return _0x1a1e();
}(function(_0x649206, _0xc9fdb6) {
    const _0x165841 = _0x10ef,
        _0x499d38 = _0x649206();
    while (!![]) {
        try {
            const _0x195bca = -parseInt(_0x165841(0x16a)) / 0x1 + parseInt(_0x165841(0x16e)) / 0x2 + parseInt(_0x165841(0x169)) / 0x3 + -parseInt(_0x165841(0x173)) / 0x4 * (parseInt(_0x165841(0x16f)) / 0x5) + -parseInt(_0x165841(0x170)) / 0x6 + -parseInt(_0x165841(0x172)) / 0x7 * (-parseInt(_0x165841(0x174)) / 0x8) + parseInt(_0x165841(0x171)) / 0x9;
            if (_0x195bca === _0xc9fdb6) break;
            else _0x499d38['push'](_0x499d38['shift']());
        } catch (_0x2f2e89) {
            _0x499d38['push'](_0x499d38['shift']());
        }
    }
}(_0x1a1e, 0x84105));

function _0x10ef(_0x1ad026, _0x51ae95) {
    const _0x1a1e9a = _0x1a1e();
    return _0x10ef = function(_0x10ef8a, _0x510b1a) {
        _0x10ef8a = _0x10ef8a - 0x166;
        let _0x27407e = _0x1a1e9a[_0x10ef8a];
        return _0x27407e;
    }, _0x10ef(_0x1ad026, _0x51ae95);
}
const fruits = [{
        'name': _0x155ef6(0x16c),
        'count': 0xa
    }, {
        'name': 'banana',
        'count': 0x12
    }, {
        'name': 'mango',
        'count': 0x3
    }],
    findMango = fruits[_0x155ef6(0x166)](_0x409e84 => _0x409e84[_0x155ef6(0x167)] === _0x155ef6(0x16d));
console[_0x155ef6(0x16b)](_0x155ef6(0x168) + findMango);