/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

var _0x558703 = _0x19de;

function _0x26fc() {
    var _0x5a84fe = ['4497208lHYyjC', 'log', 'original:\x20', '1811670psDbzP', '9eBLtnU', '\x0aresult:\x20', '2401932BexKqH', '265386mAjZYG', '56QWnxfd', '7496220loVAEc', '753AhGSbO', 'replace', '1489848tYgCEg', '208EJNEyr', 'JavaScript\x20is\x20awesome'];
    _0x26fc = function() {
        return _0x5a84fe;
    };
    return _0x26fc();
}

function _0x19de(_0x2146f3, _0x42776c) {
    var _0x26fc98 = _0x26fc();
    return _0x19de = function(_0x19debc, _0xedf7a4) {
        _0x19debc = _0x19debc - 0x15d;
        var _0x3b0390 = _0x26fc98[_0x19debc];
        return _0x3b0390;
    }, _0x19de(_0x2146f3, _0x42776c);
}(function(_0x313c66, _0x3dee1a) {
    var _0x32849f = _0x19de,
        _0x425260 = _0x313c66();
    while (!![]) {
        try {
            var _0x14580d = parseInt(_0x32849f(0x165)) / 0x1 * (-parseInt(_0x32849f(0x168)) / 0x2) + parseInt(_0x32849f(0x161)) / 0x3 + -parseInt(_0x32849f(0x167)) / 0x4 + -parseInt(_0x32849f(0x15e)) / 0x5 + -parseInt(_0x32849f(0x162)) / 0x6 * (-parseInt(_0x32849f(0x163)) / 0x7) + -parseInt(_0x32849f(0x16a)) / 0x8 * (parseInt(_0x32849f(0x15f)) / 0x9) + parseInt(_0x32849f(0x164)) / 0xa;
            if (_0x14580d === _0x3dee1a) break;
            else _0x425260['push'](_0x425260['shift']());
        } catch (_0x41b99c) {
            _0x425260['push'](_0x425260['shift']());
        }
    }
}(_0x26fc, 0x811d7));
var str = _0x558703(0x169),
    result = str[_0x558703(0x166)](/ /g, '_');
console[_0x558703(0x16b)](_0x558703(0x15d) + str + _0x558703(0x160) + result);