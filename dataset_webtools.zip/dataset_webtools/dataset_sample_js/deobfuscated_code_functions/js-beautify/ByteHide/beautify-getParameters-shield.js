/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x1f70() {
    const _0x13be40 = ['1257ErZMSc', '654388IouUOH', 'log', 'parse', '24vwwevP', 'split', '2487576EwjpyY', '3334364tOlePe', 'replace', '304670sTkZzz', '5078007VCARdB', '1468vrwkNx', '1008247RgCByF'];
    _0x1f70 = function() {
        return _0x13be40;
    };
    return _0x1f70();
}

function _0x57db(_0x155f90, _0x584326) {
    const _0x1f7073 = _0x1f70();
    return _0x57db = function(_0x57db5e, _0x48dfd1) {
        _0x57db5e = _0x57db5e - 0x1bb;
        let _0x9ea5b7 = _0x1f7073[_0x57db5e];
        return _0x9ea5b7;
    }, _0x57db(_0x155f90, _0x584326);
}
const _0x371068 = _0x57db;
(function(_0xa21439, _0x39a2c6) {
    const _0x1d86f4 = _0x57db,
        _0x111e21 = _0xa21439();
    while (!![]) {
        try {
            const _0x51b88f = -parseInt(_0x1d86f4(0x1c2)) / 0x1 + parseInt(_0x1d86f4(0x1c1)) / 0x2 * (parseInt(_0x1d86f4(0x1c3)) / 0x3) + parseInt(_0x1d86f4(0x1bd)) / 0x4 + -parseInt(_0x1d86f4(0x1bf)) / 0x5 * (-parseInt(_0x1d86f4(0x1c7)) / 0x6) + -parseInt(_0x1d86f4(0x1c4)) / 0x7 + -parseInt(_0x1d86f4(0x1bc)) / 0x8 + parseInt(_0x1d86f4(0x1c0)) / 0x9;
            if (_0x51b88f === _0x39a2c6) break;
            else _0x111e21['push'](_0x111e21['shift']());
        } catch (_0x1c5536) {
            _0x111e21['push'](_0x111e21['shift']());
        }
    }
}(_0x1f70, 0x82f62));
const getParameters = _0x2835a7 => JSON[_0x371068(0x1c6)]('{\x22' + decodeURI(_0x2835a7[_0x371068(0x1bb)]('?')[0x1])[_0x371068(0x1be)](/"/g, '\x5c\x22')[_0x371068(0x1be)](/&/g, '\x22,\x22')[_0x371068(0x1be)](/=/g, '\x22:\x22') + '\x22}');
console[_0x371068(0x1c5)](getParameters('https://www.google.de/search?q=cars&start=40'));