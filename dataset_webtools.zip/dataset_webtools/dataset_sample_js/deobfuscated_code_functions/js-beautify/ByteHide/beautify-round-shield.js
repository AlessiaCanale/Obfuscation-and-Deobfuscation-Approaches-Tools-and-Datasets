/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x1c5f(_0x5a5480, _0x3d4fbe) {
    const _0x3102a8 = _0x3102();
    return _0x1c5f = function(_0x1c5fac, _0x3e5902) {
        _0x1c5fac = _0x1c5fac - 0x81;
        let _0x29626a = _0x3102a8[_0x1c5fac];
        return _0x29626a;
    }, _0x1c5f(_0x5a5480, _0x3d4fbe);
}

function _0x3102() {
    const _0x5f1e1f = ['round', '62ybTnPF', '50488CsSaDq', '1373544efXqPz', 'log', '82379aDGTKF', '9UQmfpd', '8270104eqBUBD', '325368ZnyfEK', '4588703rPwpVT', 'toFixed', '1790NOtilk', '5SfpTBi', '17282DtVkIm'];
    _0x3102 = function() {
        return _0x5f1e1f;
    };
    return _0x3102();
}
const _0x12ef89 = _0x1c5f;
(function(_0x1e0159, _0x5e3a4d) {
    const _0x185e78 = _0x1c5f,
        _0x2bfa89 = _0x1e0159();
    while (!![]) {
        try {
            const _0x3c0a42 = -parseInt(_0x185e78(0x87)) / 0x1 * (-parseInt(_0x185e78(0x85)) / 0x2) + -parseInt(_0x185e78(0x8e)) / 0x3 + parseInt(_0x185e78(0x88)) / 0x4 * (parseInt(_0x185e78(0x84)) / 0x5) + -parseInt(_0x185e78(0x89)) / 0x6 + parseInt(_0x185e78(0x81)) / 0x7 + parseInt(_0x185e78(0x8d)) / 0x8 * (parseInt(_0x185e78(0x8c)) / 0x9) + parseInt(_0x185e78(0x83)) / 0xa * (-parseInt(_0x185e78(0x8b)) / 0xb);
            if (_0x3c0a42 === _0x5e3a4d) break;
            else _0x2bfa89['push'](_0x2bfa89['shift']());
        } catch (_0x225ba8) {
            _0x2bfa89['push'](_0x2bfa89['shift']());
        }
    }
}(_0x3102, 0x88a81), Number(1.005[_0x12ef89(0x82)](0x2)), Number(1.555['toFixed'](0x2)));
const round = (_0x2c771f, _0x4c82cf) => Number(Math[_0x12ef89(0x86)](_0x2c771f + 'e' + _0x4c82cf) + 'e-' + _0x4c82cf);
console[_0x12ef89(0x8a)](round(1.005, 0x2)), console[_0x12ef89(0x8a)](round(1.555, 0x2));