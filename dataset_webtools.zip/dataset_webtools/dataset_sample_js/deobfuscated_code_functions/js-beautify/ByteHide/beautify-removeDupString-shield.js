/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

var _0x293ae2 = _0x3a76;
(function(_0x2a217d, _0x1be7a5) {
    var _0x164293 = _0x3a76,
        _0x3498b3 = _0x2a217d();
    while (!![]) {
        try {
            var _0x326792 = -parseInt(_0x164293(0xc7)) / 0x1 + parseInt(_0x164293(0xc8)) / 0x2 * (parseInt(_0x164293(0xc6)) / 0x3) + -parseInt(_0x164293(0xd0)) / 0x4 * (parseInt(_0x164293(0xd7)) / 0x5) + -parseInt(_0x164293(0xc9)) / 0x6 * (parseInt(_0x164293(0xcf)) / 0x7) + parseInt(_0x164293(0xcd)) / 0x8 + -parseInt(_0x164293(0xc4)) / 0x9 + parseInt(_0x164293(0xcb)) / 0xa * (parseInt(_0x164293(0xd1)) / 0xb);
            if (_0x326792 === _0x1be7a5) break;
            else _0x3498b3['push'](_0x3498b3['shift']());
        } catch (_0x365295) {
            _0x3498b3['push'](_0x3498b3['shift']());
        }
    }
}(_0x30e4, 0xe2e1a));
var arr = [_0x293ae2(0xd2), 'apple', _0x293ae2(0xce), _0x293ae2(0xc5), _0x293ae2(0xd3), _0x293ae2(0xc5)];

function _0x30e4() {
    var _0x22c8e5 = ['indexOf', '12848696CWZWgv', 'orange', '35OHBpMl', '1224MmSHuo', '11lFIRRA', 'banana', 'apple', '\x0aresult:\x20', 'filter', 'original:\x20', '9795gLsSmc', '5561064FGlzZM', 'lemon', '1164hCzhfo', '1527548klQyKK', '1728VtNJAG', '1772622FhLWfd', 'log', '32100700KOuqaY'];
    _0x30e4 = function() {
        return _0x22c8e5;
    };
    return _0x30e4();
}

function removeDuplicates(_0x344116) {
    var _0x2d3c46 = _0x293ae2;
    return _0x344116[_0x2d3c46(0xd5)]((_0xf6605e, _0x4fce17) => _0x344116[_0x2d3c46(0xcc)](_0xf6605e) === _0x4fce17);
}

function _0x3a76(_0x3e4624, _0x4e43df) {
    var _0x30e467 = _0x30e4();
    return _0x3a76 = function(_0x3a76f2, _0x43e604) {
        _0x3a76f2 = _0x3a76f2 - 0xc4;
        var _0x48f436 = _0x30e467[_0x3a76f2];
        return _0x48f436;
    }, _0x3a76(_0x3e4624, _0x4e43df);
}
console[_0x293ae2(0xca)](_0x293ae2(0xd6) + arr + _0x293ae2(0xd4) + removeDuplicates(arr));