/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0xdb89(_0x40f6c4, _0x586fcf) {
    const _0x5a64c3 = _0x5a64();
    return _0xdb89 = function(_0xdb8965, _0x2f3955) {
        _0xdb8965 = _0xdb8965 - 0x1ef;
        let _0x1ad908 = _0x5a64c3[_0xdb8965];
        return _0x1ad908;
    }, _0xdb89(_0x40f6c4, _0x586fcf);
}
const _0x54f4e5 = _0xdb89;
(function(_0x59aeb2, _0x3eeeb7) {
    const _0x328ae2 = _0xdb89,
        _0x1da2e6 = _0x59aeb2();
    while (!![]) {
        try {
            const _0x48eea3 = parseInt(_0x328ae2(0x1f9)) / 0x1 + parseInt(_0x328ae2(0x1f8)) / 0x2 * (-parseInt(_0x328ae2(0x1ef)) / 0x3) + parseInt(_0x328ae2(0x1f2)) / 0x4 * (parseInt(_0x328ae2(0x1f4)) / 0x5) + parseInt(_0x328ae2(0x1f5)) / 0x6 + parseInt(_0x328ae2(0x1fc)) / 0x7 + parseInt(_0x328ae2(0x1f0)) / 0x8 * (-parseInt(_0x328ae2(0x1f6)) / 0x9) + parseInt(_0x328ae2(0x1f7)) / 0xa;
            if (_0x48eea3 === _0x3eeeb7) break;
            else _0x1da2e6['push'](_0x1da2e6['shift']());
        } catch (_0x2f9850) {
            _0x1da2e6['push'](_0x1da2e6['shift']());
        }
    }
}(_0x5a64, 0x8d252));
const marks = [0x1e, 0x46, 0x62, 0x4d, 0x66, 0x64, 0x6e];
console[_0x54f4e5(0x1f1)](_0x54f4e5(0x1fa) + marks + _0x54f4e5(0x1fb) + marks[_0x54f4e5(0x1f3)](checkMarks));

function checkMarks(_0x170661) {
    return _0x170661 > 0x5a;
}

function _0x5a64() {
    const _0x79b944 = ['12weDuuj', 'findIndex', '374295CMrTvB', '663606lfpixZ', '17757WjSThs', '9132100KJDcKB', '46klGfKc', '37891FOUDCi', 'marks:\x20', '\x0aindex\x20marks\x20>\x2090:\x20', '3654574BzoAAr', '49548FGudll', '3448THmEDG', 'log'];
    _0x5a64 = function() {
        return _0x79b944;
    };
    return _0x5a64();
}