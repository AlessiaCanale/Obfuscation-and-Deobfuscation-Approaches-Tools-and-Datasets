/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x122729 = _0x43d2;
(function(_0x5d5ffc, _0x3ba346) {
    const _0x5363c7 = _0x43d2,
        _0x326481 = _0x5d5ffc();
    while (!![]) {
        try {
            const _0x4325f5 = -parseInt(_0x5363c7(0x1ec)) / 0x1 + -parseInt(_0x5363c7(0x1ed)) / 0x2 * (-parseInt(_0x5363c7(0x1f0)) / 0x3) + -parseInt(_0x5363c7(0x1eb)) / 0x4 * (-parseInt(_0x5363c7(0x1e2)) / 0x5) + parseInt(_0x5363c7(0x1e7)) / 0x6 * (-parseInt(_0x5363c7(0x1f2)) / 0x7) + parseInt(_0x5363c7(0x1ef)) / 0x8 + -parseInt(_0x5363c7(0x1ee)) / 0x9 + parseInt(_0x5363c7(0x1e8)) / 0xa * (parseInt(_0x5363c7(0x1ea)) / 0xb);
            if (_0x4325f5 === _0x3ba346) break;
            else _0x326481['push'](_0x326481['shift']());
        } catch (_0x182b02) {
            _0x326481['push'](_0x326481['shift']());
        }
    }
}(_0x43e1, 0x50021));
const dayDif = (_0xd2c45d, _0x4e0dd6) => Math[_0x122729(0x1e9)](Math[_0x122729(0x1e3)](_0xd2c45d['getTime']() - _0x4e0dd6[_0x122729(0x1e6)]()) / 0x5265c00);
console[_0x122729(0x1f1)](dayDif(new Date(_0x122729(0x1e4)), new Date(_0x122729(0x1e5))));

function _0x43d2(_0x2a229c, _0xbc67b3) {
    const _0x43e1e1 = _0x43e1();
    return _0x43d2 = function(_0x43d2fe, _0x5aa8ac) {
        _0x43d2fe = _0x43d2fe - 0x1e2;
        let _0xa4f122 = _0x43e1e1[_0x43d2fe];
        return _0xa4f122;
    }, _0x43d2(_0x2a229c, _0xbc67b3);
}

function _0x43e1() {
    const _0x5392fd = ['20980cIpvkW', 'ceil', '2497GIvVPD', '652OXTwIR', '404951DoobpW', '36JpgdGw', '1404135bhWNHY', '829896gpWsIh', '56283ctaJnm', 'log', '423290tMbaTE', '6530gwDGQE', 'abs', '2020-10-21', '2021-10-22', 'getTime', '24OKUjBJ'];
    _0x43e1 = function() {
        return _0x5392fd;
    };
    return _0x43e1();
}