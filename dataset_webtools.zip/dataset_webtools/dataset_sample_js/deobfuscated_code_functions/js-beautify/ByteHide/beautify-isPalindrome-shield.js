/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0xd58c76 = _0x8a48;
(function(_0x2735b5, _0x4a08a7) {
    const _0x37f2be = _0x8a48,
        _0x25003c = _0x2735b5();
    while (!![]) {
        try {
            const _0x5f3839 = parseInt(_0x37f2be(0x116)) / 0x1 + parseInt(_0x37f2be(0x113)) / 0x2 * (parseInt(_0x37f2be(0x10b)) / 0x3) + -parseInt(_0x37f2be(0x110)) / 0x4 * (parseInt(_0x37f2be(0x10e)) / 0x5) + parseInt(_0x37f2be(0x108)) / 0x6 + -parseInt(_0x37f2be(0x115)) / 0x7 * (-parseInt(_0x37f2be(0x111)) / 0x8) + parseInt(_0x37f2be(0x10c)) / 0x9 + parseInt(_0x37f2be(0x10f)) / 0xa * (-parseInt(_0x37f2be(0x107)) / 0xb);
            if (_0x5f3839 === _0x4a08a7) break;
            else _0x25003c['push'](_0x25003c['shift']());
        } catch (_0x557642) {
            _0x25003c['push'](_0x25003c['shift']());
        }
    }
}(_0x2e25, 0x98ef3));

function _0x8a48(_0x3cbbce, _0x40982b) {
    const _0x2e2549 = _0x2e25();
    return _0x8a48 = function(_0x8a4869, _0xdcb0ce) {
        _0x8a4869 = _0x8a4869 - 0x107;
        let _0x8dba75 = _0x2e2549[_0x8a4869];
        return _0x8dba75;
    }, _0x8a48(_0x3cbbce, _0x40982b);
}

function isPalindrome(_0xebe869) {
    const _0x16a782 = _0x8a48;
    let _0x161e94 = _0xebe869[_0x16a782(0x112)] - 0x1;
    for (let _0x44feea = 0x0; _0x44feea < _0xebe869[_0x16a782(0x112)] / 0x2; _0x44feea++) {
        if (_0xebe869[_0x44feea] != _0xebe869[_0x161e94]) return ![];
        _0x161e94--;
    }
    return !![];
}
let str1 = _0xd58c76(0x10d),
    str2 = _0xd58c76(0x114),
    str3 = _0xd58c76(0x10a);

function _0x2e25() {
    const _0x4c214f = ['2001648pqtkmu', 'log', 'Rama', '4419PlGDGv', '2178513HeLsnT', 'racecar', '4045435ylGewC', '2890TJjeHr', '4gRyMWU', '208IHSOII', 'length', '186fAastv', 'nitin', '248549oKUxbt', '655977wrRVxf', '\x20is\x20palindrome?\x0a', '32593kJJPDW'];
    _0x2e25 = function() {
        return _0x4c214f;
    };
    return _0x2e25();
}
console['log'](str1 + _0xd58c76(0x117) + isPalindrome(str1)), console[_0xd58c76(0x109)](str2 + _0xd58c76(0x117) + isPalindrome(str2)), console[_0xd58c76(0x109)](str3 + _0xd58c76(0x117) + isPalindrome(str3));