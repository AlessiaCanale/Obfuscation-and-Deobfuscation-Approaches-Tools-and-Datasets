/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x12e72d = _0x47db;

function _0x47db(_0x29aa90, _0x306572) {
    const _0xb7a366 = _0xb7a3();
    return _0x47db = function(_0x47dbdc, _0x1bacf5) {
        _0x47dbdc = _0x47dbdc - 0x1e8;
        let _0x4720c7 = _0xb7a366[_0x47dbdc];
        return _0x4720c7;
    }, _0x47db(_0x29aa90, _0x306572);
}

function _0xb7a3() {
    const _0x187167 = ['11488614DVTqkb', '7435239WhAhxs', '374704vEJklh', '994WaVsdv', '1303866vVBfwn', '9FiphlH', 'getHours', '5703DcvwLc', '24042344iIXjiM', '5795655hXwyPk', 'It\x27s\x20currently\x20before\x2012\x20AM!', 'log', 'It\x27s\x20currently\x20after\x2012\x20AM!'];
    _0xb7a3 = function() {
        return _0x187167;
    };
    return _0xb7a3();
}(function(_0x10f8e8, _0x2ca31d) {
    const _0x3c36f1 = _0x47db,
        _0xc21340 = _0x10f8e8();
    while (!![]) {
        try {
            const _0x246d22 = -parseInt(_0x3c36f1(0x1ee)) / 0x1 + -parseInt(_0x3c36f1(0x1ed)) / 0x2 * (parseInt(_0x3c36f1(0x1f1)) / 0x3) + -parseInt(_0x3c36f1(0x1ec)) / 0x4 + parseInt(_0x3c36f1(0x1f3)) / 0x5 + -parseInt(_0x3c36f1(0x1ea)) / 0x6 + parseInt(_0x3c36f1(0x1eb)) / 0x7 + parseInt(_0x3c36f1(0x1f2)) / 0x8 * (parseInt(_0x3c36f1(0x1ef)) / 0x9);
            if (_0x246d22 === _0x2ca31d) break;
            else _0xc21340['push'](_0xc21340['shift']());
        } catch (_0x449b01) {
            _0xc21340['push'](_0xc21340['shift']());
        }
    }
}(_0xb7a3, 0xecb15));
const currentTime = new Date(),
    currentHour = currentTime[_0x12e72d(0x1f0)]();
currentHour < 0xc ? console['log'](_0x12e72d(0x1f4)) : console[_0x12e72d(0x1e8)](_0x12e72d(0x1e9));