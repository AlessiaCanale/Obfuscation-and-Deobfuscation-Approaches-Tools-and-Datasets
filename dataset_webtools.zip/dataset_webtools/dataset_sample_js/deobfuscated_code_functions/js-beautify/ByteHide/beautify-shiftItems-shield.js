/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x2045(_0x4ac6fa, _0x467408) {
    const _0x150945 = _0x1509();
    return _0x2045 = function(_0x2045c8, _0x11dac0) {
        _0x2045c8 = _0x2045c8 - 0xdc;
        let _0x12d081 = _0x150945[_0x2045c8];
        return _0x12d081;
    }, _0x2045(_0x4ac6fa, _0x467408);
}
const _0x1ed017 = _0x2045;

function _0x1509() {
    const _0x1c270f = ['milk', '140434hhGWGr', '120aaitNM', 'bread', 'shift', '1351431BZLdRM', 'log', 'eggs', 'butter', 'shifted:\x20', '4082250OGcMfS', '4353417HzjLDh', '712rDMKxp', '588xIaInH', 'original:\x20', '30765CMWhbi', '683806SVynrQ', '11207208tiTnLf'];
    _0x1509 = function() {
        return _0x1c270f;
    };
    return _0x1509();
}(function(_0x558a75, _0x3d1113) {
    const _0x54a544 = _0x2045,
        _0x569141 = _0x558a75();
    while (!![]) {
        try {
            const _0x348c51 = parseInt(_0x54a544(0xea)) / 0x1 + -parseInt(_0x54a544(0xe3)) / 0x2 + -parseInt(_0x54a544(0xdd)) / 0x3 + -parseInt(_0x54a544(0xdf)) / 0x4 * (parseInt(_0x54a544(0xe2)) / 0x5) + -parseInt(_0x54a544(0xe0)) / 0x6 * (parseInt(_0x54a544(0xe6)) / 0x7) + -parseInt(_0x54a544(0xe4)) / 0x8 + parseInt(_0x54a544(0xde)) / 0x9 * (parseInt(_0x54a544(0xe7)) / 0xa);
            if (_0x348c51 === _0x3d1113) break;
            else _0x569141['push'](_0x569141['shift']());
        } catch (_0x5cfe27) {
            _0x569141['push'](_0x569141['shift']());
        }
    }
}(_0x1509, 0xf1f93));
const items = [_0x1ed017(0xec), _0x1ed017(0xe5), 'cheese', _0x1ed017(0xe8), _0x1ed017(0xed)];
console[_0x1ed017(0xeb)](_0x1ed017(0xe1) + items), items[_0x1ed017(0xe9)](), console[_0x1ed017(0xeb)](_0x1ed017(0xdc) + items);