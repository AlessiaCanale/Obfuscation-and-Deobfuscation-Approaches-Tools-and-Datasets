/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x26e8() {
    var _0x298da7 = ['3888837qdQVAM', '64506YhlUsV', '1940516DuquvI', '\x20|\x20y2:\x20', '3317244rvwaRG', 'distance\x20between\x20x\x20and\x20y\x20is:\x20', '24580UdCpoD', 'sqrt', 'log', '558663mEfraJ', '578560VkRHpG', '5tMhTvp', '8TaPXAx'];
    _0x26e8 = function() {
        return _0x298da7;
    };
    return _0x26e8();
}
var _0x363200 = _0x4cbd;
(function(_0x131956, _0x337276) {
    var _0x5bc71f = _0x4cbd,
        _0x531755 = _0x131956();
    while (!![]) {
        try {
            var _0x2b1087 = parseInt(_0x5bc71f(0xbd)) / 0x1 * (-parseInt(_0x5bc71f(0xb8)) / 0x2) + parseInt(_0x5bc71f(0xb3)) / 0x3 + parseInt(_0x5bc71f(0xb4)) / 0x4 + -parseInt(_0x5bc71f(0xbc)) / 0x5 + -parseInt(_0x5bc71f(0xb6)) / 0x6 + -parseInt(_0x5bc71f(0xbb)) / 0x7 * (-parseInt(_0x5bc71f(0xbe)) / 0x8) + parseInt(_0x5bc71f(0xbf)) / 0x9;
            if (_0x2b1087 === _0x337276) break;
            else _0x531755['push'](_0x531755['shift']());
        } catch (_0x449f27) {
            _0x531755['push'](_0x531755['shift']());
        }
    }
}(_0x26e8, 0x466f1));

function _0x4cbd(_0x15c331, _0x55a7f6) {
    var _0x26e85e = _0x26e8();
    return _0x4cbd = function(_0x4cbda0, _0x5651a2) {
        _0x4cbda0 = _0x4cbda0 - 0xb3;
        var _0x22af1b = _0x26e85e[_0x4cbda0];
        return _0x22af1b;
    }, _0x4cbd(_0x15c331, _0x55a7f6);
}

function distance(_0x18523e, _0x4253e3, _0x2f9948, _0x1682b7) {
    var _0x23a1ce = _0x4cbd;
    return Math[_0x23a1ce(0xb9)]((_0x2f9948 - _0x18523e) * (_0x2f9948 - _0x18523e) + (_0x1682b7 - _0x4253e3) * (_0x1682b7 - _0x4253e3));
}
console[_0x363200(0xba)](_0x363200(0xb7) + distance(1.2, 1.5, 0x5, 5.2) + '\x0awith\x20x1:\x20' + 1.2 + '\x20|\x20x2:\x20' + 1.5 + '\x20|\x20y1:\x20' + 0x5 + _0x363200(0xb5) + 5.2);