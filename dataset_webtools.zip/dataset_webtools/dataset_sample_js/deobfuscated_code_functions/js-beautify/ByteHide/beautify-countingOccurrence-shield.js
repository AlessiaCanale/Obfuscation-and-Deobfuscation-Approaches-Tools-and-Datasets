/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x3228(_0x4b8043, _0x90266f) {
    const _0x1fc475 = _0x1fc4();
    return _0x3228 = function(_0x322867, _0x4b0592) {
        _0x322867 = _0x322867 - 0xa0;
        let _0x13cf76 = _0x1fc475[_0x322867];
        return _0x13cf76;
    }, _0x3228(_0x4b8043, _0x90266f);
}(function(_0x714a24, _0x77d5cd) {
    const _0x40f265 = _0x3228,
        _0x3d9e12 = _0x714a24();
    while (!![]) {
        try {
            const _0x11820a = -parseInt(_0x40f265(0xac)) / 0x1 * (-parseInt(_0x40f265(0xa0)) / 0x2) + -parseInt(_0x40f265(0xad)) / 0x3 * (-parseInt(_0x40f265(0xa5)) / 0x4) + parseInt(_0x40f265(0xa8)) / 0x5 * (parseInt(_0x40f265(0xaf)) / 0x6) + -parseInt(_0x40f265(0xab)) / 0x7 * (parseInt(_0x40f265(0xa3)) / 0x8) + parseInt(_0x40f265(0xa1)) / 0x9 + parseInt(_0x40f265(0xa7)) / 0xa + -parseInt(_0x40f265(0xa6)) / 0xb * (parseInt(_0x40f265(0xa9)) / 0xc);
            if (_0x11820a === _0x77d5cd) break;
            else _0x3d9e12['push'](_0x3d9e12['shift']());
        } catch (_0x2605cd) {
            _0x3d9e12['push'](_0x3d9e12['shift']());
        }
    }
}(_0x1fc4, 0xd7b08));

function gfg() {
    const _0x3fe502 = _0x3228;
    let _0x4ed6bb = _0x3fe502(0xaa);
    console[_0x3fe502(0xa2)](_0x3fe502(0xa4) + _0x4ed6bb + '\x20is:\x20' + _0x4ed6bb[_0x3fe502(0xb0)](/Geeks/g)[_0x3fe502(0xae)]);
}

function _0x1fc4() {
    const _0x50f6ce = ['15464322ypvKhY', 'log', '6681256uBugYi', 'occurrence\x20of\x20Geek\x20in:\x20', '120292sHeFda', '10518640rKfpZE', '650310TpAxNg', '3760950rEhUYC', '36rrkepr', 'Geeks\x20For\x20Geeks\x20', '7NGxLkN', '2yeqryT', '138pQhZSE', 'length', '6lNKRgR', 'match', '668504YumJeN'];
    _0x1fc4 = function() {
        return _0x50f6ce;
    };
    return _0x1fc4();
}
gfg();