/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

var _0x50105e = _0x4a2e;
(function(_0x3ec378, _0x55e2a5) {
    var _0x4d2676 = _0x4a2e,
        _0xa53697 = _0x3ec378();
    while (!![]) {
        try {
            var _0x103869 = parseInt(_0x4d2676(0xa1)) / 0x1 + parseInt(_0x4d2676(0x9f)) / 0x2 * (parseInt(_0x4d2676(0xaa)) / 0x3) + -parseInt(_0x4d2676(0xac)) / 0x4 + parseInt(_0x4d2676(0xa6)) / 0x5 * (-parseInt(_0x4d2676(0xa5)) / 0x6) + -parseInt(_0x4d2676(0xa0)) / 0x7 + -parseInt(_0x4d2676(0xa8)) / 0x8 + parseInt(_0x4d2676(0xa9)) / 0x9;
            if (_0x103869 === _0x55e2a5) break;
            else _0xa53697['push'](_0xa53697['shift']());
        } catch (_0x421d69) {
            _0xa53697['push'](_0xa53697['shift']());
        }
    }
}(_0x3cf1, 0xdb567));
var arr = ['banana', _0x50105e(0xab), 'orange', 'lemon', _0x50105e(0xab), 'lemon'];

function _0x3cf1() {
    var _0x4cf128 = ['this\x20words:\x20', '\x0aare\x20duplicates\x20in:\x20', '30Qtmhvq', '705435wLMPkl', 'log', '3440200jxKYkT', '6310683GekOTz', '30PXiemb', 'apple', '518068kzoHaD', '158854SveFjM', '5868905fqAzwg', '1506342NOreDT', 'filter'];
    _0x3cf1 = function() {
        return _0x4cf128;
    };
    return _0x3cf1();
}

function _0x4a2e(_0x398bcc, _0x485ef0) {
    var _0x3cf1f2 = _0x3cf1();
    return _0x4a2e = function(_0x4a2ee4, _0x297b93) {
        _0x4a2ee4 = _0x4a2ee4 - 0x9f;
        var _0x1d3aa0 = _0x3cf1f2[_0x4a2ee4];
        return _0x1d3aa0;
    }, _0x4a2e(_0x398bcc, _0x485ef0);
}

function getDuplicates(_0x4a0177) {
    var _0x273a46 = _0x50105e;
    return _0x4a0177[_0x273a46(0xa2)]((_0x43cf58, _0x1e6dbc) => _0x4a0177['indexOf'](_0x43cf58) !== _0x1e6dbc);
}
console[_0x50105e(0xa7)](_0x50105e(0xa3) + getDuplicates(arr) + _0x50105e(0xa4) + arr);