/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

var _0x4fb441 = _0x5ac7;

function _0x5ac7(_0x4bec47, _0x57659e) {
    var _0x139f50 = _0x139f();
    return _0x5ac7 = function(_0x5ac7d1, _0x3b790c) {
        _0x5ac7d1 = _0x5ac7d1 - 0x141;
        var _0x352508 = _0x139f50[_0x5ac7d1];
        return _0x352508;
    }, _0x5ac7(_0x4bec47, _0x57659e);
}

function _0x139f() {
    var _0x4e99df = ['07/12/2005', '3417436ROkIVU', '80gJYirC', 'Age\x20of\x20the\x20date\x20entered:\x20', '2136699rYSDbu', 'now', 'getUTCFullYear', '5302Auezuw', '776364olXYny', 'log', '164KGqpyj', '12aSAjMu', '42xaLEXo', '7184994TIFKdc', 'abs', '3759655FIqwHk', '241584gVADNA'];
    _0x139f = function() {
        return _0x4e99df;
    };
    return _0x139f();
}(function(_0x1d290d, _0x3e4900) {
    var _0x1149dd = _0x5ac7,
        _0x5ba282 = _0x1d290d();
    while (!![]) {
        try {
            var _0x39f5d2 = -parseInt(_0x1149dd(0x14b)) / 0x1 * (-parseInt(_0x1149dd(0x148)) / 0x2) + parseInt(_0x1149dd(0x149)) / 0x3 * (-parseInt(_0x1149dd(0x14c)) / 0x4) + -parseInt(_0x1149dd(0x150)) / 0x5 + -parseInt(_0x1149dd(0x14e)) / 0x6 + -parseInt(_0x1149dd(0x14d)) / 0x7 * (-parseInt(_0x1149dd(0x151)) / 0x8) + parseInt(_0x1149dd(0x145)) / 0x9 + parseInt(_0x1149dd(0x143)) / 0xa * (parseInt(_0x1149dd(0x142)) / 0xb);
            if (_0x39f5d2 === _0x3e4900) break;
            else _0x5ba282['push'](_0x5ba282['shift']());
        } catch (_0x257d71) {
            _0x5ba282['push'](_0x5ba282['shift']());
        }
    }
}(_0x139f, 0x95a71));
var dob = new Date(_0x4fb441(0x141)),
    month_diff = Date[_0x4fb441(0x146)]() - dob['getTime'](),
    age_dt = new Date(month_diff),
    year = age_dt[_0x4fb441(0x147)](),
    age = Math[_0x4fb441(0x14f)](year - 0x7b2);
console[_0x4fb441(0x14a)](_0x4fb441(0x144) + age + '\x20years');