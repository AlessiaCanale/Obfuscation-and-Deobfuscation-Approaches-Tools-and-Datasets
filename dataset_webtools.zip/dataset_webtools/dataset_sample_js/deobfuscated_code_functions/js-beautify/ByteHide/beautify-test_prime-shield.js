/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x319d(_0x2e7c9e, _0x2f8bf7) {
    var _0x8e1b6d = _0x8e1b();
    return _0x319d = function(_0x319d92, _0x56198e) {
        _0x319d92 = _0x319d92 - 0x176;
        var _0x2fa28d = _0x8e1b6d[_0x319d92];
        return _0x2fa28d;
    }, _0x319d(_0x2e7c9e, _0x2f8bf7);
}
var _0x5910c8 = _0x319d;
(function(_0x4d9bd7, _0x1f72ee) {
    var _0x52d1ea = _0x319d,
        _0x11a461 = _0x4d9bd7();
    while (!![]) {
        try {
            var _0x2db843 = parseInt(_0x52d1ea(0x17f)) / 0x1 * (-parseInt(_0x52d1ea(0x17e)) / 0x2) + parseInt(_0x52d1ea(0x178)) / 0x3 + parseInt(_0x52d1ea(0x176)) / 0x4 + -parseInt(_0x52d1ea(0x17a)) / 0x5 + -parseInt(_0x52d1ea(0x17c)) / 0x6 + -parseInt(_0x52d1ea(0x17b)) / 0x7 + -parseInt(_0x52d1ea(0x17d)) / 0x8 * (-parseInt(_0x52d1ea(0x179)) / 0x9);
            if (_0x2db843 === _0x1f72ee) break;
            else _0x11a461['push'](_0x11a461['shift']());
        } catch (_0x151b9a) {
            _0x11a461['push'](_0x11a461['shift']());
        }
    }
}(_0x8e1b, 0x71146));

function test_prime(_0x38a566) {
    if (_0x38a566 === 0x1) return ![];
    else {
        if (_0x38a566 === 0x2) return !![];
        else {
            for (var _0x4787c1 = 0x2; _0x4787c1 < _0x38a566; _0x4787c1++) {
                if (_0x38a566 % _0x4787c1 === 0x0) return ![];
            }
            return !![];
        }
    }
}

function _0x8e1b() {
    var _0x33b507 = ['1VLLLec', '1327948imhXHv', 'log', '2709078wxZpFE', '14382bUJKwC', '1748740NPybNt', '5558007TzSJqx', '755238HEowyH', '3232VHvnGm', '295618OYQuKj'];
    _0x8e1b = function() {
        return _0x33b507;
    };
    return _0x8e1b();
}
console[_0x5910c8(0x177)]('37\x20is\x20prime?\x20\x0a' + test_prime(0x25));