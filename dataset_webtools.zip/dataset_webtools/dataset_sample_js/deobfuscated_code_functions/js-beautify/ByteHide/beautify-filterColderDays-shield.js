/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x5867c3 = _0xb824;
(function(_0x1306d8, _0xc48df4) {
    const _0xc8a9ee = _0xb824,
        _0x2b48a5 = _0x1306d8();
    while (!![]) {
        try {
            const _0x18248b = parseInt(_0xc8a9ee(0x81)) / 0x1 * (-parseInt(_0xc8a9ee(0x8d)) / 0x2) + parseInt(_0xc8a9ee(0x82)) / 0x3 + -parseInt(_0xc8a9ee(0x8a)) / 0x4 * (-parseInt(_0xc8a9ee(0x7f)) / 0x5) + -parseInt(_0xc8a9ee(0x87)) / 0x6 * (-parseInt(_0xc8a9ee(0x86)) / 0x7) + parseInt(_0xc8a9ee(0x80)) / 0x8 + parseInt(_0xc8a9ee(0x84)) / 0x9 + -parseInt(_0xc8a9ee(0x8b)) / 0xa * (parseInt(_0xc8a9ee(0x8e)) / 0xb);
            if (_0x18248b === _0xc48df4) break;
            else _0x2b48a5['push'](_0x2b48a5['shift']());
        } catch (_0x2cbe3a) {
            _0x2b48a5['push'](_0x2b48a5['shift']());
        }
    }
}(_0xf90d, 0x3e0e1));
const weeklyReadings = [0x14, 0x16, 20.5, 0x13, 21.5, 0x17],
    colderDays = weeklyReadings[_0x5867c3(0x89)](_0x27af31 => {
        return _0x27af31 < 0x14;
    });
console['log'](_0x5867c3(0x88) + weeklyReadings + '\x0a'), console[_0x5867c3(0x8c)](colderDays);

function _0xf90d() {
    const _0x2a429e = ['4pNPuax', '30yoCISL', 'log', '12lAXhps', '3761417GaLNkm', '1748230pjCBCV', '4044216OzzKOY', '75314uyIoLd', '993402FhujVk', 'Yes,\x20there\x20were\x20colder\x20days\x20(<\x2020)\x20last\x20week', '4573575gmFKRw', 'No,\x20there\x20were\x20no\x20colder\x20days\x20(no\x20days\x20<\x2020)', '14loRSdp', '112260sqIdsp', 'weekly\x20readings:\x20', 'filter'];
    _0xf90d = function() {
        return _0x2a429e;
    };
    return _0xf90d();
}

function _0xb824(_0x43691b, _0xaecb1) {
    const _0xf90dfc = _0xf90d();
    return _0xb824 = function(_0xb82472, _0x415db3) {
        _0xb82472 = _0xb82472 - 0x7f;
        let _0x5c25b1 = _0xf90dfc[_0xb82472];
        return _0x5c25b1;
    }, _0xb824(_0x43691b, _0xaecb1);
}
colderDays != 0x0 ? console['log'](_0x5867c3(0x83)) : console['log'](_0x5867c3(0x85));