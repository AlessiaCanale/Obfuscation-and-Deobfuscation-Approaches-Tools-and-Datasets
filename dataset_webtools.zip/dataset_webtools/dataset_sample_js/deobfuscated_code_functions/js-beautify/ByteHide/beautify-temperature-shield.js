/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

var _0x247a9c = _0x1e05;

function _0x1e05(_0x47d53a, _0x1cf039) {
    var _0x71165c = _0x7116();
    return _0x1e05 = function(_0x1e05c4, _0x338bdd) {
        _0x1e05c4 = _0x1e05c4 - 0x1dd;
        var _0x1aae99 = _0x71165c[_0x1e05c4];
        return _0x1aae99;
    }, _0x1e05(_0x47d53a, _0x1cf039);
}(function(_0x287278, _0x2276a6) {
    var _0x1663d3 = _0x1e05,
        _0x5d677d = _0x287278();
    while (!![]) {
        try {
            var _0x10c34b = -parseInt(_0x1663d3(0x1e6)) / 0x1 * (-parseInt(_0x1663d3(0x1ee)) / 0x2) + -parseInt(_0x1663d3(0x1ec)) / 0x3 + parseInt(_0x1663d3(0x1eb)) / 0x4 + -parseInt(_0x1663d3(0x1e4)) / 0x5 * (parseInt(_0x1663d3(0x1e2)) / 0x6) + parseInt(_0x1663d3(0x1de)) / 0x7 * (parseInt(_0x1663d3(0x1e8)) / 0x8) + -parseInt(_0x1663d3(0x1e1)) / 0x9 * (-parseInt(_0x1663d3(0x1e9)) / 0xa) + -parseInt(_0x1663d3(0x1ea)) / 0xb;
            if (_0x10c34b === _0x2276a6) break;
            else _0x5d677d['push'](_0x5d677d['shift']());
        } catch (_0x3636e5) {
            _0x5d677d['push'](_0x5d677d['shift']());
        }
    }
}(_0x7116, 0x9b29c));

function temperature(_0x54c56f) {
    var _0x57c4af = _0x1e05;
    return _0x54c56f > 0x27 || _0x54c56f < 35.5 ? _0x57c4af(0x1df) : _0x54c56f < 37.5 && _0x54c56f > 36.5 ? 'go\x20out\x20and\x20play' : _0x54c56f <= 0x27 && _0x54c56f >= 35.5 ? _0x57c4af(0x1ed) : '';
}

function _0x7116() {
    var _0x19d66a = ['304695UppUGC', '30hvVAGj', 'temperature\x2037:\x20', '1124495hyJyge', 'temperature\x2035.1:\x20', '229HUocHN', 'log', '1375648sUSXFS', '240QDqHTD', '1226115zwCGlv', '2989144fXwIQc', '2571891hPABTw', 'take\x20some\x20rest!', '7206Outiwd', 'temperature\x2039.1:\x20', '14BXWryx', 'visit\x20doctor', 'temperature\x2038:\x20'];
    _0x7116 = function() {
        return _0x19d66a;
    };
    return _0x7116();
}
console[_0x247a9c(0x1e7)](_0x247a9c(0x1e0) + temperature(0x26)), console['log']('temperature\x2036:\x20' + temperature(0x24)), console[_0x247a9c(0x1e7)](_0x247a9c(0x1dd) + temperature(39.1)), console[_0x247a9c(0x1e7)](_0x247a9c(0x1e5) + temperature(35.1)), console[_0x247a9c(0x1e7)](_0x247a9c(0x1e3) + temperature(0x25));