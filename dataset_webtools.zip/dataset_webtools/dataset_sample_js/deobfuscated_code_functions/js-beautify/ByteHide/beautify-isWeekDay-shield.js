/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x401dc2 = _0x2455;

function _0x2455(_0x14fc0b, _0x4edbd4) {
    const _0x3a320f = _0x3a32();
    return _0x2455 = function(_0x2455d9, _0x38b586) {
        _0x2455d9 = _0x2455d9 - 0x17a;
        let _0x3f122c = _0x3a320f[_0x2455d9];
        return _0x3f122c;
    }, _0x2455(_0x14fc0b, _0x4edbd4);
}

function _0x3a32() {
    const _0x5bac9b = ['18JJEMIC', '756684qOjWVh', '10qPSMri', 'getDay', '3343024ADmsgm', '2UijnAF', '2897274wlWXxw', '14940996FvYtyB', '1601170qabTMT', '9HeeIdt', '861980LyGFUR', '11ICWKcC', '779140Zjofpf', 'log'];
    _0x3a32 = function() {
        return _0x5bac9b;
    };
    return _0x3a32();
}(function(_0x15b36f, _0x2597fa) {
    const _0x226935 = _0x2455,
        _0x414504 = _0x15b36f();
    while (!![]) {
        try {
            const _0x300199 = parseInt(_0x226935(0x17d)) / 0x1 * (parseInt(_0x226935(0x184)) / 0x2) + parseInt(_0x226935(0x17a)) / 0x3 * (-parseInt(_0x226935(0x180)) / 0x4) + -parseInt(_0x226935(0x181)) / 0x5 * (-parseInt(_0x226935(0x185)) / 0x6) + -parseInt(_0x226935(0x17b)) / 0x7 + parseInt(_0x226935(0x183)) / 0x8 * (parseInt(_0x226935(0x17f)) / 0x9) + parseInt(_0x226935(0x187)) / 0xa * (-parseInt(_0x226935(0x17c)) / 0xb) + -parseInt(_0x226935(0x186)) / 0xc;
            if (_0x300199 === _0x2597fa) break;
            else _0x414504['push'](_0x414504['shift']());
        } catch (_0x5bb33f) {
            _0x414504['push'](_0x414504['shift']());
        }
    }
}(_0x3a32, 0x765c1));
const isWeekday = _0x26217f => _0x26217f[_0x401dc2(0x182)]() % 0x6 !== 0x0;
console[_0x401dc2(0x17e)](isWeekday(new Date(0x7e5, 0x0, 0xb))), console[_0x401dc2(0x17e)](isWeekday(new Date(0x7e5, 0x0, 0xa)));