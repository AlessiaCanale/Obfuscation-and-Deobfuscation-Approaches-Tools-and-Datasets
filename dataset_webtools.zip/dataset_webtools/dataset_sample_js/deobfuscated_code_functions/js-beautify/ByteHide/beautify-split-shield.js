/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x24d092 = _0xeb7d;
(function(_0x29ab87, _0x44eb58) {
    const _0x360b6b = _0xeb7d,
        _0x381688 = _0x29ab87();
    while (!![]) {
        try {
            const _0x1a7dbb = -parseInt(_0x360b6b(0xd9)) / 0x1 + -parseInt(_0x360b6b(0xd0)) / 0x2 * (parseInt(_0x360b6b(0xd2)) / 0x3) + -parseInt(_0x360b6b(0xde)) / 0x4 + -parseInt(_0x360b6b(0xdf)) / 0x5 * (parseInt(_0x360b6b(0xd3)) / 0x6) + parseInt(_0x360b6b(0xd7)) / 0x7 * (parseInt(_0x360b6b(0xe0)) / 0x8) + -parseInt(_0x360b6b(0xd8)) / 0x9 * (parseInt(_0x360b6b(0xda)) / 0xa) + parseInt(_0x360b6b(0xdd)) / 0xb;
            if (_0x1a7dbb === _0x44eb58) break;
            else _0x381688['push'](_0x381688['shift']());
        } catch (_0xf55307) {
            _0x381688['push'](_0x381688['shift']());
        }
    }
}(_0x2879, 0x99eed));

function _0x2879() {
    const _0x4d643b = ['Hello\x20this\x20is\x20akashminds', 'text:\x20', '27335286DzhWHK', '3570504wUJaOi', '1246575qdDfCD', '8CSDlmX', '471894sIGjoc', '\x0atext:\x20', '3DSLQzs', '6vwelNy', '\x0asplit\x20using\x20space\x20and\x20index\x203:\x20', 'split', 'log', '8112083gfyPLN', '5288985QggeTl', '1047833VfJaHN', '10HUHDKg'];
    _0x2879 = function() {
        return _0x4d643b;
    };
    return _0x2879();
}
let text = 'Hello\x20this\x20is\x20akashminds';
console[_0x24d092(0xd6)](_0x24d092(0xdc) + text + '\x0asplit\x20using\x20space:\x20' + text[_0x24d092(0xd5)]('\x20'));

function _0xeb7d(_0x54cc43, _0xb550c) {
    const _0x2879eb = _0x2879();
    return _0xeb7d = function(_0xeb7ddc, _0x39167c) {
        _0xeb7ddc = _0xeb7ddc - 0xd0;
        let _0x2a86a6 = _0x2879eb[_0xeb7ddc];
        return _0x2a86a6;
    }, _0xeb7d(_0x54cc43, _0xb550c);
}
let text1 = _0x24d092(0xdb);
console[_0x24d092(0xd6)](_0x24d092(0xd1) + text1 + _0x24d092(0xd4) + text['split']('\x20', 0x3));