/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x2958ea = _0x2303;

function _0x4af5() {
    const _0xde8388 = ['102474uWpIoK', '32SIhyPD', '606ltuvnm', '1058240oghYVS', '4117800FwpSwy', 'clipboard', '1982512HJqIVo', '325XsOrRm', 'log', 'This\x20Sring\x20is\x20Copied\x20To\x20Clipboard.', '2014965yqgyIY', '7173550sIBNkS', '898ggJctl'];
    _0x4af5 = function() {
        return _0xde8388;
    };
    return _0x4af5();
}

function _0x2303(_0x1f8f01, _0x452b7a) {
    const _0x4af5bc = _0x4af5();
    return _0x2303 = function(_0x23033e, _0x264ecc) {
        _0x23033e = _0x23033e - 0x1dd;
        let _0x57fa70 = _0x4af5bc[_0x23033e];
        return _0x57fa70;
    }, _0x2303(_0x1f8f01, _0x452b7a);
}(function(_0x537d83, _0x1b5db9) {
    const _0x2ede8f = _0x2303,
        _0x2feb54 = _0x537d83();
    while (!![]) {
        try {
            const _0x2de9bf = parseInt(_0x2ede8f(0x1e3)) / 0x1 + parseInt(_0x2ede8f(0x1df)) / 0x2 * (parseInt(_0x2ede8f(0x1e2)) / 0x3) + -parseInt(_0x2ede8f(0x1e4)) / 0x4 + -parseInt(_0x2ede8f(0x1e7)) / 0x5 * (-parseInt(_0x2ede8f(0x1e0)) / 0x6) + -parseInt(_0x2ede8f(0x1e6)) / 0x7 + parseInt(_0x2ede8f(0x1e1)) / 0x8 * (-parseInt(_0x2ede8f(0x1dd)) / 0x9) + parseInt(_0x2ede8f(0x1de)) / 0xa;
            if (_0x2de9bf === _0x1b5db9) break;
            else _0x2feb54['push'](_0x2feb54['shift']());
        } catch (_0x5cd0c0) {
            _0x2feb54['push'](_0x2feb54['shift']());
        }
    }
}(_0x4af5, 0xbb8de));
const copyToClipboard = _0x113fad => navigator[_0x2958ea(0x1e5)]['writeText'](_0x113fad);
console[_0x2958ea(0x1e8)](copyToClipboard(_0x2958ea(0x1e9)));