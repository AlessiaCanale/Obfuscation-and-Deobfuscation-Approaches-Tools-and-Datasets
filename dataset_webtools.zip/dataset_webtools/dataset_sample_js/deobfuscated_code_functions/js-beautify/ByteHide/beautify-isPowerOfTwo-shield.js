/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x90d0(_0x388849, _0x17f12c) {
    var _0x341b79 = _0x341b();
    return _0x90d0 = function(_0x90d01c, _0x174dd7) {
        _0x90d01c = _0x90d01c - 0x1bb;
        var _0x1b7be6 = _0x341b79[_0x90d01c];
        return _0x1b7be6;
    }, _0x90d0(_0x388849, _0x17f12c);
}
var _0x45f7ca = _0x90d0;
(function(_0x10550c, _0x4a7dc0) {
    var _0x93e174 = _0x90d0,
        _0x347363 = _0x10550c();
    while (!![]) {
        try {
            var _0x3fac36 = -parseInt(_0x93e174(0x1be)) / 0x1 * (parseInt(_0x93e174(0x1bd)) / 0x2) + parseInt(_0x93e174(0x1c1)) / 0x3 * (-parseInt(_0x93e174(0x1c6)) / 0x4) + parseInt(_0x93e174(0x1c4)) / 0x5 * (parseInt(_0x93e174(0x1cb)) / 0x6) + -parseInt(_0x93e174(0x1bf)) / 0x7 * (-parseInt(_0x93e174(0x1bb)) / 0x8) + parseInt(_0x93e174(0x1bc)) / 0x9 + -parseInt(_0x93e174(0x1c3)) / 0xa + -parseInt(_0x93e174(0x1c9)) / 0xb * (-parseInt(_0x93e174(0x1c0)) / 0xc);
            if (_0x3fac36 === _0x4a7dc0) break;
            else _0x347363['push'](_0x347363['shift']());
        } catch (_0x3106f5) {
            _0x347363['push'](_0x347363['shift']());
        }
    }
}(_0x341b, 0x3cbde));

function isPowerOfTwo(_0x1dbf63) {
    var _0x2eaf4b = _0x90d0;
    if (_0x1dbf63 == 0x0) return ![];
    return Math[_0x2eaf4b(0x1c8)](Math[_0x2eaf4b(0x1c7)](_0x1dbf63) / Math[_0x2eaf4b(0x1c7)](0x2)) == Math[_0x2eaf4b(0x1ca)](Math[_0x2eaf4b(0x1c7)](_0x1dbf63) / Math[_0x2eaf4b(0x1c7)](0x2));
}
console['log'](_0x45f7ca(0x1cc));
if (isPowerOfTwo(0x1f)) console[_0x45f7ca(0x1c7)](_0x45f7ca(0x1c2));
else console[_0x45f7ca(0x1c7)]('No');
console[_0x45f7ca(0x1c7)](_0x45f7ca(0x1c5));
if (isPowerOfTwo(0x40)) console['log'](_0x45f7ca(0x1c2));
else console[_0x45f7ca(0x1c7)]('No');

function _0x341b() {
    var _0x43487a = ['2046582XGQqmN', '51654TdNbny', '9AwUBAg', '7lKiTho', '10936308gULjBn', '684339xFSWcG', 'Yes', '4966870rWCyBG', '76690wkfMyv', '64\x20is\x20a\x20power\x20of\x20two?', '8vRpkJR', 'log', 'ceil', '11zaJcPL', 'floor', '90UKcnqz', '31\x20is\x20a\x20power\x20of\x20two?', '522616pzesXC'];
    _0x341b = function() {
        return _0x43487a;
    };
    return _0x341b();
}