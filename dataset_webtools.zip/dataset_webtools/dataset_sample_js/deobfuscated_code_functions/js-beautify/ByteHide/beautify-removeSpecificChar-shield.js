/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x349e(_0x30fe67, _0x301ba4) {
    const _0x14c7b3 = _0x14c7();
    return _0x349e = function(_0x349e77, _0x33c98b) {
        _0x349e77 = _0x349e77 - 0x19d;
        let _0x4855fb = _0x14c7b3[_0x349e77];
        return _0x4855fb;
    }, _0x349e(_0x30fe67, _0x301ba4);
}
const _0x35fc5a = _0x349e;
(function(_0x21b750, _0x493ace) {
    const _0x4eef8e = _0x349e,
        _0x5cb8a6 = _0x21b750();
    while (!![]) {
        try {
            const _0x7c4c5b = parseInt(_0x4eef8e(0x19f)) / 0x1 * (parseInt(_0x4eef8e(0x1a2)) / 0x2) + -parseInt(_0x4eef8e(0x1ab)) / 0x3 + parseInt(_0x4eef8e(0x1a6)) / 0x4 + parseInt(_0x4eef8e(0x1a4)) / 0x5 * (-parseInt(_0x4eef8e(0x1aa)) / 0x6) + -parseInt(_0x4eef8e(0x1a5)) / 0x7 + -parseInt(_0x4eef8e(0x19d)) / 0x8 + -parseInt(_0x4eef8e(0x1a9)) / 0x9 * (-parseInt(_0x4eef8e(0x1a7)) / 0xa);
            if (_0x7c4c5b === _0x493ace) break;
            else _0x5cb8a6['push'](_0x5cb8a6['shift']());
        } catch (_0x117b26) {
            _0x5cb8a6['push'](_0x5cb8a6['shift']());
        }
    }
}(_0x14c7, 0x4d0a2));
const str = _0x35fc5a(0x1a8),
    str1 = 'ACLz$\x20@H{oKk';
console[_0x35fc5a(0x1a0)](_0x35fc5a(0x1a3) + str + _0x35fc5a(0x1a1) + str[_0x35fc5a(0x19e)](/[^a-zA-Z ]/g, '')), console['log'](_0x35fc5a(0x1a3) + str1 + _0x35fc5a(0x1a1) + str1['replace'](/[^a-zA-Z ]/g, ''));

function _0x14c7() {
    const _0x123456 = ['611574ezHVlD', '2281696fvpVoG', 'replace', '6mwcSZA', 'log', '\x0ano\x20specific\x20char:\x20', '170120fhTnCt', 'original:\x20', '3096085rUGEmw', '2079035wcvWVY', '1290728BDsKVR', '40KPsiOv', 'abc\x27s\x20test#s', '1997559QQcNrW', '6EDXKPa'];
    _0x14c7 = function() {
        return _0x123456;
    };
    return _0x14c7();
}