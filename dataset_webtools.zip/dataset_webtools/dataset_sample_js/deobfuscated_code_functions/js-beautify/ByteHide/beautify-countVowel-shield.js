/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x58d9e8 = _0x409a;
(function(_0x3a24d2, _0x906dbd) {
    const _0x110e30 = _0x409a,
        _0x4c44ef = _0x3a24d2();
    while (!![]) {
        try {
            const _0x4453be = parseInt(_0x110e30(0x1e8)) / 0x1 * (parseInt(_0x110e30(0x1eb)) / 0x2) + -parseInt(_0x110e30(0x1ed)) / 0x3 + parseInt(_0x110e30(0x1f5)) / 0x4 * (-parseInt(_0x110e30(0x1e7)) / 0x5) + parseInt(_0x110e30(0x1e9)) / 0x6 * (-parseInt(_0x110e30(0x1ee)) / 0x7) + -parseInt(_0x110e30(0x1ec)) / 0x8 + parseInt(_0x110e30(0x1f2)) / 0x9 * (parseInt(_0x110e30(0x1f0)) / 0xa) + parseInt(_0x110e30(0x1f6)) / 0xb;
            if (_0x4453be === _0x906dbd) break;
            else _0x4c44ef['push'](_0x4c44ef['shift']());
        } catch (_0x18ea40) {
            _0x4c44ef['push'](_0x4c44ef['shift']());
        }
    }
}(_0x33e2, 0x97e92));

function _0x409a(_0x4403da, _0x14afcc) {
    const _0x33e279 = _0x33e2();
    return _0x409a = function(_0x409a8e, _0x3c55c3) {
        _0x409a8e = _0x409a8e - 0x1e7;
        let _0xdf36bf = _0x33e279[_0x409a8e];
        return _0xdf36bf;
    }, _0x409a(_0x4403da, _0x14afcc);
}

function countVowel(_0x290ecd) {
    const _0x12181c = _0x409a,
        _0x11e44b = _0x290ecd[_0x12181c(0x1f4)](/[aeiou]/gi)[_0x12181c(0x1ef)];
    return _0x11e44b;
}
const string = _0x58d9e8(0x1f1),
    result = countVowel(string);

function _0x33e2() {
    const _0x48ef27 = ['1008Yyumcs', '48ElweZe', 'log', '1478IqWsAm', '2525448GAPtOf', '917220OucSna', '863800EIvzdI', 'length', '400krgXeo', 'computer', '157122dvPbZX', 'in\x20', 'match', '4YvXkLo', '20899549qzFYCU', '5561720Xetsfx'];
    _0x33e2 = function() {
        return _0x48ef27;
    };
    return _0x33e2();
}
console[_0x58d9e8(0x1ea)](_0x58d9e8(0x1f3) + string + '\x20there\x20are:\x20' + result + '\x20vowels');