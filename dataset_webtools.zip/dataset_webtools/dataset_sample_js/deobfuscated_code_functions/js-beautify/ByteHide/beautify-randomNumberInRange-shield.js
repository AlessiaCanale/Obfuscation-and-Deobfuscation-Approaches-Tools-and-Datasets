/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x14f696 = _0x3a21;

function _0x4b07() {
    const _0x4b137a = ['floor', '3NuMhGV', '1374996YpRvJh', '4yOytwl', '7643320OnFWuJ', '18fswhsV', '58368NuUhVC', '35546ZHzyJj', '1742955cFqoKo', 'log', '318nwQGAq', '1940446QqEQvZ', '718355ggDWdB', '22LTQwfv'];
    _0x4b07 = function() {
        return _0x4b137a;
    };
    return _0x4b07();
}(function(_0x5dfa56, _0x3d71aa) {
    const _0x3e3f29 = _0x3a21,
        _0x3c83f6 = _0x5dfa56();
    while (!![]) {
        try {
            const _0x4000c0 = parseInt(_0x3e3f29(0x163)) / 0x1 + -parseInt(_0x3e3f29(0x162)) / 0x2 * (parseInt(_0x3e3f29(0x158)) / 0x3) + -parseInt(_0x3e3f29(0x15a)) / 0x4 * (parseInt(_0x3e3f29(0x15f)) / 0x5) + parseInt(_0x3e3f29(0x161)) / 0x6 * (-parseInt(_0x3e3f29(0x15e)) / 0x7) + parseInt(_0x3e3f29(0x15d)) / 0x8 * (parseInt(_0x3e3f29(0x15c)) / 0x9) + parseInt(_0x3e3f29(0x15b)) / 0xa * (parseInt(_0x3e3f29(0x164)) / 0xb) + parseInt(_0x3e3f29(0x159)) / 0xc;
            if (_0x4000c0 === _0x3d71aa) break;
            else _0x3c83f6['push'](_0x3c83f6['shift']());
        } catch (_0x360b04) {
            _0x3c83f6['push'](_0x3c83f6['shift']());
        }
    }
}(_0x4b07, 0xc0716));

function _0x3a21(_0x5de2d3, _0x19a500) {
    const _0x4b0777 = _0x4b07();
    return _0x3a21 = function(_0x3a217b, _0x2cbcac) {
        _0x3a217b = _0x3a217b - 0x158;
        let _0x370d75 = _0x4b0777[_0x3a217b];
        return _0x370d75;
    }, _0x3a21(_0x5de2d3, _0x19a500);
}
const randomNumberInRange = (_0x263231 = 0x0, _0x5bb826 = 0x64) => Math[_0x14f696(0x165)](Math['random']() * (_0x5bb826 - _0x263231 + 0x1)) + _0x263231;
randomNumberInRange(), console[_0x14f696(0x160)](randomNumberInRange(0x64, 0xc8));