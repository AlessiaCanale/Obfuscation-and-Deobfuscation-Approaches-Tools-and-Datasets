/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x4198() {
    const _0x42799e = ['peacock', '68zMLWVi', '\x0aincludes\x20Dove?\x20', 'log', 'Birds', '10473DWcedZ', '628350KfkXMg', 'birds:\x20', '16317XWaTZs', '62775AieOyR', 'includes', '106044hPDako', '6067720YfBBtv', 'Dove', '2GLpjep', '455024neHycJ', '270fnrEti'];
    _0x4198 = function() {
        return _0x42799e;
    };
    return _0x4198();
}

function _0x1997(_0x25d6b9, _0xab77b1) {
    const _0x419842 = _0x4198();
    return _0x1997 = function(_0x199793, _0x104b49) {
        _0x199793 = _0x199793 - 0xca;
        let _0x251801 = _0x419842[_0x199793];
        return _0x251801;
    }, _0x1997(_0x25d6b9, _0xab77b1);
}
const _0x4a49cf = _0x1997;
(function(_0x16b7b0, _0x117c9b) {
    const _0x5e1330 = _0x1997,
        _0x12766a = _0x16b7b0();
    while (!![]) {
        try {
            const _0x1ce498 = parseInt(_0x5e1330(0xcc)) / 0x1 * (-parseInt(_0x5e1330(0xcf)) / 0x2) + parseInt(_0x5e1330(0xd7)) / 0x3 * (-parseInt(_0x5e1330(0xd3)) / 0x4) + -parseInt(_0x5e1330(0xd8)) / 0x5 + parseInt(_0x5e1330(0xd1)) / 0x6 * (-parseInt(_0x5e1330(0xda)) / 0x7) + -parseInt(_0x5e1330(0xd0)) / 0x8 + -parseInt(_0x5e1330(0xca)) / 0x9 + parseInt(_0x5e1330(0xcd)) / 0xa;
            if (_0x1ce498 === _0x117c9b) break;
            else _0x12766a['push'](_0x12766a['shift']());
        } catch (_0x353a0) {
            _0x12766a['push'](_0x12766a['shift']());
        }
    }
}(_0x4198, 0x23e13));
const birds = [_0x4a49cf(0xd6), _0x4a49cf(0xd2), _0x4a49cf(0xce), 'Sparrow'];
console[_0x4a49cf(0xd5)](_0x4a49cf(0xd9) + birds + _0x4a49cf(0xd4) + birds[_0x4a49cf(0xcb)](_0x4a49cf(0xce)));