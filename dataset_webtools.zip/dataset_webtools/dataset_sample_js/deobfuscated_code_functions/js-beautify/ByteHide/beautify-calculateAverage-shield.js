/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

var _0x1c07d6 = _0x5d99;

function _0x5d99(_0x59d9f2, _0x296b5e) {
    var _0x13101e = _0x1310();
    return _0x5d99 = function(_0x5d99af, _0x58e587) {
        _0x5d99af = _0x5d99af - 0x1a9;
        var _0x7d0d33 = _0x13101e[_0x5d99af];
        return _0x7d0d33;
    }, _0x5d99(_0x59d9f2, _0x296b5e);
}

function _0x1310() {
    var _0x2a4ca0 = ['343372ihFpbR', '1RjRONQ', '21oOObwa', '3376568urvJCc', '35724DwWRfw', 'length', '52130wLaGyY', 'log', '6540525BxKuvI', '1947uuvAqp', '1215974gxPnVX', '30GqOLcQ', '923838YxXHNR'];
    _0x1310 = function() {
        return _0x2a4ca0;
    };
    return _0x1310();
}(function(_0x5e090e, _0x4a3150) {
    var _0x3f0db8 = _0x5d99,
        _0x1c9a70 = _0x5e090e();
    while (!![]) {
        try {
            var _0x41d56b = parseInt(_0x3f0db8(0x1af)) / 0x1 * (-parseInt(_0x3f0db8(0x1ab)) / 0x2) + -parseInt(_0x3f0db8(0x1b2)) / 0x3 + parseInt(_0x3f0db8(0x1ae)) / 0x4 * (-parseInt(_0x3f0db8(0x1ac)) / 0x5) + parseInt(_0x3f0db8(0x1ad)) / 0x6 * (-parseInt(_0x3f0db8(0x1b0)) / 0x7) + parseInt(_0x3f0db8(0x1b1)) / 0x8 + parseInt(_0x3f0db8(0x1a9)) / 0x9 + parseInt(_0x3f0db8(0x1b4)) / 0xa * (parseInt(_0x3f0db8(0x1aa)) / 0xb);
            if (_0x41d56b === _0x4a3150) break;
            else _0x1c9a70['push'](_0x1c9a70['shift']());
        } catch (_0x19661a) {
            _0x1c9a70['push'](_0x1c9a70['shift']());
        }
    }
}(_0x1310, 0x73e01));

function calculateAverage(_0xbd4cd) {
    var _0x6eef2 = _0x5d99,
        _0x1f2086 = 0x0;
    for (var _0x56fd17 = 0x0; _0x56fd17 < _0xbd4cd[_0x6eef2(0x1b3)]; _0x56fd17++) {
        _0x1f2086 += _0xbd4cd[_0x56fd17];
    }
    return _0x1f2086 / _0xbd4cd[_0x6eef2(0x1b3)];
}
var array = [0x1, 0x2, 0x3, 0x4, 0x5],
    average = calculateAverage(array);
console[_0x1c07d6(0x1b5)](average);