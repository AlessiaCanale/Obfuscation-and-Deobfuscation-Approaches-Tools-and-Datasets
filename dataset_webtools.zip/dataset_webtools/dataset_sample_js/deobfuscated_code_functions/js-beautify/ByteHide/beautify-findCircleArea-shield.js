/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x4626fd = _0x1283;

function _0x1283(_0x4ccef5, _0x4118f0) {
    const _0x12b379 = _0x12b3();
    return _0x1283 = function(_0x128318, _0x149ba6) {
        _0x128318 = _0x128318 - 0x73;
        let _0x3c3cd0 = _0x12b379[_0x128318];
        return _0x3c3cd0;
    }, _0x1283(_0x4ccef5, _0x4118f0);
}(function(_0x1c48e1, _0x219b41) {
    const _0x8b181c = _0x1283,
        _0x71a9b0 = _0x1c48e1();
    while (!![]) {
        try {
            const _0x402cef = parseInt(_0x8b181c(0x75)) / 0x1 * (parseInt(_0x8b181c(0x7d)) / 0x2) + -parseInt(_0x8b181c(0x78)) / 0x3 + parseInt(_0x8b181c(0x7a)) / 0x4 + -parseInt(_0x8b181c(0x7e)) / 0x5 * (-parseInt(_0x8b181c(0x73)) / 0x6) + -parseInt(_0x8b181c(0x76)) / 0x7 + -parseInt(_0x8b181c(0x74)) / 0x8 * (-parseInt(_0x8b181c(0x7b)) / 0x9) + -parseInt(_0x8b181c(0x77)) / 0xa;
            if (_0x402cef === _0x219b41) break;
            else _0x71a9b0['push'](_0x71a9b0['shift']());
        } catch (_0x478286) {
            _0x71a9b0['push'](_0x71a9b0['shift']());
        }
    }
}(_0x12b3, 0xb7080));
let pi = 3.141592653589793;

function findArea(_0x2041a7) {
    return pi * _0x2041a7 * _0x2041a7;
}

function _0x12b3() {
    const _0x446067 = ['3341745ofEJjg', 'log', '581352vYAZwO', '9gVNfCb', 'Area\x20of\x20Circle\x20with\x20r\x20', '616QIeTnI', '355TpSley', '119562xsxZqN', '3806104QzXycV', '3399ceXhOZ', '4295515PwPPCj', '6055540SupNuz'];
    _0x12b3 = function() {
        return _0x446067;
    };
    return _0x12b3();
}
let r, Area;
r = 0x5, Area = findArea(r), console[_0x4626fd(0x79)](_0x4626fd(0x7c) + r + '\x20is:\x20' + Area);