/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

var _0x2dfef9 = _0xd18b;
(function(_0x240cbd, _0x41ec43) {
    var _0x2e3dea = _0xd18b,
        _0x35b90c = _0x240cbd();
    while (!![]) {
        try {
            var _0x573f37 = -parseInt(_0x2e3dea(0x82)) / 0x1 * (-parseInt(_0x2e3dea(0x80)) / 0x2) + parseInt(_0x2e3dea(0x7e)) / 0x3 + parseInt(_0x2e3dea(0x7d)) / 0x4 + -parseInt(_0x2e3dea(0x78)) / 0x5 * (parseInt(_0x2e3dea(0x7b)) / 0x6) + -parseInt(_0x2e3dea(0x81)) / 0x7 * (parseInt(_0x2e3dea(0x7c)) / 0x8) + parseInt(_0x2e3dea(0x7a)) / 0x9 * (-parseInt(_0x2e3dea(0x85)) / 0xa) + -parseInt(_0x2e3dea(0x79)) / 0xb * (-parseInt(_0x2e3dea(0x83)) / 0xc);
            if (_0x573f37 === _0x41ec43) break;
            else _0x35b90c['push'](_0x35b90c['shift']());
        } catch (_0x1f10e5) {
            _0x35b90c['push'](_0x35b90c['shift']());
        }
    }
}(_0x9aee, 0x90155));
var decimalNumber = 0xff,
    hexNumber = decimalNumber[_0x2dfef9(0x84)](0x10);
console[_0x2dfef9(0x7f)](decimalNumber + '\x20from\x20decimal\x20form\x20to\x20hexadecimal\x20form:\x200x' + hexNumber);

function _0xd18b(_0x59aa84, _0x46b8d0) {
    var _0x9aeec6 = _0x9aee();
    return _0xd18b = function(_0xd18b7f, _0x3e9060) {
        _0xd18b7f = _0xd18b7f - 0x78;
        var _0x45d9b4 = _0x9aeec6[_0xd18b7f];
        return _0x45d9b4;
    }, _0xd18b(_0x59aa84, _0x46b8d0);
}

function _0x9aee() {
    var _0x1e69f2 = ['6980mWYNBe', '179455CpzJJT', '341SCRUDz', '11367SiDErH', '18lqHYnd', '104suyuNf', '1934916ktnmbH', '535965iTCMDG', 'log', '4pXQOLr', '244727gqwVaC', '322022iBFVek', '281604oYHJJp', 'toString'];
    _0x9aee = function() {
        return _0x1e69f2;
    };
    return _0x9aee();
}