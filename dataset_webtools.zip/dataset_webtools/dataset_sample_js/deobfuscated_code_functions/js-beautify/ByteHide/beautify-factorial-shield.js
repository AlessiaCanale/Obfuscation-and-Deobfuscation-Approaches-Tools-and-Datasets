/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

var _0x222625 = _0x43e4;
(function(_0x76526c, _0x247634) {
    var _0x121c0b = _0x43e4,
        _0x44927d = _0x76526c();
    while (!![]) {
        try {
            var _0xf7a002 = parseInt(_0x121c0b(0x8c)) / 0x1 * (-parseInt(_0x121c0b(0x94)) / 0x2) + -parseInt(_0x121c0b(0x8b)) / 0x3 * (parseInt(_0x121c0b(0x8d)) / 0x4) + -parseInt(_0x121c0b(0x8a)) / 0x5 * (parseInt(_0x121c0b(0x93)) / 0x6) + -parseInt(_0x121c0b(0x92)) / 0x7 + parseInt(_0x121c0b(0x91)) / 0x8 + -parseInt(_0x121c0b(0x8e)) / 0x9 + parseInt(_0x121c0b(0x90)) / 0xa;
            if (_0xf7a002 === _0x247634) break;
            else _0x44927d['push'](_0x44927d['shift']());
        } catch (_0x470a53) {
            _0x44927d['push'](_0x44927d['shift']());
        }
    }
}(_0x2d6a, 0x8ad1c));

function factorial(_0x41083c) {
    return _0x41083c != 0x1 ? _0x41083c * factorial(_0x41083c - 0x1) : 0x1;
}
console['log'](_0x222625(0x8f) + factorial(0x5));

function _0x2d6a() {
    var _0x5c3c23 = ['factorial\x20of\x205\x20=\x20', '13039890qOxzqD', '6936808qOXrhm', '914809SKklLm', '10548aDHchk', '2XhIGCr', '1315XyjJYr', '3rWjUvr', '245220WUPuCj', '456028cMOcZY', '5851962yrFEpW'];
    _0x2d6a = function() {
        return _0x5c3c23;
    };
    return _0x2d6a();
}

function _0x43e4(_0x2e0190, _0x19fdf4) {
    var _0x2d6a32 = _0x2d6a();
    return _0x43e4 = function(_0x43e4bb, _0x429a07) {
        _0x43e4bb = _0x43e4bb - 0x8a;
        var _0x3801c9 = _0x2d6a32[_0x43e4bb];
        return _0x3801c9;
    }, _0x43e4(_0x2e0190, _0x19fdf4);
}

function factorial1(_0x313e1b) {
    return _0x313e1b ? _0x313e1b * factorial(_0x313e1b - 0x1) : 0x1;
}
console['log'](_0x222625(0x8f) + factorial1(0x5));