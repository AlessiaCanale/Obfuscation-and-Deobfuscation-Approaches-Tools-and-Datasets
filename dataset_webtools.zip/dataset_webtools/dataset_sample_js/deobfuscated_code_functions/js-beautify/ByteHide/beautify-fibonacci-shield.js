/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x2628(_0x26ba5d, _0x2a183b) {
    const _0x45810e = _0x4581();
    return _0x2628 = function(_0x2628c0, _0x50cc7a) {
        _0x2628c0 = _0x2628c0 - 0x177;
        let _0x149adf = _0x45810e[_0x2628c0];
        return _0x149adf;
    }, _0x2628(_0x26ba5d, _0x2a183b);
}

function _0x4581() {
    const _0x4b87bc = ['2095646XpIxFn', 'log', 'Fibonacci\x20Series:', '3064730NNyZio', '6IMDFLq', '6FowFjP', '143684escURt', '9cIOerB', '72yOGxaD', '3000239GcSivk', '1924915xIJhjF', '81224DMBHLw', '132687psOdbR'];
    _0x4581 = function() {
        return _0x4b87bc;
    };
    return _0x4581();
}
const _0x221124 = _0x2628;
(function(_0x3acb59, _0x2cfb67) {
    const _0x35d618 = _0x2628,
        _0x512519 = _0x3acb59();
    while (!![]) {
        try {
            const _0x551e65 = -parseInt(_0x35d618(0x17a)) / 0x1 * (-parseInt(_0x35d618(0x181)) / 0x2) + -parseInt(_0x35d618(0x17d)) / 0x3 * (parseInt(_0x35d618(0x17c)) / 0x4) + -parseInt(_0x35d618(0x180)) / 0x5 * (parseInt(_0x35d618(0x17b)) / 0x6) + parseInt(_0x35d618(0x183)) / 0x7 + -parseInt(_0x35d618(0x17e)) / 0x8 * (-parseInt(_0x35d618(0x182)) / 0x9) + parseInt(_0x35d618(0x179)) / 0xa + -parseInt(_0x35d618(0x17f)) / 0xb;
            if (_0x551e65 === _0x2cfb67) break;
            else _0x512519['push'](_0x512519['shift']());
        } catch (_0x3635a3) {
            _0x512519['push'](_0x512519['shift']());
        }
    }
}(_0x4581, 0x34e8b));
const number = 0xc;
let n1 = 0x0,
    n2 = 0x1,
    nextTerm, count = 0x2;
console[_0x221124(0x177)](_0x221124(0x178)), console[_0x221124(0x177)](n1), console[_0x221124(0x177)](n2), nextTerm = n1 + n2;
while (count <= number) {
    console[_0x221124(0x177)](nextTerm), n1 = n2, n2 = nextTerm, nextTerm = n1 + n2, count++;
}