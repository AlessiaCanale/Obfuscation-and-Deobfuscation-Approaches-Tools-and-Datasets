/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

var _0x253071 = _0x4813;

function _0x4813(_0x27b51f, _0x59e4ce) {
    var _0x4e3d2c = _0x4e3d();
    return _0x4813 = function(_0x481394, _0x50f846) {
        _0x481394 = _0x481394 - 0xd3;
        var _0x523e67 = _0x4e3d2c[_0x481394];
        return _0x523e67;
    }, _0x4813(_0x27b51f, _0x59e4ce);
}(function(_0x549ee5, _0x1e0ab1) {
    var _0x523b8f = _0x4813,
        _0x215d95 = _0x549ee5();
    while (!![]) {
        try {
            var _0x2dd37e = -parseInt(_0x523b8f(0xd4)) / 0x1 + parseInt(_0x523b8f(0xd3)) / 0x2 + -parseInt(_0x523b8f(0xde)) / 0x3 * (parseInt(_0x523b8f(0xd6)) / 0x4) + -parseInt(_0x523b8f(0xd7)) / 0x5 * (-parseInt(_0x523b8f(0xdb)) / 0x6) + -parseInt(_0x523b8f(0xe0)) / 0x7 + -parseInt(_0x523b8f(0xd9)) / 0x8 + parseInt(_0x523b8f(0xd8)) / 0x9;
            if (_0x2dd37e === _0x1e0ab1) break;
            else _0x215d95['push'](_0x215d95['shift']());
        } catch (_0x42d409) {
            _0x215d95['push'](_0x215d95['shift']());
        }
    }
}(_0x4e3d, 0xb2aaa));
var arr = [_0x253071(0xe1), _0x253071(0xe2), _0x253071(0xda), 'peace', _0x253071(0xe3)];

function concatEvenWords(_0x23c1b0) {
    var _0x1c6e98 = _0x253071,
        _0x4f28b6 = 0x0;
    let _0x157e70 = '';
    for (_0x4f28b6 = 0x0; _0x4f28b6 < arr[_0x1c6e98(0xdc)]; _0x4f28b6++) {
        arr[_0x4f28b6]['length'] % 0x2 == 0x0 && (_0x157e70 = _0x157e70['concat'](arr[_0x4f28b6]));
    }
    return _0x157e70;
}

function _0x4e3d() {
    var _0x14b69f = ['59165shPNHU', '9270738oDONWQ', '9946936xrlhoB', 'moon', '348gVIssu', 'length', 'array:\x20', '11058lUZQuy', '\x0aresult:\x20', '2183230fBgvGJ', 'blue', 'light', 'cloud', '1663878gblWqi', '58530LfVxpb', 'log', '220mabcaZ'];
    _0x4e3d = function() {
        return _0x14b69f;
    };
    return _0x4e3d();
}
console[_0x253071(0xd5)](_0x253071(0xdd) + arr + _0x253071(0xdf) + concatEvenWords(arr));