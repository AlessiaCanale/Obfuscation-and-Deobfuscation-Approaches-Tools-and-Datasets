/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x5772b7 = _0x5534;
(function(_0x2d738e, _0x4aeecb) {
    const _0x35488c = _0x5534,
        _0x4a9fcd = _0x2d738e();
    while (!![]) {
        try {
            const _0x2c3068 = -parseInt(_0x35488c(0xf4)) / 0x1 + parseInt(_0x35488c(0xf8)) / 0x2 + parseInt(_0x35488c(0xf2)) / 0x3 + -parseInt(_0x35488c(0xfb)) / 0x4 + parseInt(_0x35488c(0xf3)) / 0x5 * (-parseInt(_0x35488c(0xff)) / 0x6) + parseInt(_0x35488c(0xf6)) / 0x7 * (-parseInt(_0x35488c(0xfc)) / 0x8) + -parseInt(_0x35488c(0xf5)) / 0x9 * (-parseInt(_0x35488c(0xfa)) / 0xa);
            if (_0x2c3068 === _0x4aeecb) break;
            else _0x4a9fcd['push'](_0x4a9fcd['shift']());
        } catch (_0x24c304) {
            _0x4a9fcd['push'](_0x4a9fcd['shift']());
        }
    }
}(_0x4c7d, 0x7b0f8));
var arr = ['hi,', 'I', 'am', 'an', _0x5772b7(0xfe)];

function concatArray(_0x51b914) {
    const _0x3b4eaa = _0x5772b7;
    let _0x490c48 = '';
    for (let _0x429710 = 0x0; _0x429710 < _0x51b914[_0x3b4eaa(0xfd)]; _0x429710++) {
        _0x490c48 = _0x490c48[_0x3b4eaa(0xf7)](_0x51b914[_0x429710], '\x20');
    }
    return _0x490c48;
}

function _0x4c7d() {
    const _0x5a0538 = ['10SyxBbU', '2772664dSKkys', '8eixOTF', 'length', 'array', '5389668DekSon', '1982616hPadfK', '5yhEyUz', '475796BAuZlD', '18635697aJCkRk', '3361323PHIfWv', 'concat', '639960bXLrcD', 'log'];
    _0x4c7d = function() {
        return _0x5a0538;
    };
    return _0x4c7d();
}

function _0x5534(_0x44aebb, _0x49783a) {
    const _0x4c7dbc = _0x4c7d();
    return _0x5534 = function(_0x553440, _0x50a040) {
        _0x553440 = _0x553440 - 0xf2;
        let _0x506c9a = _0x4c7dbc[_0x553440];
        return _0x506c9a;
    }, _0x5534(_0x44aebb, _0x49783a);
}
console[_0x5772b7(0xf9)]('array:\x20' + arr + '\x0aconcatenation:\x20' + concatArray(arr));