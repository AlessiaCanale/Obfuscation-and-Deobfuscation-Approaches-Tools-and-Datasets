/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x484433 = _0x3c11;

function _0x3c11(_0x271858, _0x3bd090) {
    const _0x542119 = _0x5421();
    return _0x3c11 = function(_0x3c11eb, _0x333e0b) {
        _0x3c11eb = _0x3c11eb - 0x91;
        let _0x1a3fd0 = _0x542119[_0x3c11eb];
        return _0x1a3fd0;
    }, _0x3c11(_0x271858, _0x3bd090);
}(function(_0x3ec0c7, _0x164636) {
    const _0x5dd77d = _0x3c11,
        _0x11f587 = _0x3ec0c7();
    while (!![]) {
        try {
            const _0x2156a0 = -parseInt(_0x5dd77d(0x94)) / 0x1 + -parseInt(_0x5dd77d(0x93)) / 0x2 + parseInt(_0x5dd77d(0x95)) / 0x3 * (parseInt(_0x5dd77d(0x91)) / 0x4) + parseInt(_0x5dd77d(0x96)) / 0x5 + parseInt(_0x5dd77d(0x92)) / 0x6 + -parseInt(_0x5dd77d(0x97)) / 0x7 + parseInt(_0x5dd77d(0x98)) / 0x8;
            if (_0x2156a0 === _0x164636) break;
            else _0x11f587['push'](_0x11f587['shift']());
        } catch (_0x1e8cb3) {
            _0x11f587['push'](_0x11f587['shift']());
        }
    }
}(_0x5421, 0xcead1));
const goToTop = () => window[_0x484433(0x99)](0x0, 0x0);
goToTop();

function _0x5421() {
    const _0x4487de = ['2476vNihOS', '7682118ZYMjLV', '2352834nZrmjU', '1364461JvzIYW', '3099ikqorZ', '7659950Njafxk', '6985055bsEvXp', '7468144geDkMF', 'scrollTo'];
    _0x5421 = function() {
        return _0x4487de;
    };
    return _0x5421();
}