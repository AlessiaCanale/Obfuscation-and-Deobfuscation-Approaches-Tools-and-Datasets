/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x26bcdf = _0x3298;
(function(_0x6904df, _0x132b26) {
    const _0x2994c3 = _0x3298,
        _0x351888 = _0x6904df();
    while (!![]) {
        try {
            const _0x45d679 = parseInt(_0x2994c3(0xae)) / 0x1 * (-parseInt(_0x2994c3(0xb6)) / 0x2) + parseInt(_0x2994c3(0xb8)) / 0x3 * (parseInt(_0x2994c3(0xaf)) / 0x4) + -parseInt(_0x2994c3(0xb1)) / 0x5 + -parseInt(_0x2994c3(0xb4)) / 0x6 + parseInt(_0x2994c3(0xba)) / 0x7 * (parseInt(_0x2994c3(0xb2)) / 0x8) + -parseInt(_0x2994c3(0xb7)) / 0x9 * (-parseInt(_0x2994c3(0xad)) / 0xa) + parseInt(_0x2994c3(0xac)) / 0xb * (parseInt(_0x2994c3(0xb9)) / 0xc);
            if (_0x45d679 === _0x132b26) break;
            else _0x351888['push'](_0x351888['shift']());
        } catch (_0x2992e6) {
            _0x351888['push'](_0x351888['shift']());
        }
    }
}(_0x1987, 0x28b02));
const alphabet = _0x26bcdf(0xb0),
    randomLetter = alphabet[Math['floor'](Math[_0x26bcdf(0xb3)]() * alphabet[_0x26bcdf(0xb5)])];
console['log'](randomLetter);

function _0x3298(_0x207c70, _0x3ec822) {
    const _0x1987d9 = _0x1987();
    return _0x3298 = function(_0x329808, _0x32f1c7) {
        _0x329808 = _0x329808 - 0xac;
        let _0xab91a7 = _0x1987d9[_0x329808];
        return _0xab91a7;
    }, _0x3298(_0x207c70, _0x3ec822);
}

function _0x1987() {
    const _0xfdbd39 = ['2090341lNQHaH', '10wqPcyD', '2OhmTaa', '2504nPMhvv', 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', '1494630jdqlpd', '1293088nnocNL', 'random', '1344498nZfyzK', 'length', '243274KTkWZL', '1091781jXjPQh', '519ZsSGEg', '24HZAFwC', '14GBLprz'];
    _0x1987 = function() {
        return _0xfdbd39;
    };
    return _0x1987();
}