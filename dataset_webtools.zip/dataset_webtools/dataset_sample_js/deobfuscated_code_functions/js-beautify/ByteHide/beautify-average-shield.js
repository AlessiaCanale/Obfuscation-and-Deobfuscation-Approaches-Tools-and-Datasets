/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x4654cb = _0x1122;

function _0x3316() {
    const _0x5832a1 = ['2499413yNWQrX', '14305InrIEO', '494052DZGPGO', '1076764eFOmMC', '568467Kqogne', 'length', 'log', 'reduce', '696QJfTJQ', '45549BTOoyg', '8QmAFQB', '728238KznPve'];
    _0x3316 = function() {
        return _0x5832a1;
    };
    return _0x3316();
}

function _0x1122(_0x2d0d30, _0x47e9df) {
    const _0x331610 = _0x3316();
    return _0x1122 = function(_0x1122be, _0x4469c6) {
        _0x1122be = _0x1122be - 0x1c6;
        let _0x5db969 = _0x331610[_0x1122be];
        return _0x5db969;
    }, _0x1122(_0x2d0d30, _0x47e9df);
}(function(_0x37ba2a, _0x29c575) {
    const _0x1cd3a6 = _0x1122,
        _0x134d64 = _0x37ba2a();
    while (!![]) {
        try {
            const _0x4fffc4 = -parseInt(_0x1cd3a6(0x1c9)) / 0x1 + parseInt(_0x1cd3a6(0x1ce)) / 0x2 + parseInt(_0x1cd3a6(0x1cb)) / 0x3 + -parseInt(_0x1cd3a6(0x1cf)) / 0x4 + -parseInt(_0x1cd3a6(0x1cd)) / 0x5 * (parseInt(_0x1cd3a6(0x1c8)) / 0x6) + parseInt(_0x1cd3a6(0x1cc)) / 0x7 + parseInt(_0x1cd3a6(0x1ca)) / 0x8 * (parseInt(_0x1cd3a6(0x1d0)) / 0x9);
            if (_0x4fffc4 === _0x29c575) break;
            else _0x134d64['push'](_0x134d64['shift']());
        } catch (_0x146bd6) {
            _0x134d64['push'](_0x134d64['shift']());
        }
    }
}(_0x3316, 0x404d2));
const average = _0x553a7f => _0x553a7f[_0x4654cb(0x1c7)]((_0x252789, _0x25c226) => _0x252789 + _0x25c226) / _0x553a7f[_0x4654cb(0x1d1)];
console[_0x4654cb(0x1c6)](average([0x15, 0x38, 0x17, 0x7a, 0x43]));