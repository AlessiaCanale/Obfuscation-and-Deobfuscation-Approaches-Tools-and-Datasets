/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x1596f1 = _0x297c;

function _0x2a9a() {
    const _0x2b43e4 = ['random', '115002TTPdmB', '4428048OtdFNq', '353268lUnxZz', '7936614znFkiO', 'Three', '22JmmILS', 'log', 'One', '14aECflx', '745572dRkcun', '160204Ybqtgm', '1599085UFuiqf'];
    _0x2a9a = function() {
        return _0x2b43e4;
    };
    return _0x2a9a();
}(function(_0x47609f, _0x1f5932) {
    const _0x34d003 = _0x297c,
        _0x22ea36 = _0x47609f();
    while (!![]) {
        try {
            const _0x41ae7a = -parseInt(_0x34d003(0xa8)) / 0x1 + -parseInt(_0x34d003(0xab)) / 0x2 * (-parseInt(_0x34d003(0xa6)) / 0x3) + -parseInt(_0x34d003(0xa3)) / 0x4 + -parseInt(_0x34d003(0xa4)) / 0x5 + -parseInt(_0x34d003(0xa2)) / 0x6 * (-parseInt(_0x34d003(0xa1)) / 0x7) + -parseInt(_0x34d003(0xa7)) / 0x8 + parseInt(_0x34d003(0xa9)) / 0x9;
            if (_0x41ae7a === _0x1f5932) break;
            else _0x22ea36['push'](_0x22ea36['shift']());
        } catch (_0x22716b) {
            _0x22ea36['push'](_0x22ea36['shift']());
        }
    }
}(_0x2a9a, 0x45ada));

function _0x297c(_0x1afaab, _0x156864) {
    const _0x2a9adc = _0x2a9a();
    return _0x297c = function(_0x297c55, _0x9ca814) {
        _0x297c55 = _0x297c55 - 0xa0;
        let _0x22c001 = _0x2a9adc[_0x297c55];
        return _0x22c001;
    }, _0x297c(_0x1afaab, _0x156864);
}
const array = [_0x1596f1(0xa0), 'Two', _0x1596f1(0xaa), 'Four', 'Five', 'Six'];
array['sort'](function() {
    const _0x49098c = _0x1596f1;
    return Math[_0x49098c(0xa5)]() - 0.5;
}), console[_0x1596f1(0xac)](array);