/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x4b6e(_0x47d903, _0x7c3eba) {
    const _0x35a427 = _0x35a4();
    return _0x4b6e = function(_0x4b6ea5, _0x33deba) {
        _0x4b6ea5 = _0x4b6ea5 - 0xf8;
        let _0x19b8ad = _0x35a427[_0x4b6ea5];
        return _0x19b8ad;
    }, _0x4b6e(_0x47d903, _0x7c3eba);
}

function _0x35a4() {
    const _0x108fc8 = ['228679lyiCRu', '10KlBjtw', 'Paul\x20Knulst', '108AmbBcV', 'log', '351995FnNfRL', '18027naXUly', '2yKOjQz', 'Male', '9092149DKQRKP', '2021-11-19', '4357295KYRkFB', '3592cIDhYG', '4IFToiD', '14997624VclHJX', '1608933gWFOag', 'Javascript\x20tips'];
    _0x35a4 = function() {
        return _0x108fc8;
    };
    return _0x35a4();
}
const _0x177932 = _0x4b6e;
(function(_0x11b42b, _0x3f39fc) {
    const _0x65fad5 = _0x4b6e,
        _0x3ae232 = _0x11b42b();
    while (!![]) {
        try {
            const _0x596816 = -parseInt(_0x65fad5(0x100)) / 0x1 + parseInt(_0x65fad5(0x107)) / 0x2 * (-parseInt(_0x65fad5(0xfe)) / 0x3) + -parseInt(_0x65fad5(0xfc)) / 0x4 * (parseInt(_0x65fad5(0xfa)) / 0x5) + -parseInt(_0x65fad5(0x103)) / 0x6 * (-parseInt(_0x65fad5(0x105)) / 0x7) + -parseInt(_0x65fad5(0xfb)) / 0x8 * (-parseInt(_0x65fad5(0x106)) / 0x9) + parseInt(_0x65fad5(0x101)) / 0xa * (-parseInt(_0x65fad5(0xf8)) / 0xb) + parseInt(_0x65fad5(0xfd)) / 0xc;
            if (_0x596816 === _0x3f39fc) break;
            else _0x3ae232['push'](_0x3ae232['shift']());
        } catch (_0x5c47f4) {
            _0x3ae232['push'](_0x3ae232['shift']());
        }
    }
}(_0x35a4, 0x905a7));
const user = {
        'name': _0x177932(0x102),
        'gender': _0x177932(0x108)
    },
    article = {
        'title': _0x177932(0xff),
        'date': _0x177932(0xf9)
    },
    summary = {
        ...user,
        ...article
    };
console[_0x177932(0x104)](summary);