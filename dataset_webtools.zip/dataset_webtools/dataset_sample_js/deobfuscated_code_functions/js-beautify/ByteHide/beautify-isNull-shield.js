/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x3bd867 = _0x5f1e;
(function(_0x541b57, _0x5def67) {
    const _0x3ebae5 = _0x5f1e,
        _0x588fb9 = _0x541b57();
    while (!![]) {
        try {
            const _0x14a397 = parseInt(_0x3ebae5(0x1df)) / 0x1 * (parseInt(_0x3ebae5(0x1d8)) / 0x2) + parseInt(_0x3ebae5(0x1d5)) / 0x3 * (-parseInt(_0x3ebae5(0x1d7)) / 0x4) + parseInt(_0x3ebae5(0x1dd)) / 0x5 * (parseInt(_0x3ebae5(0x1e0)) / 0x6) + -parseInt(_0x3ebae5(0x1d4)) / 0x7 * (-parseInt(_0x3ebae5(0x1d6)) / 0x8) + parseInt(_0x3ebae5(0x1d9)) / 0x9 + -parseInt(_0x3ebae5(0x1d3)) / 0xa * (parseInt(_0x3ebae5(0x1dc)) / 0xb) + -parseInt(_0x3ebae5(0x1db)) / 0xc;
            if (_0x14a397 === _0x5def67) break;
            else _0x588fb9['push'](_0x588fb9['shift']());
        } catch (_0x2d2529) {
            _0x588fb9['push'](_0x588fb9['shift']());
        }
    }
}(_0x1038, 0x2e721));

function _0x5f1e(_0x309013, _0x179199) {
    const _0x1038b7 = _0x1038();
    return _0x5f1e = function(_0x5f1e59, _0x4237d2) {
        _0x5f1e59 = _0x5f1e59 - 0x1d2;
        let _0xc3cf8b = _0x1038b7[_0x5f1e59];
        return _0xc3cf8b;
    }, _0x5f1e(_0x309013, _0x179199);
}
const isNull = _0x4d7fdc => _0x4d7fdc === null || _0x4d7fdc === undefined;

function _0x1038() {
    const _0x21bea8 = ['56NRWNnT', '106254doBKGf', '315776zbkmEI', '12bwZtAB', '111298YXkjdc', '1767708bGVUIO', 'log', '4250496zlXQJO', '1309rIhvKU', '200WCEneF', '123\x20is\x20null:\x20', '4YndjVg', '8790clJoGn', 'J\x20is\x20null:\x20', 'null\x20is\x20null:\x20', '11990GAqGgZ'];
    _0x1038 = function() {
        return _0x21bea8;
    };
    return _0x1038();
}
console[_0x3bd867(0x1da)](_0x3bd867(0x1d2) + isNull(null)), console[_0x3bd867(0x1da)]('\x20is\x20null:\x20' + isNull()), console[_0x3bd867(0x1da)](_0x3bd867(0x1de) + isNull(0x7b)), console[_0x3bd867(0x1da)](_0x3bd867(0x1e1) + isNull('J'));