/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0xe04da6 = _0x1da5;

function _0x1da5(_0x58d65a, _0x5d9ee0) {
    const _0x57799a = _0x5779();
    return _0x1da5 = function(_0x1da5b1, _0x3e9ee5) {
        _0x1da5b1 = _0x1da5b1 - 0x190;
        let _0xac86a = _0x57799a[_0x1da5b1];
        return _0xac86a;
    }, _0x1da5(_0x58d65a, _0x5d9ee0);
}(function(_0x3e601b, _0x41adca) {
    const _0x2be4c9 = _0x1da5,
        _0x2318a0 = _0x3e601b();
    while (!![]) {
        try {
            const _0x17423f = -parseInt(_0x2be4c9(0x198)) / 0x1 * (parseInt(_0x2be4c9(0x190)) / 0x2) + -parseInt(_0x2be4c9(0x197)) / 0x3 + -parseInt(_0x2be4c9(0x19b)) / 0x4 * (parseInt(_0x2be4c9(0x19c)) / 0x5) + parseInt(_0x2be4c9(0x199)) / 0x6 + parseInt(_0x2be4c9(0x196)) / 0x7 * (parseInt(_0x2be4c9(0x19d)) / 0x8) + parseInt(_0x2be4c9(0x193)) / 0x9 * (-parseInt(_0x2be4c9(0x191)) / 0xa) + parseInt(_0x2be4c9(0x195)) / 0xb;
            if (_0x17423f === _0x41adca) break;
            else _0x2318a0['push'](_0x2318a0['shift']());
        } catch (_0x42d1c5) {
            _0x2318a0['push'](_0x2318a0['shift']());
        }
    }
}(_0x5779, 0xa3e27));
const test = _0xe04da6(0x19a);

function _0x5779() {
    const _0x44cfd4 = ['Hey!,\x20this\x20is\x20Akashminds,\x20have\x20a\x20nice\x20day\x20ahead.', '8ynYqSn', '3087745hHurwV', '8rJpiiy', '1126TGvhRd', '10DfNYQv', 'substring', '3289212uQRfOY', 'substr\x20from\x200\x20to\x2030:\x20', '22438317FeSEOL', '5637408EVygYU', '1146903RCPXxy', '743KovREQ', '1363536MONNLa'];
    _0x5779 = function() {
        return _0x44cfd4;
    };
    return _0x5779();
}
console['log'](_0xe04da6(0x194) + test[_0xe04da6(0x192)](0x0, 0x1e));