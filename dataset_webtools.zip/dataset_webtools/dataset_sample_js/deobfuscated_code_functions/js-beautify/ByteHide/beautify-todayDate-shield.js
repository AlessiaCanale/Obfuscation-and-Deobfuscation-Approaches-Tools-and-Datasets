/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x1f8571 = _0xef23;
(function(_0x3230ca, _0x1a5a4c) {
    const _0x36ce75 = _0xef23,
        _0x563b81 = _0x3230ca();
    while (!![]) {
        try {
            const _0x4b9823 = -parseInt(_0x36ce75(0x159)) / 0x1 * (-parseInt(_0x36ce75(0x152)) / 0x2) + -parseInt(_0x36ce75(0x153)) / 0x3 * (-parseInt(_0x36ce75(0x156)) / 0x4) + -parseInt(_0x36ce75(0x150)) / 0x5 * (-parseInt(_0x36ce75(0x14f)) / 0x6) + -parseInt(_0x36ce75(0x154)) / 0x7 * (-parseInt(_0x36ce75(0x151)) / 0x8) + -parseInt(_0x36ce75(0x155)) / 0x9 + parseInt(_0x36ce75(0x14e)) / 0xa + -parseInt(_0x36ce75(0x158)) / 0xb;
            if (_0x4b9823 === _0x1a5a4c) break;
            else _0x563b81['push'](_0x563b81['shift']());
        } catch (_0x4b28ff) {
            _0x563b81['push'](_0x563b81['shift']());
        }
    }
}(_0xcae0, 0x8fef9));
const date = new Date();

function _0xef23(_0x9c544a, _0x4d5969) {
    const _0xcae0ed = _0xcae0();
    return _0xef23 = function(_0xef23a7, _0x17780b) {
        _0xef23a7 = _0xef23a7 - 0x14e;
        let _0x32460e = _0xcae0ed[_0xef23a7];
        return _0x32460e;
    }, _0xef23(_0x9c544a, _0x4d5969);
}

function _0xcae0() {
    const _0x230e53 = ['log', '15294037btVbdA', '167yQKRMX', 'today\x20is:\x20', '5934930yvCtln', '22998rBDYIt', '75DFcRvN', '15976EajsTJ', '13622AlOiBe', '3JzZdIa', '1974gTBWcN', '5144562QmaCWT', '799868QhvsWU'];
    _0xcae0 = function() {
        return _0x230e53;
    };
    return _0xcae0();
}
console[_0x1f8571(0x157)](_0x1f8571(0x15a) + date);