/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x48919f = _0x570e;
(function(_0x42288b, _0x79df1d) {
    const _0x22358d = _0x570e,
        _0x4cb172 = _0x42288b();
    while (!![]) {
        try {
            const _0x2ab094 = parseInt(_0x22358d(0x14a)) / 0x1 + parseInt(_0x22358d(0x13e)) / 0x2 * (-parseInt(_0x22358d(0x147)) / 0x3) + -parseInt(_0x22358d(0x146)) / 0x4 + parseInt(_0x22358d(0x13f)) / 0x5 + parseInt(_0x22358d(0x141)) / 0x6 * (-parseInt(_0x22358d(0x13d)) / 0x7) + -parseInt(_0x22358d(0x14c)) / 0x8 * (-parseInt(_0x22358d(0x142)) / 0x9) + parseInt(_0x22358d(0x144)) / 0xa;
            if (_0x2ab094 === _0x79df1d) break;
            else _0x4cb172['push'](_0x4cb172['shift']());
        } catch (_0x587b05) {
            _0x4cb172['push'](_0x4cb172['shift']());
        }
    }
}(_0x46e9, 0x52ffc));
const users = [{
    'firstname': _0x48919f(0x14d),
    'lastname': _0x48919f(0x14b)
}, {
    'firstname': _0x48919f(0x14e),
    'lastname': _0x48919f(0x140)
}, {
    'firstname': _0x48919f(0x143),
    'lastname': _0x48919f(0x140)
}];
users['map'](getFullName), console[_0x48919f(0x148)](_0x48919f(0x149) + users[_0x48919f(0x13c)](getFullName));

function _0x46e9() {
    const _0x51235e = ['full\x20name\x20is:\x20', '333747qDWqfV', 'kumar', '720896gtNfQV', 'Abhishek', 'jay', 'join', 'lastname', 'map', '7xggsiN', '18rAwzrw', '597900TjtTvS', 'sharma', '124608GowQHg', '18fjivbd', 'rupal', '1612120lAJJdj', 'firstname', '1061628fsnVKH', '56208xBxjOp', 'log'];
    _0x46e9 = function() {
        return _0x51235e;
    };
    return _0x46e9();
}

function _0x570e(_0x1ca586, _0x4b0072) {
    const _0x46e9de = _0x46e9();
    return _0x570e = function(_0x570e36, _0x2bd001) {
        _0x570e36 = _0x570e36 - 0x13c;
        let _0x2af8ea = _0x46e9de[_0x570e36];
        return _0x2af8ea;
    }, _0x570e(_0x1ca586, _0x4b0072);
}

function getFullName(_0x13393) {
    const _0xa30baa = _0x48919f;
    return [_0x13393[_0xa30baa(0x145)], _0x13393[_0xa30baa(0x150)]][_0xa30baa(0x14f)](',\x20');
}