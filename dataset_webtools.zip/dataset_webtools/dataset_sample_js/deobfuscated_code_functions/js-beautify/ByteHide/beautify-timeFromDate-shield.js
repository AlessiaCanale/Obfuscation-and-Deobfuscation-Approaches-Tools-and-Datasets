/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x2efe(_0x446f6a, _0x3edaf9) {
    const _0x59097c = _0x5909();
    return _0x2efe = function(_0x2efe75, _0x435725) {
        _0x2efe75 = _0x2efe75 - 0xd8;
        let _0x303879 = _0x59097c[_0x2efe75];
        return _0x303879;
    }, _0x2efe(_0x446f6a, _0x3edaf9);
}
const _0x12a411 = _0x2efe;

function _0x5909() {
    const _0x358226 = ['slice', '32wJoTpx', '8349648mChgkQ', 'log', '11513664XkrjqD', '7271430aJRzkK', '370pDGbiW', '5797475LxCFra', '731555kEPitN', '359703VfLPmH', '327RkgwSo', '7rNBuCQ', '5378szqwlG'];
    _0x5909 = function() {
        return _0x358226;
    };
    return _0x5909();
}(function(_0x43b248, _0x35a8b2) {
    const _0x366a7c = _0x2efe,
        _0x332b24 = _0x43b248();
    while (!![]) {
        try {
            const _0x3f603d = -parseInt(_0x366a7c(0xd8)) / 0x1 * (parseInt(_0x366a7c(0xda)) / 0x2) + -parseInt(_0x366a7c(0xe4)) / 0x3 * (parseInt(_0x366a7c(0xdc)) / 0x4) + parseInt(_0x366a7c(0xe2)) / 0x5 + parseInt(_0x366a7c(0xe0)) / 0x6 * (parseInt(_0x366a7c(0xd9)) / 0x7) + -parseInt(_0x366a7c(0xdd)) / 0x8 + -parseInt(_0x366a7c(0xdf)) / 0x9 + parseInt(_0x366a7c(0xe1)) / 0xa * (parseInt(_0x366a7c(0xe3)) / 0xb);
            if (_0x3f603d === _0x35a8b2) break;
            else _0x332b24['push'](_0x332b24['shift']());
        } catch (_0x595fd5) {
            _0x332b24['push'](_0x332b24['shift']());
        }
    }
}(_0x5909, 0xa3b6c));
const timeFromDate = _0x4abcfd => _0x4abcfd['toTimeString']()[_0x12a411(0xdb)](0x0, 0x8);
console[_0x12a411(0xde)](timeFromDate(new Date(0x7e5, 0x0, 0xa, 0x11, 0x1e, 0x0))), console['log'](timeFromDate(new Date()));