/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x1de7c6 = _0x5118;

function _0x5118(_0x4a0ba4, _0x14afa4) {
    const _0x47daa9 = _0x47da();
    return _0x5118 = function(_0x51181c, _0x216b0b) {
        _0x51181c = _0x51181c - 0x1b2;
        let _0x922bd7 = _0x47daa9[_0x51181c];
        return _0x922bd7;
    }, _0x5118(_0x4a0ba4, _0x14afa4);
}(function(_0x2eef35, _0x1a4966) {
    const _0x27aa33 = _0x5118,
        _0x460271 = _0x2eef35();
    while (!![]) {
        try {
            const _0x362d9c = parseInt(_0x27aa33(0x1b2)) / 0x1 * (parseInt(_0x27aa33(0x1b4)) / 0x2) + parseInt(_0x27aa33(0x1bd)) / 0x3 * (-parseInt(_0x27aa33(0x1bb)) / 0x4) + -parseInt(_0x27aa33(0x1b3)) / 0x5 * (-parseInt(_0x27aa33(0x1b5)) / 0x6) + -parseInt(_0x27aa33(0x1be)) / 0x7 + parseInt(_0x27aa33(0x1b8)) / 0x8 * (-parseInt(_0x27aa33(0x1b7)) / 0x9) + -parseInt(_0x27aa33(0x1ba)) / 0xa + parseInt(_0x27aa33(0x1b9)) / 0xb;
            if (_0x362d9c === _0x1a4966) break;
            else _0x460271['push'](_0x460271['shift']());
        } catch (_0x3d3cc9) {
            _0x460271['push'](_0x460271['shift']());
        }
    }
}(_0x47da, 0x8a823));
const randomBoolean = () => Math[_0x1de7c6(0x1b6)]() >= 0.5;
console[_0x1de7c6(0x1bc)](randomBoolean());

function _0x47da() {
    const _0x5537ff = ['1023794iVEWPg', '4352610zeKkHv', 'random', '144hPXuEc', '426952xPUeif', '5433351fyZlpc', '1268820JcgLRz', '4uHMWJY', 'log', '198192WsIFtA', '819644rQtfgX', '1ZxJNYo', '5mTXyjZ'];
    _0x47da = function() {
        return _0x5537ff;
    };
    return _0x47da();
}