/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x25b868 = _0x4f49;
(function(_0x8e8b39, _0x299608) {
    const _0x58e9e6 = _0x4f49,
        _0x3ebfa9 = _0x8e8b39();
    while (!![]) {
        try {
            const _0x5d13bf = -parseInt(_0x58e9e6(0xe5)) / 0x1 + parseInt(_0x58e9e6(0xeb)) / 0x2 + parseInt(_0x58e9e6(0xe2)) / 0x3 + -parseInt(_0x58e9e6(0xe4)) / 0x4 * (-parseInt(_0x58e9e6(0xe7)) / 0x5) + parseInt(_0x58e9e6(0xe1)) / 0x6 * (-parseInt(_0x58e9e6(0xec)) / 0x7) + -parseInt(_0x58e9e6(0xe6)) / 0x8 * (-parseInt(_0x58e9e6(0xe8)) / 0x9) + parseInt(_0x58e9e6(0xe3)) / 0xa * (-parseInt(_0x58e9e6(0xea)) / 0xb);
            if (_0x5d13bf === _0x299608) break;
            else _0x3ebfa9['push'](_0x3ebfa9['shift']());
        } catch (_0x71612) {
            _0x3ebfa9['push'](_0x3ebfa9['shift']());
        }
    }
}(_0x4377, 0xad38e));
const celsiusToFahrenheit = _0x86180e => _0x86180e * 0x9 / 0x5 + 0x20,
    fahrenheitToCelsius = _0x4e8607 => (_0x4e8607 - 0x20) * 0x5 / 0x9;
console[_0x25b868(0xe9)](celsiusToFahrenheit(0xf)), console['log'](celsiusToFahrenheit(0x0)), console[_0x25b868(0xe9)](celsiusToFahrenheit(-0x14)), console[_0x25b868(0xe9)](fahrenheitToCelsius(0x3b)), console[_0x25b868(0xe9)](fahrenheitToCelsius(0x20));

function _0x4f49(_0x1a7dad, _0x1c3656) {
    const _0x43773a = _0x4377();
    return _0x4f49 = function(_0x4f49f4, _0x352edc) {
        _0x4f49f4 = _0x4f49f4 - 0xe1;
        let _0x29d61e = _0x43773a[_0x4f49f4];
        return _0x29d61e;
    }, _0x4f49(_0x1a7dad, _0x1c3656);
}

function _0x4377() {
    const _0x423368 = ['6IDsRpY', '1290966LRvGxA', '30fBVAIj', '4KcYrYb', '20712UEtYRd', '5287496SMCLBS', '3775535ZSHobX', '9zvdPkv', 'log', '3804317iAMyAD', '990192ioCVac', '4015837kkteMc'];
    _0x4377 = function() {
        return _0x423368;
    };
    return _0x4377();
}