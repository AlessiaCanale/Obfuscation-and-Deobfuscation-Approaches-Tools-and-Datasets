/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x3779(_0x3388a0, _0x13996b) {
    const _0x5484d5 = _0x5484();
    return _0x3779 = function(_0x377984, _0x4e07a5) {
        _0x377984 = _0x377984 - 0x81;
        let _0x3da8c8 = _0x5484d5[_0x377984];
        return _0x3da8c8;
    }, _0x3779(_0x3388a0, _0x13996b);
}
const _0x26e40d = _0x3779;
(function(_0x3f6df5, _0x2a309f) {
    const _0x4aa5fd = _0x3779,
        _0x49355c = _0x3f6df5();
    while (!![]) {
        try {
            const _0x4662ab = -parseInt(_0x4aa5fd(0x88)) / 0x1 + -parseInt(_0x4aa5fd(0x81)) / 0x2 + parseInt(_0x4aa5fd(0x8a)) / 0x3 * (-parseInt(_0x4aa5fd(0x87)) / 0x4) + parseInt(_0x4aa5fd(0x8b)) / 0x5 + -parseInt(_0x4aa5fd(0x84)) / 0x6 + parseInt(_0x4aa5fd(0x8c)) / 0x7 * (parseInt(_0x4aa5fd(0x86)) / 0x8) + parseInt(_0x4aa5fd(0x89)) / 0x9;
            if (_0x4662ab === _0x2a309f) break;
            else _0x49355c['push'](_0x49355c['shift']());
        } catch (_0x18d9ad) {
            _0x49355c['push'](_0x49355c['shift']());
        }
    }
}(_0x5484, 0x2aef8));
const marks = [0x1e, 0x46, 0x62, 0x4d];

function _0x5484() {
    const _0x31f9b9 = ['marks:\x20', '8tUQVjh', '12396ZcyPbn', '318127iIZGCc', '7440579HiirLe', '195viwmhS', '754785XKDsYd', '57995dtKMKA', '277864BGdBXG', 'find', '\x0amarks\x20>\x2090:\x20', '909690ujnwwE'];
    _0x5484 = function() {
        return _0x31f9b9;
    };
    return _0x5484();
}
console['log'](_0x26e40d(0x85) + marks + _0x26e40d(0x83) + marks[_0x26e40d(0x82)](checkMarks));

function checkMarks(_0x1aa12a) {
    return _0x1aa12a > 0x5a;
}