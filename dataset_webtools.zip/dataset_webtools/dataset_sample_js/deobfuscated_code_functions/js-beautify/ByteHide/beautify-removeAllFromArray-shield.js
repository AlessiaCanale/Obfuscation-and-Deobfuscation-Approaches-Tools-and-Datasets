/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x2ee9() {
    const _0x5f4a8f = ['359843OFEDUS', 'log', 'Array\x20Length\x20after\x20remove\x20all\x20elements:\x20', '1790815uSvDYz', 'shift', '35NlQPUe', '4407767JcWBmm', '58744NuSEvE', '1428220fhGrhu', '83286voFPiM', 'splice', 'length', '2yDBkDz', 'filter', '8QxUwEH', '45FOBrtu', 'pop', '192196EQIlTq', '\x0aarray\x20length:\x20', '96uRMcUP', 'Original\x20array:\x20', '285hyBgtP'];
    _0x2ee9 = function() {
        return _0x5f4a8f;
    };
    return _0x2ee9();
}
const _0x1f2b07 = _0x411b;
(function(_0x5112db, _0x2d8f4e) {
    const _0x30ca92 = _0x411b,
        _0x8e0393 = _0x5112db();
    while (!![]) {
        try {
            const _0x18d508 = -parseInt(_0x30ca92(0x1e4)) / 0x1 * (parseInt(_0x30ca92(0x1df)) / 0x2) + parseInt(_0x30ca92(0x1e8)) / 0x3 * (-parseInt(_0x30ca92(0x1da)) / 0x4) + -parseInt(_0x30ca92(0x1d8)) / 0x5 * (parseInt(_0x30ca92(0x1dc)) / 0x6) + parseInt(_0x30ca92(0x1d9)) / 0x7 * (parseInt(_0x30ca92(0x1e1)) / 0x8) + -parseInt(_0x30ca92(0x1e2)) / 0x9 * (-parseInt(_0x30ca92(0x1db)) / 0xa) + parseInt(_0x30ca92(0x1e9)) / 0xb + -parseInt(_0x30ca92(0x1e6)) / 0xc * (-parseInt(_0x30ca92(0x1d6)) / 0xd);
            if (_0x18d508 === _0x2d8f4e) break;
            else _0x8e0393['push'](_0x8e0393['shift']());
        } catch (_0x543835) {
            _0x8e0393['push'](_0x8e0393['shift']());
        }
    }
}(_0x2ee9, 0xc1d9b));
let array = [_0x1f2b07(0x1e3), _0x1f2b07(0x1dd), _0x1f2b07(0x1e0), _0x1f2b07(0x1d7)];
console[_0x1f2b07(0x1ea)](_0x1f2b07(0x1e7) + array + _0x1f2b07(0x1e5) + array[_0x1f2b07(0x1de)]);

function _0x411b(_0x11684d, _0x470670) {
    const _0x2ee9b9 = _0x2ee9();
    return _0x411b = function(_0x411b6a, _0x26d681) {
        _0x411b6a = _0x411b6a - 0x1d6;
        let _0x5a0326 = _0x2ee9b9[_0x411b6a];
        return _0x5a0326;
    }, _0x411b(_0x11684d, _0x470670);
}
while (array[_0x1f2b07(0x1de)]) {
    array[_0x1f2b07(0x1e3)]();
}
console['log'](_0x1f2b07(0x1eb) + array[_0x1f2b07(0x1de)]);