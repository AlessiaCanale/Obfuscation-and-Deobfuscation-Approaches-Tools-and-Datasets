/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x1b29() {
    const _0x2f64bd = ['2830224lNGSox', '\x20power\x20of\x20', '439308YYVICL', '1XUEzhc', '1547064JHoqBp', '85kZuBxY', '27gTZDdY', '980744HXHzoy', 'log', '4285869ijYUBY', '219612uElkGX', '5037530UIdRCy'];
    _0x1b29 = function() {
        return _0x2f64bd;
    };
    return _0x1b29();
}
const _0x3e60e8 = _0x96ee;

function _0x96ee(_0x428f39, _0x257481) {
    const _0x1b2964 = _0x1b29();
    return _0x96ee = function(_0x96ee6e, _0x2bb4a6) {
        _0x96ee6e = _0x96ee6e - 0x146;
        let _0xc1d654 = _0x1b2964[_0x96ee6e];
        return _0xc1d654;
    }, _0x96ee(_0x428f39, _0x257481);
}(function(_0x25390b, _0x50bc31) {
    const _0x13c110 = _0x96ee,
        _0x30fba7 = _0x25390b();
    while (!![]) {
        try {
            const _0xbd6a0a = parseInt(_0x13c110(0x147)) / 0x1 * (-parseInt(_0x13c110(0x14b)) / 0x2) + parseInt(_0x13c110(0x146)) / 0x3 + parseInt(_0x13c110(0x150)) / 0x4 + parseInt(_0x13c110(0x149)) / 0x5 * (parseInt(_0x13c110(0x14e)) / 0x6) + parseInt(_0x13c110(0x14d)) / 0x7 + parseInt(_0x13c110(0x148)) / 0x8 * (-parseInt(_0x13c110(0x14a)) / 0x9) + -parseInt(_0x13c110(0x14f)) / 0xa;
            if (_0xbd6a0a === _0x50bc31) break;
            else _0x30fba7['push'](_0x30fba7['shift']());
        } catch (_0x4e6627) {
            _0x30fba7['push'](_0x30fba7['shift']());
        }
    }
}(_0x1b29, 0x7d8ab));
let n = 0x5,
    power = 0x3,
    num = 0x1;
for (let i = 0x0; i < power; ++i) {
    num = num * n;
}
console[_0x3e60e8(0x14c)](n + _0x3e60e8(0x151) + power + '\x20=\x20' + num);