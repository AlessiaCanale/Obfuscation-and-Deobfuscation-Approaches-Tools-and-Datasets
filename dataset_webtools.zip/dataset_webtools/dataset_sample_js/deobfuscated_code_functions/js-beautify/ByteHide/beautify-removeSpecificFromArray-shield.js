/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x1112fd = _0x159e;
(function(_0x1a6a6e, _0x4fc73a) {
    const _0x371fad = _0x159e,
        _0x4ddac0 = _0x1a6a6e();
    while (!![]) {
        try {
            const _0x1c6d24 = -parseInt(_0x371fad(0xac)) / 0x1 + -parseInt(_0x371fad(0xb0)) / 0x2 + parseInt(_0x371fad(0xa6)) / 0x3 * (parseInt(_0x371fad(0xa8)) / 0x4) + -parseInt(_0x371fad(0xaf)) / 0x5 + -parseInt(_0x371fad(0xad)) / 0x6 * (parseInt(_0x371fad(0xb3)) / 0x7) + parseInt(_0x371fad(0xab)) / 0x8 + parseInt(_0x371fad(0xa7)) / 0x9 * (parseInt(_0x371fad(0xaa)) / 0xa);
            if (_0x1c6d24 === _0x4fc73a) break;
            else _0x4ddac0['push'](_0x4ddac0['shift']());
        } catch (_0x45be65) {
            _0x4ddac0['push'](_0x4ddac0['shift']());
        }
    }
}(_0x231c, 0x92cd6));
let arr = [_0x1112fd(0xae), _0x1112fd(0xb1), 'filter', 'pop'];
console[_0x1112fd(0xa9)](_0x1112fd(0xb2) + arr);

function _0x231c() {
    const _0x43f51d = ['2615016WIkjLx', '668316vACmHe', '210DpPNPJ', 'shift', '1910785MTNwVg', '15790daChDT', 'splice', 'original\x20array:\x20', '75859iHMjsu', '1595781SJPwtf', '1180161zQKZiS', '4uXUvpy', 'log', '90LZXItJ'];
    _0x231c = function() {
        return _0x43f51d;
    };
    return _0x231c();
}

function _0x159e(_0x12514d, _0x2739b7) {
    const _0x231cb = _0x231c();
    return _0x159e = function(_0x159ebc, _0x254e05) {
        _0x159ebc = _0x159ebc - 0xa6;
        let _0x453397 = _0x231cb[_0x159ebc];
        return _0x453397;
    }, _0x159e(_0x12514d, _0x2739b7);
}
let spliced = arr[_0x1112fd(0xb1)](0x1, 0x1);
console[_0x1112fd(0xa9)]('Removed\x20element:\x20' + spliced), console[_0x1112fd(0xa9)]('Remaining\x20elements:\x20' + arr);