/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x10f9(_0x19cb14, _0x3609ac) {
    const _0x3ef985 = _0x3ef9();
    return _0x10f9 = function(_0x10f951, _0x4a04fe) {
        _0x10f951 = _0x10f951 - 0x12a;
        let _0x356d26 = _0x3ef985[_0x10f951];
        return _0x356d26;
    }, _0x10f9(_0x19cb14, _0x3609ac);
}
const _0x50f82f = _0x10f9;

function _0x3ef9() {
    const _0x1ee51e = ['7416730atTTDx', 'original:\x20', '12VYYEqZ', '75402OzTizv', '286718Klwcpz', '2568208KJhdKt', '3SdWxjK', '11pquIiv', '154205sIojQx', 'unshift', 'bread', 'eggs', '166874dWohWM', 'log', '1432468zKWCKu', '14lropiO'];
    _0x3ef9 = function() {
        return _0x1ee51e;
    };
    return _0x3ef9();
}(function(_0x177ba2, _0x5785c1) {
    const _0x4bb944 = _0x10f9,
        _0x1fed59 = _0x177ba2();
    while (!![]) {
        try {
            const _0x4cd2f6 = -parseInt(_0x4bb944(0x136)) / 0x1 + parseInt(_0x4bb944(0x12e)) / 0x2 * (-parseInt(_0x4bb944(0x138)) / 0x3) + -parseInt(_0x4bb944(0x130)) / 0x4 + parseInt(_0x4bb944(0x12a)) / 0x5 * (parseInt(_0x4bb944(0x134)) / 0x6) + -parseInt(_0x4bb944(0x131)) / 0x7 * (-parseInt(_0x4bb944(0x137)) / 0x8) + -parseInt(_0x4bb944(0x135)) / 0x9 + parseInt(_0x4bb944(0x132)) / 0xa * (parseInt(_0x4bb944(0x139)) / 0xb);
            if (_0x4cd2f6 === _0x5785c1) break;
            else _0x1fed59['push'](_0x1fed59['shift']());
        } catch (_0xf03528) {
            _0x1fed59['push'](_0x1fed59['shift']());
        }
    }
}(_0x3ef9, 0xad095));
const items = [_0x50f82f(0x12d), 'milk'];
console[_0x50f82f(0x12f)](_0x50f82f(0x133) + items), items[_0x50f82f(0x12b)](_0x50f82f(0x12c)), console[_0x50f82f(0x12f)]('unshifted:\x20' + items);