/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x530d19 = _0x29d8;
(function(_0x2082ad, _0x47e939) {
    const _0x58f034 = _0x29d8,
        _0x22ee97 = _0x2082ad();
    while (!![]) {
        try {
            const _0x2c57c8 = parseInt(_0x58f034(0x176)) / 0x1 * (-parseInt(_0x58f034(0x17f)) / 0x2) + -parseInt(_0x58f034(0x179)) / 0x3 + parseInt(_0x58f034(0x178)) / 0x4 + -parseInt(_0x58f034(0x17a)) / 0x5 * (parseInt(_0x58f034(0x175)) / 0x6) + -parseInt(_0x58f034(0x17c)) / 0x7 * (-parseInt(_0x58f034(0x174)) / 0x8) + parseInt(_0x58f034(0x172)) / 0x9 * (-parseInt(_0x58f034(0x177)) / 0xa) + parseInt(_0x58f034(0x171)) / 0xb;
            if (_0x2c57c8 === _0x47e939) break;
            else _0x22ee97['push'](_0x22ee97['shift']());
        } catch (_0x4750da) {
            _0x22ee97['push'](_0x22ee97['shift']());
        }
    }
}(_0x3e30, 0x6b3fc));
let arr = ['shift', _0x530d19(0x170), _0x530d19(0x180), _0x530d19(0x17b)];
console[_0x530d19(0x17d)]('original:\x20' + arr);

function _0x3e30() {
    const _0x2e9bce = ['112630DYbOKy', '187124WDPExC', '127473qEJPfk', '216115KmGuqB', 'pop', '18123Sxdbto', 'log', 'Remaining\x20elements:\x20', '629126fTpUdq', 'filter', 'splice', '17325715SVwSuI', '432NiTrSU', 'Removed\x20element:\x20', '856KXueXc', '78ANrzbx', '1EAFwrJ'];
    _0x3e30 = function() {
        return _0x2e9bce;
    };
    return _0x3e30();
}

function _0x29d8(_0x167d14, _0x229389) {
    const _0x3e3030 = _0x3e30();
    return _0x29d8 = function(_0x29d8b5, _0x2aa6f5) {
        _0x29d8b5 = _0x29d8b5 - 0x170;
        let _0x59aa65 = _0x3e3030[_0x29d8b5];
        return _0x59aa65;
    }, _0x29d8(_0x167d14, _0x229389);
}
let popped = arr[_0x530d19(0x17b)]();
console[_0x530d19(0x17d)](_0x530d19(0x173) + popped), console[_0x530d19(0x17d)](_0x530d19(0x17e) + arr), console[_0x530d19(0x17d)]('Array\x20length:\x20' + arr['length']);