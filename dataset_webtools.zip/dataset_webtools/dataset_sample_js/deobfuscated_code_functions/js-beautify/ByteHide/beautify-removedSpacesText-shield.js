/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

function _0x31b9(_0xa2b0dd, _0x1bfeb6) {
    const _0x4a98a7 = _0x4a98();
    return _0x31b9 = function(_0x31b910, _0x294c91) {
        _0x31b910 = _0x31b910 - 0x10e;
        let _0x2e31ef = _0x4a98a7[_0x31b910];
        return _0x2e31ef;
    }, _0x31b9(_0xa2b0dd, _0x1bfeb6);
}
const _0x5ab76d = _0x31b9;
(function(_0x3dd00c, _0x2fe999) {
    const _0x449b29 = _0x31b9,
        _0x4f3ade = _0x3dd00c();
    while (!![]) {
        try {
            const _0x389782 = -parseInt(_0x449b29(0x112)) / 0x1 + -parseInt(_0x449b29(0x113)) / 0x2 + parseInt(_0x449b29(0x115)) / 0x3 + parseInt(_0x449b29(0x117)) / 0x4 + parseInt(_0x449b29(0x111)) / 0x5 + -parseInt(_0x449b29(0x119)) / 0x6 * (-parseInt(_0x449b29(0x116)) / 0x7) + -parseInt(_0x449b29(0x110)) / 0x8;
            if (_0x389782 === _0x2fe999) break;
            else _0x4f3ade['push'](_0x4f3ade['shift']());
        } catch (_0x5c2cb5) {
            _0x4f3ade['push'](_0x4f3ade['shift']());
        }
    }
}(_0x4a98, 0x5ff08));
let originalText = 'Geeks\x20for\x20Geeks\x20Portal';
console[_0x5ab76d(0x10e)](_0x5ab76d(0x10f) + originalText);

function _0x4a98() {
    const _0x125a5d = ['2125791yczEdz', '22904QtWIrS', '3123564fdVsGX', 'split', '1074wXMvAr', 'log', 'original\x20text:\x20', '9082496vIntdp', '3007415KaRVAA', '586646QpoWBk', '1123466HwWbCw', 'join'];
    _0x4a98 = function() {
        return _0x125a5d;
    };
    return _0x4a98();
}
let removedSpacesText = originalText[_0x5ab76d(0x118)]('\x20')[_0x5ab76d(0x114)]('');
console[_0x5ab76d(0x10e)]('text\x20without\x20spaces:\x20' + removedSpacesText);