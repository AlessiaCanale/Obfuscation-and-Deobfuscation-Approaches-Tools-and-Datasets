/** 
 * This file has been protected with Shield for JavaScript.
 * Use it for free at https://www.bytehide.com/products/shield-obfuscator/javascript
 * Enhance the security of your applications and automate it with ByteHide's platform.
 */

const _0x952a89 = _0x197d;
(function(_0x3cb115, _0x13dd3a) {
    const _0x56cd46 = _0x197d,
        _0x57527a = _0x3cb115();
    while (!![]) {
        try {
            const _0x35d9b8 = -parseInt(_0x56cd46(0x1a8)) / 0x1 + parseInt(_0x56cd46(0x1a7)) / 0x2 * (parseInt(_0x56cd46(0x1aa)) / 0x3) + parseInt(_0x56cd46(0x1ad)) / 0x4 * (-parseInt(_0x56cd46(0x1a5)) / 0x5) + parseInt(_0x56cd46(0x1a6)) / 0x6 + parseInt(_0x56cd46(0x1b1)) / 0x7 * (-parseInt(_0x56cd46(0x1ac)) / 0x8) + -parseInt(_0x56cd46(0x1af)) / 0x9 * (-parseInt(_0x56cd46(0x1ae)) / 0xa) + -parseInt(_0x56cd46(0x1a4)) / 0xb * (-parseInt(_0x56cd46(0x1ab)) / 0xc);
            if (_0x35d9b8 === _0x13dd3a) break;
            else _0x57527a['push'](_0x57527a['shift']());
        } catch (_0x29a814) {
            _0x57527a['push'](_0x57527a['shift']());
        }
    }
}(_0x2e96, 0x7870d));
const isAppleDevice = /Mac|iPod|iPhone|iPad/ ['test'](navigator[_0x952a89(0x1a9)]);
console[_0x952a89(0x1b0)](isAppleDevice);

function _0x197d(_0x475843, _0x1ddffb) {
    const _0x2e96cd = _0x2e96();
    return _0x197d = function(_0x197dfb, _0x3cd422) {
        _0x197dfb = _0x197dfb - 0x1a4;
        let _0x30900f = _0x2e96cd[_0x197dfb];
        return _0x30900f;
    }, _0x197d(_0x475843, _0x1ddffb);
}

function _0x2e96() {
    const _0x500a80 = ['2108628AUazzF', '350cJJojc', '100773ytpMbp', 'log', '1820qZvxBj', '11OhGLei', '5kODdsH', '591234fGUJSC', '80pVxowi', '126513pVpzEj', 'platform', '20322NrPYgK', '6895452PFuDkx', '5816KhbUSO'];
    _0x2e96 = function() {
        return _0x500a80;
    };
    return _0x2e96();
}